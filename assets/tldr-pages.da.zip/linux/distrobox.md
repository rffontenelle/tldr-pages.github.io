# distrobox

> Denne kommando er et alias af `distrobox-create`.
> Mere information: <https://github.com/89luca89/distrobox>.

- Se dokumentation for den oprindelige kommando:

`tldr distrobox-create`
