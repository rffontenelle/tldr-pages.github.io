# cc

> Denne kommando er et alias af `gcc`.
> Mere information: <https://gcc.gnu.org>.

- Se dokumentation for den oprindelige kommando:

`tldr gcc`
