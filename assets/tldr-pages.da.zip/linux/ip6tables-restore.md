# ip6tables-restore

> Denne kommando er et alias af `iptables-restore`.

- Se dokumentation for den oprindelige kommando:

`tldr iptables-restore`
