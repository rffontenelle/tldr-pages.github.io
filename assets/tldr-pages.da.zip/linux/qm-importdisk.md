# qm-importdisk

> Denne kommando er et alias af `qm disk import`.

- Se dokumentation for den oprindelige kommando:

`tldr qm disk import`
