# nmtui-hostname

> Denne kommando er et alias af `nmtui`.

- Se dokumentation for den oprindelige kommando:

`tldr nmtui`
