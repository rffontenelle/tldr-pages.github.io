# ip6tables-save

> Denne kommando er et alias af `iptables-save`.

- Se dokumentation for den oprindelige kommando:

`tldr iptables-save`
