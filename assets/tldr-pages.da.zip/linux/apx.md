# apx

> Denne kommando er et alias af `apx pkgmanagers`.
> Mere information: <https://github.com/Vanilla-OS/apx>.

- Se dokumentation for den oprindelige kommando:

`tldr apx pkgmanagers`
