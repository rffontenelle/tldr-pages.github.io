# mount.smb3

> Denne kommando er et alias af `mount.cifs`.

- Se dokumentation for den oprindelige kommando:

`tldr mount.cifs`
