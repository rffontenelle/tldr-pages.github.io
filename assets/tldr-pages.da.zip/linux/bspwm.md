# bspwm

> Denne kommando er et alias af `bspc`.
> Mere information: <https://github.com/baskerville/bspwm>.

- Se dokumentation for den oprindelige kommando:

`tldr bspc`
