# cgroups

> Denne kommando er et alias af `cgclassify`.
> Mere information: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Se dokumentation for den oprindelige kommando:

`tldr cgclassify`
