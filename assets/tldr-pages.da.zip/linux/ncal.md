# ncal

> Denne kommando er et alias af `cal`.
> Mere information: <https://manned.org/ncal>.

- Se dokumentation for den oprindelige kommando:

`tldr cal`
