# batcat

> Denne kommando er et alias af `bat`.
> Mere information: <https://github.com/sharkdp/bat>.

- Se dokumentation for den oprindelige kommando:

`tldr bat`
