# pkgctl

> Denne kommando er et alias af `pkgctl auth`.
> Mere information: <https://man.archlinux.org/man/pkgctl.1>.

- Se dokumentation for den oprindelige kommando:

`tldr pkgctl auth`
