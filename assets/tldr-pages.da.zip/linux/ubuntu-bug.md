# ubuntu-bug

> Denne kommando er et alias af `apport-bug`.
> Mere information: <https://manned.org/ubuntu-bug>.

- Se dokumentation for den oprindelige kommando:

`tldr apport-bug`
