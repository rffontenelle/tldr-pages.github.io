# megadl

> Denne kommando er et alias af `megatools-dl`.
> Mere information: <https://megatools.megous.com/man/megatools-dl.html>.

- Se dokumentation for den oprindelige kommando:

`tldr megatools-dl`
