# alternatives

> Denne kommando er et alias af `update-alternatives`.
> Mere information: <https://manned.org/alternatives>.

- Se dokumentation for den oprindelige kommando:

`tldr update-alternatives`
