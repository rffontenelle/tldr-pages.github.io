# ip6tables

> Denne kommando er et alias af `iptables`.

- Se dokumentation for den oprindelige kommando:

`tldr iptables`
