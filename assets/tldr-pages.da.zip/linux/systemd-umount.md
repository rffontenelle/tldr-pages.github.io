# systemd-umount

> Denne kommando er et alias af `systemd-mount`.

- Se dokumentation for den oprindelige kommando:

`tldr systemd-mount`
