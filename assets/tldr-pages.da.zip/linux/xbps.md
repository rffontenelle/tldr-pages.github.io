# xbps

> Denne kommando er et alias af `xbps-install`.
> Mere information: <https://docs.voidlinux.org/xbps/index.html>.

- Se dokumentation for den oprindelige kommando:

`tldr xbps-install`
