# nmcli

> Denne kommando er et alias af `nmcli agent`.
> Mere information: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Se dokumentation for den oprindelige kommando:

`tldr nmcli agent`
