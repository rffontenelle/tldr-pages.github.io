# qm-move-disk

> Denne kommando er et alias af `qm-disk-move`.
> Mere information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Se dokumentation for den oprindelige kommando:

`tldr qm-disk-move`
