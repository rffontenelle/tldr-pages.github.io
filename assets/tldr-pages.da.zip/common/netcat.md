# netcat

> Denne kommando er et alias af `nc`.

- Se dokumentation for den oprindelige kommando:

`tldr nc`
