# clojure

> Denne kommando er et alias af `clj`.

- Se dokumentation for den oprindelige kommando:

`tldr clj`
