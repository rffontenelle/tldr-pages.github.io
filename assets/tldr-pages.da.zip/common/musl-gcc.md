# musl-gcc

> Denne kommando er et alias af `gcc`.
> Mere information: <https://manned.org/musl-gcc>.

- Se dokumentation for den oprindelige kommando:

`tldr gcc`
