# bundler

> Denne kommando er et alias af `bundle`.
> Mere information: <https://bundler.io/man/bundle.1.html>.

- Se dokumentation for den oprindelige kommando:

`tldr bundle`
