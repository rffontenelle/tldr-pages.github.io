# llvm-ar

> Denne kommando er et alias af `ar`.

- Se dokumentation for den oprindelige kommando:

`tldr ar`
