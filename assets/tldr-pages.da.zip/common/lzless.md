# lzless

> Denne kommando er et alias af `xzless`.

- Se dokumentation for den oprindelige kommando:

`tldr xzless`
