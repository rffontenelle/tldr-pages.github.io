# platformio

> Denne kommando er et alias af `pio`.
> Mere information: <https://docs.platformio.org/en/latest/core/userguide/>.

- Se dokumentation for den oprindelige kommando:

`tldr pio`
