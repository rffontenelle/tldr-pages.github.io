# tlmgr arch

> Denne kommando er et alias af `tlmgr platform`.
> Mere information: <https://www.tug.org/texlive/tlmgr.html>.

- Se dokumentation for den oprindelige kommando:

`tldr tlmgr platform`
