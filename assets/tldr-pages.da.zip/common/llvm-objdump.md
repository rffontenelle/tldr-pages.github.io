# llvm-objdump

> Denne kommando er et alias af `objdump`.

- Se dokumentation for den oprindelige kommando:

`tldr objdump`
