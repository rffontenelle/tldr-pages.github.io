# gh cs

> Denne kommando er et alias af  `gh codespace`.
> Mere information: <https://cli.github.com/manual/gh_codespace>.

- Se dokumentation for den oprindelige kommando:

`tldr gh-codespace`
