# xzfgrep

> Denne kommando er et alias af `xzgrep`.

- Se dokumentation for den oprindelige kommando:

`tldr xzgrep`
