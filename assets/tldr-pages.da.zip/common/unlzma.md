# unlzma

> Denne kommando er et alias af `xz`.
> Mere information: <https://manned.org/unlzma>.

- Se dokumentation for den oprindelige kommando:

`tldr xz`
