# lima

> Denne kommando er et alias af `limactl`.
> Mere information: <https://github.com/lima-vm/lima>.

- Se dokumentation for den oprindelige kommando:

`tldr limactl`
