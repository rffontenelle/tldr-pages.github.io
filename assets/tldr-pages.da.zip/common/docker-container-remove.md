# docker-container-remove

> Denne kommando er et alias af `docker rm`.
> Mere information: <https://docs.docker.com/engine/reference/commandline/rm>.

- Se dokumentation for den oprindelige kommando:

`tldr docker rm`
