# nm-classic

> Denne kommando er et alias af `nm`.

- Se dokumentation for den oprindelige kommando:

`tldr nm`
