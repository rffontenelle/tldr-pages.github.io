# rcat

> Denne kommando er et alias af `rc`.

- Se dokumentation for den oprindelige kommando:

`tldr rc`
