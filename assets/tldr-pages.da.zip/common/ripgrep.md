# ripgrep

> Denne kommando er et alias af `rg`.

- Se dokumentation for den oprindelige kommando:

`tldr rg`
