# tldrl

> Denne kommando er et alias af `tldr-lint`.
> Mere information: <https://github.com/tldr-pages/tldr-lint>.

- Se dokumentation for den oprindelige kommando:

`tldr tldr-lint`
