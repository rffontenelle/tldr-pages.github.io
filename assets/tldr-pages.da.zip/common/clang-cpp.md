# clang-cpp

> Denne kommando er et alias af `clang++`.

- Se dokumentation for den oprindelige kommando:

`tldr clang++`
