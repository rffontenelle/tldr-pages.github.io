# w

> Vis hvem der er logget ind og hvad de laver.
> Print bruger login, TTY, fjernforbundet vært, login-tidspunkt, inaktiv tid, nuværende proces.
> Mere information: <https://manned.org/w>.

- Vis info på brugere der er logget ind:

`w`

- Vis info på brugere der er logget ind, uden overskrifter:

`w -h`
