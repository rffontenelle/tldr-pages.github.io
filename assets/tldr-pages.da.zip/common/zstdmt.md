# zstdmt

> Denne kommando er et alias af `zstd`.

- Se dokumentation for den oprindelige kommando:

`tldr zstd`
