# cola

> Denne kommando er et alias af `git-cola`.

- Se dokumentation for den oprindelige kommando:

`tldr git-cola`
