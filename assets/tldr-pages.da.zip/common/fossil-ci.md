# fossil-ci

> Denne kommando er et alias af `fossil-commit`.
> Mere information: <https://fossil-scm.org/home/help/commit>.

- Se dokumentation for den oprindelige kommando:

`tldr fossil-commit`
