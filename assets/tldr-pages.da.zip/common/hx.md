# hx

> Denne kommando er et alias af `helix`.

- Se dokumentation for den oprindelige kommando:

`tldr helix`
