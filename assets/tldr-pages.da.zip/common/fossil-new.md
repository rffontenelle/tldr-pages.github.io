# fossil-new

> Denne kommando er et alias af `fossil-init`.
> Mere information: <https://fossil-scm.org/home/help/new>.

- Se dokumentation for den oprindelige kommando:

`tldr fossil-init`
