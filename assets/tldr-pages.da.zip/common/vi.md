# vi

> Denne kommando er et alias af `vim`.

- Se dokumentation for den oprindelige kommando:

`tldr vim`
