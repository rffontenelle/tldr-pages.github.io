# transmission

> Denne kommando er et alias af `transmission-daemon`.
> Mere information: <https://transmissionbt.com/>.

- Se dokumentation for den oprindelige kommando:

`tldr transmission-daemon`
