# pio-init

> Denne kommando er et alias af `pio project`.

- Se dokumentation for den oprindelige kommando:

`tldr pio project`
