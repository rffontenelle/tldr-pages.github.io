# where

> Returnerer alle kendte instanser for en kommando.
> Eksempelvis en eksekverbar fil i PATH-miljøvariablen, et alias, eller en indbygget shellkomando.
> Mere information: <https://zsh.sourceforge.io/Doc/Release/Shell-Builtin-Commands.html>.

- Find all instanser for en kommando:

`where {{kommando}}`
