# todoman

> Denne kommando er et alias af `todo`.
> Mere information: <https://todoman.readthedocs.io/>.

- Se dokumentation for den oprindelige kommando:

`tldr todo`
