# lzcmp

> Denne kommando er et alias af `xzcmp`.

- Se dokumentation for den oprindelige kommando:

`tldr xzcmp`
