# python3

> Denne kommando er et alias af `python`.

- Se dokumentation for den oprindelige kommando:

`tldr python`
