# azure-cli

> Denne kommando er et alias af `az`.
> Mere information: <https://learn.microsoft.com/cli/azure>.

- Se dokumentation for den oprindelige kommando:

`tldr az`
