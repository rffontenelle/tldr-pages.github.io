# lzcat

> Denne kommando er et alias af `xz`.
> Mere information: <https://manned.org/lzcat>.

- Se dokumentation for den oprindelige kommando:

`tldr xz`
