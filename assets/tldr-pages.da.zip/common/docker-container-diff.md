# docker-container-diff

> Denne kommando er et alias af `docker diff`.
> Mere information: <https://docs.docker.com/engine/reference/commandline/diff>.

- Se dokumentation for den oprindelige kommando:

`tldr docker diff`
