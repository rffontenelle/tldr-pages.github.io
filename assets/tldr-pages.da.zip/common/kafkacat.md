# kafkacat

> Denne kommando er et alias af `kcat`.

- Se dokumentation for den oprindelige kommando:

`tldr kcat`
