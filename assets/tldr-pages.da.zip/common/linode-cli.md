# linode-cli

> Denne kommando er et alias af `linode-cli account`.
> Mere information: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Se dokumentation for den oprindelige kommando:

`tldr linode-cli account`
