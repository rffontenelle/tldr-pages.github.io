# ntl

> Denne kommando er et alias af `netlify`.
> Mere information: <https://cli.netlify.com>.

- Se dokumentation for den oprindelige kommando:

`tldr netlify`
