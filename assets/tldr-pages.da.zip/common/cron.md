# cron

> Denne kommando er et alias af `crontab`.

- Se dokumentation for den oprindelige kommando:

`tldr crontab`
