# ptpython3

> Denne kommando er et alias af `ptpython`.

- Se dokumentation for den oprindelige kommando:

`tldr ptpython`
