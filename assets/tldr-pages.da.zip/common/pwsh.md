# pwsh

> Denne kommando er et alias af `powershell`.

- Se dokumentation for den oprindelige kommando:

`tldr powershell`
