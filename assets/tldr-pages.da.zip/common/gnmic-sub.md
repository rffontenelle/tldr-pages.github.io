# gnmic-sub

> Denne kommando er et alias af `gnmic subscribe`.
> Mere information: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Se dokumentation for den oprindelige kommando:

`tldr gnmic subscribe`
