# lzmore

> Denne kommando er et alias af `xzmore`.

- Se dokumentation for den oprindelige kommando:

`tldr xzmore`
