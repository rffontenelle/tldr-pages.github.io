# lzma

> Denne kommando er et alias af `xz`.
> Mere information: <https://manned.org/lzma>.

- Se dokumentation for den oprindelige kommando:

`tldr xz`
