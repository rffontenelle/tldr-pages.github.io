# just

> Denne kommando er et alias af `just.1`.

- Se dokumentation for den oprindelige kommando:

`tldr just.1`
