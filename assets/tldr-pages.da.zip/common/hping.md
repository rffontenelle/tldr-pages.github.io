# hping

> Denne kommando er et alias af `hping3`.
> Mere information: <https://github.com/antirez/hping>.

- Se dokumentation for den oprindelige kommando:

`tldr hping3`
