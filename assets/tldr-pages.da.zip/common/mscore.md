# mscore

> Denne kommando er et alias af `musescore`.
> Mere information: <https://musescore.org/handbook/command-line-options>.

- Se dokumentation for den oprindelige kommando:

`tldr musescore`
