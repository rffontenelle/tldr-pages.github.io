# open

> Denne kommando er et alias af `open -p osx`.

- Se dokumentation for den oprindelige kommando:

`tldr open -p osx`
