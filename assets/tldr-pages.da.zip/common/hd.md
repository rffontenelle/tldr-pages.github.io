# hd

> Denne kommando er et alias af `hexdump`.
> Mere information: <https://manned.org/hd.1>.

- Se dokumentation for den oprindelige kommando:

`tldr hexdump`
