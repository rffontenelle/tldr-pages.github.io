# unxz

> Denne kommando er et alias af `xz`.
> Mere information: <https://manned.org/unxz>.

- Se dokumentation for den oprindelige kommando:

`tldr xz`
