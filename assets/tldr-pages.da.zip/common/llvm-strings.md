# llvm-strings

> Denne kommando er et alias af `strings`.

- Se dokumentation for den oprindelige kommando:

`tldr strings`
