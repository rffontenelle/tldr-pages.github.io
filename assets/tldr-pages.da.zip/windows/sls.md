# sls

> Denne kommando er et alias af `where-object`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Se dokumentation for den oprindelige kommando:

`tldr where-object`
