# del

> Denne kommando er et alias af `remove-item`.
> Mere information: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Se dokumentation for den oprindelige kommando:

`tldr remove-item`
