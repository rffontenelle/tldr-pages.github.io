# chdir

> Denne kommando er et alias af `cd`.
> Mere information: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Se dokumentation for den oprindelige kommando:

`tldr cd`
