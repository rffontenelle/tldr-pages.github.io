# sl

> Denne kommando er et alias af `set-location`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Se dokumentation for den oprindelige kommando:

`tldr set-location`
