# wget

> Denne kommando er et alias af `wget -p common`.
> Mere information: <https://www.gnu.org/software/wget>.

- Se dokumentation for den oprindelige kommando:

`tldr wget -p common`
