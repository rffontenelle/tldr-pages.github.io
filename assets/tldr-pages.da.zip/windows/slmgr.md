# slmgr

> Denne kommando er et alias af `slmgr.vbs`.
> Mere information: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Se dokumentation for den oprindelige kommando:

`tldr slmgr.vbs`
