# curl

> Denne kommando er et alias af `curl -p common`.
> Mere information: <https://curl.se>.

- Se dokumentation for den oprindelige kommando:

`tldr curl -p common`
