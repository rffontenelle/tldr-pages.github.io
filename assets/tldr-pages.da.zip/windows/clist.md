# clist

> Denne kommando er et alias af `choco list`.
> Mere information: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Se dokumentation for den oprindelige kommando:

`tldr choco list`
