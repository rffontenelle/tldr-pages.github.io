# cpush

> Denne kommando er et alias af `choco-push`.
> Mere information: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Se dokumentation for den oprindelige kommando:

`tldr choco-push`
