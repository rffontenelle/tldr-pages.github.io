# clear

> Denne kommando er et alias af `clear-host`.

- Se dokumentation for den oprindelige kommando:

`tldr clear-host`
