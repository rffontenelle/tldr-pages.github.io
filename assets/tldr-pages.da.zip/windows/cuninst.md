# cuninst

> Denne kommando er et alias af `choco uninstall`.
> Mere information: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Se dokumentation for den oprindelige kommando:

`tldr choco uninstall`
