# cls

> Denne kommando er et alias af `clear-host`.
> Mere information: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Se dokumentation for den oprindelige kommando:

`tldr clear-host`
