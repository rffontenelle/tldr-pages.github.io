# rmdir

> Denne kommando er et alias af `remove-item`.
> Mere information: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Se dokumentation for den oprindelige kommando:

`tldr remove-item`
