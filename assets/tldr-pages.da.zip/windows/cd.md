# cd

> Denne kommando er et alias af `set-location`.
> Mere information: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Se dokumentation for den oprindelige kommando:

`tldr set-location`
