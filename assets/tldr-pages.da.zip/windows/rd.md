# rd

> Denne kommando er et alias af `rmdir`.
> Mere information: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Se dokumentation for den oprindelige kommando:

`tldr rmdir`
