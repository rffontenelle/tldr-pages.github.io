# rm

> Denne kommando er et alias af `remove-item`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Se dokumentation for den oprindelige kommando:

`tldr remove-item`
