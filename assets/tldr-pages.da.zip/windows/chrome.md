# chrome

> Denne kommando er et alias af `chromium`.
> Mere information: <https://chrome.google.com>.

- Se dokumentation for den oprindelige kommando:

`tldr chromium`
