# iwr

> Denne kommando er et alias af `invoke-webrequest`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Se dokumentation for den oprindelige kommando:

`tldr invoke-webrequest`
