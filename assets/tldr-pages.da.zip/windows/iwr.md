# iwr

> Denne kommando er et alias af `invoke-webrequest`.

- Se dokumentation for den oprindelige kommando:

`tldr invoke-webrequest`
