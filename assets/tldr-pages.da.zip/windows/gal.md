# gal

> Denne kommando er et alias af `get-alias`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Se dokumentation for den oprindelige kommando:

`tldr get-alias`
