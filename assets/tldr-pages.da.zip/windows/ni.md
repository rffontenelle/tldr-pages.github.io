# ni

> Denne kommando er et alias af `new-item`.
> Mere information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Se dokumentation for den oprindelige kommando:

`tldr new-item`
