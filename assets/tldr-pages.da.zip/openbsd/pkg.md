# pkg

> Denne kommando er et alias af `pkg_add`.
> Mere information: <https://www.openbsd.org/faq/faq15.html>.

- Se dokumentation for den oprindelige kommando:

`tldr pkg_add`
