# guname

> Denne kommando er et alias af `-p linux uname`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux uname`
