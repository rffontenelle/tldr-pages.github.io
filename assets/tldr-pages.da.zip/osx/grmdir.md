# grmdir

> Denne kommando er et alias af `-p linux rmdir`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux rmdir`
