# gunexpand

> Denne kommando er et alias af `-p linux unexpand`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux unexpand`
