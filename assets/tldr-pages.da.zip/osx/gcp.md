# gcp

> Denne kommando er et alias af `-p linux cp`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux cp`
