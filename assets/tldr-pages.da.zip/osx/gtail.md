# gtail

> Denne kommando er et alias af `-p linux tail`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux tail`
