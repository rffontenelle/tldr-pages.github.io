# gdd

> Denne kommando er et alias af `-p linux dd`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux dd`
