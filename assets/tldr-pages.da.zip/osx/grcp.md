# grcp

> Denne kommando er et alias af `-p linux rcp`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux rcp`
