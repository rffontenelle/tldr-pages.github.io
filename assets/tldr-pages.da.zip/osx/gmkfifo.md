# gmkfifo

> Denne kommando er et alias af `-p linux mkfifo`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux mkfifo`
