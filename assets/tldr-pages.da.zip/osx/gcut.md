# gcut

> Denne kommando er et alias af `-p linux cut`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux cut`
