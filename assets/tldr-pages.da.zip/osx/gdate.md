# gdate

> Denne kommando er et alias af `-p linux date`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux date`
