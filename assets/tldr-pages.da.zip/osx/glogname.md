# glogname

> Denne kommando er et alias af `-p linux logname`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux logname`
