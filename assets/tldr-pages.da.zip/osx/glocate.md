# glocate

> Denne kommando er et alias af `-p linux locate`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux locate`
