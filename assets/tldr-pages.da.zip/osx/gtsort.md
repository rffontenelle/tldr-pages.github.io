# gtsort

> Denne kommando er et alias af `-p linux tsort`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux tsort`
