# gftp

> Denne kommando er et alias af `-p linux ftp`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux ftp`
