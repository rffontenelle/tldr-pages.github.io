# ghead

> Denne kommando er et alias af `-p linux head`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux head`
