# gshuf

> Denne kommando er et alias af `-p linux shuf`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux shuf`
