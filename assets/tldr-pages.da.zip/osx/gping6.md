# gping6

> Denne kommando er et alias af `-p linux ping6`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux ping6`
