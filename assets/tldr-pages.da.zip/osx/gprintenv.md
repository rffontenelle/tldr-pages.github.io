# gprintenv

> Denne kommando er et alias af `-p linux printenv`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux printenv`
