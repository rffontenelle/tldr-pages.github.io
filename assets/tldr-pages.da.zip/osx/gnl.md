# gnl

> Denne kommando er et alias af `-p linux nl`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux nl`
