# gpaste

> Denne kommando er et alias af `-p linux paste`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux paste`
