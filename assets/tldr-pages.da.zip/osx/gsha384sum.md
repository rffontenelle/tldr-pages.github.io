# gsha384sum

> Denne kommando er et alias af `-p linux sha384sum`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux sha384sum`
