# gcomm

> Denne kommando er et alias af `-p linux comm`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux comm`
