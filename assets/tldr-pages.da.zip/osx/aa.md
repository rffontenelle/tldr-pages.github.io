# aa

> Denne kommando er et alias af `yaa`.

- Se dokumentation for den oprindelige kommando:

`tldr yaa`
