# gid

> Denne kommando er et alias af `-p linux id`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux id`
