# gfalse

> Denne kommando er et alias af `-p linux false`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux false`
