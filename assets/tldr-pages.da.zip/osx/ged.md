# ged

> Denne kommando er et alias af `-p linux ed`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux ed`
