# gsync

> Denne kommando er et alias af `-p linux sync`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux sync`
