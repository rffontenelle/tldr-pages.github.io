# glink

> Denne kommando er et alias af `-p linux link`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux link`
