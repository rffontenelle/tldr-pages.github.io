# gbasenc

> Denne kommando er et alias af `-p linux basenc`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux basenc`
