# gawk

> Denne kommando er et alias af `-p linux awk`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux awk`
