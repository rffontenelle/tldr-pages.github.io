# gmake

> Denne kommando er et alias af `-p linux make`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux make`
