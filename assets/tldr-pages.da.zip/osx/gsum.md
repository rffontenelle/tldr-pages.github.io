# gsum

> Denne kommando er et alias af `-p linux sum`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux sum`
