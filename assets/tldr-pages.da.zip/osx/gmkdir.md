# gmkdir

> Denne kommando er et alias af `-p linux mkdir`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux mkdir`
