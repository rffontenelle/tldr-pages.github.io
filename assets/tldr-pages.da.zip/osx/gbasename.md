# gbasename

> Denne kommando er et alias af `-p linux basename`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux basename`
