# gtee

> Denne kommando er et alias af `-p linux tee`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux tee`
