# gruncon

> Denne kommando er et alias af `-p linux runcon`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux runcon`
