# gtar

> Denne kommando er et alias af `-p linux tar`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux tar`
