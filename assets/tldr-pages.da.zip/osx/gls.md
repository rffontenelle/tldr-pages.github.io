# gls

> Denne kommando er et alias af `-p linux ls`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux ls`
