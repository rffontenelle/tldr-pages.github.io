# gstat

> Denne kommando er et alias af `-p linux stat`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux stat`
