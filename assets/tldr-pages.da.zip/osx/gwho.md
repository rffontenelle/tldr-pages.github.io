# gwho

> Denne kommando er et alias af `-p linux who`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux who`
