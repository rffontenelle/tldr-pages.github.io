# gfold

> Denne kommando er et alias af `-p linux fold`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux fold`
