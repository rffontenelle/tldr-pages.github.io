# gdircolors

> Denne kommando er et alias af `-p linux dircolors`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux dircolors`
