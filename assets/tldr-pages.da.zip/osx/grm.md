# grm

> Denne kommando er et alias af `-p linux rm`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux rm`
