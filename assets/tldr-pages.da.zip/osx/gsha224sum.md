# gsha224sum

> Denne kommando er et alias af `-p linux sha224sum`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux sha224sum`
