# gecho

> Denne kommando er et alias af `-p linux echo`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux echo`
