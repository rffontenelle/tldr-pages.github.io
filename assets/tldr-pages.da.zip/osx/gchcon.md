# gchcon

> Denne kommando er et alias af `-p linux chcon`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux chcon`
