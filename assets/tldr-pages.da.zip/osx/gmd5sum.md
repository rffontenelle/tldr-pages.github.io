# gmd5sum

> Denne kommando er et alias af `-p linux md5sum`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux md5sum`
