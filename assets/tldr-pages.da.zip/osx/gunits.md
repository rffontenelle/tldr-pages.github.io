# gunits

> Denne kommando er et alias af `-p linux units`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux units`
