# grsh

> Denne kommando er et alias af `-p linux rsh`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux rsh`
