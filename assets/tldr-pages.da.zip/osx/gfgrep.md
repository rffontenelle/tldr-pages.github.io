# gfgrep

> Denne kommando er et alias af `-p linux fgrep`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux fgrep`
