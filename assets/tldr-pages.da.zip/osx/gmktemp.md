# gmktemp

> Denne kommando er et alias af `-p linux mktemp`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux mktemp`
