# gbase32

> Denne kommando er et alias af `-p linux base32`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux base32`
