# gchroot

> Denne kommando er et alias af `-p linux chroot`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux chroot`
