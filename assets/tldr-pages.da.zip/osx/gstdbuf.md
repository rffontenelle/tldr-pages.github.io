# gstdbuf

> Denne kommando er et alias af `-p linux stdbuf`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux stdbuf`
