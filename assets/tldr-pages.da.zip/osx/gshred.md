# gshred

> Denne kommando er et alias af `-p linux shred`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux shred`
