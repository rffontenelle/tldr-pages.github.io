# gdirname

> Denne kommando er et alias af `-p linux dirname`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux dirname`
