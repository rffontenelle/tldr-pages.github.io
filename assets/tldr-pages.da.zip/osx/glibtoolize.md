# glibtoolize

> Denne kommando er et alias af `-p linux libtoolize`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux libtoolize`
