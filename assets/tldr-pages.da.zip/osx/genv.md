# genv

> Denne kommando er et alias af `-p linux env`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux env`
