# god

> Denne kommando er et alias af `-p linux od`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux od`
