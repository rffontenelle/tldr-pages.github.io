# launchd

> Denne kommando er et alias af `launchctl`.
> Mere information: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Se dokumentation for den oprindelige kommando:

`tldr launchctl`
