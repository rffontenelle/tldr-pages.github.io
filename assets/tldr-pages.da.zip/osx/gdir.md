# gdir

> Denne kommando er et alias af `-p linux dir`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux dir`
