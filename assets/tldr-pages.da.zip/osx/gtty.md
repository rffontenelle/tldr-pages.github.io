# gtty

> Denne kommando er et alias af `-p linux tty`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux tty`
