# gwhich

> Denne kommando er et alias af `-p linux which`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux which`
