# gtrue

> Denne kommando er et alias af `-p linux true`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux true`
