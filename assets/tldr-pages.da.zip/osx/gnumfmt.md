# gnumfmt

> Denne kommando er et alias af `-p linux numfmt`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux numfmt`
