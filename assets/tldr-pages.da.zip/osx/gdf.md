# gdf

> Denne kommando er et alias af `-p linux df`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux df`
