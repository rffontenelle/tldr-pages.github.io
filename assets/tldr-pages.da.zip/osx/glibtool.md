# glibtool

> Denne kommando er et alias af `-p linux libtool`.

- Se dokumentation for den oprindelige kommando:

`tldr -p linux libtool`
