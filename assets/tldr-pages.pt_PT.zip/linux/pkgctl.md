# pkgctl

> Este comando é um alias de `pkgctl auth`.
> Mais informações: <https://man.archlinux.org/man/pkgctl.1>.

- Ver documentação do comando original:

`tldr pkgctl auth`
