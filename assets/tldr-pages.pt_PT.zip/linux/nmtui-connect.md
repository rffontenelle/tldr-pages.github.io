# nmtui-connect

> Este comando é um alias de `nmtui`.

- Ver documentação do comando original:

`tldr nmtui`
