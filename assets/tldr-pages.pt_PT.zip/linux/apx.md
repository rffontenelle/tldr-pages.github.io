# apx

> Este comando é um alias de `apx pkgmanagers`.
> Mais informações: <https://github.com/Vanilla-OS/apx>.

- Ver documentação do comando original:

`tldr apx pkgmanagers`
