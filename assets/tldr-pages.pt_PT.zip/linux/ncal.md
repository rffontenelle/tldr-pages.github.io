# ncal

> Este comando é um alias de `cal`.
> Mais informações: <https://manned.org/ncal>.

- Ver documentação do comando original:

`tldr cal`
