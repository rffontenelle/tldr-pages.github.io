# alternatives

> Este comando é um alias de `update-alternatives`.
> Mais informações: <https://manned.org/alternatives>.

- Exibe documentação do comando original:

`tldr update-alternatives`
