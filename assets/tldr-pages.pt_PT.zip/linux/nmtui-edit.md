# nmtui-edit

> Este comando é um alias de `nmtui`.

- Ver documentação do comando original:

`tldr nmtui`
