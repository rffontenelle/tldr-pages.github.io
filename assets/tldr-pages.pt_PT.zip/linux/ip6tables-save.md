# ip6tables-save

> Este comando é um alias de `iptables-save`.

- Ver documentação do comando original:

`tldr iptables-save`
