# qm-move-disk

> Este comando é um alias de `qm-disk-move`.
> Mais informações: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Ver documentação do comando original:

`tldr qm-disk-move`
