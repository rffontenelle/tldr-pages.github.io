# ip6tables

> Este comando é um alias de `iptables`.

- Ver documentação do comando original:

`tldr iptables`
