# qm-importdisk

> Este comando é um alias de `qm disk import`.

- Ver documentação do comando original:

`tldr qm disk import`
