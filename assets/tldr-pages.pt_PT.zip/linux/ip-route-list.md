# ip-route-list

> Este comando é um alias de `ip-route-show`.

- Ver documentação do comando original:

`tldr ip-route-show`
