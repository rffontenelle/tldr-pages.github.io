# distrobox

> Este comando é um alias de `distrobox-create`.
> Mais informações: <https://github.com/89luca89/distrobox>.

- Ver documentação do comando original:

`tldr distrobox-create`
