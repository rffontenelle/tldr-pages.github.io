# cgroups

> Este comando é um alias de `cgclassify`.
> Mais informações: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Ver documentação do comando original:

`tldr cgclassify`
