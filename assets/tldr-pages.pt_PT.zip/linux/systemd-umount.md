# systemd-umount

> Este comando é um alias de `systemd-mount`.

- Ver documentação do comando original:

`tldr systemd-mount`
