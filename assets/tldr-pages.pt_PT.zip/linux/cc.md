# cc

> Este comando é um alias de `gcc`.
> Mais informações: <https://gcc.gnu.org>.

- Ver documentação do comando original:

`tldr gcc`
