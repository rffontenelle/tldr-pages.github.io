# mount.smb3

> Este comando é um alias de `mount.cifs`.

- Ver documentação do comando original:

`tldr mount.cifs`
