# megadl

> Este comando é um alias de `megatools-dl`.
> Mais informações: <https://megatools.megous.com/man/megatools-dl.html>.

- Exibe documentação do comando original:

`tldr megatools-dl`
