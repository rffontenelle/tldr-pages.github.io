# xbps

> Este comando é um alias de `xbps-install`.
> Mais informações: <https://docs.voidlinux.org/xbps/index.html>.

- Ver documentação do comando original:

`tldr xbps-install`
