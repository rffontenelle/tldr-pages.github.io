# bspwm

> Este comando é um alias de `bspc`.
> Mais informações: <https://github.com/baskerville/bspwm>.

- Exibe documentação do comando original:

`tldr bspc`
