# shntool-split

> Este comando é um alias de `shnsplit`.

- Ver documentação do comando original:

`tldr shnsplit`
