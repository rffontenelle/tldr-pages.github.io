# ubuntu-bug

> Este comando é um alias de `apport-bug`.
> Mais informações: <https://manned.org/ubuntu-bug>.

- Ver documentação do comando original:

`tldr apport-bug`
