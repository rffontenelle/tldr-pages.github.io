# ubuntu-bug

> Este comando é um alias de `apport-bug`.
> Mais informações: <https://manned.org/ubuntu-bug>.

- Exibe documentação do comando original:

`tldr apport-bug`
