# nmcli

> Este comando é um alias de `nmcli agent`.
> Mais informações: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Ver documentação do comando original:

`tldr nmcli agent`
