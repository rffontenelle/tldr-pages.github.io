# batcat

> Este comando é um alias de `bat`.
> Mais informações: <https://github.com/sharkdp/bat>.

- Ver documentação do comando original:

`tldr bat`
