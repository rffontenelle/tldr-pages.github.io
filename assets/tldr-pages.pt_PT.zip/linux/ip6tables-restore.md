# ip6tables-restore

> Este comando é um alias de `iptables-restore`.

- Ver documentação do comando original:

`tldr iptables-restore`
