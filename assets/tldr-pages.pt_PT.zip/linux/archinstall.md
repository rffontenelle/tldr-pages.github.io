# archinstall

> Instalador com instruções para Arch Linux.
> Mais informações: <https://archinstall.readthedocs.io>.

- Iniciar o instalador guiado:

`archinstall`

- Iniciar um instalador predefenido:

`archinstall {{minimal|unattended}}`
