# dalvikvm

> A máquina virtual Java do Android.
> Mais informações: <https://source.android.com/devices/tech/dalvik>.

- Iniciar um programa Java:

`dalvikvm -classpath {{caminho/para/arquivo.jar}} {{nome_da_classe}}`
