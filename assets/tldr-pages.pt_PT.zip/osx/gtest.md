# gtest

> Este comando é um alias de `-p linux test`.

- Ver documentação do comando original:

`tldr -p linux test`
