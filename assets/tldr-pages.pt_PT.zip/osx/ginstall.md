# ginstall

> Este comando é um alias de `-p linux install`.

- Ver documentação do comando original:

`tldr -p linux install`
