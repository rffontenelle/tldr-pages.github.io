# gprintf

> Este comando é um alias de `-p linux printf`.

- Ver documentação do comando original:

`tldr -p linux printf`
