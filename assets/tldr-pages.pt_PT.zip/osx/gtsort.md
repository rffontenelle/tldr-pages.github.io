# gtsort

> Este comando é um alias de `-p linux tsort`.

- Exibe documentação do comando original:

`tldr -p linux tsort`
