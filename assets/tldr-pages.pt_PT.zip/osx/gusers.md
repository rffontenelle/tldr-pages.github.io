# gusers

> Este comando é um alias de `-p linux users`.

- Exibe documentação do comando original:

`tldr -p linux users`
