# gegrep

> Este comando é um alias de `-p linux egrep`.

- Ver documentação do comando original:

`tldr -p linux egrep`
