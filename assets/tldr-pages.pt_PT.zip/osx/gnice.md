# gnice

> Este comando é um alias de `-p linux nice`.

- Ver documentação do comando original:

`tldr -p linux nice`
