# gtty

> Este comando é um alias de `-p linux tty`.

- Exibe documentação do comando original:

`tldr -p linux tty`
