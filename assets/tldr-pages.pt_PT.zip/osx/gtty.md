# gtty

> Este comando é um alias de `-p linux tty`.

- Ver documentação do comando original:

`tldr -p linux tty`
