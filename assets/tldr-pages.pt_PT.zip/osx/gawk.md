# gawk

> Este comando é um alias de `-p linux awk`.

- Ver documentação do comando original:

`tldr -p linux awk`
