# gawk

> Este comando é um alias de `-p linux awk`.

- Exibe documentação do comando original:

`tldr -p linux awk`
