# gtee

> Este comando é um alias de `-p linux tee`.

- Exibe documentação do comando original:

`tldr -p linux tee`
