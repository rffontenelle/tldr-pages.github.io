# gnproc

> Este comando é um alias de `-p linux nproc`.

- Exibe documentação do comando original:

`tldr -p linux nproc`
