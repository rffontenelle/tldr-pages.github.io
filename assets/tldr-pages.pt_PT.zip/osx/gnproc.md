# gnproc

> Este comando é um alias de `-p linux nproc`.

- Ver documentação do comando original:

`tldr -p linux nproc`
