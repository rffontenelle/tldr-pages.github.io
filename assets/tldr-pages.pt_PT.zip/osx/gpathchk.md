# gpathchk

> Este comando é um alias de `-p linux pathchk`.

- Ver documentação do comando original:

`tldr -p linux pathchk`
