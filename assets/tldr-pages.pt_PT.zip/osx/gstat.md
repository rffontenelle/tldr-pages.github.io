# gstat

> Este comando é um alias de `-p linux stat`.

- Ver documentação do comando original:

`tldr -p linux stat`
