# gwho

> Este comando é um alias de `-p linux who`.

- Ver documentação do comando original:

`tldr -p linux who`
