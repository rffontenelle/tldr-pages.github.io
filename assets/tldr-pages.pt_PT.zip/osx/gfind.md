# gfind

> Este comando é um alias de `-p linux find`.

- Exibe documentação do comando original:

`tldr -p linux find`
