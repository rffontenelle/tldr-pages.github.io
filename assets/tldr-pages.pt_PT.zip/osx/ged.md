# ged

> Este comando é um alias de `-p linux ed`.

- Ver documentação do comando original:

`tldr -p linux ed`
