# ged

> Este comando é um alias de `-p linux ed`.

- Exibe documentação do comando original:

`tldr -p linux ed`
