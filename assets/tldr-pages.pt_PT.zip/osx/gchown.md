# gchown

> Este comando é um alias de `-p linux chown`.

- Exibe documentação do comando original:

`tldr -p linux chown`
