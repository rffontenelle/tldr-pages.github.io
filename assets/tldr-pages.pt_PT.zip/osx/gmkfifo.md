# gmkfifo

> Este comando é um alias de `-p linux mkfifo`.

- Exibe documentação do comando original:

`tldr -p linux mkfifo`
