# grlogin

> Este comando é um alias de `-p linux rlogin`.

- Ver documentação do comando original:

`tldr -p linux rlogin`
