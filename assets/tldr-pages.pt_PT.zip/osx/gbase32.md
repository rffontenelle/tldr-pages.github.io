# gbase32

> Este comando é um alias de `-p linux base32`.

- Exibe documentação do comando original:

`tldr -p linux base32`
