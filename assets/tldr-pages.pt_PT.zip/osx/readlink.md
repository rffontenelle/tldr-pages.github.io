# readlink

> Segue um link simbólico e obtêm a sua informação.
> Mais informações: <https://www.gnu.org/software/coreutils/readlink>.

- Mostra o caminho absoluto apontado por um link simbólico:

`readlink {{caminho/para/link_simbolico}}`
