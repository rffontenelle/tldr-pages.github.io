# grm

> Este comando é um alias de `-p linux rm`.

- Exibe documentação do comando original:

`tldr -p linux rm`
