# grexec

> Este comando é um alias de `-p linux rexec`.

- Ver documentação do comando original:

`tldr -p linux rexec`
