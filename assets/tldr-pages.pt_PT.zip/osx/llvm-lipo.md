# llvm-lipo

> Este comando é um alias de `lipo`.

- Ver documentação do comando original:

`tldr lipo`
