# gwhois

> Este comando é um alias de `-p linux whois`.

- Ver documentação do comando original:

`tldr -p linux whois`
