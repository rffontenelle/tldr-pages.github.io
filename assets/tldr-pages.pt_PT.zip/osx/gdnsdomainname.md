# gdnsdomainname

> Este comando é um alias de `-p linux dnsdomainname`.

- Ver documentação do comando original:

`tldr -p linux dnsdomainname`
