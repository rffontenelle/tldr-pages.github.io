# gfmt

> Este comando é um alias de `-p linux fmt`.

- Exibe documentação do comando original:

`tldr -p linux fmt`
