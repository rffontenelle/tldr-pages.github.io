# gtr

> Este comando é um alias de `-p linux tr`.

- Ver documentação do comando original:

`tldr -p linux tr`
