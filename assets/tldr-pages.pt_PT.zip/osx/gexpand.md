# gexpand

> Este comando é um alias de `-p linux expand`.

- Ver documentação do comando original:

`tldr -p linux expand`
