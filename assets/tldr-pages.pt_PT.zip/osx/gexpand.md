# gexpand

> Este comando é um alias de `-p linux expand`.

- Exibe documentação do comando original:

`tldr -p linux expand`
