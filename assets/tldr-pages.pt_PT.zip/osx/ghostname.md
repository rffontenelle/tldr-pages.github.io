# ghostname

> Este comando é um alias de `-p linux hostname`.

- Ver documentação do comando original:

`tldr -p linux hostname`
