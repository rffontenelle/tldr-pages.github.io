# gwhoami

> Este comando é um alias de `-p linux whoami`.

- Ver documentação do comando original:

`tldr -p linux whoami`
