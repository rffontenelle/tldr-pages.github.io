# gmv

> Este comando é um alias de `-p linux mv`.

- Exibe documentação do comando original:

`tldr -p linux mv`
