# gmv

> Este comando é um alias de `-p linux mv`.

- Ver documentação do comando original:

`tldr -p linux mv`
