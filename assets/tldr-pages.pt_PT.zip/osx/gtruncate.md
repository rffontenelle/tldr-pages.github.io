# gtruncate

> Este comando é um alias de `-p linux truncate`.

- Ver documentação do comando original:

`tldr -p linux truncate`
