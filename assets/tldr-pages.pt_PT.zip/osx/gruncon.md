# gruncon

> Este comando é um alias de `-p linux runcon`.

- Ver documentação do comando original:

`tldr -p linux runcon`
