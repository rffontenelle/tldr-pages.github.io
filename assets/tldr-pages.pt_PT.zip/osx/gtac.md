# gtac

> Este comando é um alias de `-p linux tac`.

- Ver documentação do comando original:

`tldr -p linux tac`
