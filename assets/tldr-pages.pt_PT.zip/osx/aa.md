# aa

> Este comando é um alias de `yaa`.

- Ver documentação do comando original:

`tldr yaa`
