# grmdir

> Este comando é um alias de `-p linux rmdir`.

- Exibe documentação do comando original:

`tldr -p linux rmdir`
