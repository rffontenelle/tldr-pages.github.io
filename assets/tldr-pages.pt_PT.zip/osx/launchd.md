# launchd

> Este comando é um alias de `launchctl`.
> Mais informações: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Ver documentação do comando original:

`tldr launchctl`
