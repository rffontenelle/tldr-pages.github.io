# gpwd

> Este comando é um alias de `-p linux pwd`.

- Exibe documentação do comando original:

`tldr -p linux pwd`
