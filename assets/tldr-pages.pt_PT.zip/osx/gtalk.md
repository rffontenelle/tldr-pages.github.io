# gtalk

> Este comando é um alias de `-p linux talk`.

- Ver documentação do comando original:

`tldr -p linux talk`
