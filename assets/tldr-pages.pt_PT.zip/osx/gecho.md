# gecho

> Este comando é um alias de `-p linux echo`.

- Exibe documentação do comando original:

`tldr -p linux echo`
