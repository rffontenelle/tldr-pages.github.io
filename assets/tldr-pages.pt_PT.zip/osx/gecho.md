# gecho

> Este comando é um alias de `-p linux echo`.

- Ver documentação do comando original:

`tldr -p linux echo`
