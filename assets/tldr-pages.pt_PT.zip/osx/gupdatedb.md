# gupdatedb

> Este comando é um alias de `-p linux updatedb`.

- Ver documentação do comando original:

`tldr -p linux updatedb`
