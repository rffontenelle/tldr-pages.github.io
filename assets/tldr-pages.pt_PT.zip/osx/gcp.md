# gcp

> Este comando é um alias de `-p linux cp`.

- Ver documentação do comando original:

`tldr -p linux cp`
