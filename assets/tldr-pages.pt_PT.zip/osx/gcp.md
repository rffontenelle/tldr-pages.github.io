# gcp

> Este comando é um alias de `-p linux cp`.

- Exibe documentação do comando original:

`tldr -p linux cp`
