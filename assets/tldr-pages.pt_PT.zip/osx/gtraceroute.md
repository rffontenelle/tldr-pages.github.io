# gtraceroute

> Este comando é um alias de `-p linux traceroute`.

- Ver documentação do comando original:

`tldr -p linux traceroute`
