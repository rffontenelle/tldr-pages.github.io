# gsha1sum

> Este comando é um alias de `-p linux sha1sum`.

- Ver documentação do comando original:

`tldr -p linux sha1sum`
