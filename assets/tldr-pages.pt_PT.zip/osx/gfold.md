# gfold

> Este comando é um alias de `-p linux fold`.

- Exibe documentação do comando original:

`tldr -p linux fold`
