# gdirname

> Este comando é um alias de `-p linux dirname`.

- Ver documentação do comando original:

`tldr -p linux dirname`
