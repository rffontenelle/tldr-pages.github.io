# gdf

> Este comando é um alias de `-p linux df`.

- Ver documentação do comando original:

`tldr -p linux df`
