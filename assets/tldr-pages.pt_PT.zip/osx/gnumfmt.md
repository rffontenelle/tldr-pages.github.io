# gnumfmt

> Este comando é um alias de `-p linux numfmt`.

- Ver documentação do comando original:

`tldr -p linux numfmt`
