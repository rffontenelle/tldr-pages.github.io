# gmktemp

> Este comando é um alias de `-p linux mktemp`.

- Exibe documentação do comando original:

`tldr -p linux mktemp`
