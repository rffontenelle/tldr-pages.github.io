# gindent

> Este comando é um alias de `-p linux indent`.

- Ver documentação do comando original:

`tldr -p linux indent`
