# gprintenv

> Este comando é um alias de `-p linux printenv`.

- Ver documentação do comando original:

`tldr -p linux printenv`
