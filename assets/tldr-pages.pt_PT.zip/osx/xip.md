# xip

> Cria ou extrai ficheiros comprimido de um arquivo xip.
> Apenas arquivos criados pela Apple são confiáveis, dado isto esta ferramenta não deve ser utilizada para criar arquivos.
> Mais informações: <https://www.manpagez.com/man/1/xip/>.

- Extrai o arquivo para o diretório de trabalho atual:

`xip --expand {{caminho/para/ficheiro.xip}}`
