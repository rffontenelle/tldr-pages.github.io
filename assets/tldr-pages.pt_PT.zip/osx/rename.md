# rename

> Altera o nome de um ficheiro ou grupo de ficheiros com uma expressão regular.
> Mais informações: <https://www.manpagez.com/man/2/rename/>.

- Altera "antes" para "depois" o nome dos ficheiros especificados:

`rename 's/{{antes}}/{{depois}}/' {{*.txt}}`
