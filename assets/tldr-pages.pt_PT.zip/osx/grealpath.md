# grealpath

> Este comando é um alias de `-p linux realpath`.

- Ver documentação do comando original:

`tldr -p linux realpath`
