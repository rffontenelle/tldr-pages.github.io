# gchmod

> Este comando é um alias de `-p linux chmod`.

- Ver documentação do comando original:

`tldr -p linux chmod`
