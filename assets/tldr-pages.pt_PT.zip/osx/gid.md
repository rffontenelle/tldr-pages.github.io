# gid

> Este comando é um alias de `-p linux id`.

- Ver documentação do comando original:

`tldr -p linux id`
