# gchgrp

> Este comando é um alias de `-p linux chgrp`.

- Ver documentação do comando original:

`tldr -p linux chgrp`
