# glink

> Este comando é um alias de `-p linux link`.

- Ver documentação do comando original:

`tldr -p linux link`
