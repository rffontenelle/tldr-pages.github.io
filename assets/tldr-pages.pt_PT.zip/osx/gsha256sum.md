# gsha256sum

> Este comando é um alias de `-p linux sha256sum`.

- Exibe documentação do comando original:

`tldr -p linux sha256sum`
