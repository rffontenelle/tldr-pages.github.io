# gexpr

> Este comando é um alias de `-p linux expr`.

- Ver documentação do comando original:

`tldr -p linux expr`
