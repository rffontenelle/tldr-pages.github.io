# arch

> Mostra o nome da arquitetura do sistema, ou executa um comando utilizando uma arquitetura escolhida.
> Ver também `uname`.
> Mais informações: <https://www.unix.com/man-page/osx/1/arch/>.

- Mostra o nome da arquitetura do sistema:

`arch`

- Executa um comando utilizando a arquitetura x86_64:

`arch -x86_64 {{comando}}`
