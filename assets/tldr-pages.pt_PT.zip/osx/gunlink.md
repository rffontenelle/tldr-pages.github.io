# gunlink

> Este comando é um alias de `-p linux unlink`.

- Ver documentação do comando original:

`tldr -p linux unlink`
