# gunlink

> Este comando é um alias de `-p linux unlink`.

- Exibe documentação do comando original:

`tldr -p linux unlink`
