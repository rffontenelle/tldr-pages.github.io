# gbasename

> Este comando é um alias de `-p linux basename`.

- Ver documentação do comando original:

`tldr -p linux basename`
