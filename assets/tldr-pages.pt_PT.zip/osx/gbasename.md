# gbasename

> Este comando é um alias de `-p linux basename`.

- Exibe documentação do comando original:

`tldr -p linux basename`
