# gshuf

> Este comando é um alias de `-p linux shuf`.

- Exibe documentação do comando original:

`tldr -p linux shuf`
