# gshuf

> Este comando é um alias de `-p linux shuf`.

- Ver documentação do comando original:

`tldr -p linux shuf`
