# gptx

> Este comando é um alias de `-p linux ptx`.

- Ver documentação do comando original:

`tldr -p linux ptx`
