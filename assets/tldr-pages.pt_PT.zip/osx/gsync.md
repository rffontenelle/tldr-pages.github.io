# gsync

> Este comando é um alias de `-p linux sync`.

- Exibe documentação do comando original:

`tldr -p linux sync`
