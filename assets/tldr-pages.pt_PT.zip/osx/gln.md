# gln

> Este comando é um alias de `-p linux ln`.

- Exibe documentação do comando original:

`tldr -p linux ln`
