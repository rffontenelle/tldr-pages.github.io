# gsum

> Este comando é um alias de `-p linux sum`.

- Ver documentação do comando original:

`tldr -p linux sum`
