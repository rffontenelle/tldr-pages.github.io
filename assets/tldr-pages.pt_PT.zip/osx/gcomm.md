# gcomm

> Este comando é um alias de `-p linux comm`.

- Ver documentação do comando original:

`tldr -p linux comm`
