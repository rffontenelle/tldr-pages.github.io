# gshred

> Este comando é um alias de `-p linux shred`.

- Exibe documentação do comando original:

`tldr -p linux shred`
