# gshred

> Este comando é um alias de `-p linux shred`.

- Ver documentação do comando original:

`tldr -p linux shred`
