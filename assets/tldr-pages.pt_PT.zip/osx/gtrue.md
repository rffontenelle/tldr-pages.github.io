# gtrue

> Este comando é um alias de `-p linux true`.

- Ver documentação do comando original:

`tldr -p linux true`
