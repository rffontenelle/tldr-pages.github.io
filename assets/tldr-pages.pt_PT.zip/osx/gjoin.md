# gjoin

> Este comando é um alias de `-p linux join`.

- Exibe documentação do comando original:

`tldr -p linux join`
