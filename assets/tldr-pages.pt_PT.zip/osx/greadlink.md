# greadlink

> Este comando é um alias de `-p linux readlink`.

- Exibe documentação do comando original:

`tldr -p linux readlink`
