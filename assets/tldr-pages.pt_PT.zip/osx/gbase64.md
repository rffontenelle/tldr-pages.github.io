# gbase64

> Este comando é um alias de `-p linux base64`.

- Ver documentação do comando original:

`tldr -p linux base64`
