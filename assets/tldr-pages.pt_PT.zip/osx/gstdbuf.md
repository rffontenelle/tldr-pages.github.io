# gstdbuf

> Este comando é um alias de `-p linux stdbuf`.

- Exibe documentação do comando original:

`tldr -p linux stdbuf`
