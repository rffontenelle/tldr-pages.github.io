# gpinky

> Este comando é um alias de `-p linux pinky`.

- Ver documentação do comando original:

`tldr -p linux pinky`
