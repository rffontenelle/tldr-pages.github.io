# gpinky

> Este comando é um alias de `-p linux pinky`.

- Exibe documentação do comando original:

`tldr -p linux pinky`
