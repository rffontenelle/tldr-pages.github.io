# gchroot

> Este comando é um alias de `-p linux chroot`.

- Ver documentação do comando original:

`tldr -p linux chroot`
