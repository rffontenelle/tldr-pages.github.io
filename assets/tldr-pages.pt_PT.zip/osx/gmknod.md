# gmknod

> Este comando é um alias de `-p linux mknod`.

- Exibe documentação do comando original:

`tldr -p linux mknod`
