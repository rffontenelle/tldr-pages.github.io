# grcp

> Este comando é um alias de `-p linux rcp`.

- Ver documentação do comando original:

`tldr -p linux rcp`
