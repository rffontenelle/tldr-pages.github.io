# gfactor

> Este comando é um alias de `-p linux factor`.

- Ver documentação do comando original:

`tldr -p linux factor`
