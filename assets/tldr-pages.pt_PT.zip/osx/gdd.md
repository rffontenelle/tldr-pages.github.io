# gdd

> Este comando é um alias de `-p linux dd`.

- Ver documentação do comando original:

`tldr -p linux dd`
