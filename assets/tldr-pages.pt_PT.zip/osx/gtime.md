# gtime

> Este comando é um alias de `-p linux time`.

- Exibe documentação do comando original:

`tldr -p linux time`
