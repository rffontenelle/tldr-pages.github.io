# grsh

> Este comando é um alias de `-p linux rsh`.

- Ver documentação do comando original:

`tldr -p linux rsh`
