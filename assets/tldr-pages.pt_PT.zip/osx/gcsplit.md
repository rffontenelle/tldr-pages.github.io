# gcsplit

> Este comando é um alias de `-p linux csplit`.

- Ver documentação do comando original:

`tldr -p linux csplit`
