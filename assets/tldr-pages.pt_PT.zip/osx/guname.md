# guname

> Este comando é um alias de `-p linux uname`.

- Ver documentação do comando original:

`tldr -p linux uname`
