# gtouch

> Este comando é um alias de `-p linux touch`.

- Exibe documentação do comando original:

`tldr -p linux touch`
