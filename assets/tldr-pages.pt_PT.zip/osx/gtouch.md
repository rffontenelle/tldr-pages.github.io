# gtouch

> Este comando é um alias de `-p linux touch`.

- Ver documentação do comando original:

`tldr -p linux touch`
