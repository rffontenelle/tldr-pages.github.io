# gfalse

> Este comando é um alias de `-p linux false`.

- Ver documentação do comando original:

`tldr -p linux false`
