# gls

> Este comando é um alias de `-p linux ls`.

- Ver documentação do comando original:

`tldr -p linux ls`
