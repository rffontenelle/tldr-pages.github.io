# gtail

> Este comando é um alias de `-p linux tail`.

- Exibe documentação do comando original:

`tldr -p linux tail`
