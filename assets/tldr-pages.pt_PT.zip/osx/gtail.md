# gtail

> Este comando é um alias de `-p linux tail`.

- Ver documentação do comando original:

`tldr -p linux tail`
