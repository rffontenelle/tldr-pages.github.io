# gsleep

> Este comando é um alias de `-p linux sleep`.

- Ver documentação do comando original:

`tldr -p linux sleep`
