# g[

> Este comando é um alias de `-p linux [`.

- Ver documentação do comando original:

`tldr -p linux [`
