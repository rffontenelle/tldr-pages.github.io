# ghostid

> Este comando é um alias de `-p linux hostid`.

- Exibe documentação do comando original:

`tldr -p linux hostid`
