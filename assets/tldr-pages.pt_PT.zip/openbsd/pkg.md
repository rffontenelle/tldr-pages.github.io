# pkg

> Este comando é um alias de `pkg_add`.
> Mais informações: <https://www.openbsd.org/faq/faq15.html>.

- Ver documentação do comando original:

`tldr pkg_add`
