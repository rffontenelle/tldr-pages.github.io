# del

> Este comando é um alias de `remove-item`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Ver documentação do comando original:

`tldr remove-item`
