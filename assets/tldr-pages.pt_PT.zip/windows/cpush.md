# cpush

> Este comando é um alias de `choco-push`.
> Mais informações: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Ver documentação do comando original:

`tldr choco-push`
