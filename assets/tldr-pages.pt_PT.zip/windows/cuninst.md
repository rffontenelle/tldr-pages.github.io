# cuninst

> Este comando é um alias de `choco uninstall`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Ver documentação do comando original:

`tldr choco uninstall`
