# rd

> Este comando é um alias de `rmdir`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Exibe documentação do comando original:

`tldr rmdir`
