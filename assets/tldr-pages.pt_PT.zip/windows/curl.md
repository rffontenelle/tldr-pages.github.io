# curl

> Este comando é um alias de `curl -p common`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Ver documentação do comando original:

`tldr curl -p common`
