# curl

> Este comando é um alias de `curl -p common`.
> Mais informações: <https://curl.se>.

- Ver documentação do comando original:

`tldr curl -p common`
