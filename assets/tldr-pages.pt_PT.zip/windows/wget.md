# wget

> Este comando é um alias de `wget -p common`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Ver documentação do comando original:

`tldr wget -p common`
