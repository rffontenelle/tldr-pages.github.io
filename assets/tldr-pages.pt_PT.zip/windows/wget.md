# wget

> Este comando é um alias de `wget -p common`.
> Mais informações: <https://www.gnu.org/software/wget>.

- Ver documentação do comando original:

`tldr wget -p common`
