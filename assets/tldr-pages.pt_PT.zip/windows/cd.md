# cd

> Este comando é um alias de `set-location`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Ver documentação do comando original:

`tldr set-location`
