# sc-delete

> Este comando é um alias de `sc`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Ver documentação do comando original:

`tldr sc`
