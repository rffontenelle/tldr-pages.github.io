# ni

> Este comando é um alias de `new-item`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Ver documentação do comando original:

`tldr new-item`
