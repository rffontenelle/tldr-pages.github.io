# clear

> Este comando é um alias de `clear-host`.

- Ver documentação do comando original:

`tldr clear-host`
