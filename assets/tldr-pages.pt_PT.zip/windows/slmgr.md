# slmgr

> Este comando é um alias de `slmgr.vbs`.
> Mais informações: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Ver documentação do comando original:

`tldr slmgr.vbs`
