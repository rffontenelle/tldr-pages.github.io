# cinst

> Este comando é um alias de `choco install`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Exibe documentação do comando original:

`tldr choco install`
