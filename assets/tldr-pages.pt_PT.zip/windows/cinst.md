# cinst

> Este comando é um alias de `choco install`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Ver documentação do comando original:

`tldr choco install`
