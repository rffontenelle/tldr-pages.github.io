# rm

> Este comando é um alias de `remove-item`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Ver documentação do comando original:

`tldr remove-item`
