# sl

> Este comando é um alias de `set-location`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Ver documentação do comando original:

`tldr set-location`
