# gal

> Este comando é um alias de `get-alias`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Ver documentação do comando original:

`tldr get-alias`
