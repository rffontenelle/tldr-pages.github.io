# chdir

> Este comando é um alias de `cd`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Ver documentação do comando original:

`tldr cd`
