# cls

> Este comando é um alias de `clear-host`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Ver documentação do comando original:

`tldr clear-host`
