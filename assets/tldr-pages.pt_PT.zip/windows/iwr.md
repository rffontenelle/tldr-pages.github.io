# iwr

> Este comando é um alias de `invoke-webrequest`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Ver documentação do comando original:

`tldr invoke-webrequest`
