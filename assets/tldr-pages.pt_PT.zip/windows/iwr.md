# iwr

> Este comando é um alias de `invoke-webrequest`.

- Ver documentação do comando original:

`tldr invoke-webrequest`
