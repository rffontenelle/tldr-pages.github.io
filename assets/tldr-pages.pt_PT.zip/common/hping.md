# hping

> Este comando é um alias de `hping3`.
> Mais informações: <https://github.com/antirez/hping>.

- Ver documentação do comando original:

`tldr hping3`
