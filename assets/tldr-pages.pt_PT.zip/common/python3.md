# python3

> Este comando é um alias de `python`.

- Ver documentação do comando original:

`tldr python`
