# azure-cli

> Este comando é um alias de `az`.
> Mais informações: <https://learn.microsoft.com/cli/azure>.

- Ver documentação do comando original:

`tldr az`
