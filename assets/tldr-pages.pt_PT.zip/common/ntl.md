# ntl

> Este comando é um alias de `netlify`.
> Mais informações: <https://cli.netlify.com>.

- Ver documentação do comando original:

`tldr netlify`
