# ntl

> Este comando é um alias de `netlify`.
> Mais informações: <https://cli.netlify.com>.

- Exibe documentação do comando original:

`tldr netlify`
