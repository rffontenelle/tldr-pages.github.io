# nm-classic

> Este comando é um alias de `nm`.

- Ver documentação do comando original:

`tldr nm`
