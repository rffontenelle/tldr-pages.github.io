# just

> Este comando é um alias de `just.1`.

- Ver documentação do comando original:

`tldr just.1`
