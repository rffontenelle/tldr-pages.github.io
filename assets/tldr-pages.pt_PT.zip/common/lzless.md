# lzless

> Este comando é um alias de `xzless`.

- Ver documentação do comando original:

`tldr xzless`
