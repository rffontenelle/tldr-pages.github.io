# unxz

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/unxz>.

- Ver documentação do comando original:

`tldr xz`
