# pwsh

> Este comando é um alias de `powershell`.

- Ver documentação do comando original:

`tldr powershell`
