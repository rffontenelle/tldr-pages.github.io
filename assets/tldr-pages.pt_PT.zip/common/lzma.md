# lzma

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/lzma>.

- Ver documentação do comando original:

`tldr xz`
