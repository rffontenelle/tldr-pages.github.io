# hx

> Este comando é um alias de `helix`.

- Ver documentação do comando original:

`tldr helix`
