# llvm-g++

> Este comando é um alias de `clang++`.

- Exibe documentação do comando original:

`tldr clang++`
