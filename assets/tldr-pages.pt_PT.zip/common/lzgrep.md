# lzgrep

> Este comando é um alias de `xzgrep`.

- Ver documentação do comando original:

`tldr xzgrep`
