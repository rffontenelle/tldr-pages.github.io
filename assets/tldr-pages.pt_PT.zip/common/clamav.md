# ClamAV

> Este comando é um alias de `clamdscan`.
> Mais informações: <https://www.clamav.net>.

- Exibe documentação do comando original:

`tldr clamdscan`
