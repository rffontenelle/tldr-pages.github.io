# ripgrep

> Este comando é um alias de `rg`.

- Ver documentação do comando original:

`tldr rg`
