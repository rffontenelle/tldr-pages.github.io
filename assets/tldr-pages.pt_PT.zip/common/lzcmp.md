# lzcmp

> Este comando é um alias de `xzcmp`.

- Ver documentação do comando original:

`tldr xzcmp`
