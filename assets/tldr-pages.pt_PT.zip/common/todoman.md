# todoman

> Este comando é um alias de `todo`.
> Mais informações: <https://todoman.readthedocs.io/>.

- Ver documentação do comando original:

`tldr todo`
