# lzmore

> Este comando é um alias de `xzmore`.

- Ver documentação do comando original:

`tldr xzmore`
