# musl-gcc

> Este comando é um alias de `gcc`.
> Mais informações: <https://manned.org/musl-gcc>.

- Ver documentação do comando original:

`tldr gcc`
