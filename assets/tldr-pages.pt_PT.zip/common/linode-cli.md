# linode-cli

> Este comando é um alias de `linode-cli account`.
> Mais informações: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Ver documentação do comando original:

`tldr linode-cli account`
