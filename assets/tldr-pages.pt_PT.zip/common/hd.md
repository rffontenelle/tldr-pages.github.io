# hd

> Este comando é um alias de `hexdump`.
> Mais informações: <https://manned.org/hd.1>.

- Ver documentação do comando original:

`tldr hexdump`
