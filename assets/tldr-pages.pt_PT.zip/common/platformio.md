# platformio

> Este comando é um alias de `pio`.
> Mais informações: <https://docs.platformio.org/en/latest/core/userguide/>.

- Ver documentação do comando original:

`tldr pio`
