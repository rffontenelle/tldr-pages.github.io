# tlmgr-arch

> Este comando é um alias de `tlmgr platform`.
> Mais informações: <https://www.tug.org/texlive/tlmgr.html>.

- Exibe documentação do comando original:

`tldr tlmgr platform`
