# piodebuggdb

> Este comando é um alias de `pio debug`.

- Ver documentação do comando original:

`tldr pio debug`
