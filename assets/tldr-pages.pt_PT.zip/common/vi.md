# vi

> Este comando é um alias de `vim`.

- Exibe documentação do comando original:

`tldr vim`
