# vi

> Este comando é um alias de `vim`.

- Ver documentação do comando original:

`tldr vim`
