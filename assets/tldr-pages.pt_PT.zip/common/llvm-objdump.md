# llvm-objdump

> Este comando é um alias de `objdump`.

- Ver documentação do comando original:

`tldr objdump`
