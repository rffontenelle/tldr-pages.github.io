# xzcat

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/xzcat>.

- Exibe documentação do comando original:

`tldr xz`
