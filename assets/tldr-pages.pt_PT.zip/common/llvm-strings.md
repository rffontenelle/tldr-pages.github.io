# llvm-strings

> Este comando é um alias de `strings`.

- Ver documentação do comando original:

`tldr strings`
