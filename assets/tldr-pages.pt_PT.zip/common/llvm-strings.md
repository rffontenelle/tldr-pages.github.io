# llvm-strings

> Este comando é um alias de `strings`.

- Exibe documentação do comando original:

`tldr strings`
