# docker-container-top

> Este comando é um alias de `docker top`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/top>.

- Ver documentação do comando original:

`tldr docker top`
