# docker-container-remove

> Este comando é um alias de `docker rm`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/rm>.

- Ver documentação do comando original:

`tldr docker rm`
