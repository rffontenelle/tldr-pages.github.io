# unlzma

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/unlzma>.

- Ver documentação do comando original:

`tldr xz`
