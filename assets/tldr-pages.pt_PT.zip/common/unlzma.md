# unlzma

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/unlzma>.

- Exibe documentação do comando original:

`tldr xz`
