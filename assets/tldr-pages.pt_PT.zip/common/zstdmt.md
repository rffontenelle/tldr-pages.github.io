# zstdmt

> Este comando é um alias de `zstd`.

- Ver documentação do comando original:

`tldr zstd`
