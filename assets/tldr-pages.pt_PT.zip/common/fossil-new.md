# fossil-new

> Este comando é um alias de `fossil-init`.
> Mais informações: <https://fossil-scm.org/home/help/new>.

- Exibe documentação do comando original:

`tldr fossil-init`
