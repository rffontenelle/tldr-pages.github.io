# cron

> Este comando é um alias de `crontab`.

- Ver documentação do comando original:

`tldr crontab`
