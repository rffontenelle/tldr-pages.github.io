# cron

> Este comando é um alias de `crontab`.

- Exibe documentação do comando original:

`tldr crontab`
