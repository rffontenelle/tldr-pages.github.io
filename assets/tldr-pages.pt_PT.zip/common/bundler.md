# bundler

> Este comando é um alias de `bundle`.
> Mais informações: <https://bundler.io/man/bundle.1.html>.

- Ver documentação do comando original:

`tldr bundle`
