# rcat

> Este comando é um alias de `rc`.

- Ver documentação do comando original:

`tldr rc`
