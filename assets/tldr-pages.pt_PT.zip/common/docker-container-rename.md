# docker-container-rename

> Este comando é um alias de `docker rename`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/rename>.

- Ver documentação do comando original:

`tldr docker rename`
