# clojure

> Este comando é um alias de `clj`.

- Exibe documentação do comando original:

`tldr clj`
