# clojure

> Este comando é um alias de `clj`.

- Ver documentação do comando original:

`tldr clj`
