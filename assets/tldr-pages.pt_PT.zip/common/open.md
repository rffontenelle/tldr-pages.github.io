# open

> Este comando é um alias de `open -p osx`.

- Ver documentação do comando original:

`tldr open -p osx`
