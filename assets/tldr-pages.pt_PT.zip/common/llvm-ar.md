# llvm-ar

> Este comando é um alias de `ar`.

- Exibe documentação do comando original:

`tldr ar`
