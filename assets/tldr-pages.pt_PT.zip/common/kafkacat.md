# kafkacat

> Este comando é um alias de `kcat`.

- Ver documentação do comando original:

`tldr kcat`
