# ptpython3

> Este comando é um alias de `ptpython`.

- Ver documentação do comando original:

`tldr ptpython`
