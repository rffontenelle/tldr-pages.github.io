# netcat

> Este comando é um alias de `nc`.

- Ver documentação do comando original:

`tldr nc`
