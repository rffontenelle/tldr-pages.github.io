# gnmic-sub

> Este comando é um alias de `gnmic subscribe`.
> Mais informações: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Ver documentação do comando original:

`tldr gnmic subscribe`
