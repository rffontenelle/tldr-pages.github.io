# lzcat

> Este comando é um alias de `xz`.
> Mais informações: <https://manned.org/lzcat>.

- Ver documentação do comando original:

`tldr xz`
