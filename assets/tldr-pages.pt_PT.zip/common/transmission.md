# transmission

> Este comando é um alias de `transmission-daemon`.
> Mais informações: <https://transmissionbt.com/>.

- Ver documentação do comando original:

`tldr transmission-daemon`
