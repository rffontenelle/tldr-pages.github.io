# docker-container-diff

> Este comando é um alias de `docker diff`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/diff>.

- Ver documentação do comando original:

`tldr docker diff`
