# lima

> Este comando é um alias de `limactl`.
> Mais informações: <https://github.com/lima-vm/lima>.

- Ver documentação do comando original:

`tldr limactl`
