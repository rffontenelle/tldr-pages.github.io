# cd

> Mudar o diretório atual.
> Mais informações: <https://manned.org/cd>.

- Ir para um dado diretório:

`cd {{caminho/para/diretorio}}`

- Ir para o diretório base do utilizador atual:

`cd`

- Ir para o diretório pai do diretório atual:

`cd ..`

- Ir para o diretório anteriormente escolhido:

`cd -`
