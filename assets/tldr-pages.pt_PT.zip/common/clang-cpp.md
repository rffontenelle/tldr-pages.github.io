# clang-cpp

> Este comando é um alias de `clang++`.

- Ver documentação do comando original:

`tldr clang++`
