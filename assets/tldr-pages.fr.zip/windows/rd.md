# rd

> Cette commande est un alias de `rmdir`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Voir la documentation de la commande originale :

`tldr rmdir`
