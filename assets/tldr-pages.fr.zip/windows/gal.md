# gal

> Cette commande est un alias de `get-alias`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Voir la documentation de la commande originale :

`tldr get-alias`
