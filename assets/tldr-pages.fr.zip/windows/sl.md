# sl

> Cette commande est un alias de `set-location`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Voir la documentation de la commande originale :

`tldr set-location`
