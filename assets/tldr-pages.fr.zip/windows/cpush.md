# cpush

> Cette commande est un alias de `choco-push`.
> Plus d'informations : <https://docs.chocolatey.org/en-us/create/commands/push>.

- Voir la documentation de la commande originale :

`tldr choco-push`
