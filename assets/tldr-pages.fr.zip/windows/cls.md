# cls

> Cette commande est un alias de `clear-host`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Voir la documentation de la commande originale :

`tldr clear-host`
