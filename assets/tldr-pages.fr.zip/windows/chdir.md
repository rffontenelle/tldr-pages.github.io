# chdir

> Cette commande est un alias de `cd`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Voir la documentation de la commande originale :

`tldr cd`
