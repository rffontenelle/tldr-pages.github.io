# wget

> Cette commande est un alias de `wget -p common`.
> Plus d'informations : <https://www.gnu.org/software/wget>.

- Voir la documentation de la commande originale :

`tldr wget -p common`
