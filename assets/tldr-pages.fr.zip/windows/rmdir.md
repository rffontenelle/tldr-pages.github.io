# rmdir

> Cette commande est un alias de `remove-item`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Voir la documentation de la commande originale :

`tldr remove-item`
