# rm

> Cette commande est un alias de `remove-item`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Voir la documentation de la commande originale :

`tldr remove-item`
