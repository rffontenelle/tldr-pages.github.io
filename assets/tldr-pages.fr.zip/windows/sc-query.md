# sc-query

> Cette commande est un alias de `sc`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Voir la documentation de la commande originale :

`tldr sc`
