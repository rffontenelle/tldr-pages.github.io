# curl

> Cette commande est un alias de `curl -p common`.
> Plus d'informations : <https://curl.se>.

- Voir la documentation de la commande originale :

`tldr curl -p common`
