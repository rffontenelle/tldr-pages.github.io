# ni

> Cette commande est un alias de `new-item`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Voir la documentation de la commande originale :

`tldr new-item`
