# cd

> Cette commande est un alias de `set-location`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Voir la documentation de la commande originale :

`tldr set-location`
