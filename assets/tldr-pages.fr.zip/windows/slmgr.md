# slmgr

> Cette commande est un alias de `slmgr.vbs`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Voir la documentation de la commande originale :

`tldr slmgr.vbs`
