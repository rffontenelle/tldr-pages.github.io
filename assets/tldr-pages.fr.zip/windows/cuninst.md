# cuninst

> Cette commande est un alias de `choco uninstall`.
> Plus d'informations : <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Voir la documentation de la commande originale :

`tldr choco uninstall`
