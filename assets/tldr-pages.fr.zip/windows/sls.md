# sls

> Cette commande est un alias de `where-object`.
> Plus d'informations : <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Voir la documentation de la commande originale :

`tldr where-object`
