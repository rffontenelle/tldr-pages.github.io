# cinst

> Cette commande est un alias de `choco install`.
> Plus d'informations : <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Voir la documentation de la commande originale :

`tldr choco install`
