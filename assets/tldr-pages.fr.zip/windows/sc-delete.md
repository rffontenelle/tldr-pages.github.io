# sc-delete

> Cette commande est un alias de `sc`.
> Plus d'informations : <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Voir la documentation de la commande originale :

`tldr sc`
