# clear

> Cette commande est un alias de `clear-host`.

- Voir la documentation de la commande originale :

`tldr clear-host`
