# grm

> Cette commande est un alias de `-p linux rm`.

- Voir la documentation de la commande originale :

`tldr -p linux rm`
