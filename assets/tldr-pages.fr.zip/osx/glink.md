# glink

> Cette commande est un alias de `-p linux link`.

- Voir la documentation de la commande originale :

`tldr -p linux link`
