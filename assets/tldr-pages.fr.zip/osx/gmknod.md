# gmknod

> Cette commande est un alias de `-p linux mknod`.

- Voir la documentation de la commande originale :

`tldr -p linux mknod`
