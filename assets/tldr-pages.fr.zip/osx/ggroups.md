# ggroups

> Cette commande est un alias de `-p linux groups`.

- Voir la documentation de la commande originale :

`tldr -p linux groups`
