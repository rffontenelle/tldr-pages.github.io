# gwc

> Cette commande est un alias de `-p linux wc`.

- Voir la documentation de la commande originale :

`tldr -p linux wc`
