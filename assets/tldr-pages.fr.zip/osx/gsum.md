# gsum

> Cette commande est un alias de `-p linux sum`.

- Voir la documentation de la commande originale :

`tldr -p linux sum`
