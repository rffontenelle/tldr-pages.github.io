# gchmod

> Cette commande est un alias de `-p linux chmod`.

- Voir la documentation de la commande originale :

`tldr -p linux chmod`
