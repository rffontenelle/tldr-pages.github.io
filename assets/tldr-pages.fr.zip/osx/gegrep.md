# gegrep

> Cette commande est un alias de `-p linux egrep`.

- Voir la documentation de la commande originale :

`tldr -p linux egrep`
