# glocate

> Cette commande est un alias de `-p linux locate`.

- Voir la documentation de la commande originale :

`tldr -p linux locate`
