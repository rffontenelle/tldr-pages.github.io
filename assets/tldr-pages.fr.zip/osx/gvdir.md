# gvdir

> Cette commande est un alias de `-p linux vdir`.

- Voir la documentation de la commande originale :

`tldr -p linux vdir`
