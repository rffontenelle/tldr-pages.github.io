# gchown

> Cette commande est un alias de `-p linux chown`.

- Voir la documentation de la commande originale :

`tldr -p linux chown`
