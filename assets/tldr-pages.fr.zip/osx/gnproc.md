# gnproc

> Cette commande est un alias de `-p linux nproc`.

- Voir la documentation de la commande originale :

`tldr -p linux nproc`
