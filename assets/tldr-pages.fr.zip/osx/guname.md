# guname

> Cette commande est un alias de `-p linux uname`.

- Voir la documentation de la commande originale :

`tldr -p linux uname`
