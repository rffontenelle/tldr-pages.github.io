# gfold

> Cette commande est un alias de `-p linux fold`.

- Voir la documentation de la commande originale :

`tldr -p linux fold`
