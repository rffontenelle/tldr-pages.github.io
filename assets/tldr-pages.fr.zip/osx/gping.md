# gping

> Cette commande est un alias de `-p linux ping`.

- Voir la documentation de la commande originale :

`tldr -p linux ping`
