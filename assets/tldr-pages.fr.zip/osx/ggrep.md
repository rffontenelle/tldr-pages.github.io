# ggrep

> Cette commande est un alias de `-p linux grep`.

- Voir la documentation de la commande originale :

`tldr -p linux grep`
