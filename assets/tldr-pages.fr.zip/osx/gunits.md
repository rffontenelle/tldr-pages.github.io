# gunits

> Cette commande est un alias de `-p linux units`.

- Voir la documentation de la commande originale :

`tldr -p linux units`
