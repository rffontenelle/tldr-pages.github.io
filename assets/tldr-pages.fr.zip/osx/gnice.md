# gnice

> Cette commande est un alias de `-p linux nice`.

- Voir la documentation de la commande originale :

`tldr -p linux nice`
