# guniq

> Cette commande est un alias de `-p linux uniq`.

- Voir la documentation de la commande originale :

`tldr -p linux uniq`
