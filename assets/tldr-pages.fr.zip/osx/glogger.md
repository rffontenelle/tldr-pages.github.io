# glogger

> Cette commande est un alias de `-p linux logger`.

- Voir la documentation de la commande originale :

`tldr -p linux logger`
