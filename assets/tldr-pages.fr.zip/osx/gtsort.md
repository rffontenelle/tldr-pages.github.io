# gtsort

> Cette commande est un alias de `-p linux tsort`.

- Voir la documentation de la commande originale :

`tldr -p linux tsort`
