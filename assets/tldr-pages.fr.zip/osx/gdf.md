# gdf

> Cette commande est un alias de `-p linux df`.

- Voir la documentation de la commande originale :

`tldr -p linux df`
