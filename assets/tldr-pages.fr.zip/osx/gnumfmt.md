# gnumfmt

> Cette commande est un alias de `-p linux numfmt`.

- Voir la documentation de la commande originale :

`tldr -p linux numfmt`
