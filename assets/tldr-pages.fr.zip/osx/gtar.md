# gtar

> Cette commande est un alias de `-p linux tar`.

- Voir la documentation de la commande originale :

`tldr -p linux tar`
