# screencap

> Prenez une capture d'écran d'un écran mobile.
> Cette commande ne peut être utilisée que via `adb shell`.
> Plus d'informations : <https://developer.android.com/tools/adb#screencap>.

- Prendre une capture d'écran :

`screencap {{chemin/vers/fichier}}`
