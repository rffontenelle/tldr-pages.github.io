# cmd

> Manager de service Android.
> Plus d'informations : <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- Liste tous les services en cours d'exécution :

`cmd -l`

- Appelle un service spécifique :

`cmd {{alarm}}`

- Appelle un service avec des arguments :

`cmd {{vibrator}} {{vibrate 300}}`
