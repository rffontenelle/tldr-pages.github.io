# logcat

> Exporte une log depuis les messages système.
> Plus d'informations : <https://developer.android.com/tools/logcat>.

- Affiche la journalisation système :

`logcat`

- Écris la journalisation système dans un fichier :

`logcat -f {{chemin/vers/fichier}}`

- Affiche les lignes qui correspondent à une expression régulière :

`logcat --regex {{expression_régulière}}`
