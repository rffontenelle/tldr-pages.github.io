# bugreport

> Affiche un rapport de bug Android.
> Cette commande peut être utilisée uniquement depuis `adb shell`.
> Plus d'informations : <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Affiche un rapport de bug d'un appareil Android :

`bugreport`
