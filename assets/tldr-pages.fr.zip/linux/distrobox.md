# distrobox

> Cette commande est un alias de `distrobox-create`.
> Plus d'informations : <https://github.com/89luca89/distrobox>.

- Voir la documentation de la commande originale :

`tldr distrobox-create`
