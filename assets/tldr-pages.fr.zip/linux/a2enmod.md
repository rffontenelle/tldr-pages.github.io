# a2enmod

> Active un module Apache sur une distribution Debian.
> Plus d'informations : <https://manpages.debian.org/latest/apache2/a2enmod.8.en.html>.

- Active un module :

`sudo a2enmod {{module}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2enmod --quiet {{module}}`
