# bspwm

> Cette commande est un alias de `bspc`.
> Plus d'informations : <https://github.com/baskerville/bspwm>.

- Voir la documentation de la commande originale :

`tldr bspc`
