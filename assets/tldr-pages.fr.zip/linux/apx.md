# apx

> Cette commande est un alias de `apx pkgmanagers`.
> Plus d'informations : <https://github.com/Vanilla-OS/apx>.

- Voir la documentation de la commande originale :

`tldr apx pkgmanagers`
