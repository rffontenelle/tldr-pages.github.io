# qm-importdisk

> Cette commande est un alias de `qm disk import`.

- Voir la documentation de la commande originale :

`tldr qm disk import`
