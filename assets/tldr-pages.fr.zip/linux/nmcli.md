# nmcli

> Cette commande est un alias de `nmcli agent`.
> Plus d'informations : <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Voir la documentation de la commande originale :

`tldr nmcli agent`
