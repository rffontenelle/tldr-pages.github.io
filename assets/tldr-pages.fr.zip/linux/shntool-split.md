# shntool-split

> Cette commande est un alias de `shnsplit`.

- Voir la documentation de la commande originale :

`tldr shnsplit`
