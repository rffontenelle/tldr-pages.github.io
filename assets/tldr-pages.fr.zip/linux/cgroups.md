# cgroups

> Cette commande est un alias de `cgclassify`.
> Plus d'informations : <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Voir la documentation de la commande originale :

`tldr cgclassify`
