# alternatives

> Cette commande est un alias de `update-alternatives`.
> Plus d'informations : <https://manned.org/alternatives>.

- Voir la documentation de la commande originale :

`tldr update-alternatives`
