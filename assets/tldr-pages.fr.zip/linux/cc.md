# cc

> Cette commande est un alias de `gcc`.
> Plus d'informations : <https://gcc.gnu.org>.

- Voir la documentation de la commande originale :

`tldr gcc`
