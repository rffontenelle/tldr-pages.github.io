# qm-resize

> Cette commande est un alias de `qm-disk-resize`.
> Plus d'informations : <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Voir la documentation de la commande originale :

`tldr qm-disk-resize`
