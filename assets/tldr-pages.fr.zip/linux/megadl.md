# megadl

> Cette commande est un alias de `megatools-dl`.
> Plus d'informations : <https://megatools.megous.com/man/megatools-dl.html>.

- Voir la documentation de la commande originale :

`tldr megatools-dl`
