# nmtui-connect

> Cette commande est un alias de `nmtui`.

- Voir la documentation de la commande originale :

`tldr nmtui`
