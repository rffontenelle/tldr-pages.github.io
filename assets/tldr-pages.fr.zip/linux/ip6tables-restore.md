# ip6tables-restore

> Cette commande est un alias de `iptables-restore`.

- Voir la documentation de la commande originale :

`tldr iptables-restore`
