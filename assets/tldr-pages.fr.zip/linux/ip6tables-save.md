# ip6tables-save

> Cette commande est un alias de `iptables-save`.

- Voir la documentation de la commande originale :

`tldr iptables-save`
