# pkgctl

> Cette commande est un alias de `pkgctl auth`.
> Plus d'informations : <https://man.archlinux.org/man/pkgctl.1>.

- Voir la documentation de la commande originale :

`tldr pkgctl auth`
