# a2ensite

> Active un hôte virtuel Apache sur des systèmes d'exploitation (SE) basés sur Debian.
> Plus d'informations : <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Active un hôte virtuel :

`sudo a2ensite {{hote_virtuel}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2ensite --quiet {{hote_virtuel}}`
