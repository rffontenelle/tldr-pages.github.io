# kafkacat

> Cette commande est un alias de `kcat`.

- Voir la documentation de la commande originale :

`tldr kcat`
