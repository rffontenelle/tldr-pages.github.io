# musl-gcc

> Cette commande est un alias de `gcc`.
> Plus d'informations : <https://manned.org/musl-gcc>.

- Voir la documentation de la commande originale :

`tldr gcc`
