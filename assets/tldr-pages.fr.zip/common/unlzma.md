# unlzma

> Cette commande est un alias de `xz`.
> Plus d'informations : <https://manned.org/unlzma>.

- Voir la documentation de la commande originale :

`tldr xz`
