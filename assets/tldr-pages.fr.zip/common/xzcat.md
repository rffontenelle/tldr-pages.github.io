# xzcat

> Cette commande est un alias de `xz`.
> Plus d'informations : <https://manned.org/xzcat>.

- Voir la documentation de la commande originale :

`tldr xz`
