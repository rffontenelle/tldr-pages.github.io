# just

> Cette commande est un alias de `just.1`.

- Voir la documentation de la commande originale :

`tldr just.1`
