# cd

> Modifie le répertoire de travail actuel.
> Plus d'informations : <https://manned.org/cd>.

- Se déplace vers le répertoire donné :

`cd {{chemin/vers/dossier}}`

- Remonte vers le parent du répertoire actuel :

`cd ..`

- Se déplace vers le répertoire personnel de l'utilisateur actuel :

`cd`

- Se déplace vers le répertoire personnel de l'utilisateur donné :

`cd ~{{nom_utilisateur}}`

- Retourne au répertoire précédent :

`cd -`

- Se déplace vers le répertoire racine :

`cd /`
