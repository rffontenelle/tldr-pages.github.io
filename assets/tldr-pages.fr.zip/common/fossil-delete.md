# fossil-delete

> Cette commande est un alias de `fossil rm`.
> Plus d'informations : <https://fossil-scm.org/home/help/delete>.

- Voir la documentation de la commande originale :

`tldr fossil rm`
