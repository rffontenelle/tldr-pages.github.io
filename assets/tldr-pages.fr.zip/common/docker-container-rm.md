# docker-container-rm

> Cette commande est un alias de `docker rm`.
> Plus d'informations : <https://docs.docker.com/engine/reference/commandline/rm>.

- Voir la documentation de la commande originale :

`tldr docker rm`
