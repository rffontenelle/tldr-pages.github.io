# docker-container-diff

> Cette commande est un alias de `docker diff`.
> Plus d'informations : <https://docs.docker.com/engine/reference/commandline/diff>.

- Voir la documentation de la commande originale :

`tldr docker diff`
