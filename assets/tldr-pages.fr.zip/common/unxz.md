# unxz

> Cette commande est un alias de `xz`.
> Plus d'informations : <https://manned.org/unxz>.

- Voir la documentation de la commande originale :

`tldr xz`
