# lima

> Cette commande est un alias de `limactl`.
> Plus d'informations : <https://github.com/lima-vm/lima>.

- Voir la documentation de la commande originale :

`tldr limactl`
