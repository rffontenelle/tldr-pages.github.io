# netcat

> Cette commande est un alias de `nc`.

- Voir la documentation de la commande originale :

`tldr nc`
