# git repack

> Empaqueter les objets décompressés dans un dépôt Git.
> Plus d'informations : <https://git-scm.com/docs/git-repack>.

- Empaqueter les objets décompressés dans le dépôt courant :

`git repack`

- Également supprimer les objets redondants après empaquetage :

`git repack -d`
