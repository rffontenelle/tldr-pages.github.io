# clamav

> Cette commande est un alias de `clamdscan`.
> Plus d'informations : <https://www.clamav.net>.

- Voir la documentation de la commande originale :

`tldr clamdscan`
