# lzmore

> Cette commande est un alias de `xzmore`.

- Voir la documentation de la commande originale :

`tldr xzmore`
