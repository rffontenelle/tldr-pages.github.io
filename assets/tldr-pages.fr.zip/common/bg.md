# bg

> Reprend l'exécution de tâches qui ont été suspendues (en utilisant `Ctrl + Z` par exemple) en arrière-plan.
> Plus d'informations : <https://manned.org/bg>.

- Reprend l'exécution de la dernière tâche suspendue en arrière-plan :

`bg`

- Reprend l'exécution d'une tâche précise (utiliser `jobs -l` pour obtenir son ID) en arrière-plan :

`bg %{{job_id}}`
