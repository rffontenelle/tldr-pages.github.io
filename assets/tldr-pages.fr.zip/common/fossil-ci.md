# fossil-ci

> Cette commande est un alias de `fossil-commit`.
> Plus d'informations : <https://fossil-scm.org/home/help/commit>.

- Voir la documentation de la commande originale :

`tldr fossil-commit`
