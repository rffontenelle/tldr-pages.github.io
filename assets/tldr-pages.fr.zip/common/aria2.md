# aria2

> Cette commande est un alias de `aria2c`.

- Voir la documentation pour la commande :

`tldr aria2c`
