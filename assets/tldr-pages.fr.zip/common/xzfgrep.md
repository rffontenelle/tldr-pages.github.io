# xzfgrep

> Cette commande est un alias de `xzgrep`.

- Voir la documentation de la commande originale :

`tldr xzgrep`
