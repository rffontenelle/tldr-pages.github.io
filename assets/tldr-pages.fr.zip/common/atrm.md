# atrm

> Supprime les travaux programmés par la commande `at` ou `batch`.
> Pour retrouver les numéros des travaux, utilise `atq`.
> Plus d'informations : <https://manned.org/atrm>.

- Supprime le travail numéro 10 :

`atrm {{10}}`

- Supprime plusieurs travaux, séparés par un espace :

`atrm {{15}} {{17}} {{22}}`
