# docker rename

> Renomme un conteneur.
> Plus d'informations : <https://docs.docker.com/engine/reference/commandline/rename>.

- Renomme un conteneur :

`docker rename {{conteneur}} {{nouveau_nom}}`

- Affiche l'aide :

`docker rename --help`
