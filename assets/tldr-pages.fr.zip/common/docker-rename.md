# docker rename

> Renomme un conteneur.
> Plus d'informations : <https://docs.docker.com/reference/cli/docker/container/rename/>.

- Renomme un conteneur :

`docker rename {{conteneur}} {{nouveau_nom}}`

- Affiche l'aide :

`docker rename --help`
