# deluged

> Un processus démon pour le client BitTorrent Deluge.
> Plus d'informations : <https://deluge-torrent.org>.

- Lance le démon Deluge :

`deluged`

- Lance le démon Deluge sur un port spécifique :

`deluged -p {{port}}`

- Lance le démon Deluge à l'aide d'un fichier de configuration spécifique :

`deluged -c {{chemin/vers/fichier_configuration}}`

- Lance le démon Deluge et enregistre les journaux dans un fichier :

`deluged -l {{chemin/vers/fichier_journalisation}}`
