# linode-cli

> Cette commande est un alias de `linode-cli account`.
> Plus d'informations : <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Voir la documentation de la commande originale :

`tldr linode-cli account`
