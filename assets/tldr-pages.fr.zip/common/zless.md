# zless

> Lire des fichiers compressés.
> Plus d'informations : <https://manned.org/zless>.

- Parcourir une archive compressée avec `less` :

`zless {{fichier.txt.gz}}`
