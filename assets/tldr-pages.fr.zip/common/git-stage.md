# git stage

> Cette commande est un alias de `git add`.
> Plus d'informations : <https://git-scm.com/docs/git-stage>.

- Voir la documentation de la commande originale :

`tldr git add`
