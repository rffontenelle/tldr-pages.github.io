# anki

> Programme de cartes mémo-techniques, puissant et intelligent.
> Plus d'informations : <https://docs.ankiweb.net>.

- Lancer `anki`:

`anki`

- Lancer `anki` avec un profil spécifique :

`anki -p {{nom_de_profile}}`

- Lancer `anki` dans une langue spécifique :

`anki -l {{langue}}`

- Lancer `anki` depuis un dossier spécifique au lieu de celui par défaut (`~/Anki`):

`anki -b {{chemin/vers/dossier}}`
