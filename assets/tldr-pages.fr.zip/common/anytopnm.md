# anytopnm

> Convertis n'importe quel type de fichier image vers un format d'image commun.
> Plus d'informations : <https://netpbm.sourceforge.net/doc/anytopnm.html>.

- Convertis une image d'entrée au format PBM, PGM ou PPM, peut importe le type d'entrée :

`anytopnm {{chemin/vers/entrée}} > {{chemin/vers/sortie.pnm}}`

- Afficher la version :

`anytopnm -version`
