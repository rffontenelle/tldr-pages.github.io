# hd

> Cette commande est un alias de `hexdump`.
> Plus d'informations : <https://manned.org/hd.1>.

- Voir la documentation de la commande originale :

`tldr hexdump`
