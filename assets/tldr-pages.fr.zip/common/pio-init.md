# pio-init

> Cette commande est un alias de `pio project`.

- Voir la documentation de la commande originale :

`tldr pio project`
