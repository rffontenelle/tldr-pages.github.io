# lzcmp

> Cette commande est un alias de `xzcmp`.

- Voir la documentation de la commande originale :

`tldr xzcmp`
