# unzstd

> Cette commande est un alias de `zstd`.

- Voir la documentation de la commande originale :

`tldr zstd`
