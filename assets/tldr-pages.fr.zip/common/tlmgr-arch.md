# tlmgr-arch

> Cette commande est un alias de `tlmgr platform`.
> Plus d'informations : <https://www.tug.org/texlive/tlmgr.html>.

- Voir la documentation de la commande originale :

`tldr tlmgr platform`
