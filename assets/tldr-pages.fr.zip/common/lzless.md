# lzless

> Cette commande est un alias de `xzless`.

- Voir la documentation de la commande originale :

`tldr xzless`
