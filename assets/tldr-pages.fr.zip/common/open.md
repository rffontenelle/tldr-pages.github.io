# open

> Cette commande est un alias de `open -p osx`.

- Voir la documentation de la commande originale :

`tldr open -p osx`
