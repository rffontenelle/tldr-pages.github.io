# ntl

> Denne kommandoen er et alias for `netlify`.
> Mer informasjon: <https://cli.netlify.com>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr netlify`
