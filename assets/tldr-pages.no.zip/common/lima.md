# lima

> Denne kommandoen er et alias for `limactl`.
> Mer informasjon: <https://github.com/lima-vm/lima>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr limactl`
