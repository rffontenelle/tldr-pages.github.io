# lb

> Et verktøy for å administrere en blogg i den gjeldende katalogen.
> Utkast og innlegg velges interaktivt når man kjører kommandoene.
> Mer informasjon: <https://github.com/LukeSmithxyz/lb>.

- Lag et nytt utkast:

`lb new`

- Rediger et utkast:

`lb edit`

- Slett et utkast:

`lb trash`

- Publiser et utkast:

`lb publish`

- Slett et publisert innlegg:

`lb delete`

- Avpubliser et publisert innlegg for å redigere det som et utkast igjen:

`lb revise`
