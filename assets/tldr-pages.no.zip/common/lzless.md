# lzless

> Denne kommandoen er et alias for `xzless`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xzless`
