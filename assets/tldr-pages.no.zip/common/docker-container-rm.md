# docker-container-rm

> Denne kommandoen er et alias for `docker rm`.
> Mer informasjon: <https://docs.docker.com/engine/reference/commandline/rm>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr docker rm`
