# xzcat

> Denne kommandoen er et alias for `xz`.
> Mer informasjon: <https://manned.org/xzcat>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xz`
