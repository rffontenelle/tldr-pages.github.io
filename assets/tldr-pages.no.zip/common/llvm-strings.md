# llvm-strings

> Denne kommandoen er et alias for `strings`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr strings`
