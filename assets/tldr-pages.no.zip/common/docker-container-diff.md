# docker-container-diff

> Denne kommandoen er et alias for `docker diff`.
> Mer informasjon: <https://docs.docker.com/engine/reference/commandline/diff>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr docker diff`
