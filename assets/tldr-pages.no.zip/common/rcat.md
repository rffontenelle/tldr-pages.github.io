# rcat

> Denne kommandoen er et alias for `rc`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr rc`
