# open

> Denne kommandoen er et alias for `open -p osx`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr open -p osx`
