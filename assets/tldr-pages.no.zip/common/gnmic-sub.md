# gnmic-sub

> Denne kommandoen er et alias for `gnmic subscribe`.
> Mer informasjon: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr gnmic subscribe`
