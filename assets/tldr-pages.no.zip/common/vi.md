# vi

> Denne kommandoen er et alias for `vim`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr vim`
