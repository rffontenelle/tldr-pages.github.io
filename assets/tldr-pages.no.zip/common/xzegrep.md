# xzegrep

> Denne kommandoen er et alias for `xzgrep`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xzgrep`
