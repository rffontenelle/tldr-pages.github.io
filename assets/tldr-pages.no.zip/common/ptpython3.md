# ptpython3

> Denne kommandoen er et alias for `ptpython`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr ptpython`
