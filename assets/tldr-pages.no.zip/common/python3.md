# python3

> Denne kommandoen er et alias for `python`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr python`
