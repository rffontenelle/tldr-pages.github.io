# kafkacat

> Denne kommandoen er et alias for `kcat`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr kcat`
