# fossil-delete

> Denne kommandoen er et alias for `fossil rm`.
> Mer informasjon: <https://fossil-scm.org/home/help/delete>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil rm`
