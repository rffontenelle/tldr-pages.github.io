# docker-container-rename

> Denne kommandoen er et alias for `docker rename`.
> Mer informasjon: <https://docs.docker.com/engine/reference/commandline/rename>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr docker rename`
