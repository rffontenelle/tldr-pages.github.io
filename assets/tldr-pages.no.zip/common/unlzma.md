# unlzma

> Denne kommandoen er et alias for `xz`.
> Mer informasjon: <https://manned.org/unlzma>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xz`
