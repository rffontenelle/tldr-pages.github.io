# unxz

> Denne kommandoen er et alias for `xz`.
> Mer informasjon: <https://manned.org/unxz>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xz`
