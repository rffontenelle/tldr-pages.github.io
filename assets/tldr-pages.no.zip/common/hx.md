# hx

> Denne kommandoen er et alias for `helix`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr helix`
