# llvm-objdump

> Denne kommandoen er et alias for `objdump`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr objdump`
