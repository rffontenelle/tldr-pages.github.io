# hd

> Denne kommandoen er et alias for `hexdump`.
> Mer informasjon: <https://manned.org/hd.1>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr hexdump`
