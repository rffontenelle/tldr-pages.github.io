# zstdmt

> Denne kommandoen er et alias for `zstd`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr zstd`
