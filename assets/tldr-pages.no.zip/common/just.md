# just

> Denne kommandoen er et alias for `just.1`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr just.1`
