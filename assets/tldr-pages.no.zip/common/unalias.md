# unalias

> Fjern aliaser.
> Mer informasjon: <https://manned.org/unalias>.

- Fjern et alias:

`unalias {{alias_navn}}`

- Fjern alle aliaser:

`unalias -a`
