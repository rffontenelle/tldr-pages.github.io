# linode-cli

> Denne kommandoen er et alias for `linode-cli account`.
> Mer informasjon: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr linode-cli account`
