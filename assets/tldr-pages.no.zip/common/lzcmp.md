# lzcmp

> Denne kommandoen er et alias for `xzcmp`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xzcmp`
