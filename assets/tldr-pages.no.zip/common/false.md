# false

> Returner en utgangskode på 1.
> Mer informasjon: <https://www.gnu.org/software/coreutils/false>.

- Returner en utgangskode på 1:

`false`
