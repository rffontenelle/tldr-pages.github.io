# pwsh

> Denne kommandoen er et alias for `powershell`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr powershell`
