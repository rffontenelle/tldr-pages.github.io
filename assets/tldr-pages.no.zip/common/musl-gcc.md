# musl-gcc

> Denne kommandoen er et alias for `gcc`.
> Mer informasjon: <https://manned.org/musl-gcc>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr gcc`
