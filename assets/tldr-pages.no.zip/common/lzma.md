# lzma

> Denne kommandoen er et alias for `xz`.
> Mer informasjon: <https://manned.org/lzma>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xz`
