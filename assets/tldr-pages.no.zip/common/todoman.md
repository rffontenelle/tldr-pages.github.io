# todoman

> Denne kommandoen er et alias for `todo`.
> Mer informasjon: <https://todoman.readthedocs.io/>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr todo`
