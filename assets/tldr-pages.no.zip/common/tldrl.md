# tldrl

> Denne kommandoen er et alias for `tldr-lint`.
> Mer informasjon: <https://github.com/tldr-pages/tldr-lint>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr tldr-lint`
