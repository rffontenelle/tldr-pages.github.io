# clojure

> Denne kommandoen er et alias for `clj`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr clj`
