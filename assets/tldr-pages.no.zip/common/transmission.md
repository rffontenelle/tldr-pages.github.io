# transmission

> Denne kommandoen er et alias for `transmission-daemon`.
> Mer informasjon: <https://transmissionbt.com/>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr transmission-daemon`
