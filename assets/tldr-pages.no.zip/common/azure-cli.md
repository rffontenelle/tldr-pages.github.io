# azure-cli

> Denne kommandoen er et alias for `az`.
> Mer informasjon: <https://learn.microsoft.com/cli/azure>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr az`
