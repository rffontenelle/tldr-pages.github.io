# cat

> Skriv ut og sammenføy filer.
> Mer informasjon: <https://manned.org/cat.1posix>.

- Skriv ut innholdet i en fil til standard utgang:

`cat {{fil}}`

- Sammenføy flere filer til en målfil:

`cat {{fil1 fil2 ...}} > {{målfil}}`

- Legg til flere filer til målfilen:

`cat {{fil1 fil2 ...}} >> {{målfil}}`
