# bundler

> Denne kommandoen er et alias for `bundle`.
> Mer informasjon: <https://bundler.io/man/bundle.1.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr bundle`
