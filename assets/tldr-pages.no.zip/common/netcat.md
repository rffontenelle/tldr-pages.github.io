# netcat

> Denne kommandoen er et alias for `nc`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr nc`
