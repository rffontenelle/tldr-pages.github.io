# time

> See hvor lang en kommand tar.
> Mer informasjon: <https://manned.org/time>.

- Tid "ls":

`time ls`
