# cron

> Denne kommandoen er et alias for `crontab`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr crontab`
