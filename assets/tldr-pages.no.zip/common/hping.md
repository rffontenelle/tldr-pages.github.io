# hping

> Denne kommandoen er et alias for `hping3`.
> Mer informasjon: <https://github.com/antirez/hping>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr hping3`
