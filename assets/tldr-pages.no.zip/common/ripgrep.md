# ripgrep

> Denne kommandoen er et alias for `rg`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr rg`
