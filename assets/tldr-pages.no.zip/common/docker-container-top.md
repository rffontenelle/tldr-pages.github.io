# docker-container-top

> Denne kommandoen er et alias for `docker top`.
> Mer informasjon: <https://docs.docker.com/engine/reference/commandline/top>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr docker top`
