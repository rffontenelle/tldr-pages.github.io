# lzmore

> Denne kommandoen er et alias for `xzmore`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xzmore`
