# sls

> Denne kommandoen er et alias for `where-object`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr where-object`
