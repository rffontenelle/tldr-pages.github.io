# gal

> Denne kommandoen er et alias for `get-alias`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr get-alias`
