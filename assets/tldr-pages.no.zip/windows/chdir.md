# chdir

> Denne kommandoen er et alias for `cd`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr cd`
