# cinst

> Denne kommandoen er et alias for `choco install`.
> Mer informasjon: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco install`
