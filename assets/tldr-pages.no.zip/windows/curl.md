# curl

> Denne kommandoen er et alias for `curl -p common`.
> Mer informasjon: <https://curl.se>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr curl -p common`
