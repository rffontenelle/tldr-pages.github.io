# sc-create

> Denne kommandoen er et alias for `sc`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr sc`
