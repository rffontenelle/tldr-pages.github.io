# slmgr

> Denne kommandoen er et alias for `slmgr.vbs`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr slmgr.vbs`
