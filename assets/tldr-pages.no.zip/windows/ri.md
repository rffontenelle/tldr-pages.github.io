# ri

> Denne kommandoen er et alias for `remove-item`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr remove-item`
