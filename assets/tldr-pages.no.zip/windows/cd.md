# cd

> Denne kommandoen er et alias for `set-location`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr set-location`
