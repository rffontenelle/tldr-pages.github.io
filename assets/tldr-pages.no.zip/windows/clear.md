# clear

> Denne kommandoen er et alias for `clear-host`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr clear-host`
