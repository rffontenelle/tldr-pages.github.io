# ni

> Denne kommandoen er et alias for `new-item`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr new-item`
