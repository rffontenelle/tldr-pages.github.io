# cls

> Denne kommandoen er et alias for `clear-host`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr clear-host`
