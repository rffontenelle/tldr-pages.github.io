# wget

> Denne kommandoen er et alias for `wget -p common`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr wget -p common`
