# wget

> Denne kommandoen er et alias for `wget -p common`.
> Mer informasjon: <https://www.gnu.org/software/wget>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr wget -p common`
