# sc-query

> Denne kommandoen er et alias for `sc`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr sc`
