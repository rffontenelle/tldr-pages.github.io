# cpush

> Denne kommandoen er et alias for `choco-push`.
> Mer informasjon: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco-push`
