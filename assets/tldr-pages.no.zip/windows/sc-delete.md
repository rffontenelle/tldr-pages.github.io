# sc-delete

> Denne kommandoen er et alias for `sc`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr sc`
