# rd

> Denne kommandoen er et alias for `rmdir`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr rmdir`
