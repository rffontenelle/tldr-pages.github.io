# sc-config

> Denne kommandoen er et alias for `sc`.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr sc`
