# iwr

> Denne kommandoen er et alias for `invoke-webrequest`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr invoke-webrequest`
