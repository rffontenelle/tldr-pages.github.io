# clist

> Denne kommandoen er et alias for `choco list`.
> Mer informasjon: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco list`
