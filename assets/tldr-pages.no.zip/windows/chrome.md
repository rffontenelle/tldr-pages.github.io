# chrome

> Denne kommandoen er et alias for `chromium`.
> Mer informasjon: <https://chrome.google.com>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr chromium`
