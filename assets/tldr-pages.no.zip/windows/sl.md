# sl

> Denne kommandoen er et alias for `set-location`.
> Mer informasjon: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr set-location`
