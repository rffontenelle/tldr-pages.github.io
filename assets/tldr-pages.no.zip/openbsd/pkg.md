# pkg

> Denne kommandoen er et alias for `pkg_add`.
> Mer informasjon: <https://www.openbsd.org/faq/faq15.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr pkg_add`
