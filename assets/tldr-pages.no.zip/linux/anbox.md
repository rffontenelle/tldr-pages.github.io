# anbox

> Kjør Android-applikasjoner på et hvilket som helst GNU/Linux-operativsystem.
> Mer informasjon: <https://manned.org/anbox>.

- Start Anbox i appbehandleren:

`anbox launch --package={{org.anbox.appmgr}} --component={{org.anbox.appmgr.AppViewActivity}}`
