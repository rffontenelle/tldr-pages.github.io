# alternatives

> Denne kommandoen er et alias for `update-alternatives`.
> Mer informasjon: <https://manned.org/alternatives>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr update-alternatives`
