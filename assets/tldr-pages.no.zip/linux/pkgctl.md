# pkgctl

> Denne kommandoen er et alias for `pkgctl auth`.
> Mer informasjon: <https://man.archlinux.org/man/pkgctl.1>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr pkgctl auth`
