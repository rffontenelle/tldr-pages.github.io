# bspwm

> Denne kommandoen er et alias for `bspc`.
> Mer informasjon: <https://github.com/baskerville/bspwm>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr bspc`
