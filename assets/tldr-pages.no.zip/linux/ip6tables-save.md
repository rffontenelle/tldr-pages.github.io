# ip6tables-save

> Denne kommandoen er et alias for `iptables-save`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr iptables-save`
