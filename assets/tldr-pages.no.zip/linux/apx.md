# apx

> Denne kommandoen er et alias for `apx pkgmanagers`.
> Mer informasjon: <https://github.com/Vanilla-OS/apx>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr apx pkgmanagers`
