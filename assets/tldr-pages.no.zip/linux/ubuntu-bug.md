# ubuntu-bug

> Denne kommandoen er et alias for `apport-bug`.
> Mer informasjon: <https://manned.org/ubuntu-bug>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr apport-bug`
