# ip6tables-restore

> Denne kommandoen er et alias for `iptables-restore`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr iptables-restore`
