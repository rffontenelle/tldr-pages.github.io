# ip6tables

> Denne kommandoen er et alias for `iptables`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr iptables`
