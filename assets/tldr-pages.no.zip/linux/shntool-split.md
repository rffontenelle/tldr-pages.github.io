# shntool-split

> Denne kommandoen er et alias for `shnsplit`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr shnsplit`
