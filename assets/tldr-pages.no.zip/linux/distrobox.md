# distrobox

> Denne kommandoen er et alias for `distrobox-create`.
> Mer informasjon: <https://github.com/89luca89/distrobox>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr distrobox-create`
