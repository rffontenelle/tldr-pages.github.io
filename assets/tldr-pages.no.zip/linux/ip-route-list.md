# ip route list

> Denne kommandoen er et alias for  `ip route show`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr ip-route-show`
