# mount.smb3

> Denne kommandoen er et alias for `mount.cifs`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr mount.cifs`
