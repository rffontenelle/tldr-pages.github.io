# cc

> Denne kommandoen er et alias for `gcc`.
> Mer informasjon: <https://gcc.gnu.org>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr gcc`
