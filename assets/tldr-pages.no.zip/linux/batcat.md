# batcat

> Denne kommandoen er et alias for `bat`.
> Mer informasjon: <https://github.com/sharkdp/bat>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr bat`
