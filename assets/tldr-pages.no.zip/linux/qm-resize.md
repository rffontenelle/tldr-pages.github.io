# qm-resize

> Denne kommandoen er et alias for `qm-disk-resize`.
> Mer informasjon: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr qm-disk-resize`
