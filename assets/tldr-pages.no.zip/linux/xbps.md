# xbps

> Denne kommandoen er et alias for `xbps-install`.
> Mer informasjon: <https://docs.voidlinux.org/xbps/index.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr xbps-install`
