# systemd-umount

> Denne kommandoen er et alias for `systemd-mount`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr systemd-mount`
