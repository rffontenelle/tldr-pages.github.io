# cgroups

> Denne kommandoen er et alias for `cgclassify`.
> Mer informasjon: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr cgclassify`
