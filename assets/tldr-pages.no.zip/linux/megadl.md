# megadl

> Denne kommandoen er et alias for `megatools-dl`.
> Mer informasjon: <https://megatools.megous.com/man/megatools-dl.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr megatools-dl`
