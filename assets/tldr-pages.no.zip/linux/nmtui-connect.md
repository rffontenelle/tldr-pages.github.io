# nmtui-connect

> Denne kommandoen er et alias for `nmtui`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr nmtui`
