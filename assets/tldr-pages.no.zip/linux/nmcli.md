# nmcli

> Denne kommandoen er et alias for `nmcli agent`.
> Mer informasjon: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr nmcli agent`
