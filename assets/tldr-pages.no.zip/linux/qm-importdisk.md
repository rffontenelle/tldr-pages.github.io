# qm-importdisk

> Denne kommandoen er et alias for `qm disk import`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr qm disk import`
