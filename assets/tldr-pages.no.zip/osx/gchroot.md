# gchroot

> Denne kommandoen er et alias for `-p linux chroot`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux chroot`
