# gtime

> Denne kommandoen er et alias for `-p linux time`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux time`
