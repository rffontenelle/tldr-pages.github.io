# grlogin

> Denne kommandoen er et alias for `-p linux rlogin`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux rlogin`
