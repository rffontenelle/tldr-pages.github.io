# gtalk

> Denne kommandoen er et alias for `-p linux talk`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux talk`
