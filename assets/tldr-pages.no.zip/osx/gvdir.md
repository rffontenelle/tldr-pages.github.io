# gvdir

> Denne kommandoen er et alias for `-p linux vdir`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux vdir`
