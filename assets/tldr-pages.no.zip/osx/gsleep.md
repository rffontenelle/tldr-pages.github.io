# gsleep

> Denne kommandoen er et alias for `-p linux sleep`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux sleep`
