# gyes

> Denne kommandoen er et alias for `-p linux yes`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux yes`
