# gping

> Denne kommandoen er et alias for `-p linux ping`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux ping`
