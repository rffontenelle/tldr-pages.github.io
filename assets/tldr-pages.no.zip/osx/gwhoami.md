# gwhoami

> Denne kommandoen er et alias for `-p linux whoami`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux whoami`
