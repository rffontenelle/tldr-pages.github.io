# gkill

> Denne kommandoen er et alias for `-p linux kill`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux kill`
