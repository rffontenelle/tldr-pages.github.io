# gsha384sum

> Denne kommandoen er et alias for `-p linux sha384sum`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux sha384sum`
