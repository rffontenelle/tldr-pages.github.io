# gwho

> Denne kommandoen er et alias for `-p linux who`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux who`
