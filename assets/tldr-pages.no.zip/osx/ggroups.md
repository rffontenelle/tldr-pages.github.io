# ggroups

> Denne kommandoen er et alias for `-p linux groups`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux groups`
