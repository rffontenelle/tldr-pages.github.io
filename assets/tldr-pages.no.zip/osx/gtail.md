# gtail

> Denne kommandoen er et alias for `-p linux tail`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux tail`
