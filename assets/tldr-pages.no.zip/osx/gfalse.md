# gfalse

> Denne kommandoen er et alias for `-p linux false`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux false`
