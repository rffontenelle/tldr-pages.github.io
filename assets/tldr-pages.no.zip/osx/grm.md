# grm

> Denne kommandoen er et alias for `-p linux rm`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux rm`
