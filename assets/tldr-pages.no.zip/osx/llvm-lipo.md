# llvm-lipo

> Denne kommandoen er et alias for `lipo`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr lipo`
