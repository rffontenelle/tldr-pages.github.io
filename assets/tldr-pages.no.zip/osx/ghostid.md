# ghostid

> Denne kommandoen er et alias for `-p linux hostid`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux hostid`
