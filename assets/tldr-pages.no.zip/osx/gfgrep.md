# gfgrep

> Denne kommandoen er et alias for `-p linux fgrep`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux fgrep`
