# gtruncate

> Denne kommandoen er et alias for `-p linux truncate`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux truncate`
