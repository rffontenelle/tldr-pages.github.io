# gtee

> Denne kommandoen er et alias for `-p linux tee`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux tee`
