# gecho

> Denne kommandoen er et alias for `-p linux echo`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux echo`
