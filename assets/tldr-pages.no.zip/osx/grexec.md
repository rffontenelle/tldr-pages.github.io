# grexec

> Denne kommandoen er et alias for `-p linux rexec`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux rexec`
