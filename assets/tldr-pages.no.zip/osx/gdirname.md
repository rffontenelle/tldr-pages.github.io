# gdirname

> Denne kommandoen er et alias for `-p linux dirname`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux dirname`
