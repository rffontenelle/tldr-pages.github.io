# gexpr

> Denne kommandoen er et alias for `-p linux expr`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux expr`
