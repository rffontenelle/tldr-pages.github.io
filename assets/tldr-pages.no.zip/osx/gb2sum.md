# gb2sum

> Denne kommandoen er et alias for `-p linux b2sum`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux b2sum`
