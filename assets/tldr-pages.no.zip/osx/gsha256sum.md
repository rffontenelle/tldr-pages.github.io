# gsha256sum

> Denne kommandoen er et alias for `-p linux sha256sum`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux sha256sum`
