# gtraceroute

> Denne kommandoen er et alias for `-p linux traceroute`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux traceroute`
