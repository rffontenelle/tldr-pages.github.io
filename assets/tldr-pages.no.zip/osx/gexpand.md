# gexpand

> Denne kommandoen er et alias for `-p linux expand`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux expand`
