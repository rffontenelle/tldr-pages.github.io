# gfactor

> Denne kommandoen er et alias for `-p linux factor`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux factor`
