# gstat

> Denne kommandoen er et alias for `-p linux stat`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux stat`
