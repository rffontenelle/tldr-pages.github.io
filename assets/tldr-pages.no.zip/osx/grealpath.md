# grealpath

> Denne kommandoen er et alias for `-p linux realpath`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux realpath`
