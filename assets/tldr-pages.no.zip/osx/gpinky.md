# gpinky

> Denne kommandoen er et alias for `-p linux pinky`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux pinky`
