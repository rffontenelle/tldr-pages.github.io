# launchd

> Denne kommandoen er et alias for `launchctl`.
> Mer informasjon: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr launchctl`
