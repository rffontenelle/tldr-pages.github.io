# glibtool

> Denne kommandoen er et alias for `-p linux libtool`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux libtool`
