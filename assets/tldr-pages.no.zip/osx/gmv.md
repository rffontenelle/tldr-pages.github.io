# gmv

> Denne kommandoen er et alias for `-p linux mv`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux mv`
