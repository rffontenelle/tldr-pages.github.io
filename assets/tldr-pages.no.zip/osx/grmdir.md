# grmdir

> Denne kommandoen er et alias for `-p linux rmdir`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux rmdir`
