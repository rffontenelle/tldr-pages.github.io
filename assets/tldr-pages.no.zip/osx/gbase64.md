# gbase64

> Denne kommandoen er et alias for `-p linux base64`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux base64`
