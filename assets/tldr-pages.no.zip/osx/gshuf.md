# gshuf

> Denne kommandoen er et alias for `-p linux shuf`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux shuf`
