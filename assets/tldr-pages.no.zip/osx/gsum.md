# gsum

> Denne kommandoen er et alias for `-p linux sum`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux sum`
