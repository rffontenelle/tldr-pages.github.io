# gmake

> Denne kommandoen er et alias for `-p linux make`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux make`
