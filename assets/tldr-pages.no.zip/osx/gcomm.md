# gcomm

> Denne kommandoen er et alias for `-p linux comm`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux comm`
