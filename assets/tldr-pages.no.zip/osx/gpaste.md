# gpaste

> Denne kommandoen er et alias for `-p linux paste`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux paste`
