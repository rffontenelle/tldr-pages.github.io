# gnohup

> Denne kommandoen er et alias for `-p linux nohup`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux nohup`
