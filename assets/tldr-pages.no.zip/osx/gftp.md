# gftp

> Denne kommandoen er et alias for `-p linux ftp`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux ftp`
