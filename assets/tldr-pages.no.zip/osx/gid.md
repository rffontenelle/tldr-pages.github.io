# gid

> Denne kommandoen er et alias for `-p linux id`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux id`
