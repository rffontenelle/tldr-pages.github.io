# gtar

> Denne kommandoen er et alias for `-p linux tar`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux tar`
