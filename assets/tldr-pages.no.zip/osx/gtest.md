# gtest

> Denne kommandoen er et alias for `-p linux test`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux test`
