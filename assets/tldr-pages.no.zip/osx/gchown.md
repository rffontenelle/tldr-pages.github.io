# gchown

> Denne kommandoen er et alias for `-p linux chown`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux chown`
