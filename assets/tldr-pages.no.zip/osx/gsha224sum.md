# gsha224sum

> Denne kommandoen er et alias for `-p linux sha224sum`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux sha224sum`
