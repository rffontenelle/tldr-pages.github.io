# aa

> Denne kommandoen er et alias for `yaa`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr yaa`
