# gping6

> Denne kommandoen er et alias for `-p linux ping6`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux ping6`
