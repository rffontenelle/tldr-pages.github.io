# gptx

> Denne kommandoen er et alias for `-p linux ptx`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux ptx`
