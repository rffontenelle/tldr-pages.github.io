# gmkfifo

> Denne kommandoen er et alias for `-p linux mkfifo`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux mkfifo`
