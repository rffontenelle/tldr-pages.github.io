# gindent

> Denne kommandoen er et alias for `-p linux indent`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux indent`
