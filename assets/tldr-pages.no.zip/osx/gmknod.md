# gmknod

> Denne kommandoen er et alias for `-p linux mknod`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux mknod`
