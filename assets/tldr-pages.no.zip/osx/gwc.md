# gwc

> Denne kommandoen er et alias for `-p linux wc`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux wc`
