# gifconfig

> Denne kommandoen er et alias for `-p linux ifconfig`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux ifconfig`
