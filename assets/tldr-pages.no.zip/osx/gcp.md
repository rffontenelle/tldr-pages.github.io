# gcp

> Denne kommandoen er et alias for `-p linux cp`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux cp`
