# gunits

> Denne kommandoen er et alias for `-p linux units`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux units`
