# gdircolors

> Denne kommandoen er et alias for `-p linux dircolors`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux dircolors`
