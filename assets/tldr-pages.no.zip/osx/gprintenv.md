# gprintenv

> Denne kommandoen er et alias for `-p linux printenv`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux printenv`
