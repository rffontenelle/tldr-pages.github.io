# guniq

> Denne kommandoen er et alias for `-p linux uniq`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux uniq`
