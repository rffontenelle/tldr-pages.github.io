# gls

> Denne kommandoen er et alias for `-p linux ls`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux ls`
