# gdf

> Denne kommandoen er et alias for `-p linux df`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux df`
