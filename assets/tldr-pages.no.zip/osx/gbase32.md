# gbase32

> Denne kommandoen er et alias for `-p linux base32`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux base32`
