# gupdatedb

> Denne kommandoen er et alias for `-p linux updatedb`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux updatedb`
