# gxargs

> Denne kommandoen er et alias for `-p linux xargs`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux xargs`
