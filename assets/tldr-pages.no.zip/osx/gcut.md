# gcut

> Denne kommandoen er et alias for `-p linux cut`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux cut`
