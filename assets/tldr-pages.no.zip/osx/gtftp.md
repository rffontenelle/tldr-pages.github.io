# gtftp

> Denne kommandoen er et alias for `-p linux tftp`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux tftp`
