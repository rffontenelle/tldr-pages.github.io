# gnproc

> Denne kommandoen er et alias for `-p linux nproc`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux nproc`
