# ginstall

> Denne kommandoen er et alias for `-p linux install`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux install`
