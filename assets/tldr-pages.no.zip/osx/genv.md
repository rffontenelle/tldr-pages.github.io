# genv

> Denne kommandoen er et alias for `-p linux env`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux env`
