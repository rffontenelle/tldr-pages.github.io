# gdir

> Denne kommandoen er et alias for `-p linux dir`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux dir`
