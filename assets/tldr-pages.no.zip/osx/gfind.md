# gfind

> Denne kommandoen er et alias for `-p linux find`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux find`
