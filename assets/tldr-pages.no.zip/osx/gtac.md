# gtac

> Denne kommandoen er et alias for `-p linux tac`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux tac`
