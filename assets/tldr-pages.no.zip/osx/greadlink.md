# greadlink

> Denne kommandoen er et alias for `-p linux readlink`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux readlink`
