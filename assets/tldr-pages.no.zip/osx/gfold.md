# gfold

> Denne kommandoen er et alias for `-p linux fold`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux fold`
