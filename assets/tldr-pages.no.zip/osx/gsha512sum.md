# gsha512sum

> Denne kommandoen er et alias for `-p linux sha512sum`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux sha512sum`
