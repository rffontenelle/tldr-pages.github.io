# gsplit

> Denne kommandoen er et alias for `-p linux split`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux split`
