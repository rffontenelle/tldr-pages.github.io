# gchgrp

> Denne kommandoen er et alias for `-p linux chgrp`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux chgrp`
