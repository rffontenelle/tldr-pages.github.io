# gdd

> Denne kommandoen er et alias for `-p linux dd`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux dd`
