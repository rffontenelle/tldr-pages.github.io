# gtrue

> Denne kommandoen er et alias for `-p linux true`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr -p linux true`
