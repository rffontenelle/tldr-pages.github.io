# qm-resize

> Ця команда є псевдонімом для `qm-disk-resize`.
> Більше інформації: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Дивись документацію для оригінальної команди:

`tldr qm-disk-resize`
