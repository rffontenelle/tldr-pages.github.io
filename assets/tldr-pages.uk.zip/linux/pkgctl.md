# pkgctl

> Ця команда є псевдонімом для `pkgctl auth`.
> Більше інформації: <https://man.archlinux.org/man/pkgctl.1>.

- Дивись документацію для оригінальної команди:

`tldr pkgctl auth`
