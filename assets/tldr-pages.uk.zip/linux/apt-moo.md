# apt moo

> Пасхалка від менеджеру пакетів `APT`.
> Більше інформації: <https://manpages.debian.org/latest/apt/apt.8.html>.

- Друкує коров'ячу пасхалку:

`apt moo`
