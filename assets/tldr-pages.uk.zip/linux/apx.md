# apx

> Ця команда є псевдонімом для `apx pkgmanagers`.
> Більше інформації: <https://github.com/Vanilla-OS/apx>.

- Дивись документацію для оригінальної команди:

`tldr apx pkgmanagers`
