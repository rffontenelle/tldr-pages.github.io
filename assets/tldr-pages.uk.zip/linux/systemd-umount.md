# systemd-umount

> Ця команда є псевдонімом для `systemd-mount`.

- Дивись документацію для оригінальної команди:

`tldr systemd-mount`
