# distrobox

> Ця команда є псевдонімом для `distrobox-create`.
> Більше інформації: <https://github.com/89luca89/distrobox>.

- Дивись документацію для оригінальної команди:

`tldr distrobox-create`
