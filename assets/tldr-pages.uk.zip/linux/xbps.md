# xbps

> Ця команда є псевдонімом для `xbps-install`.
> Більше інформації: <https://docs.voidlinux.org/xbps/index.html>.

- Дивись документацію для оригінальної команди:

`tldr xbps-install`
