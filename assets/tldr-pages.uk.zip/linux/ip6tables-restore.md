# ip6tables-restore

> Ця команда є псевдонімом для `iptables-restore`.

- Дивись документацію для оригінальної команди:

`tldr iptables-restore`
