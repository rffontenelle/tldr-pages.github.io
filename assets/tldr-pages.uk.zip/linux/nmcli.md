# nmcli

> Ця команда є псевдонімом для `nmcli agent`.
> Більше інформації: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Дивись документацію для оригінальної команди:

`tldr nmcli agent`
