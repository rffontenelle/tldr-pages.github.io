# ip6tables-save

> Ця команда є псевдонімом для `iptables-save`.

- Дивись документацію для оригінальної команди:

`tldr iptables-save`
