# alternatives

> Ця команда є псевдонімом для `update-alternatives`.
> Більше інформації: <https://manned.org/alternatives>.

- Дивись документацію для оригінальної команди:

`tldr update-alternatives`
