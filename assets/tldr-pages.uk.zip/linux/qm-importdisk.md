# qm-importdisk

> Ця команда є псевдонімом для `qm disk import`.

- Дивись документацію для оригінальної команди:

`tldr qm disk import`
