# megadl

> Ця команда є псевдонімом для `megatools-dl`.
> Більше інформації: <https://megatools.megous.com/man/megatools-dl.html>.

- Дивись документацію для оригінальної команди:

`tldr megatools-dl`
