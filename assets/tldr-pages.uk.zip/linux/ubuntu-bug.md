# ubuntu-bug

> Ця команда є псевдонімом для `apport-bug`.
> Більше інформації: <https://manned.org/ubuntu-bug>.

- Дивись документацію для оригінальної команди:

`tldr apport-bug`
