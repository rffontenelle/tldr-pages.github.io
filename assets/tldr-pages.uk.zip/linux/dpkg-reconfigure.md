# dpkg-reconfigure

> Змінює конфігурацію вже встановленого пакету.
> Більше інформації: <https://manpages.debian.org/latest/debconf/dpkg-reconfigure.8.html>.

- Змінити конфігурацію одного або декількох пакетів:

`dpkg-reconfigure {{пакунок1 пакунок2 ...}}`
