# bspwm

> Ця команда є псевдонімом для `bspc`.
> Більше інформації: <https://github.com/baskerville/bspwm>.

- Дивись документацію для оригінальної команди:

`tldr bspc`
