# cgroups

> Ця команда є псевдонімом для `cgclassify`.
> Більше інформації: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Дивись документацію для оригінальної команди:

`tldr cgclassify`
