# getprop

> Виводить інформацію про системні властивості Android.
> Більше інформації: <https://manned.org/getprop>.

- Виводить інформацію про системні властивості Android:

`getprop`

- Виводить інформацію про специфічну системну властивість:

`getprop {{властивість}}`

- Виводить рівень SDK API:

`getprop {{ro.build.version.sdk}}`

- Виводить версію Android:

`getprop {{ro.build.version.release}}`

- Виводить модель девайсу Android:

`getprop {{ro.vendor.product.model}}`

- Виводить розблокований статус OEM:

`getprop {{ro.oem_unlock_supported}}`

- Виводить MAC адресу Wi-Fi карти Android:

`getprop {{ro.boot.wifimacaddr}}`
