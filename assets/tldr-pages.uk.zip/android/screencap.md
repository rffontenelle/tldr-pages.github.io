# screencap

> Зробіть знімок мобільного екрану.
> Ця команда може бути виконана тільки за допомогою `adb shell`.
> Більше інформації: <https://developer.android.com/studio/command-line/adb#screencap>.

- Зробіть знімок мобільного екрану:

`screencap {{шлях/до/файлу}}`
