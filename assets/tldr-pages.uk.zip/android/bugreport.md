# bugreport

> Показати звіт багів в Android.
> Ця команда може бути виконана тільки за допомогою `adb shell`.
> Більше інформації: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Показати повний звіт багів Android девайсу:

`bugreport`
