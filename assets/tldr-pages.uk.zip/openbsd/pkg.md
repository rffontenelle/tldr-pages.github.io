# pkg

> Ця команда є псевдонімом для `pkg_add`.
> Більше інформації: <https://www.openbsd.org/faq/faq15.html>.

- Дивись документацію для оригінальної команди:

`tldr pkg_add`
