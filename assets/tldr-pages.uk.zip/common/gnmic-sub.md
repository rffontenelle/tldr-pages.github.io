# gnmic sub

> Ця команда є псевдонімом для `gnmic subscribe`.
> Більше інформації: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Дивись документацію для оригінальної команди:

`tldr gnmic subscribe`
