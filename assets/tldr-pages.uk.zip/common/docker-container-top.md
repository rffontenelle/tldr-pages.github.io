# docker-container-top

> Ця команда є псевдонімом для `docker top`.
> Більше інформації: <https://docs.docker.com/engine/reference/commandline/top>.

- Дивись документацію для оригінальної команди:

`tldr docker top`
