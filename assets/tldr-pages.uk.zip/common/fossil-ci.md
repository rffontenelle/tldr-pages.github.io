# fossil ci

> Ця команда є псевдонімом для  `fossil commit`.
> Більше інформації: <https://fossil-scm.org/home/help/commit>.

- Дивись документацію для оригінальної команди:

`tldr fossil-commit`
