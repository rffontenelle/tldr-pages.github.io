# todoman

> Ця команда є псевдонімом для `todo`.
> Більше інформації: <https://todoman.readthedocs.io/>.

- Дивись документацію для оригінальної команди:

`tldr todo`
