# linode-cli

> Ця команда є псевдонімом для `linode-cli account`.
> Більше інформації: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Дивись документацію для оригінальної команди:

`tldr linode-cli account`
