# azure-cli

> Ця команда є псевдонімом для `az`.
> Більше інформації: <https://learn.microsoft.com/cli/azure>.

- Дивись документацію для оригінальної команди:

`tldr az`
