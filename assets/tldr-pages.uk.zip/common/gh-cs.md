# gh-cs

> Ця команда є псевдонімом для `gh-codespace`.
> Більше інформації: <https://cli.github.com/manual/gh_codespace>.

- Дивись документацію для оригінальної команди:

`tldr gh-codespace`
