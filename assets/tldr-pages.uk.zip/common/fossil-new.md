# fossil new

> Ця команда є псевдонімом для  `fossil init`.
> Більше інформації: <https://fossil-scm.org/home/help/new>.

- Дивись документацію для оригінальної команди:

`tldr fossil-init`
