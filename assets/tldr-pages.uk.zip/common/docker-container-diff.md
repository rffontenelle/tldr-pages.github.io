# docker-container-diff

> Ця команда є псевдонімом для `docker diff`.
> Більше інформації: <https://docs.docker.com/engine/reference/commandline/diff>.

- Дивись документацію для оригінальної команди:

`tldr docker diff`
