# git commits-since

> Виводить коміти починаючи з певного періоду часу або дати.
> Частина `git-extras`.
> Більше інформації: <https://github.com/tj/git-extras/blob/master/Commands.md#git-commits-since>.

- Виводить коміти починаючи зі вчора:

`git commits-since {{yesterday}}`

- Виводить коміти починаючи з минулого тижня:

`git commits-since {{last week}}`

- Виводить коміти починаючи з минулого місяця:

`git commits-since {{last month}}`

- Виводить коміти починаючи зі вчора з 14:00:

`git commits-since {{yesterday 2pm}}`
