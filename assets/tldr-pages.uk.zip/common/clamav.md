# clamav

> Ця команда є псевдонімом для `clamdscan`.
> Більше інформації: <https://www.clamav.net>.

- Дивись документацію для оригінальної команди:

`tldr clamdscan`
