# docker-container-remove

> Ця команда є псевдонімом для `docker rm`.
> Більше інформації: <https://docs.docker.com/engine/reference/commandline/rm>.

- Дивись документацію для оригінальної команди:

`tldr docker rm`
