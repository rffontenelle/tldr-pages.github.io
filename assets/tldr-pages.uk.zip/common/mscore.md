# mscore

> Ця команда є псевдонімом для `musescore`.
> Більше інформації: <https://musescore.org/handbook/command-line-options>.

- Дивись документацію для оригінальної команди:

`tldr musescore`
