# hping

> Ця команда є псевдонімом для `hping3`.
> Більше інформації: <https://github.com/antirez/hping>.

- Дивись документацію для оригінальної команди:

`tldr hping3`
