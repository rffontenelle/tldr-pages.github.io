# transmission

> Ця команда є псевдонімом для `transmission-daemon`.
> Більше інформації: <https://transmissionbt.com/>.

- Дивись документацію для оригінальної команди:

`tldr transmission-daemon`
