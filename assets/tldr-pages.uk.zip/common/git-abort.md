# git abort

> Перериває поточне перебазування(rebase), злиття(merge) або вибір(cherry-pick).
> Частина `git-extras`.
> Більше інформації: <https://github.com/tj/git-extras/blob/master/Commands.md#git-abort>.

- Перериває Git перебазування(rebase), злиття(merge) або вибір(cherry-pick):

`git abort`
