# lima

> Ця команда є псевдонімом для `limactl`.
> Більше інформації: <https://github.com/lima-vm/lima>.

- Дивись документацію для оригінальної команди:

`tldr limactl`
