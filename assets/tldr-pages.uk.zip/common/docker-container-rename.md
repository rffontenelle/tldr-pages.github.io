# docker-container-rename

> Ця команда є псевдонімом для `docker rename`.
> Більше інформації: <https://docs.docker.com/engine/reference/commandline/rename>.

- Дивись документацію для оригінальної команди:

`tldr docker rename`
