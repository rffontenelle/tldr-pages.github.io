# fossil delete

> Ця команда є псевдонімом для `fossil rm`.
> Більше інформації: <https://fossil-scm.org/home/help/delete>.

- Дивись документацію для оригінальної команди:

`tldr fossil rm`
