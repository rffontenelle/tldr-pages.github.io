# bundler

> Ця команда є псевдонімом для `bundle`.
> Більше інформації: <https://bundler.io/man/bundle.1.html>.

- Дивись документацію для оригінальної команди:

`tldr bundle`
