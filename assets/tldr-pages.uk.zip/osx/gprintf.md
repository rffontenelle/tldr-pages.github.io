# gprintf

> Ця команда є псевдонімом для `-p linux printf`.

- Дивись документацію для оригінальної команди:

`tldr -p linux printf`
