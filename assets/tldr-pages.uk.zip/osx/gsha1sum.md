# gsha1sum

> Ця команда є псевдонімом для `-p linux sha1sum`.

- Дивись документацію для оригінальної команди:

`tldr -p linux sha1sum`
