# grealpath

> Ця команда є псевдонімом для `-p linux realpath`.

- Дивись документацію для оригінальної команди:

`tldr -p linux realpath`
