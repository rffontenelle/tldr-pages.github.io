# ggroups

> Ця команда є псевдонімом для `-p linux groups`.

- Дивись документацію для оригінальної команди:

`tldr -p linux groups`
