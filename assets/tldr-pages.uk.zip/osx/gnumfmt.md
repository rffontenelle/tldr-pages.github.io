# gnumfmt

> Ця команда є псевдонімом для `-p linux numfmt`.

- Дивись документацію для оригінальної команди:

`tldr -p linux numfmt`
