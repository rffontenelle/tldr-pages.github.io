# gunexpand

> Ця команда є псевдонімом для `-p linux unexpand`.

- Дивись документацію для оригінальної команди:

`tldr -p linux unexpand`
