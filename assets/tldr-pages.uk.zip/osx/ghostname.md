# ghostname

> Ця команда є псевдонімом для `-p linux hostname`.

- Дивись документацію для оригінальної команди:

`tldr -p linux hostname`
