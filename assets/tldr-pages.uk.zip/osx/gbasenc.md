# gbasenc

> Ця команда є псевдонімом для `-p linux basenc`.

- Дивись документацію для оригінальної команди:

`tldr -p linux basenc`
