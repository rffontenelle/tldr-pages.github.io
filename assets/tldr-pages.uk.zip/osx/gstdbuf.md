# gstdbuf

> Ця команда є псевдонімом для `-p linux stdbuf`.

- Дивись документацію для оригінальної команди:

`tldr -p linux stdbuf`
