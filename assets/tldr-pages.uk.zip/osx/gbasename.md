# gbasename

> Ця команда є псевдонімом для `-p linux basename`.

- Дивись документацію для оригінальної команди:

`tldr -p linux basename`
