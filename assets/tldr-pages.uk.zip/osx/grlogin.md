# grlogin

> Ця команда є псевдонімом для `-p linux rlogin`.

- Дивись документацію для оригінальної команди:

`tldr -p linux rlogin`
