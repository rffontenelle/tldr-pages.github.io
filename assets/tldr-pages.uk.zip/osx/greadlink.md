# greadlink

> Ця команда є псевдонімом для `-p linux readlink`.

- Дивись документацію для оригінальної команди:

`tldr -p linux readlink`
