# glibtoolize

> Ця команда є псевдонімом для `-p linux libtoolize`.

- Дивись документацію для оригінальної команди:

`tldr -p linux libtoolize`
