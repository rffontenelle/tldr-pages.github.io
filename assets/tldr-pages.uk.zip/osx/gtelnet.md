# gtelnet

> Ця команда є псевдонімом для `-p linux telnet`.

- Дивись документацію для оригінальної команди:

`tldr -p linux telnet`
