# guptime

> Ця команда є псевдонімом для `-p linux uptime`.

- Дивись документацію для оригінальної команди:

`tldr -p linux uptime`
