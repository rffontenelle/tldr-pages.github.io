# gexpand

> Ця команда є псевдонімом для `-p linux expand`.

- Дивись документацію для оригінальної команди:

`tldr -p linux expand`
