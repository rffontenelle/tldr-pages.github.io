# gdircolors

> Ця команда є псевдонімом для `-p linux dircolors`.

- Дивись документацію для оригінальної команди:

`tldr -p linux dircolors`
