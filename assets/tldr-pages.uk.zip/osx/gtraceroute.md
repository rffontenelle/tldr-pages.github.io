# gtraceroute

> Ця команда є псевдонімом для `-p linux traceroute`.

- Дивись документацію для оригінальної команди:

`tldr -p linux traceroute`
