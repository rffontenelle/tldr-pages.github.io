# gpathchk

> Ця команда є псевдонімом для `-p linux pathchk`.

- Дивись документацію для оригінальної команди:

`tldr -p linux pathchk`
