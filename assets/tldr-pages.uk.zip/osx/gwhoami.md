# gwhoami

> Ця команда є псевдонімом для `-p linux whoami`.

- Дивись документацію для оригінальної команди:

`tldr -p linux whoami`
