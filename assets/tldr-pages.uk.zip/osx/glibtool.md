# glibtool

> Ця команда є псевдонімом для `-p linux libtool`.

- Дивись документацію для оригінальної команди:

`tldr -p linux libtool`
