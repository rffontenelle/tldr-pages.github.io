# glogger

> Ця команда є псевдонімом для `-p linux logger`.

- Дивись документацію для оригінальної команди:

`tldr -p linux logger`
