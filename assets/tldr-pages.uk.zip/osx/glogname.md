# glogname

> Ця команда є псевдонімом для `-p linux logname`.

- Дивись документацію для оригінальної команди:

`tldr -p linux logname`
