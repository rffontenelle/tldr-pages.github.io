# gunlink

> Ця команда є псевдонімом для `-p linux unlink`.

- Дивись документацію для оригінальної команди:

`tldr -p linux unlink`
