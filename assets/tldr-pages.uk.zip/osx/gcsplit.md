# gcsplit

> Ця команда є псевдонімом для `-p linux csplit`.

- Дивись документацію для оригінальної команди:

`tldr -p linux csplit`
