# gprintenv

> Ця команда є псевдонімом для `-p linux printenv`.

- Дивись документацію для оригінальної команди:

`tldr -p linux printenv`
