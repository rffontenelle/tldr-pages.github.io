# gmkfifo

> Ця команда є псевдонімом для `-p linux mkfifo`.

- Дивись документацію для оригінальної команди:

`tldr -p linux mkfifo`
