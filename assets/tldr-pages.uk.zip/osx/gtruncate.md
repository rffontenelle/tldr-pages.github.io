# gtruncate

> Ця команда є псевдонімом для `-p linux truncate`.

- Дивись документацію для оригінальної команди:

`tldr -p linux truncate`
