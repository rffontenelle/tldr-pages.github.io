# gchroot

> Ця команда є псевдонімом для `-p linux chroot`.

- Дивись документацію для оригінальної команди:

`tldr -p linux chroot`
