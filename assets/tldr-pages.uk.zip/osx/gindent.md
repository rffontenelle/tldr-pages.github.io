# gindent

> Ця команда є псевдонімом для `-p linux indent`.

- Дивись документацію для оригінальної команди:

`tldr -p linux indent`
