# ghostid

> Ця команда є псевдонімом для `-p linux hostid`.

- Дивись документацію для оригінальної команди:

`tldr -p linux hostid`
