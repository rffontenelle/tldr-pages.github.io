# glocate

> Ця команда є псевдонімом для `-p linux locate`.

- Дивись документацію для оригінальної команди:

`tldr -p linux locate`
