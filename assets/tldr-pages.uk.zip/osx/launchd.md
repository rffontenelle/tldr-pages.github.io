# launchd

> Ця команда є псевдонімом для `launchctl`.
> Більше інформації: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Дивись документацію для оригінальної команди:

`tldr launchctl`
