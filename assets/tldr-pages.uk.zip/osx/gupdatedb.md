# gupdatedb

> Ця команда є псевдонімом для `-p linux updatedb`.

- Дивись документацію для оригінальної команди:

`tldr -p linux updatedb`
