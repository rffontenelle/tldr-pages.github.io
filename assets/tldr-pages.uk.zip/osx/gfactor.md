# gfactor

> Ця команда є псевдонімом для `-p linux factor`.

- Дивись документацію для оригінальної команди:

`tldr -p linux factor`
