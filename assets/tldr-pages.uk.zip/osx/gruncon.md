# gruncon

> Ця команда є псевдонімом для `-p linux runcon`.

- Дивись документацію для оригінальної команди:

`tldr -p linux runcon`
