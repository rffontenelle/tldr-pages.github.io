# gtimeout

> Ця команда є псевдонімом для `-p linux timeout`.

- Дивись документацію для оригінальної команди:

`tldr -p linux timeout`
