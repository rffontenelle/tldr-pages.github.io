# cls

> Ця команда є псевдонімом для `clear-host`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Дивись документацію для оригінальної команди:

`tldr clear-host`
