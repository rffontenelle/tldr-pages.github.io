# sl

> Ця команда є псевдонімом для `set-location`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Дивись документацію для оригінальної команди:

`tldr set-location`
