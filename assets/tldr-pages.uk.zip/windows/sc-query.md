# sc-query

> Ця команда є псевдонімом для `sc`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Дивись документацію для оригінальної команди:

`tldr sc`
