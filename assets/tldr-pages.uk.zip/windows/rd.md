# rd

> Ця команда є псевдонімом для `rmdir`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Дивись документацію для оригінальної команди:

`tldr rmdir`
