# sls

> Ця команда є псевдонімом для `Select-String`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Дивись документацію для оригінальної команди:

`tldr select-string`
