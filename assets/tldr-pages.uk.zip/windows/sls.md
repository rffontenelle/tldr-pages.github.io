# sls

> Ця команда є псевдонімом для `where-object`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Дивись документацію для оригінальної команди:

`tldr where-object`
