# chrome

> Ця команда є псевдонімом для `chromium`.
> Більше інформації: <https://chrome.google.com>.

- Дивись документацію для оригінальної команди:

`tldr chromium`
