# cpush

> Ця команда є псевдонімом для `choco-push`.
> Більше інформації: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Дивись документацію для оригінальної команди:

`tldr choco-push`
