# cd

> Ця команда є псевдонімом для `set-location`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Дивись документацію для оригінальної команди:

`tldr set-location`
