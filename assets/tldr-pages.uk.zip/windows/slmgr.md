# slmgr

> Ця команда є псевдонімом для `slmgr.vbs`.
> Більше інформації: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Дивись документацію для оригінальної команди:

`tldr slmgr.vbs`
