# clist

> Ця команда є псевдонімом для `choco list`.
> Більше інформації: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Дивись документацію для оригінальної команди:

`tldr choco list`
