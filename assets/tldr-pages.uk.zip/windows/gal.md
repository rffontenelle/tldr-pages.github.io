# gal

> Ця команда є псевдонімом для `get-alias`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Дивись документацію для оригінальної команди:

`tldr get-alias`
