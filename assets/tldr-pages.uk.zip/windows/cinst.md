# cinst

> Ця команда є псевдонімом для `choco install`.
> Більше інформації: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Дивись документацію для оригінальної команди:

`tldr choco install`
