# ni

> Ця команда є псевдонімом для `new-item`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Дивись документацію для оригінальної команди:

`tldr new-item`
