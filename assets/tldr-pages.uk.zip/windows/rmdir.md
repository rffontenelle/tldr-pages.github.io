# rmdir

> Ця команда є псевдонімом для `remove-item`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Дивись документацію для оригінальної команди:

`tldr remove-item`
