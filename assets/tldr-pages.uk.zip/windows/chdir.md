# chdir

> Ця команда є псевдонімом для `cd`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Дивись документацію для оригінальної команди:

`tldr cd`
