# sc-create

> Ця команда є псевдонімом для `sc`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Дивись документацію для оригінальної команди:

`tldr sc`
