# wget

> Ця команда є псевдонімом для `wget -p common`.
> Більше інформації: <https://www.gnu.org/software/wget>.

- Дивись документацію для оригінальної команди:

`tldr wget -p common`
