# pwsh where

> Ця команда є псевдонімом для `Where-Object`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Дивись документацію для оригінальної команди:

`tldr Where-Object`
