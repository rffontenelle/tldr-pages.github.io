# ri

> Ця команда є псевдонімом для `remove-item`.
> Більше інформації: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Дивись документацію для оригінальної команди:

`tldr remove-item`
