# sc-delete

> Ця команда є псевдонімом для `sc`.
> Більше інформації: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Дивись документацію для оригінальної команди:

`tldr sc`
