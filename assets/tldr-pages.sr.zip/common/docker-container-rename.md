# docker-container-rename

> Ова наредба је псеудоним `docker rename`.
> Više informacija na: <https://docs.docker.com/engine/reference/commandline/rename>.

- Погледајте документацију за оригиналну команду:

`tldr docker rename`
