# musl-gcc

> Ова наредба је псеудоним `gcc`.
> Više informacija na: <https://manned.org/musl-gcc>.

- Погледајте документацију за оригиналну команду:

`tldr gcc`
