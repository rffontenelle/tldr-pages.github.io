# docker-container-top

> Ова наредба је псеудоним `docker top`.
> Više informacija na: <https://docs.docker.com/engine/reference/commandline/top>.

- Погледајте документацију за оригиналну команду:

`tldr docker top`
