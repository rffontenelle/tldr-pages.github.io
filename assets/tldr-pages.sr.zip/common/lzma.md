# lzma

> Ова наредба је псеудоним `xz`.
> Više informacija na: <https://manned.org/lzma>.

- Погледајте документацију за оригиналну команду:

`tldr xz`
