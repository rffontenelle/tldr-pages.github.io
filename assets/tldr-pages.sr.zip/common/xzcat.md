# xzcat

> Ова наредба је псеудоним `xz`.
> Više informacija na: <https://manned.org/xzcat>.

- Погледајте документацију за оригиналну команду:

`tldr xz`
