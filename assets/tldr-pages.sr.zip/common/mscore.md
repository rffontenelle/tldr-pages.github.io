# mscore

> Ова наредба је псеудоним `musescore`.
> Više informacija na: <https://musescore.org/handbook/command-line-options>.

- Погледајте документацију за оригиналну команду:

`tldr musescore`
