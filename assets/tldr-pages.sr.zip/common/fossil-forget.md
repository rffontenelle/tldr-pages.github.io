# fossil-forget

> Ова наредба је псеудоним `fossil rm`.
> Više informacija na: <https://fossil-scm.org/home/help/forget>.

- Погледајте документацију за оригиналну команду:

`tldr fossil rm`
