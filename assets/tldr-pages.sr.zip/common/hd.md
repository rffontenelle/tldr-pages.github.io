# hd

> Ова наредба је псеудоним `hexdump`.
> Više informacija na: <https://manned.org/hd.1>.

- Погледајте документацију за оригиналну команду:

`tldr hexdump`
