# fossil-delete

> Ова наредба је псеудоним `fossil rm`.
> Više informacija na: <https://fossil-scm.org/home/help/delete>.

- Погледајте документацију за оригиналну команду:

`tldr fossil rm`
