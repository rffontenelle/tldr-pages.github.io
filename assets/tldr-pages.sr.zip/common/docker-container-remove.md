# docker-container-remove

> Ова наредба је псеудоним `docker rm`.
> Više informacija na: <https://docs.docker.com/engine/reference/commandline/rm>.

- Погледајте документацију за оригиналну команду:

`tldr docker rm`
