# tldrl

> Ова наредба је псеудоним `tldr-lint`.
> Više informacija na: <https://github.com/tldr-pages/tldr-lint>.

- Погледајте документацију за оригиналну команду:

`tldr tldr-lint`
