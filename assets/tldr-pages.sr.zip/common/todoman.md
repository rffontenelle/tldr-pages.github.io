# todoman

> Ова наредба је псеудоним `todo`.
> Više informacija na: <https://todoman.readthedocs.io/>.

- Погледајте документацију за оригиналну команду:

`tldr todo`
