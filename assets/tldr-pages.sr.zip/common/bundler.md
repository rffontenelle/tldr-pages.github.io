# bundler

> Ова наредба је псеудоним `bundle`.
> Više informacija na: <https://bundler.io/man/bundle.1.html>.

- Погледајте документацију за оригиналну команду:

`tldr bundle`
