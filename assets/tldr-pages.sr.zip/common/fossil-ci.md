# fossil-ci

> Ова наредба је псеудоним `fossil-commit`.
> Više informacija na: <https://fossil-scm.org/home/help/commit>.

- Погледајте документацију за оригиналну команду:

`tldr fossil-commit`
