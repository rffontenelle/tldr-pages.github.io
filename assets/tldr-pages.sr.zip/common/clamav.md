# clamav

> Ова наредба је псеудоним `clamdscan`.
> Više informacija na: <https://www.clamav.net>.

- Погледајте документацију за оригиналну команду:

`tldr clamdscan`
