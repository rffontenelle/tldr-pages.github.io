# gh-cs

> Ова наредба је псеудоним `gh-codespace`.
> Više informacija na: <https://cli.github.com/manual/gh_codespace>.

- Погледајте документацију за оригиналну команду:

`tldr gh-codespace`
