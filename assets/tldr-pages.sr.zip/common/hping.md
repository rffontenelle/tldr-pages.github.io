# hping

> Ова наредба је псеудоним `hping3`.
> Više informacija na: <https://github.com/antirez/hping>.

- Погледајте документацију за оригиналну команду:

`tldr hping3`
