# tlmgr-arch

> Ова наредба је псеудоним `tlmgr platform`.
> Više informacija na: <https://www.tug.org/texlive/tlmgr.html>.

- Погледајте документацију за оригиналну команду:

`tldr tlmgr platform`
