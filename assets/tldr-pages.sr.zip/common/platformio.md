# platformio

> Ова наредба је псеудоним `pio`.
> Više informacija na: <https://docs.platformio.org/en/latest/core/userguide/>.

- Погледајте документацију за оригиналну команду:

`tldr pio`
