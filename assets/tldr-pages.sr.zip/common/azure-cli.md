# azure-cli

> Ова наредба је псеудоним `az`.
> Više informacija na: <https://learn.microsoft.com/cli/azure>.

- Погледајте документацију за оригиналну команду:

`tldr az`
