# ntl

> Ова наредба је псеудоним `netlify`.
> Više informacija na: <https://cli.netlify.com>.

- Погледајте документацију за оригиналну команду:

`tldr netlify`
