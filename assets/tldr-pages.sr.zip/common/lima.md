# lima

> Ова наредба је псеудоним `limactl`.
> Više informacija na: <https://github.com/lima-vm/lima>.

- Погледајте документацију за оригиналну команду:

`tldr limactl`
