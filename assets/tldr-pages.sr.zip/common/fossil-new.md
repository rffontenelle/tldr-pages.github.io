# fossil-new

> Ова наредба је псеудоним `fossil-init`.
> Više informacija na: <https://fossil-scm.org/home/help/new>.

- Погледајте документацију за оригиналну команду:

`tldr fossil-init`
