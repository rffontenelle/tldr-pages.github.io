# google-chrome

> Ова наредба је псеудоним `chromium`.
> Više informacija na: <https://chrome.google.com>.

- Погледајте документацију за оригиналну команду:

`tldr chromium`
