# linode-cli

> Ова наредба је псеудоним `linode-cli account`.
> Više informacija na: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Погледајте документацију за оригиналну команду:

`tldr linode-cli account`
