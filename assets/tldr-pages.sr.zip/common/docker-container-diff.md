# docker-container-diff

> Ова наредба је псеудоним `docker diff`.
> Više informacija na: <https://docs.docker.com/engine/reference/commandline/diff>.

- Погледајте документацију за оригиналну команду:

`tldr docker diff`
