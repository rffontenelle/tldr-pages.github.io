# lzcat

> Ова наредба је псеудоним `xz`.
> Više informacija na: <https://manned.org/lzcat>.

- Погледајте документацију за оригиналну команду:

`tldr xz`
