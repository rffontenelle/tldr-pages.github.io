# transmission

> Ова наредба је псеудоним `transmission-daemon`.
> Više informacija na: <https://transmissionbt.com/>.

- Погледајте документацију за оригиналну команду:

`tldr transmission-daemon`
