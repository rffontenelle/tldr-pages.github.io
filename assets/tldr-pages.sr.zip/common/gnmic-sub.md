# gnmic-sub

> Ова наредба је псеудоним `gnmic subscribe`.
> Više informacija na: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Погледајте документацију за оригиналну команду:

`tldr gnmic subscribe`
