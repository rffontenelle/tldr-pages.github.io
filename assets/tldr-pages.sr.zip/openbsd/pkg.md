# pkg

> Ова наредба је псеудоним `pkg_add`.
> Više informacija na: <https://www.openbsd.org/faq/faq15.html>.

- Погледајте документацију за оригиналну команду:

`tldr pkg_add`
