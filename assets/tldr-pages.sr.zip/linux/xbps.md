# xbps

> Ова наредба је псеудоним `xbps-install`.
> Više informacija na: <https://docs.voidlinux.org/xbps/index.html>.

- Погледајте документацију за оригиналну команду:

`tldr xbps-install`
