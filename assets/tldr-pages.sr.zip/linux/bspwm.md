# bspwm

> Ова наредба је псеудоним `bspc`.
> Više informacija na: <https://github.com/baskerville/bspwm>.

- Погледајте документацију за оригиналну команду:

`tldr bspc`
