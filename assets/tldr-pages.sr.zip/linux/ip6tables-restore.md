# ip6tables-restore

> Ова наредба је псеудоним `iptables-restore`.

- Погледајте документацију за оригиналну команду:

`tldr iptables-restore`
