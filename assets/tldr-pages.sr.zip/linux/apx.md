# apx

> Ова наредба је псеудоним `apx pkgmanagers`.
> Više informacija na: <https://github.com/Vanilla-OS/apx>.

- Погледајте документацију за оригиналну команду:

`tldr apx pkgmanagers`
