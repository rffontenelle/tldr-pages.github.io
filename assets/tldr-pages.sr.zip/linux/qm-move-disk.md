# qm-move-disk

> Ова наредба је псеудоним `qm-disk-move`.
> Više informacija na: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Погледајте документацију за оригиналну команду:

`tldr qm-disk-move`
