# cc

> Ова наредба је псеудоним `gcc`.
> Više informacija na: <https://gcc.gnu.org>.

- Погледајте документацију за оригиналну команду:

`tldr gcc`
