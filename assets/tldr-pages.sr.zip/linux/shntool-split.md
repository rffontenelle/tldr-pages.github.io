# shntool-split

> Ова наредба је псеудоним `shnsplit`.

- Погледајте документацију за оригиналну команду:

`tldr shnsplit`
