# ip6tables-save

> Ова наредба је псеудоним `iptables-save`.

- Погледајте документацију за оригиналну команду:

`tldr iptables-save`
