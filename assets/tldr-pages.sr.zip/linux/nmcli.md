# nmcli

> Ова наредба је псеудоним `nmcli agent`.
> Više informacija na: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Погледајте документацију за оригиналну команду:

`tldr nmcli agent`
