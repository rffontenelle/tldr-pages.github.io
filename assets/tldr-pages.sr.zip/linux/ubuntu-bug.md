# ubuntu-bug

> Ова наредба је псеудоним `apport-bug`.
> Više informacija na: <https://manned.org/ubuntu-bug>.

- Погледајте документацију за оригиналну команду:

`tldr apport-bug`
