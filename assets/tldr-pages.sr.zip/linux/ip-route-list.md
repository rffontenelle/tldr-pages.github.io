# ip-route-list

> Ова наредба је псеудоним `ip-route-show`.

- Погледајте документацију за оригиналну команду:

`tldr ip-route-show`
