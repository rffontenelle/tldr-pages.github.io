# qm-importdisk

> Ова наредба је псеудоним `qm disk import`.

- Погледајте документацију за оригиналну команду:

`tldr qm disk import`
