# distrobox

> Ова наредба је псеудоним `distrobox-create`.
> Više informacija na: <https://github.com/89luca89/distrobox>.

- Погледајте документацију за оригиналну команду:

`tldr distrobox-create`
