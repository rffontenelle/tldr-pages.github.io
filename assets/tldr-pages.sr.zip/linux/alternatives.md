# alternatives

> Ова наредба је псеудоним `update-alternatives`.
> Više informacija na: <https://manned.org/alternatives>.

- Погледајте документацију за оригиналну команду:

`tldr update-alternatives`
