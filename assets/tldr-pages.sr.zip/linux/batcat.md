# batcat

> Ова наредба је псеудоним `bat`.
> Više informacija na: <https://github.com/sharkdp/bat>.

- Погледајте документацију за оригиналну команду:

`tldr bat`
