# qm-resize

> Ова наредба је псеудоним `qm-disk-resize`.
> Više informacija na: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Погледајте документацију за оригиналну команду:

`tldr qm-disk-resize`
