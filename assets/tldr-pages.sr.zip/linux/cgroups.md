# cgroups

> Ова наредба је псеудоним `cgclassify`.
> Više informacija na: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Погледајте документацију за оригиналну команду:

`tldr cgclassify`
