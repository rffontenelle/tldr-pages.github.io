# systemd-umount

> Ова наредба је псеудоним `systemd-mount`.

- Погледајте документацију за оригиналну команду:

`tldr systemd-mount`
