# pkgctl

> Ова наредба је псеудоним `pkgctl auth`.
> Više informacija na: <https://man.archlinux.org/man/pkgctl.1>.

- Погледајте документацију за оригиналну команду:

`tldr pkgctl auth`
