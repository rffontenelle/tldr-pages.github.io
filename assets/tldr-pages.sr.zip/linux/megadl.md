# megadl

> Ова наредба је псеудоним `megatools-dl`.
> Više informacija na: <https://megatools.megous.com/man/megatools-dl.html>.

- Погледајте документацију за оригиналну команду:

`tldr megatools-dl`
