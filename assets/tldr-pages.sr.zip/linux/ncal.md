# ncal

> Ова наредба је псеудоним `cal`.
> Više informacija na: <https://manned.org/ncal>.

- Погледајте документацију за оригиналну команду:

`tldr cal`
