# sc-delete

> Ова наредба је псеудоним `sc`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Погледајте документацију за оригиналну команду:

`tldr sc`
