# chdir

> Ова наредба је псеудоним `cd`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Погледајте документацију за оригиналну команду:

`tldr cd`
