# sc-create

> Ова наредба је псеудоним `sc`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Погледајте документацију за оригиналну команду:

`tldr sc`
