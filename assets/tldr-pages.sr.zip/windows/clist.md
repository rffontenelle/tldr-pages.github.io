# clist

> Ова наредба је псеудоним `choco list`.
> Više informacija na: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Погледајте документацију за оригиналну команду:

`tldr choco list`
