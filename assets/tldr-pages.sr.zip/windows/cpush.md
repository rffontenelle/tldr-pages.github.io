# cpush

> Ова наредба је псеудоним `choco-push`.
> Više informacija na: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Погледајте документацију за оригиналну команду:

`tldr choco-push`
