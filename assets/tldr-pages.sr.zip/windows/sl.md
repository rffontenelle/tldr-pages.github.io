# sl

> Ова наредба је псеудоним `set-location`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Погледајте документацију за оригиналну команду:

`tldr set-location`
