# gal

> Ова наредба је псеудоним `get-alias`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Погледајте документацију за оригиналну команду:

`tldr get-alias`
