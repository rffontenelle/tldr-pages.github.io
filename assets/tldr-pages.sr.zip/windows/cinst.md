# cinst

> Ова наредба је псеудоним `choco install`.
> Više informacija na: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Погледајте документацију за оригиналну команду:

`tldr choco install`
