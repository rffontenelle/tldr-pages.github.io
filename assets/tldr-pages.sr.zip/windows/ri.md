# ri

> Ова наредба је псеудоним `remove-item`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Погледајте документацију за оригиналну команду:

`tldr remove-item`
