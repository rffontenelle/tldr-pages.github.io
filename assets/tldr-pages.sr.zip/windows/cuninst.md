# cuninst

> Ова наредба је псеудоним `choco uninstall`.
> Više informacija na: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Погледајте документацију за оригиналну команду:

`tldr choco uninstall`
