# ni

> Ова наредба је псеудоним `new-item`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Погледајте документацију за оригиналну команду:

`tldr new-item`
