# sc-query

> Ова наредба је псеудоним `sc`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Погледајте документацију за оригиналну команду:

`tldr sc`
