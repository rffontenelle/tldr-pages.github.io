# rd

> Ова наредба је псеудоним `rmdir`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Погледајте документацију за оригиналну команду:

`tldr rmdir`
