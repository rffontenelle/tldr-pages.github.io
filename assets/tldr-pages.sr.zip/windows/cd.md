# cd

> Ова наредба је псеудоним `set-location`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Погледајте документацију за оригиналну команду:

`tldr set-location`
