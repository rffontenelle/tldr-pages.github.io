# cls

> Ова наредба је псеудоним `clear-host`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Погледајте документацију за оригиналну команду:

`tldr clear-host`
