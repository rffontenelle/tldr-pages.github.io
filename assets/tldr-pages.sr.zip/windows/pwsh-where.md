# pwsh-where

> Ова наредба је псеудоним `Where-Object`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Погледајте документацију за оригиналну команду:

`tldr Where-Object`
