# iwr

> Ова наредба је псеудоним `invoke-webrequest`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Погледајте документацију за оригиналну команду:

`tldr invoke-webrequest`
