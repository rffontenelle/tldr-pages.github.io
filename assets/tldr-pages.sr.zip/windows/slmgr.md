# slmgr

> Ова наредба је псеудоним `slmgr.vbs`.
> Više informacija na: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Погледајте документацију за оригиналну команду:

`tldr slmgr.vbs`
