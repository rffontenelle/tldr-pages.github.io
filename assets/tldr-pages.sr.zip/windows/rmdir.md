# rmdir

> Ова наредба је псеудоним `remove-item`.
> Više informacija na: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Погледајте документацију за оригиналну команду:

`tldr remove-item`
