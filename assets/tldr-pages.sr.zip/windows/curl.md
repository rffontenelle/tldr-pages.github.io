# curl

> Ова наредба је псеудоним `curl -p common`.
> Više informacija na: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Погледајте документацију за оригиналну команду:

`tldr curl -p common`
