# gdircolors

> Ова наредба је псеудоним `-p linux dircolors`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux dircolors`
