# gtimeout

> Ова наредба је псеудоним `-p linux timeout`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux timeout`
