# grealpath

> Ова наредба је псеудоним `-p linux realpath`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux realpath`
