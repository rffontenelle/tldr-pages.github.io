# gfactor

> Ова наредба је псеудоним `-p linux factor`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux factor`
