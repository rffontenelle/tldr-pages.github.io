# gprintenv

> Ова наредба је псеудоним `-p linux printenv`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux printenv`
