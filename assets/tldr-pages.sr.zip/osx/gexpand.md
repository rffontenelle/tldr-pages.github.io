# gexpand

> Ова наредба је псеудоним `-p linux expand`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux expand`
