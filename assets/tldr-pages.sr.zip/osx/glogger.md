# glogger

> Ова наредба је псеудоним `-p linux logger`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux logger`
