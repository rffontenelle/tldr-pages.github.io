# gbasenc

> Ова наредба је псеудоним `-p linux basenc`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux basenc`
