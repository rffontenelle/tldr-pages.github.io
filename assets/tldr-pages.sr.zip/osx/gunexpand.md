# gunexpand

> Ова наредба је псеудоним `-p linux unexpand`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux unexpand`
