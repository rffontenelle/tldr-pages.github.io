# grlogin

> Ова наредба је псеудоним `-p linux rlogin`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux rlogin`
