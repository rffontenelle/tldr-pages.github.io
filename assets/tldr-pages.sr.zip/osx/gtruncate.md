# gtruncate

> Ова наредба је псеудоним `-p linux truncate`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux truncate`
