# gsha1sum

> Ова наредба је псеудоним `-p linux sha1sum`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux sha1sum`
