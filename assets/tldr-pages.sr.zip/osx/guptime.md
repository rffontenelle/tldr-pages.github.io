# guptime

> Ова наредба је псеудоним `-p linux uptime`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux uptime`
