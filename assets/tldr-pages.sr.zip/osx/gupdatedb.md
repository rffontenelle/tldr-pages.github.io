# gupdatedb

> Ова наредба је псеудоним `-p linux updatedb`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux updatedb`
