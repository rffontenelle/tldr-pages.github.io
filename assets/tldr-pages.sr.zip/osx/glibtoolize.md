# glibtoolize

> Ова наредба је псеудоним `-p linux libtoolize`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux libtoolize`
