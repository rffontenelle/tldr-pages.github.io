# gbasename

> Ова наредба је псеудоним `-p linux basename`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux basename`
