# ghostname

> Ова наредба је псеудоним `-p linux hostname`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux hostname`
