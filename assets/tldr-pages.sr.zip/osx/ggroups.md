# ggroups

> Ова наредба је псеудоним `-p linux groups`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux groups`
