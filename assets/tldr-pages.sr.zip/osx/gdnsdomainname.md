# gdnsdomainname

> Ова наредба је псеудоним `-p linux dnsdomainname`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux dnsdomainname`
