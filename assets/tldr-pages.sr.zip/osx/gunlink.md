# gunlink

> Ова наредба је псеудоним `-p linux unlink`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux unlink`
