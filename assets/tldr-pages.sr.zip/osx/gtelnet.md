# gtelnet

> Ова наредба је псеудоним `-p linux telnet`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux telnet`
