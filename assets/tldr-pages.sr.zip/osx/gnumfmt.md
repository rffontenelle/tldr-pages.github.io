# gnumfmt

> Ова наредба је псеудоним `-p linux numfmt`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux numfmt`
