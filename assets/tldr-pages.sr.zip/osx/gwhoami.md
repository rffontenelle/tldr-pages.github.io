# gwhoami

> Ова наредба је псеудоним `-p linux whoami`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux whoami`
