# gstdbuf

> Ова наредба је псеудоним `-p linux stdbuf`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux stdbuf`
