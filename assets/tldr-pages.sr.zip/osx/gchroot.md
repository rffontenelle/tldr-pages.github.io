# gchroot

> Ова наредба је псеудоним `-p linux chroot`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux chroot`
