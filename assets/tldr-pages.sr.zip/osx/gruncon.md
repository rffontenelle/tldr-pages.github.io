# gruncon

> Ова наредба је псеудоним `-p linux runcon`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux runcon`
