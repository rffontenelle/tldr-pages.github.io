# gprintf

> Ова наредба је псеудоним `-p linux printf`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux printf`
