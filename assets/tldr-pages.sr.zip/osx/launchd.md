# launchd

> Ова наредба је псеудоним `launchctl`.
> Više informacija na: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Погледајте документацију за оригиналну команду:

`tldr launchctl`
