# ginstall

> Ова наредба је псеудоним `-p linux install`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux install`
