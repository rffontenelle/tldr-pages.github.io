# glibtool

> Ова наредба је псеудоним `-p linux libtool`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux libtool`
