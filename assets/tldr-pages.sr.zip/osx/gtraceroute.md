# gtraceroute

> Ова наредба је псеудоним `-p linux traceroute`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux traceroute`
