# gpathchk

> Ова наредба је псеудоним `-p linux pathchk`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux pathchk`
