# gindent

> Ова наредба је псеудоним `-p linux indent`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux indent`
