# greadlink

> Ова наредба је псеудоним `-p linux readlink`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux readlink`
