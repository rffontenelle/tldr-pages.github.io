# gcsplit

> Ова наредба је псеудоним `-p linux csplit`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux csplit`
