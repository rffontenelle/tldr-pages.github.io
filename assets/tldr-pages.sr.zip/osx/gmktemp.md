# gmktemp

> Ова наредба је псеудоним `-p linux mktemp`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux mktemp`
