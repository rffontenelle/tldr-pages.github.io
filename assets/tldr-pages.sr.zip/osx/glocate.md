# glocate

> Ова наредба је псеудоним `-p linux locate`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux locate`
