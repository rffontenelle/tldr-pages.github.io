# gifconfig

> Ова наредба је псеудоним `-p linux ifconfig`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux ifconfig`
