# gmkfifo

> Ова наредба је псеудоним `-p linux mkfifo`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux mkfifo`
