# gdirname

> Ова наредба је псеудоним `-p linux dirname`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux dirname`
