# glogname

> Ова наредба је псеудоним `-p linux logname`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux logname`
