# ghostid

> Ова наредба је псеудоним `-p linux hostid`.

- Погледајте документацију за оригиналну команду:

`tldr -p linux hostid`
