# docker-container-remove

> ഈ കമാൻഡ് `docker rm` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://docs.docker.com/engine/reference/commandline/rm>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr docker rm`
