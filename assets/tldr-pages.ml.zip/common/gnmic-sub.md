# gnmic sub

> ഈ കമാൻഡ് `gnmic subscribe` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://gnmic.kmrd.dev/cmd/subscribe>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gnmic subscribe`
