# gh cs

> ഈ കമാൻഡ്  `gh codespace`.എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://cli.github.com/manual/gh_codespace>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gh-codespace`
