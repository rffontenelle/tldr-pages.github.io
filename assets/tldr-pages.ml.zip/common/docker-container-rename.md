# docker-container-rename

> ഈ കമാൻഡ് `docker rename` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://docs.docker.com/engine/reference/commandline/rename>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr docker rename`
