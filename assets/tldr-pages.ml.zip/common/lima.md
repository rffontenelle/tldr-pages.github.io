# lima

> ഈ കമാൻഡ് `limactl` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://github.com/lima-vm/lima>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr limactl`
