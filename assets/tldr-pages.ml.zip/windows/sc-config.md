# sc-config

> ഈ കമാൻഡ് `sc` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr sc`
