# slmgr

> ഈ കമാൻഡ് `slmgr.vbs` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr slmgr.vbs`
