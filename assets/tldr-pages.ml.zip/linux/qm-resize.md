# qm-resize

> ഈ കമാൻഡ് `qm-disk-resize` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr qm-disk-resize`
