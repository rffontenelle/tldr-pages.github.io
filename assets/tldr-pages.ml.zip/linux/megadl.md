# megadl

> ഈ കമാൻഡ് `megatools-dl` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://megatools.megous.com/man/megatools-dl.html>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr megatools-dl`
