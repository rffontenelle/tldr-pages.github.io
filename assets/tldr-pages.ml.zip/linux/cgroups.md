# cgroups

> ഈ കമാൻഡ് `cgclassify` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr cgclassify`
