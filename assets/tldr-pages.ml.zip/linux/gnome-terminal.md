# gnome-terminal

> ഗ്നോം ടെർമിനൽ എമുലേറ്റർ.
> കൂടുതൽ വിവരങ്ങൾ: <https://help.gnome.org/users/gnome-terminal/stable/>.

- ഒരു പുതിയ ഗ്നോം ടെർമിനൽ വിൻഡോ തുറക്കാൻ:

`gnome-terminal`

- പുതിയ വിൻഡോയിൽ ഒരു കമാൻഡ് പ്രവർത്തിപ്പിക്കാൻ:

`gnome-terminal -- {{കമാൻഡ്}}`

- അവസാനമായി തുറക്കപെട്ട വിൻഡോയിൽ ഒരു പുതിയ ടാബ് സൃഷ്ടിക്കാൻ:

`gnome-terminal --tab`

- പുതിയ ടാബിന്റെ ടൈറ്റിൽ മാറ്റുവാൻ:

`gnome-terminal --tab --title "{{ടൈറ്റിൽ}}"`
