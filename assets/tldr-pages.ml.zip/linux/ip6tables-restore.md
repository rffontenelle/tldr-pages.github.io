# ip6tables-restore

> ഈ കമാൻഡ് `iptables-restore` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr iptables-restore`
