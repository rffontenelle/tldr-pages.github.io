# ubuntu-bug

> ഈ കമാൻഡ് `apport-bug` എന്നത്തിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://manned.org/ubuntu-bug>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr apport-bug`
