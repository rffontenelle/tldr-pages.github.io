# glibtool

> ഈ കമാൻഡ് `-p linux libtool` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr -p linux libtool`
