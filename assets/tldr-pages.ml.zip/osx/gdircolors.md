# gdircolors

> ഈ കമാൻഡ് `-p linux dircolors` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr -p linux dircolors`
