# gtraceroute

> ഈ കമാൻഡ് `-p linux traceroute` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr -p linux traceroute`
