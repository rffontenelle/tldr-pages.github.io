# cmd

> Androids Service-Manager.
> Weitere Informationen: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- Liste alle laufenden Services auf:

`cmd -l`

- Rufe einen bestimmten Service auf:

`cmd {{alarm}}`

- Rufe einen bestimmten Service mit Parametern auf:

`cmd {{vibrator}} {{vibrate 300}}`
