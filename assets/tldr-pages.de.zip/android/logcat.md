# logcat

> Gib ein Protokoll aller Systemmeldungen aus.
> Weitere Informationen: <https://developer.android.com/tools/logcat>.

- Gib ein Protokoll aller Systemmeldungen aus:

`logcat`

- Schreibe alle Systemmeldungen in eine Datei:

`logcat -f {{pfad/zu/datei}}`

- Gib Zeilen aus, die einem regulären Ausdruck entsprechen:

`logcat --regex {{regex}}`
