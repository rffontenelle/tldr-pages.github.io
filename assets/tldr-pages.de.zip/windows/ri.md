# ri

> Dieser Befehl ist ein Alias von `remove-item`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr remove-item`
