# rmdir

> Dieser Befehl ist ein Alias von `remove-item`.
> Weitere Informationen: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr remove-item`
