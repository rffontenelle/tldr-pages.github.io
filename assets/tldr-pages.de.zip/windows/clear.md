# clear

> Dieser Befehl ist ein Alias von `clear-host`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr clear-host`
