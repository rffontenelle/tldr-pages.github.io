# cls

> Dieser Befehl ist ein Alias von `clear-host`.
> Weitere Informationen: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr clear-host`
