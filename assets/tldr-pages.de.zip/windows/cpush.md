# cpush

> Dieser Befehl ist ein Alias von `choco-push`.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr choco-push`
