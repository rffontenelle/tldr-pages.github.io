# sl

> Dieser Befehl ist ein Alias von `set-location`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr set-location`
