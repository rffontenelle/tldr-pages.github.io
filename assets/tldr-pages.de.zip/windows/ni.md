# ni

> Dieser Befehl ist ein Alias von `new-item`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr new-item`
