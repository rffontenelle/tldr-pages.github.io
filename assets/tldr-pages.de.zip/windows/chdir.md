# chdir

> Dieser Befehl ist ein Alias von `cd`.
> Weitere Informationen: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr cd`
