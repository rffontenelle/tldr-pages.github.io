# sc-config

> Dieser Befehl ist ein Alias von `sc`.
> Weitere Informationen: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr sc`
