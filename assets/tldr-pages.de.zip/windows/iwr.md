# iwr

> Dieser Befehl ist ein Alias von `invoke-webrequest`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr invoke-webrequest`
