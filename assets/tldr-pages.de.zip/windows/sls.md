# sls

> Dieser Befehl ist ein Alias von `where-object`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr where-object`
