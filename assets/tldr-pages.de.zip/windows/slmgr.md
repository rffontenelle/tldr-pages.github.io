# slmgr

> Dieser Befehl ist ein Alias von `slmgr.vbs`.
> Weitere Informationen: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr slmgr.vbs`
