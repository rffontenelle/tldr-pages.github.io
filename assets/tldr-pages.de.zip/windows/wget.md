# wget

> Dieser Befehl ist ein Alias von `wget -p common`.
> Weitere Informationen: <https://www.gnu.org/software/wget>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr wget -p common`
