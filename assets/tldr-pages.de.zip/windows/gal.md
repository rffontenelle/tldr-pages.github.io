# gal

> Dieser Befehl ist ein Alias von `get-alias`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr get-alias`
