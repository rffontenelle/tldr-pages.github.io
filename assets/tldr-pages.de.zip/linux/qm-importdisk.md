# qm-importdisk

> Dieser Befehl ist ein Alias von `qm disk import`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr qm disk import`
