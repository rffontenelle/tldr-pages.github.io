# ip-route-list

> Dieser Befehl ist ein Alias von `ip-route-show`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr ip-route-show`
