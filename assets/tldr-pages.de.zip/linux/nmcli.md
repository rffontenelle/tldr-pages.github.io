# nmcli

> Dieser Befehl ist ein Alias von `nmcli agent`.
> Weitere Informationen: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr nmcli agent`
