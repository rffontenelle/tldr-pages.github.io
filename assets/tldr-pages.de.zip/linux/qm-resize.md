# qm-resize

> Dieser Befehl ist ein Alias von `qm-disk-resize`.
> Weitere Informationen: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr qm-disk-resize`
