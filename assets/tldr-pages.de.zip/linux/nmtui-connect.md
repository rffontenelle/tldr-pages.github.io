# nmtui-connect

> Dieser Befehl ist ein Alias von `nmtui`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr nmtui`
