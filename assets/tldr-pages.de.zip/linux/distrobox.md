# distrobox

> Dieser Befehl ist ein Alias von `distrobox-create`.
> Weitere Informationen: <https://github.com/89luca89/distrobox>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr distrobox-create`
