# ip6tables-save

> Dieser Befehl ist ein Alias von `iptables-save`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr iptables-save`
