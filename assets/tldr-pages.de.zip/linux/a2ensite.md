# a2ensite

> Aktiviert einen Apache virtuellen Host auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manned.org/a2ensite.8>.

- Aktiviere einen virtuellen Host:

`sudo a2ensite {{virtueller_host}}`

- Zeige keine Informationsnachrichten an:

`sudo a2ensite --quiet {{virtueller_host}}`
