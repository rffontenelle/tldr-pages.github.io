# a2ensite

> Aktiviert einen Apache virtuellen Host auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Aktiviere einen virtuellen Host:

`sudo a2ensite {{virtueller_host}}`

- Zeige keine Informationsnachrichten an:

`sudo a2ensite --quiet {{virtueller_host}}`
