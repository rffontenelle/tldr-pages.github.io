# esa snap

> Sentinel Application Platform (SNAP) für die Prozessierung von Satellitendaten der Europäischen Raumfahrtagentur (ESA).
> Weitere Informationen: <http://step.esa.int/main/download/snap-download/>.

- Zeige alle Updates an:

`snap --nosplash --nogui --modules --list --refresh`

- Zeige Hilfe an:

`snap --help`
