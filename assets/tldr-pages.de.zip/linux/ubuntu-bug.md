# ubuntu-bug

> Dieser Befehl ist ein Alias von `apport-bug`.
> Weitere Informationen: <https://manned.org/ubuntu-bug>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr apport-bug`
