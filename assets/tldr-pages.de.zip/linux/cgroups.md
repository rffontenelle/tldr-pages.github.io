# cgroups

> Dieser Befehl ist ein Alias von `cgclassify`.
> Weitere Informationen: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr cgclassify`
