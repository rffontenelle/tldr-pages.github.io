# a2enmod

> Aktiviert ein Apache-Modul auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manned.org/a2enmod.8>.

- Aktiviere ein Modul:

`sudo a2enmod {{modul}}`

- Zeige keine Informationsnachrichten an:

`sudo a2enmod --quiet {{modul}}`
