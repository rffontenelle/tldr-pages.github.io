# google-chrome

> Der Webbrowser von Google.
> Weitere Informationen: <https://chrome.google.com>.

- Starte mit einem benutzerdefinierten Profilverzeichnis:

`google-chrome --user-data-dir={{pfad/zu/verzeichnis}}`

- Starte ohne CORS-Validierung, nützlich zum Testen einer API:

`google-chrome --user-data-dir={{pfad/zu/verzeichnis}} --disable-web-security`
