# alpine

> Ein E-Mail und Usenet Client mit pico/nano-inspirierten Interface.
> Unterstützt die meisten modernen IMAP Server.
> Weitere Informationen: <https://manned.org/alpine>.

- Öffne Alpine:

`alpine`

- Öffne alpine im E-Mail-Editor, um eine E-Mail an eine bestimmte Adresse zu verfassen:

`alpine {{email@example.net}}`

- Beende Alpine:

`q + y`
