# qm-move-disk

> Dieser Befehl ist ein Alias von `qm-disk-move`.
> Weitere Informationen: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr qm-disk-move`
