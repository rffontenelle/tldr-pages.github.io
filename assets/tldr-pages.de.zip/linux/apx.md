# apx

> Dieser Befehl ist ein Alias von `apx pkgmanagers`.
> Weitere Informationen: <https://github.com/Vanilla-OS/apx>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr apx pkgmanagers`
