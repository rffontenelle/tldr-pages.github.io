# pkgctl

> Dieser Befehl ist ein Alias von `pkgctl auth`.
> Weitere Informationen: <https://man.archlinux.org/man/pkgctl.1>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr pkgctl auth`
