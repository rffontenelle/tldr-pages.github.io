# ip6tables-restore

> Dieser Befehl ist ein Alias von `iptables-restore`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr iptables-restore`
