# ip6tables

> Dieser Befehl ist ein Alias von `iptables`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr iptables`
