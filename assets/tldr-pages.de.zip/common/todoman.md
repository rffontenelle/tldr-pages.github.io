# todoman

> Dieser Befehl ist ein Alias von `todo`.
> Weitere Informationen: <https://todoman.readthedocs.io/>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr todo`
