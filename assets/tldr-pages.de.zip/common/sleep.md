# sleep

> Verzögert für einen bestimmten Zeitraum.
> Weitere Informationen: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html>.

- Verzögere in Sekunden:

`sleep {{sekunden}}`

- Verzögere in Minuten:

`sleep {{minuten}}m`

- Verzögere in Stunden:

`sleep {{stunden}}h`
