# mscore

> Dieser Befehl ist ein Alias von `musescore`.
> Weitere Informationen: <https://musescore.org/handbook/command-line-options>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr musescore`
