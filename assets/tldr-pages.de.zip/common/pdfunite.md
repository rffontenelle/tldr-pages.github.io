# pdfunite

> Füge PDF Dateien zusammen.
> Weitere Informationen: <https://github.com/mtgrosser/pdfunite>.

- Füge zwei PDF Dateien zu einer PDF Datei zusammen:

`pdfunite {{pfad/zu/datei1.pdf}} {{pfad/zu/datei2.pdf}} {{pfad/zu/zieldatei.pdf}}`

- Füge alle PDF Dateien in einem Verzeichnis zu einer PDF Datei zusammen:

`pdfunite {{pfad/zu/verzeichnis/*.pdf}} {{pfad/zu/zieldatei.pdf}}`
