# sc_warts2json

> Wandelt eine `warts`-Datei in eine `json`-Datei um:
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Wandle `warts'-Dateien in JSON um und gebe dieses aus:

`sc_warts2json {{path/to/file1.warts path/to/file2.warts ...}}`
