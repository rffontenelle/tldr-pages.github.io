# sc_warts2csv

> Umwandlung von tracroutes aus `warts`-Dateien in das CSV-Format.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Wandle traceroute-Daten in einer `warts`-Datei in CSV um und gebe dieses aus:

`sc_warts2csv {{path/to/file1.warts path/to/file2.warts ...}}`
