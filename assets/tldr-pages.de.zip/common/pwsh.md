# pwsh

> Dieser Befehl ist ein Alias von `powershell`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr powershell`
