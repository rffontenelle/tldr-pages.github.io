# docker-container-rename

> Dieser Befehl ist ein Alias von `docker rename`.
> Weitere Informationen: <https://docs.docker.com/engine/reference/commandline/rename>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr docker rename`
