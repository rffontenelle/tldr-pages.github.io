# hd

> Dieser Befehl ist ein Alias von `hexdump`.
> Weitere Informationen: <https://manned.org/hd.1>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr hexdump`
