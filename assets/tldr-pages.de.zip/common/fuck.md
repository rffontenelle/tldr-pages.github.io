# fuck

> Korrigiert den zuletzt ausgeführten Befehl.
> Weitere Informationen: <https://github.com/nvbn/thefuck>.

- Lege den `fuck` alias für `thefuck` fest:

`eval "$(thefuck --alias)"`

- Versuche den zuletzt ausgeführten Befehl zu korrigieren:

`fuck`

- Bestätige das erste Ergebnis sofort (korrektes Argument hängt vom Level der Frustration ab):

`fuck --{{yes|yeah|hard}}`
