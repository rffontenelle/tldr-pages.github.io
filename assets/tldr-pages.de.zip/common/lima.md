# lima

> Dieser Befehl ist ein Alias von `limactl`.
> Weitere Informationen: <https://github.com/lima-vm/lima>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr limactl`
