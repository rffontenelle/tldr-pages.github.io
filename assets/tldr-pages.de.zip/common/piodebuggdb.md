# piodebuggdb

> Dieser Befehl ist ein Alias von `pio debug`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr pio debug`
