# tldrl

> Dieser Befehl ist ein Alias von `tldr-lint`.
> Weitere Informationen: <https://github.com/tldr-pages/tldr-lint>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr tldr-lint`
