# platformio

> Dieser Befehl ist ein Alias von `pio`.
> Weitere Informationen: <https://docs.platformio.org/en/latest/core/userguide/>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr pio`
