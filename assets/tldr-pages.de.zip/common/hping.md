# hping

> Dieser Befehl ist ein Alias von `hping3`.
> Weitere Informationen: <https://github.com/antirez/hping>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr hping3`
