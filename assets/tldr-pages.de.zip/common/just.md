# just

> Dieser Befehl ist ein Alias von `just.1`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr just.1`
