# docker-container-diff

> Dieser Befehl ist ein Alias von `docker diff`.
> Weitere Informationen: <https://docs.docker.com/engine/reference/commandline/diff>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr docker diff`
