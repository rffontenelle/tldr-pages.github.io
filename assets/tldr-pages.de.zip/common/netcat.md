# netcat

> Dieser Befehl ist ein Alias von `nc`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr nc`
