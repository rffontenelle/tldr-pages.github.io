# exit

> Verlasse die Shell.
> Weitere Informationen: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#exit>.

- Beende die Shell mit dem Exitcode des zuletzt ausgeführten Befehls:

`exit`

- Beende die Shell mit dem angegebenen Exitcode:

`exit {{exitcode}}`
