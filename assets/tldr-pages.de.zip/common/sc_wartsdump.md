# sc_wartsdump

> Ausführliche Ausgabe der in einer `warts`-Datei enthaltenen Daten.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Gib den Inhalt von `warts`-Dateien ausführlich aus:

`sc_wartsdump {{path/to/file1.warts path/to/file2.warts ...}}`
