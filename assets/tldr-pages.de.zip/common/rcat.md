# rcat

> Dieser Befehl ist ein Alias von `rc`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr rc`
