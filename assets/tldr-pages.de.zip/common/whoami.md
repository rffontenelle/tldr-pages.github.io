# whoami

> Gib den Benutzernamen des aktuellen Benutzers aus.
> Weitere Informationen: <https://www.gnu.org/software/coreutils/whoami>.

- Gib den aktiven Benutzernamen aus:

`whoami`

- Gib den Benutzernamen nach einer Änderung der Benutzeridentität aus:

`sudo whoami`
