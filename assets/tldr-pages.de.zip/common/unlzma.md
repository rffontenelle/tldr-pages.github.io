# unlzma

> Dieser Befehl ist ein Alias von `xz`.
> Weitere Informationen: <https://manned.org/unlzma>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr xz`
