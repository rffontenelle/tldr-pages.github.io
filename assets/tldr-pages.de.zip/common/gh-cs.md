# gh-cs

> Dieser Befehl ist ein Alias von `gh-codespace`.
> Weitere Informationen: <https://cli.github.com/manual/gh_codespace>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr gh-codespace`
