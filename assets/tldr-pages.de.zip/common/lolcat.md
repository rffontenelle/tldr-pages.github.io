# lolcat

> Färbe Text in Regenbogenfarben ein.
> Weitere Informationen: <https://github.com/busyloop/lolcat>.

- Gib den Inhalt einer Datei in Regenbogenfarben in der Konsole aus:

`lolcat {{pfad/zu/datei}}`

- Gib die Ausgabe eines Befehls in Regenbogenfarben in der Konsole aus:

`{{fortune}} | lolcat`

- Gib den Inhalt einer Datei in animierten Regenbogenfarben in der Konsole aus:

`lolcat -a {{pfad/zu/datei}}`

- Gib den Inhalt einer Datei in 24-bit (truecolor) Regenbogenfarben in der Konsole aus:

`lolcat -t {{pfad/zu/datei}}`
