# lzgrep

> Dieser Befehl ist ein Alias von `xzgrep`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr xzgrep`
