# azure-cli

> Dieser Befehl ist ein Alias von `az`.
> Weitere Informationen: <https://learn.microsoft.com/cli/azure>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr az`
