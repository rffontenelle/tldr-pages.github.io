# zstdcat

> Dieser Befehl ist ein Alias von `zstd`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr zstd`
