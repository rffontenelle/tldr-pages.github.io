# cola

> Dieser Befehl ist ein Alias von `git-cola`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr git-cola`
