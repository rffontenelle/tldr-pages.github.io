# git setup

> Erstelle ein Git Repository in einem bestimmten Verzeichnis und committe alle Dateien.
> Teil der `git-extras`.
> Weitere Informationen: <https://github.com/tj/git-extras/blob/master/Commands.md#git-setup>.

- Erstelle ein Git Repository im aktuellen Verzeichnis und committe alle Dateien:

`git setup`

- Erstelle ein Git Repository in einem bestimmten Verzeichnis und committe alle Dateien:

`git setup {{pfad/zu/verzeichnis}}`
