# stun

> Classic STUN-Client.
> Weitere Informationen: <https://manned.org/stun.1>.

- Stelle eine STUN-Anfrage:

`stun {{stun.1und1.de}}`

- Stelle eine STUN-Anfrage und spezifiziere den Quellport:

`stun {{stun.1und1.de}} -p {{4302}}`
