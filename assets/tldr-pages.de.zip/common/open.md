# open

> Dieser Befehl ist ein Alias von `open -p osx`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr open -p osx`
