# linode-cli

> Dieser Befehl ist ein Alias von `linode-cli account`.
> Weitere Informationen: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr linode-cli account`
