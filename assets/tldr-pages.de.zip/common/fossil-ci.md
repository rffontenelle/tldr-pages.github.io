# fossil ci

> Dieser Befehl ist ein Alias von  `fossil commit`.
> Weitere Informationen: <https://fossil-scm.org/home/help/commit>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr fossil-commit`
