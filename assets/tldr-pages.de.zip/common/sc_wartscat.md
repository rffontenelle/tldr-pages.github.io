# sc_wartscat

> Füge mehrere `warts`-Dateien zusammen.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Verkette mehrere `warts`-Dateien zu Einer:

`sc_wartscat -o {{path/to/output.warts}} {{path/to/file1.warts path/to/file2.warts ...}}`
