# fossil-new

> Dieser Befehl ist ein Alias von `fossil-init`.
> Weitere Informationen: <https://fossil-scm.org/home/help/new>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr fossil-init`
