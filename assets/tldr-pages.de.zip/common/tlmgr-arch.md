# tlmgr-arch

> Dieser Befehl ist ein Alias von `tlmgr platform`.
> Weitere Informationen: <https://www.tug.org/texlive/tlmgr.html>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr tlmgr platform`
