# lzmore

> Dieser Befehl ist ein Alias von `xzmore`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr xzmore`
