# gnmic-sub

> Dieser Befehl ist ein Alias von `gnmic subscribe`.
> Weitere Informationen: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr gnmic subscribe`
