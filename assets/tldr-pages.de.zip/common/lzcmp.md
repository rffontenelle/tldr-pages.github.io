# lzcmp

> Dieser Befehl ist ein Alias von `xzcmp`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr xzcmp`
