# docker-container-remove

> Dieser Befehl ist ein Alias von `docker rm`.
> Weitere Informationen: <https://docs.docker.com/engine/reference/commandline/rm>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr docker rm`
