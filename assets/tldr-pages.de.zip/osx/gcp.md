# gcp

> Dieser Befehl ist ein Alias von `-p linux cp`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux cp`
