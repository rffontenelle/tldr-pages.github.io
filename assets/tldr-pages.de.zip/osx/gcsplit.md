# gcsplit

> Dieser Befehl ist ein Alias von `-p linux csplit`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux csplit`
