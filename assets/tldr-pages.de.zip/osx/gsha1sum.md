# gsha1sum

> Dieser Befehl ist ein Alias von `-p linux sha1sum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux sha1sum`
