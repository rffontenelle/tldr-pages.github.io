# gvdir

> Dieser Befehl ist ein Alias von `-p linux vdir`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux vdir`
