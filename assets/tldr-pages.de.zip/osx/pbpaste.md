# pbpaste

> Sende den Inhalt der Zwischenablage zum Standardoutput.
> Weitere Informationen: <https://keith.github.io/xcode-man-pages/pbpaste.1.html>.

- Schreibe den Inhalt der Zwischenablage in eine Datei:

`pbpaste > {{datei}}`

- Benutze die Zwischenablage als Eingabe für andere Kommandos:

`pbpaste | grep foo`
