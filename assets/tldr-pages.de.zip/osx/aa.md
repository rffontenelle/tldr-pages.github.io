# aa

> Dieser Befehl ist ein Alias von `yaa`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr yaa`
