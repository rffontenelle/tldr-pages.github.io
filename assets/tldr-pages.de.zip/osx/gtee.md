# gtee

> Dieser Befehl ist ein Alias von `-p linux tee`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux tee`
