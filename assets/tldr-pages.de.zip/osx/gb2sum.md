# gb2sum

> Dieser Befehl ist ein Alias von `-p linux b2sum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux b2sum`
