# gmv

> Dieser Befehl ist ein Alias von `-p linux mv`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux mv`
