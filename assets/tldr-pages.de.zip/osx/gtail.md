# gtail

> Dieser Befehl ist ein Alias von `-p linux tail`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux tail`
