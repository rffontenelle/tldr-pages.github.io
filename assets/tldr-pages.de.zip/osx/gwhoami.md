# gwhoami

> Dieser Befehl ist ein Alias von `-p linux whoami`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux whoami`
