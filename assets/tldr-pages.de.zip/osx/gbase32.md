# gbase32

> Dieser Befehl ist ein Alias von `-p linux base32`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux base32`
