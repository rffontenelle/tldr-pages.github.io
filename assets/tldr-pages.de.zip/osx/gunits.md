# gunits

> Dieser Befehl ist ein Alias von `-p linux units`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux units`
