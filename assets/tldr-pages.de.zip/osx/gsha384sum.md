# gsha384sum

> Dieser Befehl ist ein Alias von `-p linux sha384sum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux sha384sum`
