# gecho

> Dieser Befehl ist ein Alias von `-p linux echo`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux echo`
