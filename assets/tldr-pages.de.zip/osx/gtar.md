# gtar

> Dieser Befehl ist ein Alias von `-p linux tar`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux tar`
