# gwhois

> Dieser Befehl ist ein Alias von `-p linux whois`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux whois`
