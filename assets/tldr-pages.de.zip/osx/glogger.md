# glogger

> Dieser Befehl ist ein Alias von `-p linux logger`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux logger`
