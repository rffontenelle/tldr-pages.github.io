# gshred

> Dieser Befehl ist ein Alias von `-p linux shred`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux shred`
