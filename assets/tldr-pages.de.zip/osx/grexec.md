# grexec

> Dieser Befehl ist ein Alias von `-p linux rexec`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux rexec`
