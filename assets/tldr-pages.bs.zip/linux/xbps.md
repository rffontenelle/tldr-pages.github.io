# xbps

> Ova komanda je pseudonim za `xbps-install`.
> Više informacija: <https://docs.voidlinux.org/xbps/index.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xbps-install`
