# systemd-umount

> Ova komanda je pseudonim za `systemd-mount`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr systemd-mount`
