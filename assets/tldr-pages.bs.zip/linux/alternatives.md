# alternatives

> Ova komanda je pseudonim za `update-alternatives`.
> Više informacija: <https://manned.org/alternatives>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr update-alternatives`
