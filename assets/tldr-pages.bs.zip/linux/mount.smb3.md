# mount.smb3

> Ova komanda je pseudonim za `mount.cifs`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr mount.cifs`
