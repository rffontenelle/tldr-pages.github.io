# shntool-split

> Ova komanda je pseudonim za `shnsplit`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr shnsplit`
