# distrobox

> Ova komanda je pseudonim za `distrobox-create`.
> Više informacija: <https://github.com/89luca89/distrobox>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr distrobox-create`
