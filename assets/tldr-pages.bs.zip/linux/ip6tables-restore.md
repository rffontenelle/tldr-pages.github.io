# ip6tables-restore

> Ova komanda je pseudonim za `iptables-restore`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr iptables-restore`
