# apx

> Ova komanda je pseudonim za `apx pkgmanagers`.
> Više informacija: <https://github.com/Vanilla-OS/apx>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr apx pkgmanagers`
