# qm-move-disk

> Ova komanda je pseudonim za `qm-disk-move`.
> Više informacija: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr qm-disk-move`
