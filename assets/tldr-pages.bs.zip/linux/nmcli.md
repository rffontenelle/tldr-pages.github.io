# nmcli

> Ova komanda je pseudonim za `nmcli agent`.
> Više informacija: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr nmcli agent`
