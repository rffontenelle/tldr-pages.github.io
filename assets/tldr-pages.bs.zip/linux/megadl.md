# megadl

> Ova komanda je pseudonim za `megatools-dl`.
> Više informacija: <https://megatools.megous.com/man/megatools-dl.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr megatools-dl`
