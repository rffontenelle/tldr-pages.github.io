# pkgctl

> Ova komanda je pseudonim za `pkgctl auth`.
> Više informacija: <https://man.archlinux.org/man/pkgctl.1>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr pkgctl auth`
