# ip6tables

> Ova komanda je pseudonim za `iptables`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr iptables`
