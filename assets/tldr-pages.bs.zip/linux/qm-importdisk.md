# qm-importdisk

> Ova komanda je pseudonim za `qm disk import`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr qm disk import`
