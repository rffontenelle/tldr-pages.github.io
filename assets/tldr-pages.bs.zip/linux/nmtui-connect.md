# nmtui-connect

> Ova komanda je pseudonim za `nmtui`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr nmtui`
