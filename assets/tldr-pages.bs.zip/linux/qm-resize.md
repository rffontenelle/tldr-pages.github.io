# qm-resize

> Ova komanda je pseudonim za `qm-disk-resize`.
> Više informacija: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr qm-disk-resize`
