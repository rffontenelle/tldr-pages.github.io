# ip6tables-save

> Ova komanda je pseudonim za `iptables-save`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr iptables-save`
