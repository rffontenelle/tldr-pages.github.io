# ged

> Ova komanda je pseudonim za `-p linux ed`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux ed`
