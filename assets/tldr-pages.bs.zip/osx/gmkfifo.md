# gmkfifo

> Ova komanda je pseudonim za `-p linux mkfifo`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux mkfifo`
