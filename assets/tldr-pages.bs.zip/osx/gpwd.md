# gpwd

> Ova komanda je pseudonim za `-p linux pwd`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux pwd`
