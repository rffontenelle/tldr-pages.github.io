# gtouch

> Ova komanda je pseudonim za `-p linux touch`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux touch`
