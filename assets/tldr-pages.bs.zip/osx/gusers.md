# gusers

> Ova komanda je pseudonim za `-p linux users`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux users`
