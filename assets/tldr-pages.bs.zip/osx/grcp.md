# grcp

> Ova komanda je pseudonim za `-p linux rcp`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux rcp`
