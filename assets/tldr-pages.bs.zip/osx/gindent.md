# gindent

> Ova komanda je pseudonim za `-p linux indent`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux indent`
