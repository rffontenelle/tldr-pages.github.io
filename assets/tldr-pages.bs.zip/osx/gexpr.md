# gexpr

> Ova komanda je pseudonim za `-p linux expr`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux expr`
