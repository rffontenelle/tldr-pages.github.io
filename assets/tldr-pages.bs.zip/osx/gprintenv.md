# gprintenv

> Ova komanda je pseudonim za `-p linux printenv`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux printenv`
