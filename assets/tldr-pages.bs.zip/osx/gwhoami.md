# gwhoami

> Ova komanda je pseudonim za `-p linux whoami`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux whoami`
