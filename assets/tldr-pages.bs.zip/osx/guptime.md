# guptime

> Ova komanda je pseudonim za `-p linux uptime`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux uptime`
