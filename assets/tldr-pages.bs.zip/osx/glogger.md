# glogger

> Ova komanda je pseudonim za `-p linux logger`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux logger`
