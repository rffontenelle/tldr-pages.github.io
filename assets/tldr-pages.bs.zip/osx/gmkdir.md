# gmkdir

> Ova komanda je pseudonim za `-p linux mkdir`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux mkdir`
