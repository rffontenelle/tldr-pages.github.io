# launchd

> Ova komanda je pseudonim za `launchctl`.
> Više informacija: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr launchctl`
