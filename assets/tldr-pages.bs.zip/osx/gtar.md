# gtar

> Ova komanda je pseudonim za `-p linux tar`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux tar`
