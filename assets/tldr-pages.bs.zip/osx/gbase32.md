# gbase32

> Ova komanda je pseudonim za `-p linux base32`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux base32`
