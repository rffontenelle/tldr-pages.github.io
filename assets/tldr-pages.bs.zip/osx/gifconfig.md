# gifconfig

> Ova komanda je pseudonim za `-p linux ifconfig`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux ifconfig`
