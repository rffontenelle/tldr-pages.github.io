# aa

> Ova komanda je pseudonim za `yaa`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr yaa`
