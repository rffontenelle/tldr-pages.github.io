# gwhois

> Ova komanda je pseudonim za `-p linux whois`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux whois`
