# glibtoolize

> Ova komanda je pseudonim za `-p linux libtoolize`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux libtoolize`
