# gchcon

> Ova komanda je pseudonim za `-p linux chcon`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux chcon`
