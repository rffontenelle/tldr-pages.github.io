# gkill

> Ova komanda je pseudonim za `-p linux kill`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux kill`
