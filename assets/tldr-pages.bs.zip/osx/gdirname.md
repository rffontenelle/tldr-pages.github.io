# gdirname

> Ova komanda je pseudonim za `-p linux dirname`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux dirname`
