# llvm-lipo

> Ova komanda je pseudonim za `lipo`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr lipo`
