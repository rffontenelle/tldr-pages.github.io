# grm

> Ova komanda je pseudonim za `-p linux rm`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux rm`
