# gmd5sum

> Ova komanda je pseudonim za `-p linux md5sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux md5sum`
