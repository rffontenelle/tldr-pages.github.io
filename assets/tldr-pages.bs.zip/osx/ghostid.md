# ghostid

> Ova komanda je pseudonim za `-p linux hostid`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux hostid`
