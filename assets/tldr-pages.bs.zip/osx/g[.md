# g[

> Ova komanda je pseudonim za `-p linux [`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux [`
