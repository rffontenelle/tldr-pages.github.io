# gchgrp

> Ova komanda je pseudonim za `-p linux chgrp`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux chgrp`
