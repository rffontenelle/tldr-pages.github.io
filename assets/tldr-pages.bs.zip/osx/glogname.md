# glogname

> Ova komanda je pseudonim za `-p linux logname`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux logname`
