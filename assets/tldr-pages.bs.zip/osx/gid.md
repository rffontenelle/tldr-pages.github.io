# gid

> Ova komanda je pseudonim za `-p linux id`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux id`
