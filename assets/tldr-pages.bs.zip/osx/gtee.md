# gtee

> Ova komanda je pseudonim za `-p linux tee`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux tee`
