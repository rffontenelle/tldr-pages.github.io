# gstdbuf

> Ova komanda je pseudonim za `-p linux stdbuf`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux stdbuf`
