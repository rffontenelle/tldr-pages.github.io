# gseq

> Ova komanda je pseudonim za `-p linux seq`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux seq`
