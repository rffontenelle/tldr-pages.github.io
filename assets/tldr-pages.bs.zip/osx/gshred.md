# gshred

> Ova komanda je pseudonim za `-p linux shred`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux shred`
