# gwho

> Ova komanda je pseudonim za `-p linux who`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux who`
