# gnproc

> Ova komanda je pseudonim za `-p linux nproc`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux nproc`
