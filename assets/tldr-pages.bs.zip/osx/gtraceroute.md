# gtraceroute

> Ova komanda je pseudonim za `-p linux traceroute`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux traceroute`
