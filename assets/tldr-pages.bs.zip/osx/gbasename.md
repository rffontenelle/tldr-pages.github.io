# gbasename

> Ova komanda je pseudonim za `-p linux basename`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux basename`
