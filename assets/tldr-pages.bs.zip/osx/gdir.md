# gdir

> Ova komanda je pseudonim za `-p linux dir`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux dir`
