# gvdir

> Ova komanda je pseudonim za `-p linux vdir`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux vdir`
