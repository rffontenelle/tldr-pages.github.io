# gpathchk

> Ova komanda je pseudonim za `-p linux pathchk`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux pathchk`
