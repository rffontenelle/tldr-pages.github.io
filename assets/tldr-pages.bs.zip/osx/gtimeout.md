# gtimeout

> Ova komanda je pseudonim za `-p linux timeout`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux timeout`
