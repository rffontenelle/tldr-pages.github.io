# gnl

> Ova komanda je pseudonim za `-p linux nl`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux nl`
