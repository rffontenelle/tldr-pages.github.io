# gmake

> Ova komanda je pseudonim za `-p linux make`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux make`
