# gsha1sum

> Ova komanda je pseudonim za `-p linux sha1sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sha1sum`
