# gptx

> Ova komanda je pseudonim za `-p linux ptx`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux ptx`
