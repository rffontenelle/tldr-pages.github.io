# gtrue

> Ova komanda je pseudonim za `-p linux true`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux true`
