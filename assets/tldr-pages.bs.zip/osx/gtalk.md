# gtalk

> Ova komanda je pseudonim za `-p linux talk`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux talk`
