# gnohup

> Ova komanda je pseudonim za `-p linux nohup`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux nohup`
