# gecho

> Ova komanda je pseudonim za `-p linux echo`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux echo`
