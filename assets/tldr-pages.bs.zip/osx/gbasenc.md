# gbasenc

> Ova komanda je pseudonim za `-p linux basenc`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux basenc`
