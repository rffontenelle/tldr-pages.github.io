# gftp

> Ova komanda je pseudonim za `-p linux ftp`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux ftp`
