# gwc

> Ova komanda je pseudonim za `-p linux wc`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux wc`
