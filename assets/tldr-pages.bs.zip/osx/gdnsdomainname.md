# gdnsdomainname

> Ova komanda je pseudonim za `-p linux dnsdomainname`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux dnsdomainname`
