# gtr

> Ova komanda je pseudonim za `-p linux tr`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux tr`
