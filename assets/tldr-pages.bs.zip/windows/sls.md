# sls

> Ova komanda je pseudonim za `Select-String`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr select-string`
