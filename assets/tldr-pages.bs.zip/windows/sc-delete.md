# sc-delete

> Ova komanda je pseudonim za `sc`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr sc`
