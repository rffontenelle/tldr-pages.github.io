# ri

> Ova komanda je pseudonim za `remove-item`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr remove-item`
