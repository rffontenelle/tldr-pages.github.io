# rmdir

> Ova komanda je pseudonim za `remove-item`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr remove-item`
