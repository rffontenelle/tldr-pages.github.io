# cd

> Ova komanda je pseudonim za `set-location`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr set-location`
