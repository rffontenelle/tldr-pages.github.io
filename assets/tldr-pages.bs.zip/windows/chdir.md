# chdir

> Ova komanda je pseudonim za `cd`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr cd`
