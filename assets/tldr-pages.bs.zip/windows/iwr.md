# iwr

> Ova komanda je pseudonim za `invoke-webrequest`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr invoke-webrequest`
