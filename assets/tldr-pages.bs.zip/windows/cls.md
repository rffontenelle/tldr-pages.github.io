# cls

> Ova komanda je pseudonim za `clear-host`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr clear-host`
