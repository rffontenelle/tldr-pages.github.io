# sl

> Ova komanda je pseudonim za `set-location`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr set-location`
