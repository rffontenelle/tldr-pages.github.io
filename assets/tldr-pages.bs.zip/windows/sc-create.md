# sc-create

> Ova komanda je pseudonim za `sc`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr sc`
