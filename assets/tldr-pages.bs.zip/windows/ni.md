# ni

> Ova komanda je pseudonim za `new-item`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr new-item`
