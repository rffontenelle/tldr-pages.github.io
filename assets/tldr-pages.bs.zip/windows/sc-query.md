# sc-query

> Ova komanda je pseudonim za `sc`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr sc`
