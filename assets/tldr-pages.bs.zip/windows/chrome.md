# chrome

> Ova komanda je pseudonim za `chromium`.
> Više informacija: <https://chrome.google.com>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr chromium`
