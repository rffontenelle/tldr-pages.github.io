# slmgr

> Ova komanda je pseudonim za `slmgr.vbs`.
> Više informacija: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr slmgr.vbs`
