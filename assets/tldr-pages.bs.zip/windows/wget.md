# wget

> Ova komanda je pseudonim za `wget -p common`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr wget -p common`
