# wget

> Ova komanda je pseudonim za `wget -p common`.
> Više informacija: <https://www.gnu.org/software/wget>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr wget -p common`
