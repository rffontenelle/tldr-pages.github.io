# clear

> Ova komanda je pseudonim za `clear-host`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr clear-host`
