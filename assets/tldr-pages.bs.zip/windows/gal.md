# gal

> Ova komanda je pseudonim za `get-alias`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr get-alias`
