# pkg

> Ova komanda je pseudonim za `pkg_add`.
> Više informacija: <https://www.openbsd.org/faq/faq15.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr pkg_add`
