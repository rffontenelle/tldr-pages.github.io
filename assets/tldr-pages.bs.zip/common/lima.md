# lima

> Ova komanda je pseudonim za `limactl`.
> Više informacija: <https://github.com/lima-vm/lima>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr limactl`
