# ptpython3

> Ova komanda je pseudonim za `ptpython`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr ptpython`
