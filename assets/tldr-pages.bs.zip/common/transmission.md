# transmission

> Ova komanda je pseudonim za `transmission-daemon`.
> Više informacija: <https://transmissionbt.com/>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr transmission-daemon`
