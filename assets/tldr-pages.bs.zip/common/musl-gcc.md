# musl-gcc

> Ova komanda je pseudonim za `gcc`.
> Više informacija: <https://manned.org/musl-gcc>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr gcc`
