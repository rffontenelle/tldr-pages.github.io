# rcat

> Ova komanda je pseudonim za `rc`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr rc`
