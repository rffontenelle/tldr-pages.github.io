# cron

> Ova komanda je pseudonim za `crontab`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr crontab`
