# clamav

> Ova komanda je pseudonim za `clamdscan`.
> Više informacija: <https://www.clamav.net>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr clamdscan`
