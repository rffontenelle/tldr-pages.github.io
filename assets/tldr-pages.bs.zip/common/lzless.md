# lzless

> Ova komanda je pseudonim za `xzless`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xzless`
