# docker-container-rm

> Ova komanda je pseudonim za `docker rm`.
> Više informacija: <https://docs.docker.com/engine/reference/commandline/rm>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr docker rm`
