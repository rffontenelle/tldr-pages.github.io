# azure-cli

> Ova komanda je pseudonim za `az`.
> Više informacija: <https://learn.microsoft.com/cli/azure>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr az`
