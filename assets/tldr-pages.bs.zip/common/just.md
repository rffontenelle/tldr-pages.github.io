# just

> Ova komanda je pseudonim za `just.1`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr just.1`
