# open

> Ova komanda je pseudonim za `open -p osx`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr open -p osx`
