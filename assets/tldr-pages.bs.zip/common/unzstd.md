# unzstd

> Ova komanda je pseudonim za `zstd`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr zstd`
