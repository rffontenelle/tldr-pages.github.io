# xzfgrep

> Ova komanda je pseudonim za `xzgrep`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xzgrep`
