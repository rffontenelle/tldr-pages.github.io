# docker-container-top

> Ova komanda je pseudonim za `docker top`.
> Više informacija: <https://docs.docker.com/engine/reference/commandline/top>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr docker top`
