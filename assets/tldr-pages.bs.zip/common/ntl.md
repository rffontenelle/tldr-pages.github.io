# ntl

> Ova komanda je pseudonim za `netlify`.
> Više informacija: <https://cli.netlify.com>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr netlify`
