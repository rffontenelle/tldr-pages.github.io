# netcat

> Ova komanda je pseudonim za `nc`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr nc`
