# llvm-nm

> Ova komanda je pseudonim za `nm`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr nm`
