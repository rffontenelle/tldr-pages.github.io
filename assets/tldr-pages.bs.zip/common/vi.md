# vi

> Ova komanda je pseudonim za `vim`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr vim`
