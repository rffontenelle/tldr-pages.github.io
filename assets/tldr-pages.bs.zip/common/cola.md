# cola

> Ova komanda je pseudonim za `git-cola`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr git-cola`
