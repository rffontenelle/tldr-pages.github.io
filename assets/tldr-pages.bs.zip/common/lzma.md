# lzma

> Ova komanda je pseudonim za `xz`.
> Više informacija: <https://manned.org/lzma>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xz`
