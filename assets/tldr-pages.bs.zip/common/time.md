# time

> Vidi koliko dugo traje komanda.
> Više informacija: <https://manned.org/time>.

- Vrijeme `komanda`:

`time {{komanda}}`
