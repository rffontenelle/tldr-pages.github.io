# lzcmp

> Ova komanda je pseudonim za `xzcmp`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xzcmp`
