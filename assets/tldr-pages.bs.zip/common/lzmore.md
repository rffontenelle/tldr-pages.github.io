# lzmore

> Ova komanda je pseudonim za `xzmore`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xzmore`
