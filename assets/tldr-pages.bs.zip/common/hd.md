# hd

> Ova komanda je pseudonim za `hexdump`.
> Više informacija: <https://manned.org/hd.1>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr hexdump`
