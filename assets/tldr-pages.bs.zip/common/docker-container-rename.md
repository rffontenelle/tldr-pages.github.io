# docker-container-rename

> Ova komanda je pseudonim za `docker rename`.
> Više informacija: <https://docs.docker.com/engine/reference/commandline/rename>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr docker rename`
