# pwsh

> Ova komanda je pseudonim za `powershell`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr powershell`
