# false

> Vrati izlazni kod od 1.
> Više informacija: <https://www.gnu.org/software/coreutils/false>.

- Vrati izlazni kod od 1:

`false`
