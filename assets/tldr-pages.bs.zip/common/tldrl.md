# tldrl

> Ova komanda je pseudonim za `tldr-lint`.
> Više informacija: <https://github.com/tldr-pages/tldr-lint>.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr tldr-lint`
