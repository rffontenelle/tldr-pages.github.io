# linode-cli

> Ova komanda je pseudonim za `linode-cli account`.
> Više informacija: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr linode-cli account`
