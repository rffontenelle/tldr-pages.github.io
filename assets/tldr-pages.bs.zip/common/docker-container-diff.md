# docker-container-diff

> Ova komanda je pseudonim za `docker diff`.
> Više informacija: <https://docs.docker.com/engine/reference/commandline/diff>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr docker diff`
