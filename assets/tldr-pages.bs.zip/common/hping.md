# hping

> Ova komanda je pseudonim za `hping3`.
> Više informacija: <https://github.com/antirez/hping>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr hping3`
