# ripgrep

> Ova komanda je pseudonim za `rg`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr rg`
