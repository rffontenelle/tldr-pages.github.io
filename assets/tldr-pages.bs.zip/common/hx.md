# hx

> Ova komanda je pseudonim za `helix`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr helix`
