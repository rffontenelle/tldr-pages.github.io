# screencap

> 捕获移动设备显示器的屏幕截图。
> 此命令只能通过 `adb shell` 使用。
> 更多信息：<https://developer.android.com/tools/adb#screencap>.

- 捕获屏幕截图：

`screencap {{路径/到/文件}}`
