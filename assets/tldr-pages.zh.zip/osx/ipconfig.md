# ipconfig

> 查看和编辑网卡信息.
> 更多信息：<https://ss64.com/osx/ipconfig.html>.

- 列出所有的网卡：

`ipconfig getiflist`

- 获取特定网卡的地址信息：

`ipconfig getifaddr {{接口名称}}`
