# gbase32

> 这是 `-p linux base32` 命令的一个别名。

- 原命令的文档在：

`tldr -p linux base32`
