# head

> 输出文件的开头部分。
> 更多信息：<https://keith.github.io/xcode-man-pages/head.1.html>.

- 输出文件的前几行：

`head -n {{行数}} {{文件名}}`

- 输出文件的前几个字节：

`head -c {{字节数}} {{文件名}}`
