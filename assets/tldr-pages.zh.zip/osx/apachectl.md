# apachectl

> 用于 macOS 的 Apache HTTP Server 控制接口（工具）。
> 更多信息：<https://www.unix.com/man-page/osx/8/apachectl/>.

- 启动 org.apache.httpd 服务：

`apachectl start`

- 停止已启动的服务：

`apachectl stop`

- 重新启动服务：

`apachectl restart`
