# wifi-password

> 获取 Wi-Fi 的密码。
> 更多信息：<https://github.com/rauchg/wifi-password>.

- 获取你当前登录的 Wi-Fi 的密码：

`wifi-password`

- 获取特定 SSID 的 Wi-Fi 的密码：

`wifi-password {{ssid}}`

- 仅输出密码：

`wifi-password -q`
