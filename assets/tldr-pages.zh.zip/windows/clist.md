# clist

> 这是 `choco list` 命令的一个别名。
> 更多信息：<https://docs.chocolatey.org/en-us/choco/commands/list>.

- 原命令的文档在：

`tldr choco list`
