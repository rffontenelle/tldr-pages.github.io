# sls

> 这是 `Select-String` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- 原命令的文档在：

`tldr select-string`
