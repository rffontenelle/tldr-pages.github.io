# reg unload

> 从使用`reg load`命令加载的注册表中删除数据。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/reg-unload>.

- 从使用`reg load`命令加载的注册表中删除数据：

`reg unload {{键名}}`
