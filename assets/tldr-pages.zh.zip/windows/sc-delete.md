# sc-delete

> 这是 `sc` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- 原命令的文档在：

`tldr sc`
