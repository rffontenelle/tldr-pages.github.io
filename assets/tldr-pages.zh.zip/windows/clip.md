# clip

> 将输入的内容复制到 Windows 的剪贴板。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/clip>.

- 用管道将命令的输出内容复制到 Windows 剪贴板：

`{{dir}} | clip`

- 将一个文件中的内容复制到 Windows 剪贴板：

`clip < {{文件的路径}}`
