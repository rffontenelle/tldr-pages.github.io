# sl

> 这是 `set-location` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- 原命令的文档在：

`tldr set-location`
