# chdir

> 这是 `cd` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- 原命令的文档在：

`tldr cd`
