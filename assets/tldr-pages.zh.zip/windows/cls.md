# cls

> 这是 `clear-host` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- 原命令的文档在：

`tldr clear-host`
