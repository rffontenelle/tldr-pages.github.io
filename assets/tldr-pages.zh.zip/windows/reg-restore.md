# reg restore

> 从备份文件中恢复键和值。
> 参见 `reg-save` 来获取更多的信息。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/reg-restore>.

- 使用备份文件中的数据覆盖指定的键：

`reg restore {{键名}} {{文件路径}}`
