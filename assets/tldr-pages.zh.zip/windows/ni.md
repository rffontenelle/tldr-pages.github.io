# ni

> 这是 `new-item` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- 原命令的文档在：

`tldr new-item`
