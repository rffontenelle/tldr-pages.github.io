# curl

> 这是 `curl -p common` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- 原命令的文档在：

`tldr curl -p common`
