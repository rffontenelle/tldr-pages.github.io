# curl

> 这是 `curl -p common` 命令的一个别名。
> 更多信息：<https://curl.se>.

- 原命令的文档在：

`tldr curl -p common`
