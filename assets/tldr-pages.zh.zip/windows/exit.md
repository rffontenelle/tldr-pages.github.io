# exit

> 退出当前的命令行实例或 bat 脚本。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- 退出当前的命令行实例：

`exit`

- 退出当前的 bat 脚本：

`exit /b`

- 使用一个指定的退出码退出：

`exit {{退出码}}`
