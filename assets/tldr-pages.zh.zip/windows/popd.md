# popd

> 将当前目录切换到`pushd`命令存储的目录。
> 更多信息：<https://learn.microsoft.com/windows-server/administration/windows-commands/popd>.

- 切换到储存在栈顶的目录：

`popd`
