# docker-container-rename

> 这是 `docker rename` 命令的一个别名。
> 更多信息：<https://docs.docker.com/engine/reference/commandline/rename>.

- 原命令的文档在：

`tldr docker rename`
