# lima

> 这是 `limactl` 命令的一个别名。
> 更多信息：<https://github.com/lima-vm/lima>.

- 原命令的文档在：

`tldr limactl`
