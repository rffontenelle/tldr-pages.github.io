# transmission

> 这是 `transmission-daemon` 命令的一个别名。
> 更多信息：<https://transmissionbt.com/>.

- 原命令的文档在：

`tldr transmission-daemon`
