# linode-cli

> 这是 `linode-cli account` 命令的一个别名。
> 更多信息：<https://www.linode.com/docs/products/tools/cli/get-started/>.

- 原命令的文档在：

`tldr linode-cli account`
