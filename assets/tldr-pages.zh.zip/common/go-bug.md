# go bug

> 报告一个错误。
> 更多信息：<https://golang.org/cmd/go/#hdr-Start_a_bug_report>.

- 打开一个网页并开始报告错误：

`go bug`
