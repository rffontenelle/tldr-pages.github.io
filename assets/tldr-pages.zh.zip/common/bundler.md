# bundler

> 这是 `bundle` 命令的一个别名。
> 更多信息：<https://bundler.io/man/bundle.1.html>.

- 原命令的文档在：

`tldr bundle`
