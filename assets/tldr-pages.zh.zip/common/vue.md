# vue

> 适用于 Vue.js 项目的多用途命令行接口。
> 此命令也有关于其子命令的文件，例如：`vue build`。
> 更多信息：<https://cli.vuejs.org>.

- 交互式地创建一个新的 Vue 项目：

`vue create {{项目名}}`

- 使用图形化界面创建一个新项目：

`vue ui`
