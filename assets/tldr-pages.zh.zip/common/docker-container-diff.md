# docker-container-diff

> 这是 `docker diff` 命令的一个别名。
> 更多信息：<https://docs.docker.com/engine/reference/commandline/diff>.

- 原命令的文档在：

`tldr docker diff`
