# airpaste

> 在同一网络下共享信息和文件。
> 更多信息：<https://github.com/mafintosh/airpaste>.

- 等待接收消息并显示接收到的信息：

`airpaste`

- 发送文本：

`echo {{文本}} | airpaste`

- 发送文件：

`airpaste < {{文件的路径}}`

- 接收文件：

`airpaste > {{文件的路径}}`

- 创建 / 加入频道：

`airpaste {{频道名}}`
