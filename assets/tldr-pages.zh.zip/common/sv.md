# sv

> 控制正在运行的服务。
> 更多信息：<https://manpages.ubuntu.com/manpages/latest/man8/sv.8.html>.

- 启动服务：

`sudo sv up {{目标目录 / 服务文件}}`

- 停止服务：

`sudo sv down {{目标目录 / 服务文件}}`

- 获取服务状态：

`sudo sv status {{目标目录 / 服务文件}}`
