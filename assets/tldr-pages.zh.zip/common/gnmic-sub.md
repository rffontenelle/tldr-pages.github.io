# gnmic-sub

> 这是 `gnmic subscribe` 命令的一个别名。
> 更多信息：<https://gnmic.kmrd.dev/cmd/subscribe>.

- 原命令的文档在：

`tldr gnmic subscribe`
