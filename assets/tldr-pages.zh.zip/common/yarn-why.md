# yarn-why

> 确认安装这个 Yarn 软件包的原因。
> 更多信息：<https://github.com/amio/yarn-why>.

- 打印安装这个 Yarn 软件包的原因：

`yarn-why {{package_name}}`
