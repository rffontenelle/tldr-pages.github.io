# view

> `vim` 的只读版本。
> 等效于 `vim -R`.
> 更多信息：<https://www.vim.org>.

- 打开文件：

`view {{file}}`
