# mkdir

> 创建目录。
> 更多信息：<https://www.gnu.org/software/coreutils/mkdir>.

- 在当前目录下创建多个目录：

`mkdir {{路径/到/目录1 路径/到/目录2 ...}}`

- 递归地创建目录（对创建嵌套目录很有用）：

`mkdir {{-p|--parents} {{路径/到/目录1 路径/到/目录2 ...}}`
