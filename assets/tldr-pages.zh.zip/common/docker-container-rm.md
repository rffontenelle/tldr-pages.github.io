# docker-container-rm

> 这是 `docker rm` 命令的一个别名。
> 更多信息：<https://docs.docker.com/engine/reference/commandline/rm>.

- 原命令的文档在：

`tldr docker rm`
