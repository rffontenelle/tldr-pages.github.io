# fossil ci

> 这是  `fossil commit`.命令的一个别名。
> 更多信息：<https://fossil-scm.org/home/help/commit>.

- 原命令的文档在：

`tldr fossil-commit`
