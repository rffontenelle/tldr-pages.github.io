# whoami

> 打印当前有效用户 ID 的用户名。
> 更多信息：<https://www.gnu.org/software/coreutils/whoami>.

- 显示当前登录用户名：

`whoami`

- 修改用户 ID 后显示当前登录用户名：

`sudo whoami`
