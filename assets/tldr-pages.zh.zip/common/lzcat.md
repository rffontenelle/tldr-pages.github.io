# lzcat

> 这是 `xz` 命令的一个别名。
> 更多信息：<https://manned.org/lzcat>.

- 原命令的文档在：

`tldr xz`
