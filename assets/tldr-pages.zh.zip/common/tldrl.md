# tldrl

> 这是 `tldr-lint` 命令的一个别名。
> 更多信息：<https://github.com/tldr-pages/tldr-lint>.

- 原命令的文档在：

`tldr tldr-lint`
