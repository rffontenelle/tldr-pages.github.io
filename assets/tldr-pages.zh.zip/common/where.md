# where

> 报告所有已知的命令入口。
> 它可以是一个在`PATH`中的可执行文件，一个别名，或者一个 shell 內建命令。
> 更多信息：<https://zsh.sourceforge.io/Doc/Release/Shell-Builtin-Commands.html>.

- 报告所有已知命令入口：

`where {{command}}`
