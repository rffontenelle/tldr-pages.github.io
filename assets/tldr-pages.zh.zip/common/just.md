# just

> 这是 `just.1` 命令的一个别名。

- 原命令的文档在：

`tldr just.1`
