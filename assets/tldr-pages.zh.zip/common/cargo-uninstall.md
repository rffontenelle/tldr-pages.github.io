# cargo uninstall

> 移除使用 `cargo install` 安装的 Rust 二进制文件。
> 更多信息：<https://doc.rust-lang.org/cargo/commands/cargo-uninstall.html>.

- 移除一个已安装的二进制文件：

`cargo remove {{package_spec}}`
