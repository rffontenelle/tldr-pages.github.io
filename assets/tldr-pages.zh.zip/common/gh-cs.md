# gh-cs

> 这是 `gh-codespace` 命令的一个别名。
> 更多信息：<https://cli.github.com/manual/gh_codespace>.

- 原命令的文档在：

`tldr gh-codespace`
