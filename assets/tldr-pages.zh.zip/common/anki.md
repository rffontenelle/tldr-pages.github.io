# anki

> 强大、智能的记忆卡片软件。
> 更多信息：<https://docs.ankiweb.net>.

- 启动 `anki`：

`anki`

- 用一个特定的配置文件启动 `anki`：

`anki -p {{配置文件名称}}`

- 以特定语言启动 `anki`：

`anki -l {{语言}}`

- 从一个特定的目录而不是默认的（`~/Anki`）启动`anki`：

`anki -b {{路径/到/目录}}`
