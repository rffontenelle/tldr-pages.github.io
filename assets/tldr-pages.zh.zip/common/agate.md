# agate

> 一个简单的 Gemini 网络协议的服务器。
> 更多信息：<https://github.com/mbrubeck/agate>.

- 运行并生成一个私钥和证书：

`agate --content {{路径/到/内容/}} --addr {{[::]:1965}} --addr {{0.0.0.0:1965}} --hostname {{example.com}} --lang {{en-US}}`

- 启动服务器：

`agate {{路径/到/文件}}`

- 显示帮助：

`agate -h`
