# aria2

> 这是 `aria2c` 命令的一个别名。

- 原命令的文档在：

`tldr aria2c`
