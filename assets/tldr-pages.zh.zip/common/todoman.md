# todoman

> 这是 `todo` 命令的一个别名。
> 更多信息：<https://todoman.readthedocs.io/>.

- 原命令的文档在：

`tldr todo`
