# hping

> 这是 `hping3` 命令的一个别名。
> 更多信息：<https://github.com/antirez/hping>.

- 原命令的文档在：

`tldr hping3`
