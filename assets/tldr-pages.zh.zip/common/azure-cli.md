# azure-cli

> 这是 `az` 命令的一个别名。
> 更多信息：<https://learn.microsoft.com/cli/azure>.

- 原命令的文档在：

`tldr az`
