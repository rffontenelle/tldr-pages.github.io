# ntl

> 这是 `netlify` 命令的一个别名。
> 更多信息：<https://cli.netlify.com>.

- 原命令的文档在：

`tldr netlify`
