# runsv

> 启动和管理 runit 服务。
> 更多信息：<https://manpages.ubuntu.com/manpages/latest/man8/runsv.8.html>.

- 以当前用户身份启动 runit 服务：

`runsv {{目录 / 服务文件}}`

- 以 root 用户身份启动 runit 服务：

`sudo runsv {{目录 / 服务文件}}`
