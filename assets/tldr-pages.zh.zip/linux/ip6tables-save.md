# ip6tables-save

> 这是 `iptables-save` 命令的一个别名。

- 原命令的文档在：

`tldr iptables-save`
