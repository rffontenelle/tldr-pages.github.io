# line

> 读取单行输入。
> 更多信息：<https://manned.org/line.1>.

- 读取输入：

`line`
