# ip6tables-restore

> 这是 `iptables-restore` 命令的一个别名。

- 原命令的文档在：

`tldr iptables-restore`
