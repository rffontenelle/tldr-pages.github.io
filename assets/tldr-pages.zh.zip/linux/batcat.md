# batcat

> 这是 `bat` 命令的一个别名。
> 更多信息：<https://github.com/sharkdp/bat>.

- 原命令的文档在：

`tldr bat`
