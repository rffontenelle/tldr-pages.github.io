# a2dismod

> 在基于 Debian 的操作系统上禁用 Apache 模块。
> 更多信息：<https://manned.org/a2dismod.8>.

- 禁用模块：

`sudo a2dismod {{模块路径}}`

- 不显示信息性消息：

`sudo a2dismod --quiet {{模块路径}}`
