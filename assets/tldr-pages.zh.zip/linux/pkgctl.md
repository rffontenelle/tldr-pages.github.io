# pkgctl

> 这是 `pkgctl auth` 命令的一个别名。
> 更多信息：<https://man.archlinux.org/man/pkgctl.1>.

- 原命令的文档在：

`tldr pkgctl auth`
