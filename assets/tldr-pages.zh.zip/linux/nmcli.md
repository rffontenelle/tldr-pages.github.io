# nmcli

> 这是 `nmcli agent` 命令的一个别名。
> 更多信息：<https://networkmanager.dev/docs/api/latest/nmcli.html>.

- 原命令的文档在：

`tldr nmcli agent`
