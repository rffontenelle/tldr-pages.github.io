# anbox

> 在任何 GNU/Linux 操作系统上运行安卓应用。
> 更多信息：<https://manned.org/anbox>.

- 在应用管理器中运行 Anbox：

`anbox launch --package={{org.anbox.appmgr}} --component={{org.anbox.appmgr.AppViewActivity}}`
