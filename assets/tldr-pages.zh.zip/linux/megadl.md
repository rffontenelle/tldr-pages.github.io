# megadl

> 这是 `megatools-dl` 命令的一个别名。
> 更多信息：<https://megatools.megous.com/man/megatools-dl.html>.

- 原命令的文档在：

`tldr megatools-dl`
