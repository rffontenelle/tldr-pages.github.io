# qm-resize

> 这是 `qm-disk-resize` 命令的一个别名。
> 更多信息：<https://pve.proxmox.com/pve-docs/qm.1.html>.

- 原命令的文档在：

`tldr qm-disk-resize`
