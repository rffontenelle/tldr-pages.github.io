# archey

> 一个可以以新颖的方式显示系统信息的简单工具。
> 更多信息：<https://lclarkmichalek.github.io/archey3/>.

- 显示系统信息：

`archey`
