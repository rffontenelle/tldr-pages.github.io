# bspwm

> 这是 `bspc` 命令的一个别名。
> 更多信息：<https://github.com/baskerville/bspwm>.

- 原命令的文档在：

`tldr bspc`
