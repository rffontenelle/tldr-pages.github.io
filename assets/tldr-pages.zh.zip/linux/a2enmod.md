# a2enmod

> 在基于 Debian 的操作系统上启用 Apache 模块。
> 更多信息：<https://manned.org/a2enmod.8>.

- 启用模块：

`sudo a2enmod {{模块名}}`

- 不显示信息性消息：

`sudo a2enmod --quiet {{模块名}}`
