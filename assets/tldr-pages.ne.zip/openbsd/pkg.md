# pkg

> यो आदेश `pkg_add` को उपनाम हो |
> थप जानकारी: <https://www.openbsd.org/faq/faq15.html>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pkg_add`
