# apx

> यो आदेश `apx pkgmanagers` को उपनाम हो |
> थप जानकारी: <https://github.com/Vanilla-OS/apx>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr apx pkgmanagers`
