# mount.smb3

> यो आदेश `mount.cifs` को उपनाम हो |

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr mount.cifs`
