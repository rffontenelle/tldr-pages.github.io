# bspwm

> यो आदेश `bspc` को उपनाम हो |
> थप जानकारी: <https://github.com/baskerville/bspwm>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bspc`
