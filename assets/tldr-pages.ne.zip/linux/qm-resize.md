# qm-resize

> यो आदेश `qm-disk-resize` को उपनाम हो |
> थप जानकारी: <https://pve.proxmox.com/pve-docs/qm.1.html>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr qm-disk-resize`
