# pkgctl

> यो आदेश `pkgctl auth` को उपनाम हो |
> थप जानकारी: <https://man.archlinux.org/man/pkgctl.1>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pkgctl auth`
