# batcat

> यो आदेश `bat` को उपनाम हो |
> थप जानकारी: <https://github.com/sharkdp/bat>.

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bat`
