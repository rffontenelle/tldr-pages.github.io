# alternatives

> यो आदेश `update-alternatives` को उपनाम हो |
> थप जानकारी: <https://manned.org/alternatives>.

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr update-alternatives`
