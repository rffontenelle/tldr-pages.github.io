# nmcli

> यो आदेश `nmcli agent` को उपनाम हो |
> थप जानकारी: <https://networkmanager.dev/docs/api/latest/nmcli.html>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr nmcli agent`
