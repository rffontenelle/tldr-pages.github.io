# gtail

> यो आदेश `-p linux tail` को उपनाम हो |

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr -p linux tail`
