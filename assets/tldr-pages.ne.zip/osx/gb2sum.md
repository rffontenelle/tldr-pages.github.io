# gb2sum

> यो आदेश `-p linux b2sum` को उपनाम हो |

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr -p linux b2sum`
