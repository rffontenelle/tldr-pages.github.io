# launchd

> यो आदेश `launchctl` को उपनाम हो।
> थप जानकारी: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr launchctl`
