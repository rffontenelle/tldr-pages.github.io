# azure-cli

> यो आदेश `az` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/cli/azure>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr az`
