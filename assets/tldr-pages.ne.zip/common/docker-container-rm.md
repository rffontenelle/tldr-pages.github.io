# docker-container-rm

> यो आदेश `docker rm` को उपनाम हो |
> थप जानकारी: <https://docs.docker.com/engine/reference/commandline/rm>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker rm`
