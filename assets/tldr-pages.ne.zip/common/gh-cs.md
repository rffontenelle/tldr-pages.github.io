# gh-cs

> यो आदेश `gh-codespace` को उपनाम हो |
> थप जानकारी: <https://cli.github.com/manual/gh_codespace>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr gh-codespace`
