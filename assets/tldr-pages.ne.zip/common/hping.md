# hping

> यो आदेश `hping3` को उपनाम हो |
> थप जानकारी: <https://github.com/antirez/hping>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr hping3`
