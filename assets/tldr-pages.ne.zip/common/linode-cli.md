# linode-cli

> यो आदेश `linode-cli account` को उपनाम हो |
> थप जानकारी: <https://www.linode.com/docs/products/tools/cli/get-started/>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr linode-cli account`
