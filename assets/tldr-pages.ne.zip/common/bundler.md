# bundler

> यो आदेश `bundle` को उपनाम हो |
> थप जानकारी: <https://bundler.io/man/bundle.1.html>.

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bundle`
