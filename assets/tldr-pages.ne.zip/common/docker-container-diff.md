# docker-container-diff

> यो आदेश `docker diff` को उपनाम हो |
> थप जानकारी: <https://docs.docker.com/engine/reference/commandline/diff>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker diff`
