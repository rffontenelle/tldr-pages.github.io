# google-chrome

> यो आदेश `chromium` को उपनाम हो |
> थप जानकारी: <https://chrome.google.com>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr chromium`
