# tldrl

> यो आदेश `tldr-lint` को उपनाम हो |
> थप जानकारी: <https://github.com/tldr-pages/tldr-lint>.

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr tldr-lint`
