# platformio

> यो आदेश `pio` को उपनाम हो |
> थप जानकारी: <https://docs.platformio.org/en/latest/core/userguide/>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pio`
