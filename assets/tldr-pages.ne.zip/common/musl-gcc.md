# musl-gcc

> यो आदेश `gcc` को उपनाम हो |
> थप जानकारी: <https://manned.org/musl-gcc>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr gcc`
