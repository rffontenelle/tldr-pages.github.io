# wget

> यो आदेश `wget -p common` को उपनाम हो |
> थप जानकारी: <https://www.gnu.org/software/wget>.

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr wget -p common`
