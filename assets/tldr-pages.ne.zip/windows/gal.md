# gal

> यो आदेश `get-alias` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr get-alias`
