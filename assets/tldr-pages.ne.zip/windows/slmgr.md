# slmgr

> यो आदेश `slmgr.vbs` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr slmgr.vbs`
