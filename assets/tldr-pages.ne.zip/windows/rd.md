# rd

> यो आदेश `rmdir` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr rmdir`
