# rm

> यो आदेश `remove-item` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr remove-item`
