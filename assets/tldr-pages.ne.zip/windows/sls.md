# sls

> यो आदेश `where-object` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr where-object`
