# sl

> यो आदेश `set-location` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr set-location`
