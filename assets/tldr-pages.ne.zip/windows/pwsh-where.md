# pwsh-where

> यो आदेश `Where-Object` को उपनाम हो |
> थप जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr Where-Object`
