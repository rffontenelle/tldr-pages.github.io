# bugreport

> एन्ड्रोइड बग रिपोर्ट देखाउनुहोस्।
> यो आदेश `adb shell` मार्फत मात्र प्रयोग गर्न सकिन्छ।
> थप जानकारी: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- एन्ड्रोइड उपकरणको पूर्ण बग रिपोर्ट प्रदर्शन गर्नुहोस्:

`bugreport`
