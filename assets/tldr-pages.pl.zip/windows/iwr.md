# iwr

> To polecenie jest aliasem `invoke-webrequest`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr invoke-webrequest`
