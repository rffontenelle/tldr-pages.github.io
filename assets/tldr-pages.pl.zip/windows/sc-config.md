# sc-config

> To polecenie jest aliasem `sc`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sc`
