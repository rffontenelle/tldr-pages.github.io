# ri

> To polecenie jest aliasem `remove-item`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr remove-item`
