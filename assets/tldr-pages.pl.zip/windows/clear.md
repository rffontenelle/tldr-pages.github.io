# clear

> To polecenie jest aliasem `clear-host`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr clear-host`
