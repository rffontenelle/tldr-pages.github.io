# sc-delete

> To polecenie jest aliasem `sc`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sc`
