# rd

> To polecenie jest aliasem `rmdir`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rmdir`
