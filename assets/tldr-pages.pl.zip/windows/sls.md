# sls

> To polecenie jest aliasem `where-object`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr where-object`
