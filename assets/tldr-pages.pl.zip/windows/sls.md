# sls

> To polecenie jest aliasem `Select-String`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr select-string`
