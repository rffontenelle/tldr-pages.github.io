# rmdir

> To polecenie jest aliasem `remove-item`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr remove-item`
