# wget

> To polecenie jest aliasem `wget -p common`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr wget -p common`
