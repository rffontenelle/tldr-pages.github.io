# wget

> To polecenie jest aliasem `wget -p common`.
> Więcej informacji: <https://www.gnu.org/software/wget>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr wget -p common`
