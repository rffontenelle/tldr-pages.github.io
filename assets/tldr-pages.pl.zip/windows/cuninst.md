# cuninst

> To polecenie jest aliasem `choco uninstall`.
> Więcej informacji: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr choco uninstall`
