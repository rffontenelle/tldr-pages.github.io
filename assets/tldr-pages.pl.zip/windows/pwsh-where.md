# pwsh where

> To polecenie jest aliasem `Where-Object`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr Where-Object`
