# cls

> To polecenie jest aliasem `clear-host`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr clear-host`
