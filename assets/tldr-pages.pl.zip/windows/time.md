# time

> Wyświetl lub ustaw czas systemowy.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/time>.

- Wyświetl aktualny czas systemowy i zapytaj o wprowadzenie nowego czasu (pozostawić puste, aby zachować niezmieniony czas):

`time`

- Wyświetl aktualny czas systemowy bez pytania o nowy czas:

`time /t`
