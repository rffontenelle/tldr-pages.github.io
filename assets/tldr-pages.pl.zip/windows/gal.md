# gal

> To polecenie jest aliasem `get-alias`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr get-alias`
