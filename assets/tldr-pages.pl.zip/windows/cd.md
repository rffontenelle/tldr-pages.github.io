# cd

> To polecenie jest aliasem `set-location`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr set-location`
