# sl

> To polecenie jest aliasem `set-location`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr set-location`
