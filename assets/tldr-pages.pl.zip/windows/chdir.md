# chdir

> To polecenie jest aliasem `cd`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr cd`
