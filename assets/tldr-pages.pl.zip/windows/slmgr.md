# slmgr

> To polecenie jest aliasem `slmgr.vbs`.
> Więcej informacji: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr slmgr.vbs`
