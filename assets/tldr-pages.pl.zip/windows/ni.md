# ni

> To polecenie jest aliasem `new-item`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr new-item`
