# print

> Wyślij plik tekstowy do drukarki.
> Więcej informacji: <https://learn.microsoft.com/windows-server/administration/windows-commands/print>.

- Drukuj plik tekstowy używając domyślnej drukarki:

`print {{ścieżka/do/pliku}}`

- Drukuj plik tekstowy używakąc wybranej drukarki:

`print /d:{{drukarka}} {{ścieżka/do/pliku}}`
