# ip6tables-save

> To polecenie jest aliasem `iptables-save`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr iptables-save`
