# distrobox

> To polecenie jest aliasem `distrobox-create`.
> Więcej informacji: <https://github.com/89luca89/distrobox>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr distrobox-create`
