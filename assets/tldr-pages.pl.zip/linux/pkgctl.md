# pkgctl

> To polecenie jest aliasem `pkgctl auth`.
> Więcej informacji: <https://man.archlinux.org/man/pkgctl.1>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pkgctl auth`
