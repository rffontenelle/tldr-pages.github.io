# line

> Wczytuje pojedynczą linię wejścia.
> Więcej informacji: <https://manned.org/line.1>.

- Wczytanie wejścia:

`line`
