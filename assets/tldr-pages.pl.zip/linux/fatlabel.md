# fatlabel

> Ustawia lub pobiera informację o nazwie partycji FAT32.
> Więcej informacji: <https://manned.org/fatlabel>.

- Pobranie informacji o nazwie partycji FAT32:

`fatlabel {{/dev/sda1}}`

- Ustawienie nazwy partycji FAT32:

`fatlabel {{/dev/sdc3}} "{{nowa_etykieta}}"`
