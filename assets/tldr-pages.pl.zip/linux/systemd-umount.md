# systemd-umount

> To polecenie jest aliasem `systemd-mount`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr systemd-mount`
