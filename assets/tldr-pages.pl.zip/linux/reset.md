# reset

> Reinicjalizuje bieżacy terminal. Czyści cały ekran terminala.
> Więcej informacji: <https://manned.org/reset>.

- Reinicjalizacja bieżącego terminala:

`reset`

- Wyświetlenie typu terminala:

`reset -q`
