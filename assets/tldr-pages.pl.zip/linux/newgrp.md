# newgrp

> Przełącza członkostwo podstawowej grupy.
> Więcej informacji: <https://manned.org/newgrp>.

- Zmień podstawową grupę użytkownika:

`newgrp {{nazwa_grupy}}`

- Przywróć podstawową grupę użytkownika na domyślną grupę w `/etc/passwd`:

`newgrp`
