# apx

> To polecenie jest aliasem `apx pkgmanagers`.
> Więcej informacji: <https://github.com/Vanilla-OS/apx>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr apx pkgmanagers`
