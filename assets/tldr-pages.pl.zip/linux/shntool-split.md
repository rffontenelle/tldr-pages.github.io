# shntool-split

> To polecenie jest aliasem `shnsplit`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr shnsplit`
