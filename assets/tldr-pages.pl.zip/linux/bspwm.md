# bspwm

> To polecenie jest aliasem `bspc`.
> Więcej informacji: <https://github.com/baskerville/bspwm>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bspc`
