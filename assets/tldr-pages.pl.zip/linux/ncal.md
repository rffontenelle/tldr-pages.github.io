# ncal

> To polecenie jest aliasem `cal`.
> Więcej informacji: <https://manned.org/ncal>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr cal`
