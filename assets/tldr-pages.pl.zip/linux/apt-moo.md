# apt moo

> Easter egg `APT`.
> Więcej informacji: <https://manned.org/apt.8>.

- Wyświetl easter egga z krową:

`apt moo`
