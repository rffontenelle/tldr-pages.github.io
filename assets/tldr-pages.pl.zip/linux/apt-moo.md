# apt moo

> Easter egg `APT`.
> Więcej informacji: <https://manpages.debian.org/latest/apt/apt.8.html>.

- Wyświetl easter egga z krową:

`apt moo`
