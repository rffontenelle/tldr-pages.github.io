# raspi-config

> GUI działające w terminalu `ncurses` do konfiguracji Raspberry Pi.
> Więcej informacji: <https://www.raspberrypi.org/documentation/computers/configuration.html>.

- Uruchom `raspi-config`:

`sudo raspi-config`
