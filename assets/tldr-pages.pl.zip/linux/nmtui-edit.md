# nmtui-edit

> To polecenie jest aliasem `nmtui`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nmtui`
