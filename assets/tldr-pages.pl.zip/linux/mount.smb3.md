# mount.smb3

> To polecenie jest aliasem `mount.cifs`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mount.cifs`
