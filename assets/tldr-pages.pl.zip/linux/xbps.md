# xbps

> To polecenie jest aliasem `xbps-install`.
> Więcej informacji: <https://docs.voidlinux.org/xbps/index.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xbps-install`
