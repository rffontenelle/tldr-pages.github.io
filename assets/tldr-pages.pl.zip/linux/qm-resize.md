# qm-resize

> To polecenie jest aliasem `qm-disk-resize`.
> Więcej informacji: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr qm-disk-resize`
