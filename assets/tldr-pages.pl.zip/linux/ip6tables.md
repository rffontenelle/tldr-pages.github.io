# ip6tables

> To polecenie jest aliasem `iptables`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr iptables`
