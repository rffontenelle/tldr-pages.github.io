# batcat

> To polecenie jest aliasem dla `bat`.
> Więcej informacji: <https://github.com/sharkdp/bat>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bat`
