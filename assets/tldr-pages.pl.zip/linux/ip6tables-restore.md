# ip6tables-restore

> To polecenie jest aliasem `iptables-restore`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr iptables-restore`
