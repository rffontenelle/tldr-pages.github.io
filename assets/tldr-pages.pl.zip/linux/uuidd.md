# uuidd

> Daemon generujący UUID.
> Więcej informacji: <https://manned.org/uuidd>.

- Stwórz losowy UUID:

`uuidd --random`

- Stwórz większą ilość losowych UUID:

`uuidd --random --uuids {{ilość_uuid}}`

- Stwórz UUID oparty o aktualny czas i adres MAC:

`uuidd --time`
