# qm-move-disk

> To polecenie jest aliasem `qm-disk-move`.
> Więcej informacji: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr qm-disk-move`
