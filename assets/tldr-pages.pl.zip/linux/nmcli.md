# nmcli

> To polecenie jest aliasem `nmcli agent`.
> Więcej informacji: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nmcli agent`
