# wtf

> Pokazuje rozwinięcia akronimów.
> Więcej informacji: <https://manpages.debian.org/latest/bsdgames/wtf.6.en.html>.

- Rozwinięcie podanego akronimu:

`wtf {{IMO}}`

- Określenie typu wyszukania jako związanego z komputerem:

`wtf -t {{comp}} {{WWW}}`
