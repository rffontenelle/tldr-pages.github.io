# mklost+found

> Tworzy katalog lost+found.
> Więcej informacji: <https://manned.org/mklost+found>.

- Utwórz katalog `lost+found` w bieżącym katalogu:

`mklost+found`
