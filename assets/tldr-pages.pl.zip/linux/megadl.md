# megadl

> To polecenie jest aliasem dla `megatools-dl`.
> Więcej informacji: <https://megatools.megous.com/man/megatools-dl.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr megatools-dl`
