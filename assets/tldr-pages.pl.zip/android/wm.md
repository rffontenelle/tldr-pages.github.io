# wm

> Wyświetl informacje o ekranie urządzenia Android.
> Ta komenda może być używana tylko poprzez `adb shell`.
> Więcej informacji: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Wyświetl fizyczny rozmiaru ekranu urządzenia Android:

`wm size`

- Wyświetl fizyczną gęstość ekranu urządzenia Android:

`wm density`
