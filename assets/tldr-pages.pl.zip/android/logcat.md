# logcat

> Zrzut dziennika komunikatów systemowych.
> Więcej informacji: <https://developer.android.com/studio/command-line/logcat>.

- Wyświetl logi systemowe:

`logcat`

- Zapisz logi systemowe do pliku:

`logcat -f {{ścieżka/do/pliku}}`

- Wyświetl linie pasujące do wyrażenia regularnego:

`logcat --regex {{wyrażenie_regularne}}`
