# dalvikvm

> Wirtualna maszyna Android Java.
> Więcej informacji: <https://source.android.com/docs/core/runtime>.

- Uruchom program Java:

`dalvikvm -classpath {{ścieżka/do/pliku.jar}} {{nazwaklasy}}`
