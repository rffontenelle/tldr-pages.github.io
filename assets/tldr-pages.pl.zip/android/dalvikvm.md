# dalvikvm

> Wirtualna maszyna Android Java.
> Więcej informacji: <https://source.android.com/devices/tech/dalvik>.

- Uruchom program Java:

`dalvikvm -classpath {{ścieżka/do/pliku.jar}} {{nazwaklasy}}`
