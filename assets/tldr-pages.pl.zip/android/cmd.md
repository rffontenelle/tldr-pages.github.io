# cmd

> Menedżer usług Android.
> Więcej informacji: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- Pokaż wszystkie działające usługi:

`cmd -l`

- Uruchom konkretną usługę:

`cmd {{alarm}}`

- Uruchom usługę z argumentami:

`cmd {{wibrator}} {{wibruj 300}}`
