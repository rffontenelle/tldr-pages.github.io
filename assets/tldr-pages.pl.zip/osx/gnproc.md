# gnproc

> To polecenie jest aliasem `-p linux nproc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux nproc`
