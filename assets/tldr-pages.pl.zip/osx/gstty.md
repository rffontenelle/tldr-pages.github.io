# gstty

> To polecenie jest aliasem `-p linux stty`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux stty`
