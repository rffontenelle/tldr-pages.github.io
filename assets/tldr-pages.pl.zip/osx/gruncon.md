# gruncon

> To polecenie jest aliasem `-p linux runcon`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux runcon`
