# gdd

> To polecenie jest aliasem `-p linux dd`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux dd`
