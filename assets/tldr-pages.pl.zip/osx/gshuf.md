# gshuf

> To polecenie jest aliasem `-p linux shuf`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux shuf`
