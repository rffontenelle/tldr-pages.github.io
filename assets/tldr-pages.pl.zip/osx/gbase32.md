# gbase32

> To polecenie jest aliasem `-p linux base32`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux base32`
