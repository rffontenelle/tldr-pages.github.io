# gunits

> To polecenie jest aliasem `-p linux units`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux units`
