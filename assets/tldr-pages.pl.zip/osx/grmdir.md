# grmdir

> To polecenie jest aliasem `-p linux rmdir`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux rmdir`
