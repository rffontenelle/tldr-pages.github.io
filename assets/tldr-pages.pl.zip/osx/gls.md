# gls

> To polecenie jest aliasem `-p linux ls`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ls`
