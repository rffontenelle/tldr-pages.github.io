# gshred

> To polecenie jest aliasem `-p linux shred`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux shred`
