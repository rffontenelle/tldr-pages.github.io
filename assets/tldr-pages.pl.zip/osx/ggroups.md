# ggroups

> To polecenie jest aliasem `-p linux groups`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux groups`
