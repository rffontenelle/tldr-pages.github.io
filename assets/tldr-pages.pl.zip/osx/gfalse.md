# gfalse

> To polecenie jest aliasem `-p linux false`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux false`
