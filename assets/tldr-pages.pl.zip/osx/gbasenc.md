# gbasenc

> To polecenie jest aliasem `-p linux basenc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux basenc`
