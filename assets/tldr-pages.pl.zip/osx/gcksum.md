# gcksum

> To polecenie jest aliasem `-p linux cksum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux cksum`
