# gxargs

> To polecenie jest aliasem `-p linux xargs`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux xargs`
