# gexpr

> To polecenie jest aliasem `-p linux expr`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux expr`
