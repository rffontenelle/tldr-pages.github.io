# gchgrp

> To polecenie jest aliasem `-p linux chgrp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux chgrp`
