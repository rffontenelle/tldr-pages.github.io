# gcat

> To polecenie jest aliasem `-p linux cat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux cat`
