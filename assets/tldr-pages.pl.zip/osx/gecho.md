# gecho

> To polecenie jest aliasem `-p linux echo`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux echo`
