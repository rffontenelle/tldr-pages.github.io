# ginstall

> To polecenie jest aliasem `-p linux install`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux install`
