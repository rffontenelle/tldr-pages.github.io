# ghead

> To polecenie jest aliasem `-p linux head`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux head`
