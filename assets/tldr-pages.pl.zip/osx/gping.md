# gping

> To polecenie jest aliasem `-p linux ping`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux ping`
