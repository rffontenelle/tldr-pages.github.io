# gsha1sum

> To polecenie jest aliasem `-p linux sha1sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sha1sum`
