# gawk

> To polecenie jest aliasem `-p linux awk`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux awk`
