# gmv

> To polecenie jest aliasem `-p linux mv`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux mv`
