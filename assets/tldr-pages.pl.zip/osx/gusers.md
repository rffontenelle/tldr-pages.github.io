# gusers

> To polecenie jest aliasem `-p linux users`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux users`
