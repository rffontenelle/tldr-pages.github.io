# gchroot

> To polecenie jest aliasem `-p linux chroot`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux chroot`
