# gtty

> To polecenie jest aliasem `-p linux tty`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tty`
