# gid

> To polecenie jest aliasem `-p linux id`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux id`
