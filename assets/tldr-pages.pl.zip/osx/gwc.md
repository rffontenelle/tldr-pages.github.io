# gwc

> To polecenie jest aliasem `-p linux wc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux wc`
