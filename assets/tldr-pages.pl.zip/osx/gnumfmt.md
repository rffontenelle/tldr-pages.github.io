# gnumfmt

> To polecenie jest aliasem `-p linux numfmt`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux numfmt`
