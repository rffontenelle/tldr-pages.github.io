# gbase64

> To polecenie jest aliasem `-p linux base64`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux base64`
