# gmkdir

> To polecenie jest aliasem `-p linux mkdir`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux mkdir`
