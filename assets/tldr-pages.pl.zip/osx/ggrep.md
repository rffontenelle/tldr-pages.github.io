# ggrep

> To polecenie jest aliasem `-p linux grep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux grep`
