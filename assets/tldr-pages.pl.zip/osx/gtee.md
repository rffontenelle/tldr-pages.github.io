# gtee

> To polecenie jest aliasem `-p linux tee`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tee`
