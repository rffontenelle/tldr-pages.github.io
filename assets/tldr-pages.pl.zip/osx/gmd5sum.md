# gmd5sum

> To polecenie jest aliasem `-p linux md5sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux md5sum`
