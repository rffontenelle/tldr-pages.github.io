# glink

> To polecenie jest aliasem `-p linux link`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux link`
