# gnice

> To polecenie jest aliasem `-p linux nice`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux nice`
