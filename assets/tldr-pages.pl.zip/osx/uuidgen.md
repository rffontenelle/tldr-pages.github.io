# uuidgen

> Wygeneruj nowy UUID (Universally Unique IDentifier).
> Więcej informacji: <https://www.ss64.com/osx/uuidgen.html>.

- Wygneruj ciąg znaków UUID:

`uuidgen`
