# uuidgen

> Wygeneruj nowy UUID (Universally Unique IDentifier).
> Więcej informacji: <https://keith.github.io/xcode-man-pages/uuidgen.1.html>.

- Wygneruj ciąg znaków UUID:

`uuidgen`
