# gwhoami

> To polecenie jest aliasem `-p linux whoami`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux whoami`
