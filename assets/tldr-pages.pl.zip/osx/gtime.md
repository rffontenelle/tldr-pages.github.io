# gtime

> To polecenie jest aliasem `-p linux time`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux time`
