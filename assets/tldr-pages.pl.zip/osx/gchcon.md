# gchcon

> To polecenie jest aliasem `-p linux chcon`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux chcon`
