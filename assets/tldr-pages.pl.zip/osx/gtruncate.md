# gtruncate

> To polecenie jest aliasem `-p linux truncate`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux truncate`
