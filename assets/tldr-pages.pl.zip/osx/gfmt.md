# gfmt

> To polecenie jest aliasem `-p linux fmt`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux fmt`
