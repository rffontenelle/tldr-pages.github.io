# gdate

> To polecenie jest aliasem `-p linux date`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux date`
