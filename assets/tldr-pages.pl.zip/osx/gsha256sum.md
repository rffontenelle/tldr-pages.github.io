# gsha256sum

> To polecenie jest aliasem `-p linux sha256sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux sha256sum`
