# gtest

> To polecenie jest aliasem `-p linux test`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux test`
