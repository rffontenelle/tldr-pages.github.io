# grlogin

> To polecenie jest aliasem `-p linux rlogin`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux rlogin`
