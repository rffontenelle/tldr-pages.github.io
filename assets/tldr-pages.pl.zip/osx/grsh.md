# grsh

> To polecenie jest aliasem `-p linux rsh`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux rsh`
