# xsand

> Demon zarządzający systemem plików Xsan. Zapewnia usługi dla systemu plików Xsan.
> Nie powinien być wywoływany ręcznie.
> Więcej informacji: <https://developer.apple.com/support/downloads/Xsan-Management-Guide.pdf>.

- Uruchom demona:

`xsand`
