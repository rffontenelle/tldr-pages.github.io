# ghostid

> To polecenie jest aliasem `-p linux hostid`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux hostid`
