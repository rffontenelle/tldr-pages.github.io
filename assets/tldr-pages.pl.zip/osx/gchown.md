# gchown

> To polecenie jest aliasem `-p linux chown`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux chown`
