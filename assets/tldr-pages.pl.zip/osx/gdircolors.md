# gdircolors

> To polecenie jest aliasem `-p linux dircolors`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux dircolors`
