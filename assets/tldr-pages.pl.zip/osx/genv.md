# genv

> To polecenie jest aliasem `-p linux env`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux env`
