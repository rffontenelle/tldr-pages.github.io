# gvdir

> To polecenie jest aliasem `-p linux vdir`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux vdir`
