# gjoin

> To polecenie jest aliasem `-p linux join`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux join`
