# gpwd

> To polecenie jest aliasem `-p linux pwd`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux pwd`
