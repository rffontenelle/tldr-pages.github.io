# gtraceroute

> To polecenie jest aliasem `-p linux traceroute`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux traceroute`
