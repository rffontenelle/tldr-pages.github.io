# w

> Pokazuje kto jest zalogowany i co aktualnie robi.
> Wyświetla login, TTY, zdalny host, czas zalogowania, czas bezczynności i aktualny proces.
> Więcej informacji: <https://keith.github.io/xcode-man-pages/w.1.html>.

- Pokazuje informacje o aktualnie zalogowanych użytkownikach:

`w`

- Pokazuje aktualnie zalogowanych użytkowników bez nagłówka:

`w -h`

- Pokazuje aktualnie zalogowanych użytkowników posortowanych po czasie bezczynności:

`w -i`
