# gfactor

> To polecenie jest aliasem `-p linux factor`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux factor`
