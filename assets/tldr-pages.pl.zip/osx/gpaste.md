# gpaste

> To polecenie jest aliasem `-p linux paste`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux paste`
