# gupdatedb

> To polecenie jest aliasem `-p linux updatedb`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux updatedb`
