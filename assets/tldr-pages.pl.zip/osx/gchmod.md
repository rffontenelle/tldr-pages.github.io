# gchmod

> To polecenie jest aliasem `-p linux chmod`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux chmod`
