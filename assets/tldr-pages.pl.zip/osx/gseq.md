# gseq

> To polecenie jest aliasem `-p linux seq`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux seq`
