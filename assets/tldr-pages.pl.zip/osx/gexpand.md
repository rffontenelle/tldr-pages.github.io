# gexpand

> To polecenie jest aliasem `-p linux expand`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux expand`
