# g[

> To polecenie jest aliasem `-p linux [`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux [`
