# gtouch

> To polecenie jest aliasem `-p linux touch`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux touch`
