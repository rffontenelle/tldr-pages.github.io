# gtsort

> To polecenie jest aliasem `-p linux tsort`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux tsort`
