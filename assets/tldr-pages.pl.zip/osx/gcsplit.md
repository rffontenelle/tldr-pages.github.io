# gcsplit

> To polecenie jest aliasem `-p linux csplit`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux csplit`
