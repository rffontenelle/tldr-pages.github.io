# gegrep

> To polecenie jest aliasem `-p linux egrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux egrep`
