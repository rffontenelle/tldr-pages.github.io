# llvm-lipo

> To polecenie jest aliasem `lipo`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr lipo`
