# gindent

> To polecenie jest aliasem `-p linux indent`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr -p linux indent`
