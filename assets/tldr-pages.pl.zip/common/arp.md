# arp

> Pokaż i manipuluj pamięcią podręczną ARP systemu.
> Więcej informacji: <https://manned.org/arp>.

- Pokaż bieżącą tabelę arp:

`arp -a`

- Usuń konkretny wpis:

`arp -d {{adres}}`

- Utwórz wpis:

`arp -s {{adres}} {{adres_mac}}`
