# jfrog

> To polecenie jest aliasem `jf`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr jf`
