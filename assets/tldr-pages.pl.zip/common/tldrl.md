# tldrl

> To polecenie jest aliasem `tldr-lint`.
> Więcej informacji: <https://github.com/tldr-pages/tldr-lint>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr tldr-lint`
