# mscore

> To polecenie jest aliasem `musescore`.
> Więcej informacji: <https://musescore.org/handbook/command-line-options>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr musescore`
