# docker container rename

> To polecenie jest aliasem `docker rename`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker rename`
