# docker container rename

> To polecenie jest aliasem `docker rename`.
> Więcej informacji: <https://docs.docker.com/reference/cli/docker/container/rename/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker rename`
