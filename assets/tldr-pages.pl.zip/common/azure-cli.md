# azure-cli

> To polecenie jest aliasem `az`.
> Więcej informacji: <https://learn.microsoft.com/cli/azure>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr az`
