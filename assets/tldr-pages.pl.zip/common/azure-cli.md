# azure-cli

> To polecenie jest aliasem `az`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr az`
