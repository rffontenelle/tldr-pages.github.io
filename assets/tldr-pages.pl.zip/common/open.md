# open

> `open` może odnosić się do kilku komend o tej samej nazwie.

- Zobacz dokumentację komendy dostępnej w macOS:

`tldr open -p osx`

- Zobacz dokumentację komendy dostępnej w `fish`:

`tldr open.fish`
