# open

> To polecenie jest aliasem `open -p osx`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr open -p osx`
