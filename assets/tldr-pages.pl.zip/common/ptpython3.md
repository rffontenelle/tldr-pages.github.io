# ptpython3

> To polecenie jest aliasem `ptpython`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ptpython`
