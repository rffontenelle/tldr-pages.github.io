# platformio

> To polecenie jest aliasem `pio`.
> Więcej informacji: <https://docs.platformio.org/en/latest/core/userguide/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pio`
