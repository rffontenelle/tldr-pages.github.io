# transmission

> To polecenie jest aliasem `transmission-daemon`.
> Więcej informacji: <https://transmissionbt.com/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr transmission-daemon`
