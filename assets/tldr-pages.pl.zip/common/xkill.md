# xkill

> Zabija okno z sesji graficznej.
> Zobacz też `kill` i `killall`.
> Więcej informacji: <https://www.x.org/releases/current/doc/man/man1/xkill.1.xhtml>.

- Wyświetla kursor pozwalający na wybranie okna do zabicia przy pomocy lewego przycisku myszy (pozostałe przyciski anulują):

`xkill`
