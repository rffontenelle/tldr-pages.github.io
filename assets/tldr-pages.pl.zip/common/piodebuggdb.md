# piodebuggdb

> To polecenie jest aliasem `pio debug`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pio debug`
