# gemtopbm

> To polecenie zostało zastąpione przez `gemtopnm`.
> Więcej informacji: <https://netpbm.sourceforge.net/doc/gemtopbm.html>.

- Zobacz dokumentację aktualnego polecenia:

`tldr gemtopnm`
