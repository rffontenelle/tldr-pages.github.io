# pwsh

> To polecenie jest aliasem `powershell`.
> Więcej informacji: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/about/about_pwsh>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr powershell`
