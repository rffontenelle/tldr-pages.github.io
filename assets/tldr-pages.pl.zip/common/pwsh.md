# pwsh

> To polecenie jest aliasem `powershell`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr powershell`
