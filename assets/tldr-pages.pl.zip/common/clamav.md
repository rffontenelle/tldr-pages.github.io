# clamav

> To polecenie jest aliasem `clamdscan`.
> Więcej informacji: <https://www.clamav.net>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr clamdscan`
