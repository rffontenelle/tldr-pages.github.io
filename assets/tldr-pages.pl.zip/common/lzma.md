# lzma

> To polecenie jest aliasem `xz`.
> Więcej informacji: <https://manned.org/lzma>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
