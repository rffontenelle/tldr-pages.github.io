# musl-gcc

> Skrypt opakowujący `gcc`, który automatycznie ustawia opcje do linkowania z musl libc.
> Wszystkie podane opcje są przekazywane bezpośrednio do `gcc`.
> Więcej informacji: <https://manned.org/musl-gcc>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gcc`
