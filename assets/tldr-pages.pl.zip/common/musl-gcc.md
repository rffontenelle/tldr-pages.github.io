# musl-gcc

> To polecenie jest aliasem `gcc`.
> Więcej informacji: <https://manned.org/musl-gcc>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gcc`
