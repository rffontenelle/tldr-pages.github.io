# clang-cpp

> To polecenie jest aliasem `clang++`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr clang++`
