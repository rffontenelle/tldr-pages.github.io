# atq

> Pokaż zadania zaplanowane przez polecenia `at` lub `batch`.
> Więcej informacji: <https://manned.org/atq>.

- Pokaż zaplanowane zadania bieżącego użytkownika:

`atq`

- Pokaż zadania z kolejki 'a' (kolejki mają jednoznakowe nazwy):

`atq -q {{a}}`

- Pokaż zadania wszystkich użytkowników (uruchom jako superużytkownik):

`sudo atq`
