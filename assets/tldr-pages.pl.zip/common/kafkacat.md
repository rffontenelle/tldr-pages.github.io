# kafkacat

> To polecenie jest aliasem `kcat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr kcat`
