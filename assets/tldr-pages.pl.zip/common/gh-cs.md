# gh-cs

> To polecenie jest aliasem `gh-codespace`.
> Więcej informacji: <https://cli.github.com/manual/gh_codespace>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gh-codespace`
