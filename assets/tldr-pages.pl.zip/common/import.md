# import

> To polecenie jest aliasem `magick import`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr magick import`
