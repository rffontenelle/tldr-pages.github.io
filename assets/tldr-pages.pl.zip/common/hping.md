# hping

> To polecenie jest aliasem `hping3`.
> Więcej informacji: <https://github.com/antirez/hping>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr hping3`
