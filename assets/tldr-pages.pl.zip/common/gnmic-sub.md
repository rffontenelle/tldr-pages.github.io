# gnmic-sub

> To polecenie jest aliasem `gnmic subscribe`.
> Więcej informacji: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gnmic subscribe`
