# clojure

> To polecenie jest aliasem `clj`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr clj`
