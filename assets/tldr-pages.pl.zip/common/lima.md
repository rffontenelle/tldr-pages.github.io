# lima

> To polecenie jest aliasem `limactl shell` dla domyślnej instancji maszyny wirtualnej.
> Możesz także ustawić zmienną środowiskową `$LIMA_INSTANCE` aby pracować na innej instancji.
> Więcej informacji: <https://github.com/lima-vm/lima>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr limactl`
