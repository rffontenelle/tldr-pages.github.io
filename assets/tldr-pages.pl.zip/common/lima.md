# lima

> To polecenie jest aliasem `limactl`.
> Więcej informacji: <https://github.com/lima-vm/lima>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr limactl`
