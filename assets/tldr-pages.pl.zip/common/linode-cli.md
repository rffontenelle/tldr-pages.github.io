# linode-cli

> To polecenie jest aliasem `linode-cli account`.
> Więcej informacji: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr linode-cli account`
