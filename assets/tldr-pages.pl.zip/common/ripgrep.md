# ripgrep

> To polecenie jest aliasem `rg`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rg`
