# fossil-forget

> To polecenie jest aliasem `fossil rm`.
> Więcej informacji: <https://fossil-scm.org/home/help/forget>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil rm`
