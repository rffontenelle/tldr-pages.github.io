# CUPS

> Otwarty system drukowania.
> CUPS nie jest pojedynczym poleceniem, ale zestawem poleceń.
> Więcej informacji: <https://www.cups.org/index.html>.

- Zobacz dokumentację uruchamiania demona CUPS:

`tldr cupsd`

- Zobacz dokumentację zarządzania drukarkami:

`tldr lpadmin`

- Zobacz dokumentację drukowania plików:

`tldr lp`

- Zobacz dokumentację sprawdzania informacji o stanie bieżących klas, zadań i drukarek:

`tldr lpstat`

- Zobacz dokumentację anulowania zadań drukowania:

`tldr lprm`
