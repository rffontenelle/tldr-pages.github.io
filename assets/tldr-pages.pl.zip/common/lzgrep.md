# lzgrep

> To polecenie jest aliasem `xzgrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xzgrep`
