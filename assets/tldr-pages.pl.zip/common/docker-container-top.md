# docker-container-top

> To polecenie jest aliasem `docker top`.
> Więcej informacji: <https://docs.docker.com/engine/reference/commandline/top>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker top`
