# docker container remove

> To polecenie jest aliasem `docker rm`.
> Więcej informacji: <https://docs.docker.com/engine/reference/commandline/rm>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker rm`
