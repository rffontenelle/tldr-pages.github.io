# docker container remove

> To polecenie jest aliasem `docker rm`.
> Więcej informacji: <https://docs.docker.com/reference/cli/docker/container/rm/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker rm`
