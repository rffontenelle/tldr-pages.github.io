# cron

> To polecenie jest aliasem `crontab`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr crontab`
