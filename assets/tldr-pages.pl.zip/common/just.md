# just

> `just` może odnosić się do kilku komend o tej samej nazwie.

- Zobacz dokumentację programu uruchamiającego polecenia:

`tldr just.1`

- Zobacz dokumentację środowiska V8 JavaScript:

`tldr just.js`
