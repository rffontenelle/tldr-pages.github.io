# just

> To polecenie jest aliasem `just.1`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr just.1`
