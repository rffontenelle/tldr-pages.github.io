# fossil delete

> To polecenie jest aliasem `fossil rm`.
> Więcej informacji: <https://fossil-scm.org/home/help/delete>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil rm`
