# hx

> To polecenie jest aliasem `helix`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr helix`
