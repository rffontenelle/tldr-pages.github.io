# zstdmt

> To polecenie jest aliasem `zstd`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr zstd`
