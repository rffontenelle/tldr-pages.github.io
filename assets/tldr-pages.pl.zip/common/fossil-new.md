# fossil-new

> To polecenie jest aliasem `fossil-init`.
> Więcej informacji: <https://fossil-scm.org/home/help/new>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fossil-init`
