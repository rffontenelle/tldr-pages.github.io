# pio-init

> To polecenie jest aliasem `pio project`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pio project`
