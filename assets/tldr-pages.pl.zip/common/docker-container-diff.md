# docker container diff

> To polecenie jest aliasem `docker diff`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker diff`
