# docker-container-diff

> To polecenie jest aliasem `docker diff`.
> Więcej informacji: <https://docs.docker.com/engine/reference/commandline/diff>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker diff`
