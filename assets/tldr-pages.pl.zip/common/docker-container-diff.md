# docker container diff

> To polecenie jest aliasem `docker diff`.
> Więcej informacji: <https://docs.docker.com/reference/cli/docker/container/diff/>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr docker diff`
