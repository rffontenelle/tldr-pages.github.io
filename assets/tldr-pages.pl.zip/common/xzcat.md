# xzcat

> To polecenie jest aliasem `xz`.
> Więcej informacji: <https://manned.org/xzcat>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
