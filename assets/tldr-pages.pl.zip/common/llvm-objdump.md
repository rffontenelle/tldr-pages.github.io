# llvm-objdump

> To polecenie jest aliasem `objdump`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr objdump`
