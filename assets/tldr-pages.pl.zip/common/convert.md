# convert

> To polecenie jest aliasem `magick convert`.
> Uwaga: ten alias jest wycofany od ImageMagick 7. Został on zastąpiony przez `magick`.
> Użyj `magick convert` jeśli potrzebujesz użyć starego narzędzia w wersjach 7+.

- Zobacz dokumentację oryginalnego polecenia:

`tldr magick convert`
