# pkg

> To polecenie jest aliasem `pkg_add`.
> Więcej informacji: <https://www.openbsd.org/faq/faq15.html>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pkg_add`
