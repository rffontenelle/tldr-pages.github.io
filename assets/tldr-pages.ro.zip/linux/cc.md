# cc

> Această comandă este un alias al `gcc`.
> Mai multe informații: <https://gcc.gnu.org>.

- Vizualizați documentația pentru comanda originală:

`tldr gcc`
