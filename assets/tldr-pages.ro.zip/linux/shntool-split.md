# shntool-split

> Această comandă este un alias al `shnsplit`.

- Vizualizați documentația pentru comanda originală:

`tldr shnsplit`
