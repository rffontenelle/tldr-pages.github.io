# ip6tables

> Această comandă este un alias al `iptables`.

- Vizualizați documentația pentru comanda originală:

`tldr iptables`
