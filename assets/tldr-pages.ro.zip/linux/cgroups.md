# cgroups

> Această comandă este un alias al `cgclassify`.
> Mai multe informații: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Vizualizați documentația pentru comanda originală:

`tldr cgclassify`
