# qm-importdisk

> Această comandă este un alias al `qm disk import`.

- Vizualizați documentația pentru comanda originală:

`tldr qm disk import`
