# batcat

> Această comandă este un alias al `bat`.
> Mai multe informații: <https://github.com/sharkdp/bat>.

- Vizualizați documentația pentru comanda originală:

`tldr bat`
