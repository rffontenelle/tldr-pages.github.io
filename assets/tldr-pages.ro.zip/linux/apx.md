# apx

> Această comandă este un alias al `apx pkgmanagers`.
> Mai multe informații: <https://github.com/Vanilla-OS/apx>.

- Vizualizați documentația pentru comanda originală:

`tldr apx pkgmanagers`
