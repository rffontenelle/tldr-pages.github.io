# pkgctl

> Această comandă este un alias al `pkgctl auth`.
> Mai multe informații: <https://man.archlinux.org/man/pkgctl.1>.

- Vizualizați documentația pentru comanda originală:

`tldr pkgctl auth`
