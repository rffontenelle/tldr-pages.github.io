# distrobox

> Această comandă este un alias al `distrobox-create`.
> Mai multe informații: <https://github.com/89luca89/distrobox>.

- Vizualizați documentația pentru comanda originală:

`tldr distrobox-create`
