# megadl

> Această comandă este un alias al `megatools-dl`.
> Mai multe informații: <https://megatools.megous.com/man/megatools-dl.html>.

- Vizualizați documentația pentru comanda originală:

`tldr megatools-dl`
