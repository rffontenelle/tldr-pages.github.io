# ip6tables-save

> Această comandă este un alias al `iptables-save`.

- Vizualizați documentația pentru comanda originală:

`tldr iptables-save`
