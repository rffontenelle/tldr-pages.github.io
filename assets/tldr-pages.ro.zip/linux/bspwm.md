# bspwm

> Această comandă este un alias al `bspc`.
> Mai multe informații: <https://github.com/baskerville/bspwm>.

- Vizualizați documentația pentru comanda originală:

`tldr bspc`
