# alternatives

> Această comandă este un alias al `update-alternatives`.
> Mai multe informații: <https://manned.org/alternatives>.

- Vizualizați documentația pentru comanda originală:

`tldr update-alternatives`
