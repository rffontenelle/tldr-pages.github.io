# qm-resize

> Această comandă este un alias al `qm-disk-resize`.
> Mai multe informații: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Vizualizați documentația pentru comanda originală:

`tldr qm-disk-resize`
