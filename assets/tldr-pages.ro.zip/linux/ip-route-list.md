# ip-route-list

> Această comandă este un alias al `ip-route-show`.

- Vizualizați documentația pentru comanda originală:

`tldr ip-route-show`
