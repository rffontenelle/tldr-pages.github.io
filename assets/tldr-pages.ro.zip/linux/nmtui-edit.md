# nmtui-edit

> Această comandă este un alias al `nmtui`.

- Vizualizați documentația pentru comanda originală:

`tldr nmtui`
