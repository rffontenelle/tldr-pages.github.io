# mount.smb3

> Această comandă este un alias al `mount.cifs`.

- Vizualizați documentația pentru comanda originală:

`tldr mount.cifs`
