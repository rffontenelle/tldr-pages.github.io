# qm-move-disk

> Această comandă este un alias al `qm-disk-move`.
> Mai multe informații: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Vizualizați documentația pentru comanda originală:

`tldr qm-disk-move`
