# ubuntu-bug

> Această comandă este un alias al `apport-bug`.
> Mai multe informații: <https://manned.org/ubuntu-bug>.

- Vizualizați documentația pentru comanda originală:

`tldr apport-bug`
