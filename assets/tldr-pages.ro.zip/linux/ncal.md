# ncal

> Această comandă este un alias al `cal`.
> Mai multe informații: <https://manned.org/ncal>.

- Vizualizați documentația pentru comanda originală:

`tldr cal`
