# nmtui-connect

> Această comandă este un alias al `nmtui`.

- Vizualizați documentația pentru comanda originală:

`tldr nmtui`
