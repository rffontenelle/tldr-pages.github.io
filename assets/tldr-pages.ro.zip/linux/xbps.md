# xbps

> Această comandă este un alias al `xbps-install`.
> Mai multe informații: <https://docs.voidlinux.org/xbps/index.html>.

- Vizualizați documentația pentru comanda originală:

`tldr xbps-install`
