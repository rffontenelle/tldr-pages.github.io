# ip6tables-restore

> Această comandă este un alias al `iptables-restore`.

- Vizualizați documentația pentru comanda originală:

`tldr iptables-restore`
