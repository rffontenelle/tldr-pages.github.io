# nmcli

> Această comandă este un alias al `nmcli agent`.
> Mai multe informații: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Vizualizați documentația pentru comanda originală:

`tldr nmcli agent`
