# systemd-umount

> Această comandă este un alias al `systemd-mount`.

- Vizualizați documentația pentru comanda originală:

`tldr systemd-mount`
