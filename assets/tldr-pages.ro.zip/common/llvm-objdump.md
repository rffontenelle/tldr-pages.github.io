# llvm-objdump

> Această comandă este un alias al `objdump`.

- Vizualizați documentația pentru comanda originală:

`tldr objdump`
