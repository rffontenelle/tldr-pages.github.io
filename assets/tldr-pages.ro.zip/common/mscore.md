# mscore

> Această comandă este un alias al `musescore`.
> Mai multe informații: <https://musescore.org/handbook/command-line-options>.

- Vizualizați documentația pentru comanda originală:

`tldr musescore`
