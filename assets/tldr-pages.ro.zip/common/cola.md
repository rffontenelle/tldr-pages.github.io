# cola

> Această comandă este un alias al `git-cola`.

- Vizualizați documentația pentru comanda originală:

`tldr git-cola`
