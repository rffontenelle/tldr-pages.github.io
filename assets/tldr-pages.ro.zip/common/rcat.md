# rcat

> Această comandă este un alias al `rc`.

- Vizualizați documentația pentru comanda originală:

`tldr rc`
