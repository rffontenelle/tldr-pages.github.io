# fossil-new

> Această comandă este un alias al `fossil-init`.
> Mai multe informații: <https://fossil-scm.org/home/help/new>.

- Vizualizați documentația pentru comanda originală:

`tldr fossil-init`
