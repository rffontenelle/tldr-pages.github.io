# gnmic-sub

> Această comandă este un alias al `gnmic subscribe`.
> Mai multe informații: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Vizualizați documentația pentru comanda originală:

`tldr gnmic subscribe`
