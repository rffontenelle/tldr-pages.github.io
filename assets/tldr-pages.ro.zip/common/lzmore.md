# lzmore

> Această comandă este un alias al `xzmore`.

- Vizualizați documentația pentru comanda originală:

`tldr xzmore`
