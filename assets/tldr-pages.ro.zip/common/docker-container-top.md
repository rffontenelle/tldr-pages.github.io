# docker-container-top

> Această comandă este un alias al `docker top`.
> Mai multe informații: <https://docs.docker.com/engine/reference/commandline/top>.

- Vizualizați documentația pentru comanda originală:

`tldr docker top`
