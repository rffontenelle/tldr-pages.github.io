# clojure

> Această comandă este un alias al `clj`.

- Vizualizați documentația pentru comanda originală:

`tldr clj`
