# unlzma

> Această comandă este un alias al `xz`.
> Mai multe informații: <https://manned.org/unlzma>.

- Vizualizați documentația pentru comanda originală:

`tldr xz`
