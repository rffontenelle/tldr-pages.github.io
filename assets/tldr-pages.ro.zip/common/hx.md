# hx

> Această comandă este un alias al `helix`.

- Vizualizați documentația pentru comanda originală:

`tldr helix`
