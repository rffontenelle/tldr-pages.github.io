# docker-container-remove

> Această comandă este un alias al `docker rm`.
> Mai multe informații: <https://docs.docker.com/engine/reference/commandline/rm>.

- Vizualizați documentația pentru comanda originală:

`tldr docker rm`
