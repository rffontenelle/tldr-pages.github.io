# lzless

> Această comandă este un alias al `xzless`.

- Vizualizați documentația pentru comanda originală:

`tldr xzless`
