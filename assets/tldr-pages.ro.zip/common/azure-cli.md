# azure-cli

> Această comandă este un alias al `az`.
> Mai multe informații: <https://learn.microsoft.com/cli/azure>.

- Vizualizați documentația pentru comanda originală:

`tldr az`
