# gh-cs

> Această comandă este un alias al `gh-codespace`.
> Mai multe informații: <https://cli.github.com/manual/gh_codespace>.

- Vizualizați documentația pentru comanda originală:

`tldr gh-codespace`
