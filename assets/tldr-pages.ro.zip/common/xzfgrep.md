# xzfgrep

> Această comandă este un alias al `xzgrep`.

- Vizualizați documentația pentru comanda originală:

`tldr xzgrep`
