# platformio

> Această comandă este un alias al `pio`.
> Mai multe informații: <https://docs.platformio.org/en/latest/core/userguide/>.

- Vizualizați documentația pentru comanda originală:

`tldr pio`
