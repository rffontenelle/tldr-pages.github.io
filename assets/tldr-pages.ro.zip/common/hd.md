# hd

> Această comandă este un alias al `hexdump`.
> Mai multe informații: <https://manned.org/hd.1>.

- Vizualizați documentația pentru comanda originală:

`tldr hexdump`
