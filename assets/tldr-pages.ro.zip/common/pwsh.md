# pwsh

> Această comandă este un alias al `powershell`.

- Vizualizați documentația pentru comanda originală:

`tldr powershell`
