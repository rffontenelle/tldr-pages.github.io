# hping

> Această comandă este un alias al `hping3`.
> Mai multe informații: <https://github.com/antirez/hping>.

- Vizualizați documentația pentru comanda originală:

`tldr hping3`
