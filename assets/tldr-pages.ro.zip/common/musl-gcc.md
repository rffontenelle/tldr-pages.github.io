# musl-gcc

> Această comandă este un alias al `gcc`.
> Mai multe informații: <https://manned.org/musl-gcc>.

- Vizualizați documentația pentru comanda originală:

`tldr gcc`
