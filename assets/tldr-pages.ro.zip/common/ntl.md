# ntl

> Această comandă este un alias al `netlify`.
> Mai multe informații: <https://cli.netlify.com>.

- Vizualizați documentația pentru comanda originală:

`tldr netlify`
