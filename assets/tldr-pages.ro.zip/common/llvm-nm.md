# llvm-nm

> Această comandă este un alias al `nm`.

- Vizualizați documentația pentru comanda originală:

`tldr nm`
