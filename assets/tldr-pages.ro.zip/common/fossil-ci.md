# fossil-ci

> Această comandă este un alias al `fossil-commit`.
> Mai multe informații: <https://fossil-scm.org/home/help/commit>.

- Vizualizați documentația pentru comanda originală:

`tldr fossil-commit`
