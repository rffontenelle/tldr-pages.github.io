# docker-container-rename

> Această comandă este un alias al `docker rename`.
> Mai multe informații: <https://docs.docker.com/engine/reference/commandline/rename>.

- Vizualizați documentația pentru comanda originală:

`tldr docker rename`
