# unxz

> Această comandă este un alias al `xz`.
> Mai multe informații: <https://manned.org/unxz>.

- Vizualizați documentația pentru comanda originală:

`tldr xz`
