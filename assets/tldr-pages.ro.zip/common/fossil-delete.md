# fossil-delete

> Această comandă este un alias al `fossil rm`.
> Mai multe informații: <https://fossil-scm.org/home/help/delete>.

- Vizualizați documentația pentru comanda originală:

`tldr fossil rm`
