# cron

> Această comandă este un alias al `crontab`.

- Vizualizați documentația pentru comanda originală:

`tldr crontab`
