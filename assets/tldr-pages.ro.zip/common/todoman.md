# todoman

> Această comandă este un alias al `todo`.
> Mai multe informații: <https://todoman.readthedocs.io/>.

- Vizualizați documentația pentru comanda originală:

`tldr todo`
