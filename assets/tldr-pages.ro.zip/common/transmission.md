# transmission

> Această comandă este un alias al `transmission-daemon`.
> Mai multe informații: <https://transmissionbt.com/>.

- Vizualizați documentația pentru comanda originală:

`tldr transmission-daemon`
