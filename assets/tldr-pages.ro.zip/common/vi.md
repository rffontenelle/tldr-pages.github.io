# vi

> Această comandă este un alias al `vim`.

- Vizualizați documentația pentru comanda originală:

`tldr vim`
