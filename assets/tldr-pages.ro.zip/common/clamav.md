# clamav

> Această comandă este un alias al `clamdscan`.
> Mai multe informații: <https://www.clamav.net>.

- Vizualizați documentația pentru comanda originală:

`tldr clamdscan`
