# zstdmt

> Această comandă este un alias al `zstd`.

- Vizualizați documentația pentru comanda originală:

`tldr zstd`
