# docker-container-diff

> Această comandă este un alias al `docker diff`.
> Mai multe informații: <https://docs.docker.com/engine/reference/commandline/diff>.

- Vizualizați documentația pentru comanda originală:

`tldr docker diff`
