# lima

> Această comandă este un alias al `limactl`.
> Mai multe informații: <https://github.com/lima-vm/lima>.

- Vizualizați documentația pentru comanda originală:

`tldr limactl`
