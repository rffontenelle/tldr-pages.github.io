# netcat

> Această comandă este un alias al `nc`.

- Vizualizați documentația pentru comanda originală:

`tldr nc`
