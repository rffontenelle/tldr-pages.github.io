# clang-cpp

> Această comandă este un alias al `clang++`.

- Vizualizați documentația pentru comanda originală:

`tldr clang++`
