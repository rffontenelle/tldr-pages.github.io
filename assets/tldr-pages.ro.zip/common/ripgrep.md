# ripgrep

> Această comandă este un alias al `rg`.

- Vizualizați documentația pentru comanda originală:

`tldr rg`
