# just

> Această comandă este un alias al `just.1`.

- Vizualizați documentația pentru comanda originală:

`tldr just.1`
