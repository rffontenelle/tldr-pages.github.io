# llvm-ar

> Această comandă este un alias al `ar`.

- Vizualizați documentația pentru comanda originală:

`tldr ar`
