# ptpython3

> Această comandă este un alias al `ptpython`.

- Vizualizați documentația pentru comanda originală:

`tldr ptpython`
