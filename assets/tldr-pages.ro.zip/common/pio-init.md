# pio-init

> Această comandă este un alias al `pio project`.

- Vizualizați documentația pentru comanda originală:

`tldr pio project`
