# linode-cli

> Această comandă este un alias al `linode-cli account`.
> Mai multe informații: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Vizualizați documentația pentru comanda originală:

`tldr linode-cli account`
