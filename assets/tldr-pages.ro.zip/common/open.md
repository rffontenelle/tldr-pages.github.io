# open

> Această comandă este un alias al `open -p osx`.

- Vizualizați documentația pentru comanda originală:

`tldr open -p osx`
