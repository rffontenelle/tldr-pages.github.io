# kafkacat

> Această comandă este un alias al `kcat`.

- Vizualizați documentația pentru comanda originală:

`tldr kcat`
