# tlmgr-arch

> Această comandă este un alias al `tlmgr platform`.
> Mai multe informații: <https://www.tug.org/texlive/tlmgr.html>.

- Vizualizați documentația pentru comanda originală:

`tldr tlmgr platform`
