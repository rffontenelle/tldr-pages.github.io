# llvm-strings

> Această comandă este un alias al `strings`.

- Vizualizați documentația pentru comanda originală:

`tldr strings`
