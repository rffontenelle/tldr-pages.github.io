# piodebuggdb

> Această comandă este un alias al `pio debug`.

- Vizualizați documentația pentru comanda originală:

`tldr pio debug`
