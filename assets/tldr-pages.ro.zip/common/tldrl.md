# tldrl

> Această comandă este un alias al `tldr-lint`.
> Mai multe informații: <https://github.com/tldr-pages/tldr-lint>.

- Vizualizați documentația pentru comanda originală:

`tldr tldr-lint`
