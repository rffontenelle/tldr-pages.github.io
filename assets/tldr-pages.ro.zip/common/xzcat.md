# xzcat

> Această comandă este un alias al `xz`.
> Mai multe informații: <https://manned.org/xzcat>.

- Vizualizați documentația pentru comanda originală:

`tldr xz`
