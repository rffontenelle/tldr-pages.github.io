# bundler

> Această comandă este un alias al `bundle`.
> Mai multe informații: <https://bundler.io/man/bundle.1.html>.

- Vizualizați documentația pentru comanda originală:

`tldr bundle`
