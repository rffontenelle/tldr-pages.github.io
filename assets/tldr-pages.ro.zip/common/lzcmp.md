# lzcmp

> Această comandă este un alias al `xzcmp`.

- Vizualizați documentația pentru comanda originală:

`tldr xzcmp`
