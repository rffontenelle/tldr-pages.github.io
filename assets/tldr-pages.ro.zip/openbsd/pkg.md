# pkg

> Această comandă este un alias al `pkg_add`.
> Mai multe informații: <https://www.openbsd.org/faq/faq15.html>.

- Vizualizați documentația pentru comanda originală:

`tldr pkg_add`
