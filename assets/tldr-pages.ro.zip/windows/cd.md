# cd

> Această comandă este un alias al `set-location`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Vizualizați documentația pentru comanda originală:

`tldr set-location`
