# curl

> Această comandă este un alias al `curl -p common`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Vizualizați documentația pentru comanda originală:

`tldr curl -p common`
