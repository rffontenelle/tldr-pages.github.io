# ri

> Această comandă este un alias al `remove-item`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Vizualizați documentația pentru comanda originală:

`tldr remove-item`
