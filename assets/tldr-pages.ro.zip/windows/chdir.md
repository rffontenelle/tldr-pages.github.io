# chdir

> Această comandă este un alias al `cd`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Vizualizați documentația pentru comanda originală:

`tldr cd`
