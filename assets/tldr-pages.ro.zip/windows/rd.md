# rd

> Această comandă este un alias al `rmdir`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Vizualizați documentația pentru comanda originală:

`tldr rmdir`
