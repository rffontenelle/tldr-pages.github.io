# iwr

> Această comandă este un alias al `invoke-webrequest`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Vizualizați documentația pentru comanda originală:

`tldr invoke-webrequest`
