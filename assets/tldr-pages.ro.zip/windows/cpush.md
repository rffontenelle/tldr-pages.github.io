# cpush

> Această comandă este un alias al `choco-push`.
> Mai multe informații: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Vizualizați documentația pentru comanda originală:

`tldr choco-push`
