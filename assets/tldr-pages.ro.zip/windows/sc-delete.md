# sc-delete

> Această comandă este un alias al `sc`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Vizualizați documentația pentru comanda originală:

`tldr sc`
