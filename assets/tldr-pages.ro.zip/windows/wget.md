# wget

> Această comandă este un alias al `wget -p common`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Vizualizați documentația pentru comanda originală:

`tldr wget -p common`
