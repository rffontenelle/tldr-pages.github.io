# slmgr

> Această comandă este un alias al `slmgr.vbs`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Vizualizați documentația pentru comanda originală:

`tldr slmgr.vbs`
