# rmdir

> Această comandă este un alias al `remove-item`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Vizualizați documentația pentru comanda originală:

`tldr remove-item`
