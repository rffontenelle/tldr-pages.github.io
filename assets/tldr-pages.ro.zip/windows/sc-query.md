# sc-query

> Această comandă este un alias al `sc`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Vizualizați documentația pentru comanda originală:

`tldr sc`
