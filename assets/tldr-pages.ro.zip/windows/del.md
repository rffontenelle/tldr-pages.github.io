# del

> Această comandă este un alias al `remove-item`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Vizualizați documentația pentru comanda originală:

`tldr remove-item`
