# sl

> Această comandă este un alias al `set-location`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Vizualizați documentația pentru comanda originală:

`tldr set-location`
