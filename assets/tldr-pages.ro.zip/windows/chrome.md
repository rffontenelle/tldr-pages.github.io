# chrome

> Această comandă este un alias al `chromium`.
> Mai multe informații: <https://chrome.google.com>.

- Vizualizați documentația pentru comanda originală:

`tldr chromium`
