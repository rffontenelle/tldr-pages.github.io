# cinst

> Această comandă este un alias al `choco install`.
> Mai multe informații: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Vizualizați documentația pentru comanda originală:

`tldr choco install`
