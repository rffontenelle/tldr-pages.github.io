# ni

> Această comandă este un alias al `new-item`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Vizualizați documentația pentru comanda originală:

`tldr new-item`
