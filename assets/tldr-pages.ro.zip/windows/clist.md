# clist

> Această comandă este un alias al `choco list`.
> Mai multe informații: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Vizualizați documentația pentru comanda originală:

`tldr choco list`
