# clear

> Această comandă este un alias al `clear-host`.

- Vizualizați documentația pentru comanda originală:

`tldr clear-host`
