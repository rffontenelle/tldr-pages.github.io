# sc-create

> Această comandă este un alias al `sc`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Vizualizați documentația pentru comanda originală:

`tldr sc`
