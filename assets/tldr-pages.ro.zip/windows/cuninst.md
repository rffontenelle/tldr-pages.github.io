# cuninst

> Această comandă este un alias al `choco uninstall`.
> Mai multe informații: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Vizualizați documentația pentru comanda originală:

`tldr choco uninstall`
