# sls

> Această comandă este un alias al `where-object`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Vizualizați documentația pentru comanda originală:

`tldr where-object`
