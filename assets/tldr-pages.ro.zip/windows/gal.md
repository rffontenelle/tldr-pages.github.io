# gal

> Această comandă este un alias al `get-alias`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Vizualizați documentația pentru comanda originală:

`tldr get-alias`
