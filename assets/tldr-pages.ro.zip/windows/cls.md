# cls

> Această comandă este un alias al `clear-host`.
> Mai multe informații: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Vizualizați documentația pentru comanda originală:

`tldr clear-host`
