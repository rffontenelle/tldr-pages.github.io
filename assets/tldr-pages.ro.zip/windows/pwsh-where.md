# pwsh-where

> Această comandă este un alias al `Where-Object`.
> Mai multe informații: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Vizualizați documentația pentru comanda originală:

`tldr Where-Object`
