# gbasename

> Această comandă este un alias al `-p linux basename`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux basename`
