# grexec

> Această comandă este un alias al `-p linux rexec`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux rexec`
