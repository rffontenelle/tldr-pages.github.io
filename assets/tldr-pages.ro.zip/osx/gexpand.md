# gexpand

> Această comandă este un alias al `-p linux expand`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux expand`
