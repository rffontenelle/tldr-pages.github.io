# gls

> Această comandă este un alias al `-p linux ls`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ls`
