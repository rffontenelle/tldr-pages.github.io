# gecho

> Această comandă este un alias al `-p linux echo`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux echo`
