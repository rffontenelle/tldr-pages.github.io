# gsha384sum

> Această comandă este un alias al `-p linux sha384sum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux sha384sum`
