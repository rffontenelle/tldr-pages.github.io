# gtee

> Această comandă este un alias al `-p linux tee`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tee`
