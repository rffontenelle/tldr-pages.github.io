# gfalse

> Această comandă este un alias al `-p linux false`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux false`
