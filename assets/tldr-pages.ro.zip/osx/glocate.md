# glocate

> Această comandă este un alias al `-p linux locate`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux locate`
