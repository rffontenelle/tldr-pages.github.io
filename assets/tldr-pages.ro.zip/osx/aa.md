# aa

> Această comandă este un alias al `yaa`.

- Vizualizați documentația pentru comanda originală:

`tldr yaa`
