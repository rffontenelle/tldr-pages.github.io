# gchroot

> Această comandă este un alias al `-p linux chroot`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux chroot`
