# gtty

> Această comandă este un alias al `-p linux tty`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tty`
