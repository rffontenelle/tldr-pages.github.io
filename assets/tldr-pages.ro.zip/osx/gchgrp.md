# gchgrp

> Această comandă este un alias al `-p linux chgrp`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux chgrp`
