# gpathchk

> Această comandă este un alias al `-p linux pathchk`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux pathchk`
