# gwc

> Această comandă este un alias al `-p linux wc`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux wc`
