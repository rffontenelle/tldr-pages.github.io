# gfold

> Această comandă este un alias al `-p linux fold`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux fold`
