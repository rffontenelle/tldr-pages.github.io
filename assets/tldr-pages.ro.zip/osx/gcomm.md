# gcomm

> Această comandă este un alias al `-p linux comm`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux comm`
