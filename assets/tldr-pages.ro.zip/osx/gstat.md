# gstat

> Această comandă este un alias al `-p linux stat`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux stat`
