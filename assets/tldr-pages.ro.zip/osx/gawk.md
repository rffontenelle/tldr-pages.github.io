# gawk

> Această comandă este un alias al `-p linux awk`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux awk`
