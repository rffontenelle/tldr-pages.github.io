# gftp

> Această comandă este un alias al `-p linux ftp`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ftp`
