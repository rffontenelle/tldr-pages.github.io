# gxargs

> Această comandă este un alias al `-p linux xargs`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux xargs`
