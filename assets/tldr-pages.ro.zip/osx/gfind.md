# gfind

> Această comandă este un alias al `-p linux find`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux find`
