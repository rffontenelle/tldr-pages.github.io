# gtail

> Această comandă este un alias al `-p linux tail`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tail`
