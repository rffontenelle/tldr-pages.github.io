# gruncon

> Această comandă este un alias al `-p linux runcon`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux runcon`
