# gmktemp

> Această comandă este un alias al `-p linux mktemp`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux mktemp`
