# glink

> Această comandă este un alias al `-p linux link`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux link`
