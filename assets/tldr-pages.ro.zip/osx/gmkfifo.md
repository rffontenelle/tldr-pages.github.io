# gmkfifo

> Această comandă este un alias al `-p linux mkfifo`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux mkfifo`
