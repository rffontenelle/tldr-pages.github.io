# gfactor

> Această comandă este un alias al `-p linux factor`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux factor`
