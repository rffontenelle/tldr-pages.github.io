# grealpath

> Această comandă este un alias al `-p linux realpath`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux realpath`
