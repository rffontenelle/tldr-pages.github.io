# guname

> Această comandă este un alias al `-p linux uname`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux uname`
