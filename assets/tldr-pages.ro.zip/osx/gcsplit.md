# gcsplit

> Această comandă este un alias al `-p linux csplit`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux csplit`
