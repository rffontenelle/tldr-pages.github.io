# gchown

> Această comandă este un alias al `-p linux chown`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux chown`
