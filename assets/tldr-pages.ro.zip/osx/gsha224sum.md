# gsha224sum

> Această comandă este un alias al `-p linux sha224sum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux sha224sum`
