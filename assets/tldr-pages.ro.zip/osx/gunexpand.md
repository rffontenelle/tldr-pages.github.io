# gunexpand

> Această comandă este un alias al `-p linux unexpand`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux unexpand`
