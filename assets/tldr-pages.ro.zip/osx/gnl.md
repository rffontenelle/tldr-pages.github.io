# gnl

> Această comandă este un alias al `-p linux nl`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux nl`
