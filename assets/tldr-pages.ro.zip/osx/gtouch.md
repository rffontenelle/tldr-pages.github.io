# gtouch

> Această comandă este un alias al `-p linux touch`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux touch`
