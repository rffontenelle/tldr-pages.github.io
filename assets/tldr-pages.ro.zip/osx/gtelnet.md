# gtelnet

> Această comandă este un alias al `-p linux telnet`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux telnet`
