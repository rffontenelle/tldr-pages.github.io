# gprintenv

> Această comandă este un alias al `-p linux printenv`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux printenv`
