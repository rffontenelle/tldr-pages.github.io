# gtimeout

> Această comandă este un alias al `-p linux timeout`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux timeout`
