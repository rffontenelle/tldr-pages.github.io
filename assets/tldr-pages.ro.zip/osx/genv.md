# genv

> Această comandă este un alias al `-p linux env`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux env`
