# ged

> Această comandă este un alias al `-p linux ed`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ed`
