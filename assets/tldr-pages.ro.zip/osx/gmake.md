# gmake

> Această comandă este un alias al `-p linux make`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux make`
