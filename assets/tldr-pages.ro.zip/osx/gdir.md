# gdir

> Această comandă este un alias al `-p linux dir`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux dir`
