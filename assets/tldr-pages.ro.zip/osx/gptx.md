# gptx

> Această comandă este un alias al `-p linux ptx`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ptx`
