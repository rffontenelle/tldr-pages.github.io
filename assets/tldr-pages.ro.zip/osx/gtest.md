# gtest

> Această comandă este un alias al `-p linux test`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux test`
