# gstty

> Această comandă este un alias al `-p linux stty`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux stty`
