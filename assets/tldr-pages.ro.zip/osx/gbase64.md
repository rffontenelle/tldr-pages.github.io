# gbase64

> Această comandă este un alias al `-p linux base64`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux base64`
