# ghostid

> Această comandă este un alias al `-p linux hostid`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux hostid`
