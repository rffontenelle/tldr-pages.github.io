# gsleep

> Această comandă este un alias al `-p linux sleep`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux sleep`
