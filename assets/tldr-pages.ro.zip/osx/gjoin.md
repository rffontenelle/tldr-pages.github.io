# gjoin

> Această comandă este un alias al `-p linux join`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux join`
