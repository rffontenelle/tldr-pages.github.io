# gnproc

> Această comandă este un alias al `-p linux nproc`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux nproc`
