# gsync

> Această comandă este un alias al `-p linux sync`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux sync`
