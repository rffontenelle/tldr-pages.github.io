# ghostname

> Această comandă este un alias al `-p linux hostname`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux hostname`
