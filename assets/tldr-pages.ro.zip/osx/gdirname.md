# gdirname

> Această comandă este un alias al `-p linux dirname`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux dirname`
