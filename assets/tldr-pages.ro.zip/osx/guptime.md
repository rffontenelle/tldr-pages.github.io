# guptime

> Această comandă este un alias al `-p linux uptime`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux uptime`
