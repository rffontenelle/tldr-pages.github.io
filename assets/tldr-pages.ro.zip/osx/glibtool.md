# glibtool

> Această comandă este un alias al `-p linux libtool`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux libtool`
