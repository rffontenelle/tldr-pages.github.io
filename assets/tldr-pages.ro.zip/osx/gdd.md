# gdd

> Această comandă este un alias al `-p linux dd`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux dd`
