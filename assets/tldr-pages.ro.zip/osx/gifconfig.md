# gifconfig

> Această comandă este un alias al `-p linux ifconfig`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ifconfig`
