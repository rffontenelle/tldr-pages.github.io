# grm

> Această comandă este un alias al `-p linux rm`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux rm`
