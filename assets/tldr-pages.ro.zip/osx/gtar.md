# gtar

> Această comandă este un alias al `-p linux tar`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tar`
