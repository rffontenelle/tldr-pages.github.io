# gchmod

> Această comandă este un alias al `-p linux chmod`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux chmod`
