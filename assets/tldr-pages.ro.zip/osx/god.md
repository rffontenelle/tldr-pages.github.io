# god

> Această comandă este un alias al `-p linux od`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux od`
