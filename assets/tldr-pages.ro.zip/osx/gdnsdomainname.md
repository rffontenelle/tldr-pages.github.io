# gdnsdomainname

> Această comandă este un alias al `-p linux dnsdomainname`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux dnsdomainname`
