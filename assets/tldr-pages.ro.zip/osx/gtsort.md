# gtsort

> Această comandă este un alias al `-p linux tsort`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tsort`
