# gshuf

> Această comandă este un alias al `-p linux shuf`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux shuf`
