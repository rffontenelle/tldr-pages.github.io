# glogname

> Această comandă este un alias al `-p linux logname`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux logname`
