# gsum

> Această comandă este un alias al `-p linux sum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux sum`
