# gcksum

> Această comandă este un alias al `-p linux cksum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux cksum`
