# gdf

> Această comandă este un alias al `-p linux df`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux df`
