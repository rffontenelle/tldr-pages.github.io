# launchd

> Această comandă este un alias al `launchctl`.
> Mai multe informații: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Vizualizați documentația pentru comanda originală:

`tldr launchctl`
