# grcp

> Această comandă este un alias al `-p linux rcp`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux rcp`
