# gtrue

> Această comandă este un alias al `-p linux true`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux true`
