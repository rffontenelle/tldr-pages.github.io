# gcut

> Această comandă este un alias al `-p linux cut`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux cut`
