# gtr

> Această comandă este un alias al `-p linux tr`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tr`
