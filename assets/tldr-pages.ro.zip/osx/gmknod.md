# gmknod

> Această comandă este un alias al `-p linux mknod`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux mknod`
