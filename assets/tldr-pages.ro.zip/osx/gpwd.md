# gpwd

> Această comandă este un alias al `-p linux pwd`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux pwd`
