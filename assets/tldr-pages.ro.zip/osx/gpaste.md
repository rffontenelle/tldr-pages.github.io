# gpaste

> Această comandă este un alias al `-p linux paste`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux paste`
