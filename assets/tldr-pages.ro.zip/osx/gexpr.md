# gexpr

> Această comandă este un alias al `-p linux expr`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux expr`
