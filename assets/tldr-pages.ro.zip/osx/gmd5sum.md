# gmd5sum

> Această comandă este un alias al `-p linux md5sum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux md5sum`
