# gdircolors

> Această comandă este un alias al `-p linux dircolors`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux dircolors`
