# gseq

> Această comandă este un alias al `-p linux seq`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux seq`
