# gb2sum

> Această comandă este un alias al `-p linux b2sum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux b2sum`
