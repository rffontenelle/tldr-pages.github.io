# gegrep

> Această comandă este un alias al `-p linux egrep`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux egrep`
