# gtraceroute

> Această comandă este un alias al `-p linux traceroute`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux traceroute`
