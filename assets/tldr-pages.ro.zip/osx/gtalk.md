# gtalk

> Această comandă este un alias al `-p linux talk`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux talk`
