# gkill

> Această comandă este un alias al `-p linux kill`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux kill`
