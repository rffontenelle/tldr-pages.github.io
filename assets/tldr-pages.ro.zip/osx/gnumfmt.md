# gnumfmt

> Această comandă este un alias al `-p linux numfmt`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux numfmt`
