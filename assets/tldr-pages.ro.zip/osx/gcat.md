# gcat

> Această comandă este un alias al `-p linux cat`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux cat`
