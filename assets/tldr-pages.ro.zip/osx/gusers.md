# gusers

> Această comandă este un alias al `-p linux users`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux users`
