# gsha256sum

> Această comandă este un alias al `-p linux sha256sum`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux sha256sum`
