# gbase32

> Această comandă este un alias al `-p linux base32`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux base32`
