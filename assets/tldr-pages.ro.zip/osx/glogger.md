# glogger

> Această comandă este un alias al `-p linux logger`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux logger`
