# gfmt

> Această comandă este un alias al `-p linux fmt`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux fmt`
