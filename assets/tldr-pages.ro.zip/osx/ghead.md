# ghead

> Această comandă este un alias al `-p linux head`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux head`
