# gdate

> Această comandă este un alias al `-p linux date`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux date`
