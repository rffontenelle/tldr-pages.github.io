# gtftp

> Această comandă este un alias al `-p linux tftp`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux tftp`
