# gyes

> Această comandă este un alias al `-p linux yes`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux yes`
