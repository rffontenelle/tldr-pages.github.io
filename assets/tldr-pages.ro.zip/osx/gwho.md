# gwho

> Această comandă este un alias al `-p linux who`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux who`
