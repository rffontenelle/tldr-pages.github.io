# grmdir

> Această comandă este un alias al `-p linux rmdir`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux rmdir`
