# gchcon

> Această comandă este un alias al `-p linux chcon`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux chcon`
