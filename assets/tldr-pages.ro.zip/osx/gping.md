# gping

> Această comandă este un alias al `-p linux ping`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ping`
