# ggrep

> Această comandă este un alias al `-p linux grep`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux grep`
