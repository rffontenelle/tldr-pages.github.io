# gshred

> Această comandă este un alias al `-p linux shred`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux shred`
