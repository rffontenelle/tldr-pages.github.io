# llvm-lipo

> Această comandă este un alias al `lipo`.

- Vizualizați documentația pentru comanda originală:

`tldr lipo`
