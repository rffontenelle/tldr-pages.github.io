# gprintf

> Această comandă este un alias al `-p linux printf`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux printf`
