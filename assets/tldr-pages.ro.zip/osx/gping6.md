# gping6

> Această comandă este un alias al `-p linux ping6`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux ping6`
