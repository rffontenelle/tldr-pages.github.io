# gnohup

> Această comandă este un alias al `-p linux nohup`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux nohup`
