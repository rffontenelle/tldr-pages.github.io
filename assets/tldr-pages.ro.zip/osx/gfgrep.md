# gfgrep

> Această comandă este un alias al `-p linux fgrep`.

- Vizualizați documentația pentru comanda originală:

`tldr -p linux fgrep`
