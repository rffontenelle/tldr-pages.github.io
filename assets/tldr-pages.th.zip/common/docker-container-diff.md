# docker-container-diff

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `docker diff`
> ข้อมูลเพิ่มเติม: <https://docs.docker.com/engine/reference/commandline/diff>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr docker diff`
