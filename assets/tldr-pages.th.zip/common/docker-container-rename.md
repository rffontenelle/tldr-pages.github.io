# docker-container-rename

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `docker rename`
> ข้อมูลเพิ่มเติม: <https://docs.docker.com/engine/reference/commandline/rename>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr docker rename`
