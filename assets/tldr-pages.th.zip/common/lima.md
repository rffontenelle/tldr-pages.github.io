# lima

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `limactl`
> ข้อมูลเพิ่มเติม: <https://github.com/lima-vm/lima>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr limactl`
