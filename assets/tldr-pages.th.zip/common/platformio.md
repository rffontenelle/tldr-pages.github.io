# platformio

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `pio`
> ข้อมูลเพิ่มเติม: <https://docs.platformio.org/en/latest/core/userguide/>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr pio`
