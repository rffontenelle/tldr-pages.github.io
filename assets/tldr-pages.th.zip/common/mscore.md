# mscore

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `musescore`
> ข้อมูลเพิ่มเติม: <https://musescore.org/handbook/command-line-options>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr musescore`
