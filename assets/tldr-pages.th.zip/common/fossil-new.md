# fossil new

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `fossil-init`
> ข้อมูลเพิ่มเติม: <https://fossil-scm.org/home/help/new>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr fossil-init`
