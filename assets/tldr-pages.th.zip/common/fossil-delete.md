# fossil-delete

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `fossil rm`
> ข้อมูลเพิ่มเติม: <https://fossil-scm.org/home/help/delete>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr fossil rm`
