# linode-cli

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `linode-cli account`
> ข้อมูลเพิ่มเติม: <https://www.linode.com/docs/products/tools/cli/get-started/>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr linode-cli account`
