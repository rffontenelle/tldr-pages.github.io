# docker-container-top

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `docker top`
> ข้อมูลเพิ่มเติม: <https://docs.docker.com/engine/reference/commandline/top>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr docker top`
