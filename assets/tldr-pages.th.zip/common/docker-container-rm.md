# docker-container-rm

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `docker rm`
> ข้อมูลเพิ่มเติม: <https://docs.docker.com/engine/reference/commandline/rm>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr docker rm`
