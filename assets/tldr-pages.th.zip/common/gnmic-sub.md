# gnmic-sub

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `gnmic subscribe`
> ข้อมูลเพิ่มเติม: <https://gnmic.kmrd.dev/cmd/subscribe>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr gnmic subscribe`
