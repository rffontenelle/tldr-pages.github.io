# azure-cli

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `az`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/cli/azure>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr az`
