# wget

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `wget -p common`
> ข้อมูลเพิ่มเติม: <https://www.gnu.org/software/wget>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr wget -p common`
