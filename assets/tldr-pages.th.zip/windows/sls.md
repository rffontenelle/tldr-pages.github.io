# sls

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `Select-String`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr select-string`
