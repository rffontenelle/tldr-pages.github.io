# slmgr

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `slmgr.vbs`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr slmgr.vbs`
