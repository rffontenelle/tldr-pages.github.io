# ni

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `new-item`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr new-item`
