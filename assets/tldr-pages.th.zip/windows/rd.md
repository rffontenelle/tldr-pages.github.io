# rd

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `rmdir`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr rmdir`
