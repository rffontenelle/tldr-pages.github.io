# pwsh where

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `Where-Object`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr Where-Object`
