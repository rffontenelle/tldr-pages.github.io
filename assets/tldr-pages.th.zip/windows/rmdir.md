# rmdir

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `remove-item`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr remove-item`
