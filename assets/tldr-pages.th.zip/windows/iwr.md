# iwr

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `invoke-webrequest`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr invoke-webrequest`
