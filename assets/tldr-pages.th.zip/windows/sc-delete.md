# sc-delete

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `sc`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr sc`
