# cinst

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `choco install`
> ข้อมูลเพิ่มเติม: <https://docs.chocolatey.org/en-us/choco/commands/install>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr choco install`
