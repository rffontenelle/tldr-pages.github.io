# cls

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `clear-host`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr clear-host`
