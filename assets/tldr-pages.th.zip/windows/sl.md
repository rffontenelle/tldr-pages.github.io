# sl

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `set-location`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr set-location`
