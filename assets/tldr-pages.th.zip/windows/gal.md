# gal

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `get-alias`
> ข้อมูลเพิ่มเติม: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr get-alias`
