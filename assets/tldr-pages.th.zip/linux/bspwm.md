# bspwm

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `bspc`
> ข้อมูลเพิ่มเติม: <https://github.com/baskerville/bspwm>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr bspc`
