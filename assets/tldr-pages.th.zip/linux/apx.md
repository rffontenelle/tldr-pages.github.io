# apx

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `apx pkgmanagers`
> ข้อมูลเพิ่มเติม: <https://github.com/Vanilla-OS/apx>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr apx pkgmanagers`
