# cgroups

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `cgclassify`
> ข้อมูลเพิ่มเติม: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr cgclassify`
