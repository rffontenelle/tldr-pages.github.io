# ip6tables-restore

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `iptables-restore`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr iptables-restore`
