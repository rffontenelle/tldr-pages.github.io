# qm-move-disk

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `qm-disk-move`
> ข้อมูลเพิ่มเติม: <https://pve.proxmox.com/pve-docs/qm.1.html>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr qm-disk-move`
