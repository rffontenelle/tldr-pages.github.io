# pkgctl

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `pkgctl auth`
> ข้อมูลเพิ่มเติม: <https://man.archlinux.org/man/pkgctl.1>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr pkgctl auth`
