# xbps

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `xbps-install`
> ข้อมูลเพิ่มเติม: <https://docs.voidlinux.org/xbps/index.html>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr xbps-install`
