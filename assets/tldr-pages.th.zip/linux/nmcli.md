# nmcli

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `nmcli agent`
> ข้อมูลเพิ่มเติม: <https://networkmanager.dev/docs/api/latest/nmcli.html>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr nmcli agent`
