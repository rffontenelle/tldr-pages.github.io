# distrobox

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `distrobox-create`
> ข้อมูลเพิ่มเติม: <https://github.com/89luca89/distrobox>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr distrobox-create`
