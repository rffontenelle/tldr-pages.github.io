# qm-importdisk

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `qm disk import`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr qm disk import`
