# ip6tables-save

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `iptables-save`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr iptables-save`
