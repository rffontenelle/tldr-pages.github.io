# launchd

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `launchctl`
> ข้อมูลเพิ่มเติม: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr launchctl`
