# gdircolors

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `-p linux dircolors`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr -p linux dircolors`
