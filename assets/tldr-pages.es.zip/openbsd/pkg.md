# pkg

> Este comando es un alias de `pkg_add`.
> Más información: <https://www.openbsd.org/faq/faq15.html>.

- Ver documentación para el comando original:

`tldr pkg_add`
