# sls

> Este comando es un alias de `Select-String`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Ver documentación para el comando original:

`tldr select-string`
