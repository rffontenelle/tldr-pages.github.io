# rmdir

> Este comando es un alias de `remove-item`.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Ver documentación para el comando original:

`tldr remove-item`
