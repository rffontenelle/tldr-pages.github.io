# ni

> Este comando es un alias de `new-item`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Ver documentación para el comando original:

`tldr new-item`
