# rd

> Este comando es un alias de `rmdir`.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Muestra la documentación del comando original:

`tldr rmdir`
