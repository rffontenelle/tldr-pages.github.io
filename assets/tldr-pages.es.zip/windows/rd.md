# rd

> Este comando es un alias de `rmdir`.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Ver documentación para el comando original:

`tldr rmdir`
