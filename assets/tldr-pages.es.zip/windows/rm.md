# rm

> Este comando es un alias de `remove-item`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Ver documentación para el comando original:

`tldr remove-item`
