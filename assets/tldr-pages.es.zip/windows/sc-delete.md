# sc-delete

> Este comando es un alias de `sc`.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Ver documentación para el comando original:

`tldr sc`
