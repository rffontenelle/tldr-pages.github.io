# cpush

> Este comando es un alias de `choco push`.
> Más información: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Ver documentación para el comando original:

`tldr choco-push`
