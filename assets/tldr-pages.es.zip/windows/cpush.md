# cpush

> Este comando es un alias de `choco push`.
> Más información: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Muestra la documentación del comando original:

`tldr choco-push`
