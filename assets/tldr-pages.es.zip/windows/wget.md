# wget

> Este comando es un alias de `wget -p common`.
> Más información: <https://www.gnu.org/software/wget>.

- Ver documentación para el comando original:

`tldr wget -p common`
