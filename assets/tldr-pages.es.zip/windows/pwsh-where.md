# pwsh-where

> Este comando es un alias de `Where-Object`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Ver documentación para el comando original:

`tldr Where-Object`
