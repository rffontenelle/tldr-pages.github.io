# clist

> Este comando es un alias de `choco list`.
> Más información: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Ver documentación para el comando original:

`tldr choco list`
