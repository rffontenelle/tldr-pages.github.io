# sl

> Este comando es un alias de `set-location`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Ver documentación para el comando original:

`tldr set-location`
