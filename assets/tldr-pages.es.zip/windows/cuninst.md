# cuninst

> Este comando es un alias de `choco uninstall`.
> Más información: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Ver documentación para el comando original:

`tldr choco uninstall`
