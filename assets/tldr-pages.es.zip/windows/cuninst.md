# cuninst

> Este comando es un alias de `choco uninstall`.
> Más información: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Muestra la documentación del comando original:

`tldr choco uninstall`
