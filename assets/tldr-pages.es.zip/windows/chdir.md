# chdir

> Este comando es un alias de `cd`.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Ver documentación para el comando original:

`tldr cd`
