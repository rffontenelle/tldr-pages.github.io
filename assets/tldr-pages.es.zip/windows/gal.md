# gal

> Este comando es un alias de `get-alias`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Ver documentación para el comando original:

`tldr get-alias`
