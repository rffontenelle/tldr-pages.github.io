# chrome

> Este comando es un alias de `chromium`.
> Más información: <https://chrome.google.com>.

- Ver documentación para el comando original:

`tldr chromium`
