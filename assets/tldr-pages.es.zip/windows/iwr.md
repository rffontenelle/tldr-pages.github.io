# iwr

> Este comando es un alias de `invoke-webrequest`.

- Ver documentación para el comando original:

`tldr invoke-webrequest`
