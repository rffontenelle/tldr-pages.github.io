# iwr

> Este comando es un alias de `invoke-webrequest`.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Ver documentación para el comando original:

`tldr invoke-webrequest`
