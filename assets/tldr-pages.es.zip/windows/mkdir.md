# mkdir

> Crea un directorio.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- Crea un directorio:

`mkdir {{ruta\al\directorio}}`

- Crea un árbol de directorios anidado de forma recursiva:

`mkdir {{ruta\al\sub_directorio}}`
