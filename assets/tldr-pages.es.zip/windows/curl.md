# curl

> Este comando es un alias de `curl -p common`.
> Más información: <https://curl.se>.

- Ver documentación para el comando original:

`tldr curl -p common`
