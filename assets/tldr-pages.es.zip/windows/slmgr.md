# slmgr

> Este comando es un alias de `slmgr.vbs`.
> Más información: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Ver documentación para el comando original:

`tldr slmgr.vbs`
