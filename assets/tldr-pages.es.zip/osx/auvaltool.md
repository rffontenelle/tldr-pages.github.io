# auvaltool

> Herramienta de validación AudioUnit para Mac.
> Más información: <https://www.unix.com/man-page/mojave/1/auvaltool>.

- Lista todas las AudioUnits disponibles de cualquier tipo:

`auvaltool -a`

- Lista todas las AudioUnits [a]vailable de cualquier tipo con su [l]ocalización:

`auvaltool -al`
