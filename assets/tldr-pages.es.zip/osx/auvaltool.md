# auvaltool

> Herramienta de validación AudioUnit para Mac.
> Más información: <https://keith.github.io/xcode-man-pages/auvaltool.1.html>.

- Lista todas las AudioUnits disponibles de cualquier tipo:

`auvaltool -a`

- Lista todas las AudioUnits [a]vailable de cualquier tipo con su [l]ocalización:

`auvaltool -al`
