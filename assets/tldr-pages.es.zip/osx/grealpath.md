# grealpath

> Este comando es un alias de `-p linux realpath`.

- Ver documentación para el comando original:

`tldr -p linux realpath`
