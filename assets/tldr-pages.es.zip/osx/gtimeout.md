# gtimeout

> Este comando es un alias de `-p linux timeout`.

- Ver documentación para el comando original:

`tldr -p linux timeout`
