# gnproc

> Este comando es un alias de `-p linux nproc`.

- Ver documentación para el comando original:

`tldr -p linux nproc`
