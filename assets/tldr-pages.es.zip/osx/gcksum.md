# gcksum

> Este comando es un alias de `-p linux cksum`.

- Ver documentación para el comando original:

`tldr -p linux cksum`
