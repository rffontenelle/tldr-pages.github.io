# appsleepd

> Proporciona servicios de suspensión de aplicaciones.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/appsleepd.8.html>.

- Inicia el daemon:

`appsleepd`
