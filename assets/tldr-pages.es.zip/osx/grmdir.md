# grmdir

> Este comando es un alias de `-p linux rmdir`.

- Ver documentación para el comando original:

`tldr -p linux rmdir`
