# gwc

> Este comando es un alias de `-p linux wc`.

- Ver documentación para el comando original:

`tldr -p linux wc`
