# gdnsdomainname

> Este comando es un alias de `-p linux dnsdomainname`.

- Ver documentación para el comando original:

`tldr -p linux dnsdomainname`
