# uuidgen

> Genera nuevas cadenas UUID (Identificador único universal).
> Más información: <https://keith.github.io/xcode-man-pages/uuidgen.1.html>.

- Genera una cadena UUID:

`uuidgen`
