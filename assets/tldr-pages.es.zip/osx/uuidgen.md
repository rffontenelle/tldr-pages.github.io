# uuidgen

> Genera nuevas cadenas UUID (Identificador único universal).
> Más información: <https://www.ss64.com/osx/uuidgen.html>.

- Genera una cadena UUID:

`uuidgen`
