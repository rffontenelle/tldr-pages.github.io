# gunexpand

> Este comando es un alias de `-p linux unexpand`.

- Ver documentación para el comando original:

`tldr -p linux unexpand`
