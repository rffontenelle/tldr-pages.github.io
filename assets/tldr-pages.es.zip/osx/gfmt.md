# gfmt

> Este comando es un alias de `-p linux fmt`.

- Muestra la documentación del comando original:

`tldr -p linux fmt`
