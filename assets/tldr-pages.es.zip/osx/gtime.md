# gtime

> Este comando es un alias de `-p linux time`.

- Ver documentación para el comando original:

`tldr -p linux time`
