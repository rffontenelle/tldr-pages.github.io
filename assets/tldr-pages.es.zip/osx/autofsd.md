# autofsd

> Ejecuta `automount` al inicio del sistema y en cambios en la configuración de red.
> No debe ser invocado manualmente.
> Más información: <https://www.manpagez.com/man/8/autofsd/>.

- Inicia el proceso residente:

`autofsd`
