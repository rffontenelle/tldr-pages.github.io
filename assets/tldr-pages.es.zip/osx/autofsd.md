# autofsd

> Ejecuta `automount` al inicio del sistema y en cambios en la configuración de red.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/autofsd.8.html>.

- Inicia el proceso residente:

`autofsd`
