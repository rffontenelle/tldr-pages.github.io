# grm

> Este comando es un alias de `-p linux rm`.

- Muestra la documentación del comando original:

`tldr -p linux rm`
