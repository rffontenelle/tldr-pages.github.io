# ggrep

> Este comando es un alias de `-p linux grep`.

- Ver documentación para el comando original:

`tldr -p linux grep`
