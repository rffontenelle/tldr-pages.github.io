# gsha256sum

> Este comando es un alias de `-p linux sha256sum`.

- Ver documentación para el comando original:

`tldr -p linux sha256sum`
