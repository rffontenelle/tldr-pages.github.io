# airportd

> Gestiona las interfaces inalámbricas.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/airportd/>.

- Inicia el daemon:

`airportd`
