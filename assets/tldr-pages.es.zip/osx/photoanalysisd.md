# photoanalysisd

> Analiza las bibliotecas de fotos para Memorias, Personas, y búsquedas basadas en escenas u objetos.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/photoanalysisd.8.html>.

- Inicia el daemon:

`photoanalysisd`
