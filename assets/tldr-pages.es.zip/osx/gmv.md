# gmv

> Este comando es un alias de `-p linux mv`.

- Ver documentación para el comando original:

`tldr -p linux mv`
