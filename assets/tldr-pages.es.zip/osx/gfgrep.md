# gfgrep

> Este comando es un alias de `-p linux fgrep`.

- Ver documentación para el comando original:

`tldr -p linux fgrep`
