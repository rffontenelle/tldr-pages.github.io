# god

> Este comando es un alias de `-p linux od`.

- Ver documentación para el comando original:

`tldr -p linux od`
