# systemsoundserverd

> Daemon relacionado con Core Audio.
> No debe invocarse manualmente.

- Inicia el daemon:

`systemsoundserverd`
