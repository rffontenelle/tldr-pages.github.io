# xartstorageremoted

> El Daemon de Almacenamiento Remoto xART. Recibe las solicitudes de guardar/obtener del CoProcesador.
> No debe ser invocado manualmente.
> Más información: <http://www.manpagez.com/man/8/xartstorageremoted/>.

- Inicia el daemon:

`xartstorageremoted`
