# gtrue

> Este comando es un alias de `-p linux true`.

- Ver documentación para el comando original:

`tldr -p linux true`
