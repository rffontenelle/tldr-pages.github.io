# gnice

> Este comando es un alias de `-p linux nice`.

- Muestra la documentación del comando original:

`tldr -p linux nice`
