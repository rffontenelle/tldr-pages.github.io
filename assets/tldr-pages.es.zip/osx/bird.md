# bird

> Esto admite la sincronización de iCloud e iCloud Drive.
> No debe ser invocado manualmente.
> Más información: <https://www.unix.com/man-page/mojave/8/bird/>.

- Inicia el proceso residente:

`bird`
