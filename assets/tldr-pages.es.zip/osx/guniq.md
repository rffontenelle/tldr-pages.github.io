# guniq

> Este comando es un alias de `-p linux uniq`.

- Muestra la documentación del comando original:

`tldr -p linux uniq`
