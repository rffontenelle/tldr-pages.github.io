# gmknod

> Este comando es un alias de `-p linux mknod`.

- Ver documentación para el comando original:

`tldr -p linux mknod`
