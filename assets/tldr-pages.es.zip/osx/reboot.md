# reboot

> Reinicia el sistema.
> Más información: <https://ss64.com/osx/reboot.html>.

- Reinicia inmediatamente:

`sudo reboot`

- Reinicia inmediatamente sin apagar el sistema:

`sudo reboot -q`
