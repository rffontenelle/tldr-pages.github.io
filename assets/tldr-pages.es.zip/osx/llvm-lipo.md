# llvm-lipo

> Este comando es un alias de `lipo`.

- Ver documentación para el comando original:

`tldr lipo`
