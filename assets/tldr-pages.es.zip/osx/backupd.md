# backupd

> Crea copias de seguridad de Time Machine y gestiona el historial de copias de seguridad.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/backupd.8.html>.

- Inicia el daemon:

`backupd`
