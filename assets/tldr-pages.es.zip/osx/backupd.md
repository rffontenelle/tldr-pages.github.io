# backupd

> Crea copias de seguridad de Time Machine y gestiona el historial de copias de seguridad.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/backupd/>.

- Inicia el daemon:

`backupd`
