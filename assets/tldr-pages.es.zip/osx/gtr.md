# gtr

> Este comando es un alias de `-p linux tr`.

- Ver documentación para el comando original:

`tldr -p linux tr`
