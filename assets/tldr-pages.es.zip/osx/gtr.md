# gtr

> Este comando es un alias de `-p linux tr`.

- Muestra la documentación del comando original:

`tldr -p linux tr`
