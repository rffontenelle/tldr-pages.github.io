# gmake

> Este comando es un alias de `-p linux make`.

- Ver documentación para el comando original:

`tldr -p linux make`
