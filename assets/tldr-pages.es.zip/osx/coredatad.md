# coredatad

> Programa operaciones CloudKit para clientes de NSPersistentCloudKitContainer.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/coredatad.8.html>.

- Inicia el proceso residente:

`coredatad`
