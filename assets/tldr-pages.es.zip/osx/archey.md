# archey

> Herramienta sencilla para mostrar información del sistema con estilo.
> Más información: <https://github.com/joshfinnie/archey-osx>.

- Muestra información del sistema:

`archey`

- Muestra información del sistema sin colorear la salida:

`archey --nocolor`

- Muestra información del sistema, usando MacPorts en lugar de Homebrew:

`archey --macports`

- Muestra información del sistema sin verificación dirección IP:

`archey --offline`
