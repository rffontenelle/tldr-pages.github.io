# usernoted

> Proporciona servicios de notificación.
> No debe invocarse manualmente.
> Más información: <https://www.unix.com/man-page/mojave/8/usernoted>.

- Inicia el daemon:

`usernoted`
