# usernoted

> Proporciona servicios de notificación.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/usernoted.8.html>.

- Inicia el daemon:

`usernoted`
