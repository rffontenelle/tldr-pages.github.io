# gwho

> Este comando es un alias de `-p linux who`.

- Muestra la documentación del comando original:

`tldr -p linux who`
