# gsha224sum

> Este comando es un alias de `-p linux sha224sum`.

- Ver documentación para el comando original:

`tldr -p linux sha224sum`
