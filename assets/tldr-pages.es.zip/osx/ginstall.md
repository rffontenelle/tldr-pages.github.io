# ginstall

> Este comando es un alias de `-p linux install`.

- Ver documentación para el comando original:

`tldr -p linux install`
