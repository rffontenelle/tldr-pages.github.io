# gegrep

> Este comando es un alias de `-p linux egrep`.

- Ver documentación para el comando original:

`tldr -p linux egrep`
