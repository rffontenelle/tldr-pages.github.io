# gstat

> Este comando es un alias de `-p linux stat`.

- Muestra la documentación del comando original:

`tldr -p linux stat`
