# gindent

> Este comando es un alias de `-p linux indent`.

- Ver documentación para el comando original:

`tldr -p linux indent`
