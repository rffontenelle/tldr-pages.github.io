# grexec

> Este comando es un alias de `-p linux rexec`.

- Ver documentación para el comando original:

`tldr -p linux rexec`
