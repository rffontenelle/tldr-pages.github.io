# grexec

> Este comando es un alias de `-p linux rexec`.

- Muestra la documentación del comando original:

`tldr -p linux rexec`
