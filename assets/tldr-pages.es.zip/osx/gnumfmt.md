# gnumfmt

> Este comando es un alias de `-p linux numfmt`.

- Ver documentación para el comando original:

`tldr -p linux numfmt`
