# grcp

> Este comando es un alias de `-p linux rcp`.

- Ver documentación para el comando original:

`tldr -p linux rcp`
