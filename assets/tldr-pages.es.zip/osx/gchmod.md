# gchmod

> Este comando es un alias de `-p linux chmod`.

- Ver documentación para el comando original:

`tldr -p linux chmod`
