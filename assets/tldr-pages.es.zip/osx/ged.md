# ged

> Este comando es un alias de `-p linux ed`.

- Ver documentación para el comando original:

`tldr -p linux ed`
