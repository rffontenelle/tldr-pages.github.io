# gbasename

> Este comando es un alias de `-p linux basename`.

- Ver documentación para el comando original:

`tldr -p linux basename`
