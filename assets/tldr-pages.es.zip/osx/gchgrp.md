# gchgrp

> Este comando es un alias de `-p linux chgrp`.

- Ver documentación para el comando original:

`tldr -p linux chgrp`
