# gwhois

> Este comando es un alias de `-p linux whois`.

- Ver documentación para el comando original:

`tldr -p linux whois`
