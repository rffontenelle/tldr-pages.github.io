# wps

> Ayuda a AirPort a conectarse a una red mediante la Configuración inalámbrica protegida.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/wps/>.

- Inicia el daemon:

`wps`
