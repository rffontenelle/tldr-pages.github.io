# wps

> Ayuda a AirPort a conectarse a una red mediante la Configuración inalámbrica protegida.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/wps.8.html>.

- Inicia el daemon:

`wps`
