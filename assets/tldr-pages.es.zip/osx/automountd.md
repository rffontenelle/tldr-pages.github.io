# automountd

> Un daemon de montaje/desmontaje automático para `autofs`. Iniciado bajo demanda por `launchd`.
> No debe ser invocado manualmente.
> Más información: <https://www.manpagez.com/man/8/automountd/>.

- Inicia el daemon:

`automountd`

- Registra más detalles en `syslog`:

`automountd -v`
