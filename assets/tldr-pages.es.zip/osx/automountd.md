# automountd

> Un daemon de montaje/desmontaje automático para `autofs`. Iniciado bajo demanda por `launchd`.
> No debe ser invocado manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/automountd.8.html>.

- Inicia el daemon:

`automountd`

- Registra más detalles en `syslog`:

`automountd -v`
