# glink

> Este comando es un alias de `-p linux link`.

- Ver documentación para el comando original:

`tldr -p linux link`
