# glink

> Este comando es un alias de `-p linux link`.

- Muestra la documentación del comando original:

`tldr -p linux link`
