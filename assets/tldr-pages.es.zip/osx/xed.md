# xed

> Abre archivos para editarlos en Xcode.
> Más información: <https://www.manpagez.com/man/1/xed/>.

- Abre archivo en Xcode:

`xed {{archivo1}}`

- Abre archivo(s) en Xcode, lo crea si no existe:

`xed --create {{nombre_archivo1}}`

- Abre un archivo en Xcode y salta a la línea número 75:

`xed --line 75 {{nombre_archivo}}`
