# launchd

> Este comando es un alias de `launchctl`.
> Más información: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Ver documentación para el comando original:

`tldr launchctl`
