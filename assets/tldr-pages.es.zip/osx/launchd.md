# launchd

> Este comando es un alias de `launchctl`.
> Más información: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Muestra la documentación del comando original:

`tldr launchctl`
