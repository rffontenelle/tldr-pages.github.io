# gtouch

> Este comando es un alias de `-p linux touch`.

- Ver documentación para el comando original:

`tldr -p linux touch`
