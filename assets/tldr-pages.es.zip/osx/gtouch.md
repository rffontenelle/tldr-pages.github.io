# gtouch

> Este comando es un alias de `-p linux touch`.

- Muestra la documentación del comando original:

`tldr -p linux touch`
