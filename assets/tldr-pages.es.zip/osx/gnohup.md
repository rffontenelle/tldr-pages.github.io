# gnohup

> Este comando es un alias de `-p linux nohup`.

- Muestra la documentación del comando original:

`tldr -p linux nohup`
