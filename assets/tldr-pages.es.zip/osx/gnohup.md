# gnohup

> Este comando es un alias de `-p linux nohup`.

- Ver documentación para el comando original:

`tldr -p linux nohup`
