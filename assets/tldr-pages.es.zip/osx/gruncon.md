# gruncon

> Este comando es un alias de `-p linux runcon`.

- Ver documentación para el comando original:

`tldr -p linux runcon`
