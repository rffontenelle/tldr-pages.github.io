# vm_stat

> Muestra estadísticas de memoria virtual.
> Más información: <https://www.unix.com/man-page/osx/1/vm_stat>.

- Muestra estadísticas de memoria virtual:

`vm_stat`

- Muestra informes cada 2 segundos durante 5 veces:

`vm_stat -c {{5}} {{2}}`
