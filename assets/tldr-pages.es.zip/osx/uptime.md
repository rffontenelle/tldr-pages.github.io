# uptime

> Indica cuánto tiempo lleva funcionando el sistema y otras informaciones.
> Más información: <https://ss64.com/osx/uptime.html>.

- Imprime la hora actual, el tiempo de actividad, el número de usuarios conectados y otras informaciones:

`uptime`
