# machine

> Imprime el tipo de máquina.
> Más información: <https://manned.org/machine>.

- Imprime la arquitectura de la CPU:

`machine`
