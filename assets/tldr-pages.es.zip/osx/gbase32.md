# gbase32

> Este comando es un alias de `-p linux base32`.

- Ver documentación para el comando original:

`tldr -p linux base32`
