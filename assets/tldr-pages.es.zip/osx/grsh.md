# grsh

> Este comando es un alias de `-p linux rsh`.

- Muestra la documentación del comando original:

`tldr -p linux rsh`
