# grsh

> Este comando es un alias de `-p linux rsh`.

- Ver documentación para el comando original:

`tldr -p linux rsh`
