# gpathchk

> Este comando es un alias de `-p linux pathchk`.

- Ver documentación para el comando original:

`tldr -p linux pathchk`
