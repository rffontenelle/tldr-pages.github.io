# gfold

> Este comando es un alias de `-p linux fold`.

- Muestra la documentación del comando original:

`tldr -p linux fold`
