# gfold

> Este comando es un alias de `-p linux fold`.

- Ver documentación para el comando original:

`tldr -p linux fold`
