# gshred

> Este comando es un alias de `-p linux shred`.

- Ver documentación para el comando original:

`tldr -p linux shred`
