# readlink

> Sigue enlaces simbólicos y obtiene información sobre enlaces simbólicos.
> Más información: <https://www.gnu.org/software/coreutils/readlink>.

- Imprime la ruta absoluta a la que apunta el enlace simbólico:

`readlink {{ruta/al/archivo_symlink}}`
