# glibtoolize

> Este comando es un alias de `-p linux libtoolize`.

- Ver documentación para el comando original:

`tldr -p linux libtoolize`
