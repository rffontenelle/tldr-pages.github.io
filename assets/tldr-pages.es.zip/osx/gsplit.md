# gsplit

> Este comando es un alias de `-p linux split`.

- Ver documentación para el comando original:

`tldr -p linux split`
