# glogname

> Este comando es un alias de `-p linux logname`.

- Ver documentación para el comando original:

`tldr -p linux logname`
