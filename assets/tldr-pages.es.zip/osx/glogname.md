# glogname

> Este comando es un alias de `-p linux logname`.

- Muestra la documentación del comando original:

`tldr -p linux logname`
