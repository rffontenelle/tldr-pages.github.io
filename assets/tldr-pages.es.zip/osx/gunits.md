# gunits

> Este comando es un alias de `-p linux units`.

- Muestra la documentación del comando original:

`tldr -p linux units`
