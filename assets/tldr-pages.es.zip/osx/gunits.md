# gunits

> Este comando es un alias de `-p linux units`.

- Ver documentación para el comando original:

`tldr -p linux units`
