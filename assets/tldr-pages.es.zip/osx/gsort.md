# gsort

> Este comando es un alias de `-p linux sort`.

- Muestra la documentación del comando original:

`tldr -p linux sort`
