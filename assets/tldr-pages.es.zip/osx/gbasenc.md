# gbasenc

> Este comando es un alias de `-p linux basenc`.

- Ver documentación para el comando original:

`tldr -p linux basenc`
