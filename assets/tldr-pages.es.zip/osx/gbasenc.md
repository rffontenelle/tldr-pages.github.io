# gbasenc

> Este comando es un alias de `-p linux basenc`.

- Muestra la documentación del comando original:

`tldr -p linux basenc`
