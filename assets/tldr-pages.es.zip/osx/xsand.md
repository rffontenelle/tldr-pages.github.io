# xsand

> Daemon de gestión del sistema de archivos Xsan. Proporciona servicios para el sistema de archivos Xsan.
> No debe invocarse manualmente.
> Más información: <https://developer.apple.com/support/downloads/Xsan-Management-Guide.pdf>.

- Inicia el daemon:

`xsand`
