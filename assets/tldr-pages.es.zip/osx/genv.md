# genv

> Este comando es un alias de `-p linux env`.

- Muestra la documentación del comando original:

`tldr -p linux env`
