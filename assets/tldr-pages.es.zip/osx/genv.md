# genv

> Este comando es un alias de `-p linux env`.

- Ver documentación para el comando original:

`tldr -p linux env`
