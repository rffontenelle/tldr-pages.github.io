# wwand

> Daemon de configuración del dispositivo USB WWAN.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/wwand.8.html>.

- Inicia el daemon:

`wwand`
