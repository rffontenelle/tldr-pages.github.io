# gprintf

> Este comando es un alias de `-p linux printf`.

- Muestra la documentación del comando original:

`tldr -p linux printf`
