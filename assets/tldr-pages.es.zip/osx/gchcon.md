# gchcon

> Este comando es un alias de `-p linux chcon`.

- Ver documentación para el comando original:

`tldr -p linux chcon`
