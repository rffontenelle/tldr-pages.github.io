# warmd

> Controla las cachés utilizadas durante el arranque y el inicio de sesión.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/warmd/>.

- Inicia el daemon:

`warmd`
