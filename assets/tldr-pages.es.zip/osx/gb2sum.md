# gb2sum

> Este comando es un alias de `-p linux b2sum`.

- Ver documentación para el comando original:

`tldr -p linux b2sum`
