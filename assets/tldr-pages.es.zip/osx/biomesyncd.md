# biomesyncd

> Sincroniza datos entre dispositivos registrados en la misma cuenta.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/biomesyncd.8.html>.

- Inicia el daemon:

`biomesyncd`
