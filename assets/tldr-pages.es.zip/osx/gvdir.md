# gvdir

> Este comando es un alias de `-p linux vdir`.

- Muestra la documentación del comando original:

`tldr -p linux vdir`
