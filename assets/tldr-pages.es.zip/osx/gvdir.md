# gvdir

> Este comando es un alias de `-p linux vdir`.

- Ver documentación para el comando original:

`tldr -p linux vdir`
