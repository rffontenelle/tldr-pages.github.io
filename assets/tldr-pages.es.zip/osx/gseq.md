# gseq

> Este comando es un alias de `-p linux seq`.

- Ver documentación para el comando original:

`tldr -p linux seq`
