# gwhich

> Este comando es un alias de `-p linux which`.

- Ver documentación para el comando original:

`tldr -p linux which`
