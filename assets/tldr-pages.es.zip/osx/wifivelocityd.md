# wifivelocityd

> Asistente XPC para realizar acciones de contexto de sistema para el framework WiFiVelocity.
> No debe invocarse manualmente.
> Más información: <http://www.manpagez.com/man/8/wifivelocityd/>.

- Inicia el daemon:

`wifivelocityd`
