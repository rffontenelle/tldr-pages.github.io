# gxargs

> Este comando es un alias de `-p linux xargs`.

- Ver documentación para el comando original:

`tldr -p linux xargs`
