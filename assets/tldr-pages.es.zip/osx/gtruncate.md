# gtruncate

> Este comando es un alias de `-p linux truncate`.

- Ver documentación para el comando original:

`tldr -p linux truncate`
