# gfalse

> Este comando es un alias de `-p linux false`.

- Ver documentación para el comando original:

`tldr -p linux false`
