# aa

> Este comando es un alias de `yaa`.

- Ver documentación para el comando original:

`tldr yaa`
