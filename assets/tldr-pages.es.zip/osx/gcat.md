# gcat

> Este comando es un alias de `-p linux cat`.

- Muestra la documentación del comando original:

`tldr -p linux cat`
