# gexpr

> Este comando es un alias de `-p linux expr`.

- Ver documentación para el comando original:

`tldr -p linux expr`
