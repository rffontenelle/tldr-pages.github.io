# gexpr

> Este comando es un alias de `-p linux expr`.

- Muestra la documentación del comando original:

`tldr -p linux expr`
