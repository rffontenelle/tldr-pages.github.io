# biometrickitd

> Proporciona soporte para operaciones biométricas.
> No debe ser invocado manualmente.
> Más información: <https://www.manpagez.com/man/8/biometrickitd/>.

- Inicia el proceso residente:

`biometrickitd`
