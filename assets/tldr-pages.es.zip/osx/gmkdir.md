# gmkdir

> Este comando es un alias de `-p linux mkdir`.

- Muestra la documentación del comando original:

`tldr -p linux mkdir`
