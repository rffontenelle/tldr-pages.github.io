# gfind

> Este comando es un alias de `-p linux find`.

- Ver documentación para el comando original:

`tldr -p linux find`
