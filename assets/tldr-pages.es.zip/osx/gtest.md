# gtest

> Este comando es un alias de `-p linux test`.

- Ver documentación para el comando original:

`tldr -p linux test`
