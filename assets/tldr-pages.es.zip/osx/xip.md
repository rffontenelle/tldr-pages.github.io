# xip

> Crea o expande archivos comprimidos en un archivo xip seguro.
> Sólo los archivos firmados por Apple son de confianza, por lo que esta herramienta no debe utilizarse para crear archivos comprimidos.
> Más información: <https://keith.github.io/xcode-man-pages/xip.1.html>.

- Expande el archivo en el directorio de trabajo actual:

`xip --expand {{ruta/al/archivo.xip}}`
