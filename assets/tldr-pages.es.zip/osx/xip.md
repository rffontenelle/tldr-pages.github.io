# xip

> Crea o expande archivos comprimidos en un archivo xip seguro.
> Sólo los archivos firmados por Apple son de confianza, por lo que esta herramienta no debe utilizarse para crear archivos comprimidos.
> Más información: <https://www.manpagez.com/man/1/xip/>.

- Expande el archivo en el directorio de trabajo actual:

`xip --expand {{ruta/al/archivo.xip}}`
