# avbdeviced

> Un servicio para gestionar dispositivos Audio Video Bridging (AVB).
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/1/avbdeviced/>.

- Inicia el daemon:

`avbdeviced`
