# bnepd

> Un servicio que gestiona todas las conexiones de red Bluetooth.
> No debe invocarse manualmente.
> Más información: <https://www.unix.com/man-page/osx/8/bnepd/>.

- Inicia el daemon:

`bnepd`
