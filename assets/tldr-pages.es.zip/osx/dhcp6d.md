# dhcp6d

> Servidor DHCPv6 sin estado. Ver también: `InternetSharing`.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/dhcp6d/>.

- Inicia el daemon:

`dhcp6d`

- Utiliza una configuración personalizada:

`dhcp6d {{ruta/al/archivo_config}}`
