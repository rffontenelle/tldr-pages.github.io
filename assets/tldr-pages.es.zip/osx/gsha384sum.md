# gsha384sum

> Este comando es un alias de `-p linux sha384sum`.

- Ver documentación para el comando original:

`tldr -p linux sha384sum`
