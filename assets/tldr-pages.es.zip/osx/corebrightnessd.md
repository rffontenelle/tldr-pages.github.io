# corebrightnessd

> Gestiona Night Shift.
> No debe ser invocado manualmente.
> Más información: <https://www.manpagez.com/man/8/corebrightnessd/>.

- Inicia el proceso residente:

`corebrightnessd`
