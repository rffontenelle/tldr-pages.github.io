# gstdbuf

> Este comando es un alias de `-p linux stdbuf`.

- Ver documentación para el comando original:

`tldr -p linux stdbuf`
