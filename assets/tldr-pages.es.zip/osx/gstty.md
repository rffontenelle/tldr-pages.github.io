# gstty

> Este comando es un alias de `-p linux stty`.

- Ver documentación para el comando original:

`tldr -p linux stty`
