# glogger

> Este comando es un alias de `-p linux logger`.

- Muestra la documentación del comando original:

`tldr -p linux logger`
