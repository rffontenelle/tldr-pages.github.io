# gmkfifo

> Este comando es un alias de `-p linux mkfifo`.

- Ver documentación para el comando original:

`tldr -p linux mkfifo`
