# gtty

> Este comando es un alias de `-p linux tty`.

- Ver documentación para el comando original:

`tldr -p linux tty`
