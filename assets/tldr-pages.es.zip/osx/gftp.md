# gftp

> Este comando es un alias de `-p linux ftp`.

- Muestra la documentación del comando original:

`tldr -p linux ftp`
