# gptx

> Este comando es un alias de `-p linux ptx`.

- Ver documentación para el comando original:

`tldr -p linux ptx`
