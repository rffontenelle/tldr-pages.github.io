# gptx

> Este comando es un alias de `-p linux ptx`.

- Muestra la documentación del comando original:

`tldr -p linux ptx`
