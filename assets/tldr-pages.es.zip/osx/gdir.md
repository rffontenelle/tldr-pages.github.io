# gdir

> Este comando es un alias de `-p linux dir`.

- Ver documentación para el comando original:

`tldr -p linux dir`
