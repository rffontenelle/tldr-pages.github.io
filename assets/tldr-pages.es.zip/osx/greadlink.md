# greadlink

> Este comando es un alias de `-p linux readlink`.

- Ver documentación para el comando original:

`tldr -p linux readlink`
