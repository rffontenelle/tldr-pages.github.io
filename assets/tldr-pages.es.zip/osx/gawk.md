# gawk

> Este comando es un alias de `-p linux awk`.

- Muestra la documentación del comando original:

`tldr -p linux awk`
