# apachectl

> Interfaz de control de Apache HTTP Server para macOS.
> Más información: <https://keith.github.io/xcode-man-pages/apachectl.8.html>.

- Inicia la tarea launchd `org.apache.httpd`:

`apachectl start`

- Finaliza la tarea launchd:

`apachectl stop`

- Finaliza e inicia la tarea launchd:

`apachectl restart`
