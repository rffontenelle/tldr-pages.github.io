# gbase64

> Este comando es un alias de `-p linux base64`.

- Ver documentación para el comando original:

`tldr -p linux base64`
