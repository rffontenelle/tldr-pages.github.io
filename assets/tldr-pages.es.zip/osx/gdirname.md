# gdirname

> Este comando es un alias de `-p linux dirname`.

- Ver documentación para el comando original:

`tldr -p linux dirname`
