# webinspectord

> Transmite comandos entre Web Inspector y objetos remotos como WKWebView.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/webinspectord.8.html>.

- Inicia el daemon:

`webinspectord`
