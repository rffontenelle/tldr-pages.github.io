# watchlistd

> Gestiona la lista de seguimiento de la aplicación Apple TV.
> No debe invocarse manualmente.
> Más información: <https://keith.github.io/xcode-man-pages/watchlistd.8.html>.

- Inicia el daemon:

`watchlistd`
