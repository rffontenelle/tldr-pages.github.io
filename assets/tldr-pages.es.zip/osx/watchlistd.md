# watchlistd

> Gestiona la lista de seguimiento de la aplicación Apple TV.
> No debe invocarse manualmente.
> Más información: <https://www.manpagez.com/man/8/watchlistd/>.

- Inicia el daemon:

`watchlistd`
