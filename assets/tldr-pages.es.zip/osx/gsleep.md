# gsleep

> Este comando es un alias de `-p linux sleep`.

- Ver documentación para el comando original:

`tldr -p linux sleep`
