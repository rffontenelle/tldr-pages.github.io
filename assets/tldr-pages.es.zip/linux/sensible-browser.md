# sensible-browser

> Abre el navegador predeterminado.
> Más información: <https://manned.org/sensible-browser>.

- Abre una nueva ventana del navegador predeterminado:

`sensible-browser`

- Abre una URL en el navegador predeterminado:

`sensible-browser {{url}}`
