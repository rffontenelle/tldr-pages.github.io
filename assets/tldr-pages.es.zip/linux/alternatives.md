# alternatives

> Este comando es un alias de `update-alternatives`.
> Más información: <https://manned.org/alternatives>.

- Ver documentación para el comando original:

`tldr update-alternatives`
