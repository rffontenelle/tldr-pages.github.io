# alternatives

> Este comando es un alias de `update-alternatives`.
> Más información: <https://manned.org/alternatives>.

- Muestra la documentación del comando original:

`tldr update-alternatives`
