# halt

> Detiene, apaga o reinicia la máquina.
> Más información: <https://www.man7.org/linux/man-pages/man8/halt.8.html>.

- Detiene la máquina:

`halt`

- Apaga la máquina:

`halt --poweroff`

- Reinicia la máquina:

`halt --reboot`
