# bspwm

> Este comando es un alias de `bspc`.
> Más información: <https://github.com/baskerville/bspwm>.

- Ver documentación para el comando original:

`tldr bspc`
