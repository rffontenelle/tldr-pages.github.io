# bspwm

> Este comando es un alias de `bspc`.
> Más información: <https://github.com/baskerville/bspwm>.

- Muestra la documentación del comando original:

`tldr bspc`
