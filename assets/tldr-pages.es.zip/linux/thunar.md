# thunar

> Administrador de archivos gráficos para entornos de escritorio XFCE.
> Más información: <https://docs.xfce.org/xfce/thunar/start>.

- Abre una nueva ventana mostrando el directorio actual:

`thunar`

- Abra la utilidad de cambio de nombre masivo:

`thunar --bulk-rename`

- Cierra todas las ventanas abiertas de thunar:

`thunar --quit`
