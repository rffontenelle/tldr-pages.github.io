# ip-route-list

> Este comando es un alias de `ip-route-show`.

- Muestra la documentación del comando original:

`tldr ip-route-show`
