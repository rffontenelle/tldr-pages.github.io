# ip-route-list

> Este comando es un alias de `ip-route-show`.

- Ver documentación para el comando original:

`tldr ip-route-show`
