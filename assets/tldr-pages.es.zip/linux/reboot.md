# reboot

> Reinicia la máquina.
> Más información: <https://manned.org/reboot.8>.

- Reinicia inmediatamente:

`reboot`

- Reinicia inmediatamente sin hacer un apagado limpio:

`reboot -f`
