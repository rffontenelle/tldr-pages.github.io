# cacaview

> Muestra una imagen en formato PMN.
> Más información: <https://packages.debian.org/sid/caca-utils>.

- Muestra una imagen:

`cacaview {{ruta/a/imagen}}`
