# xfs_repair

> Repara un sistema de archivos XFS.
> Más información: <https://manned.org/xfs_repair>.

- Repara una partición:

`sudo xfs_repair {{ruta/a/partición}}`
