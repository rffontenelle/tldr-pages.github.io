# ip6tables-save

> Este comando es un alias de `iptables-save`.

- Ver documentación para el comando original:

`tldr iptables-save`
