# mount.smb3

> Este comando es un alias de `mount.cifs`.

- Ver documentación para el comando original:

`tldr mount.cifs`
