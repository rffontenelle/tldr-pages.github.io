# shntool-split

> Este comando es un alias de `shnsplit`.

- Ver documentación para el comando original:

`tldr shnsplit`
