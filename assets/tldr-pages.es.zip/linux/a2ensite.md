# a2ensite

> Habilita un servidor virtual Apache en sistemas operativos basados en Debian.
> Más información: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Habilita un host virtual:

`sudo a2ensite {{host_virtual}}`

- Habilita un host virtual sin mostrar mensajes informativos:

`sudo a2ensite --quiet {{host_virtual}}`
