# groupdel

> Elimina del sistema grupos de usuarios existentes.
> Más información: <https://manned.org/groupdel>.

- Borra un grupo existente:

`sudo groupdel {{nombre_del_grupo}}`
