# line

> Lee una única línea de entrada.
> Más información: <https://manned.org/line.1>.

- Lee una entrada:

`line`
