# cacafire

> Muestra un fuego animado ASCII.
> Más información: <https://packages.debian.org/sid/caca-utils>.

- Muestra el fuego ASCII:

`cacafire`
