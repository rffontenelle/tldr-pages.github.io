# Factorio

> Crea e inicia un servidor Factorio sin interfaz gráfica.
> Más información: <https://wiki.factorio.com/Multiplayer>.

- Crea un nuevo archivo guardado:

`{{ruta/a/factorio}} --create {{ruta/a/archivo_guardado.zip}}`

- Inicia un servidor Factorio:

`{{ruta/a/factorio}} --start-server {{ruta/a/archivo_guardado.zip}}`
