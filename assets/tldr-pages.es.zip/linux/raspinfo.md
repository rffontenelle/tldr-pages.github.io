# raspinfo

> Muestra información del sistema en una Raspberry Pi.
> Más información: <https://github.com/raspberrypi/utils/tree/master/raspinfo>.

- Muestra información del sistema:

`raspinfo`
