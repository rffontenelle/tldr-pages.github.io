# qm-resize

> Este comando es un alias de `qm-disk-resize`.
> Más información: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Ver documentación para el comando original:

`tldr qm-disk-resize`
