# ip6tables

> Este comando es un alias de `iptables`.

- Ver documentación para el comando original:

`tldr iptables`
