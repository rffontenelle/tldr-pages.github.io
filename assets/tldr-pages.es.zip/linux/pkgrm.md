# pkgrm

> Elimina un paquete de un sistema CRUX.
> Más información: <https://docs.oracle.com/cd/E88353_01/html/E72487/pkgrm-8.html>.

- Elimina un paquete instalado:

`pkgrm {{nombre_del_paquete}}`
