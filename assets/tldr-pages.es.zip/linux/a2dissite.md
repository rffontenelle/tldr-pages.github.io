# a2dissite

> Deshabilita un servidor virtual Apache en sistemas operativos basados en Debian.
> Más información: <https://manpages.debian.org/latest/apache2/a2dissite.8.en.html>.

- Deshabilita un host virtual:

`sudo a2dissite {{host_virtual}}`

- No muestra mensajes informativos:

`sudo a2dissite --quiet {{host_virtual}}`
