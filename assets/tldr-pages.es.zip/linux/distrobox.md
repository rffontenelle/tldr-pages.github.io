# distrobox

> Este comando es un alias de `distrobox-create`.
> Más información: <https://github.com/89luca89/distrobox>.

- Ver documentación para el comando original:

`tldr distrobox-create`
