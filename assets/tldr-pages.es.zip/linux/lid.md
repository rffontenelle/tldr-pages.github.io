# lid

> NOTA: Esta página es actualmente una de redirección. Si está familiarizado con este programa, por favor abra una solicitud de extracción.
> Consulta la base de datos de identificadores y reporta los resultados.
> En Fedora y Arch Linux, `lid` es otro programa. Vea `tldr libuser-lid`.
> Más información: <https://www.gnu.org/software/idutils/>.

- Ve documentación de `libuser-lid`:

`tldr libuser-lid`
