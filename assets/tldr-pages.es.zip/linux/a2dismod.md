# a2dismod

> Deshabilita un módulo de Apache en sistemas operativos basados en Debian.
> Más información: <https://manpages.debian.org/latest/apache2/a2dismod.8.en.html>.

- Deshabilita un módulo:

`sudo a2dismod {{módulo}}`

- No muestra mensajes informativos:

`sudo a2dismod --quiet {{módulo}}`
