# torsocks

> Utiliza cualquier aplicación a través de la red de Tor.
> Más información: <https://gitlab.torproject.org/tpo/core/torsocks/>.

- Ejecuta un comando usando Tor:

`torsocks {{comando}}`

- Activa o desactiva Tor en este intérprete de comandos:

`. torsocks {{on|off}}`
