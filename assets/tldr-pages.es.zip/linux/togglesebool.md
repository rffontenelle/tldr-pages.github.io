# togglesebool

> Voltea los valores actuales (no persistentes) de los booleanos de SELinux.
> Nota: Esta herramienta ha quedado obsoleta y a menudo se elimina en favor de `setsebool`.
> Más información: <https://manned.org/man/togglesebool>.

- Cambia los valores actuales (no persistentes) de los booleanos especificados:

`sudo togglesebool {{virt_use_samba virt_use_usb ...}}`
