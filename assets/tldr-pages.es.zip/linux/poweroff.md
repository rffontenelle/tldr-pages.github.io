# poweroff

> Apaga la máquina.
> Más información: <https://www.manned.org/poweroff>.

- Apaga la máquina:

`sudo poweroff`
