# ip6tables-restore

> Este comando es un alias de `iptables-restore`.

- Ver documentación para el comando original:

`tldr iptables-restore`
