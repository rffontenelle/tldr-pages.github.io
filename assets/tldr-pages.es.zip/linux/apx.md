# apx

> Este comando es un alias de `apx pkgmanagers`.
> Más información: <https://github.com/Vanilla-OS/apx>.

- Ver documentación para el comando original:

`tldr apx pkgmanagers`
