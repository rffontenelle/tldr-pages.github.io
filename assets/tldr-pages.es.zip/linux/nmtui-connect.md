# nmtui-connect

> Este comando es un alias de `nmtui`.

- Ver documentación para el comando original:

`tldr nmtui`
