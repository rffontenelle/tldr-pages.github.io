# cc

> Este comando es un alias de `gcc`.
> Más información: <https://gcc.gnu.org>.

- Muestra la documentación del comando original:

`tldr gcc`
