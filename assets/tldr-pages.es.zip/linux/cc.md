# cc

> Este comando es un alias de `gcc`.
> Más información: <https://gcc.gnu.org>.

- Ver documentación para el comando original:

`tldr gcc`
