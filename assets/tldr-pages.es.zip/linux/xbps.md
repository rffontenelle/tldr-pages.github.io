# xbps

> Este comando es un alias de `xbps-install`.
> Más información: <https://docs.voidlinux.org/xbps/index.html>.

- Ver documentación para el comando original:

`tldr xbps-install`
