# qm-importdisk

> Este comando es un alias de `qm disk import`.

- Ver documentación para el comando original:

`tldr qm disk import`
