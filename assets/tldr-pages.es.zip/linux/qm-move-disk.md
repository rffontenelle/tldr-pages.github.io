# qm-move-disk

> Este comando es un alias de `qm-disk-move`.
> Más información: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Ver documentación para el comando original:

`tldr qm-disk-move`
