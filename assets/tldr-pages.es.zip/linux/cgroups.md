# cgroups

> Este comando es un alias de `cgclassify`.
> Más información: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Muestra la documentación del comando original:

`tldr cgclassify`
