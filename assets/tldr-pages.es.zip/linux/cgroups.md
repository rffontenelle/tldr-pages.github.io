# cgroups

> Este comando es un alias de `cgclassify`.
> Más información: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Ver documentación para el comando original:

`tldr cgclassify`
