# repo-remove

> Utilidad de mantenimiento de la base de datos de paquetes que elimina paquetes de un repositorio local.
> Más información: <https://manned.org/repo-add>.

- Elimina un paquete de un repositorio local:

`repo-remove {{ruta/a/base_de_datos.db.tar.gz}} {{paquete}}`
