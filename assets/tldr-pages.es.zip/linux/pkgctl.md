# pkgctl

> Este comando es un alias de `pkgctl auth`.
> Más información: <https://man.archlinux.org/man/pkgctl.1>.

- Ver documentación para el comando original:

`tldr pkgctl auth`
