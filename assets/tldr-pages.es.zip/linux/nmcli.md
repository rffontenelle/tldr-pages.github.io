# nmcli

> Este comando es un alias de `nmcli agent`.
> Más información: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Ver documentación para el comando original:

`tldr nmcli agent`
