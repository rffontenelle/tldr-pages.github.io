# waypipe

> Ejecuta remotamente aplicaciones gráficas bajo un compositor para Wayland.
> Más información: <https://gitlab.freedesktop.org/mstoeckl/waypipe>.

- Ejecuta un programa gráfico remotamente y muestralo localmente:

`waypipe ssh {{usuario}}@{{servidor}} {{programa}}`

- Abre un túnel SSH para ejecutar cualquier programa de forma remota y visualizarlo localmente:

`waypipe ssh {{usuario}}@{{servidor}}`
