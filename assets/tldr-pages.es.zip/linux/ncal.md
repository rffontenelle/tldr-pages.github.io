# ncal

> Este comando es un alias de `cal`.
> Más información: <https://manned.org/ncal>.

- Ver documentación para el comando original:

`tldr cal`
