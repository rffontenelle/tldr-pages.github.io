# pwdx

> Muestra el directorio de trabajo de un proceso.
> Más información: <https://manned.org/pwdx>.

- Muestra el directorio de trabajo actual de un proceso:

`pwdx {{process_id}}`
