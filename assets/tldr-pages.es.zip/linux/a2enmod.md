# a2enmod

> Habilita un módulo de Apache en sistemas operativos basados en Debian.
> Más información: <https://manpages.debian.org/latest/apache2/a2enmod.8.en.html>.

- Habilita un módulo:

`sudo a2enmod {{módulo}}`

- No muestra mensajes informativos:

`sudo a2enmod --quiet {{módulo}}`
