# a2enmod

> Habilita un módulo de Apache en sistemas operativos basados en Debian.
> Más información: <https://manned.org/a2enmod.8>.

- Habilita un módulo:

`sudo a2enmod {{módulo}}`

- Habilita un módulo sin mostrar mensajes informativos:

`sudo a2enmod --quiet {{módulo}}`
