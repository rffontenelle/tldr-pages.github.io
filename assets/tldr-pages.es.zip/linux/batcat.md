# batcat

> Este comando es un alias de `bat`.
> Más información: <https://github.com/sharkdp/bat>.

- Ver documentación para el comando original:

`tldr bat`
