# ubuntu-bug

> Este comando es un alias de `apport-bug`.
> Más información: <https://manned.org/ubuntu-bug>.

- Ver documentación para el comando original:

`tldr apport-bug`
