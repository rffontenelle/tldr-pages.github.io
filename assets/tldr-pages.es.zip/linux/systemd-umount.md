# systemd-umount

> Este comando es un alias de `systemd-mount`.

- Ver documentación para el comando original:

`tldr systemd-mount`
