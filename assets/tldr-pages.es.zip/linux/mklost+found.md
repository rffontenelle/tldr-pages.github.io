# mklost+found

> Crea un directorio lost+found.
> Más información: <https://manned.org/mklost+found>.

- Crea un directorio `lost+found` en el directorio actual:

`mklost+found`
