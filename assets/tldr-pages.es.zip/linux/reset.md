# reset

> Reinicializa la terminal actual. Borra toda la pantalla de la terminal.
> Más información: <https://manned.org/reset>.

- Reinicializa la terminal actual:

`reset`

- Muestra el tipo de terminal:

`reset -q`
