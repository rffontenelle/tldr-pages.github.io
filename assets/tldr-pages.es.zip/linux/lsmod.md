# lsmod

> Muestra el estado de los módulos cargados en el kernel de linux.
> Vease tambien `modprobe`, el cual carga módulos de kernel.
> Más información: <https://manned.org/lsmod>.

- Lista todos los módulos de kernel cargados:

`lsmod`
