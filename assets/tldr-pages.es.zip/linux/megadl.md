# megadl

> Este comando es un alias de `megatools-dl`.
> Más información: <https://megatools.megous.com/man/megatools-dl.html>.

- Ver documentación para el comando original:

`tldr megatools-dl`
