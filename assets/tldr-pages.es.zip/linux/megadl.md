# megadl

> Este comando es un alias de `megatools-dl`.
> Más información: <https://megatools.megous.com/man/megatools-dl.html>.

- Muestra la documentación del comando original:

`tldr megatools-dl`
