# unlzma

> Este comando es un alias de `xz`.
> Más información: <https://manned.org/unlzma>.

- Muestra la documentación del comando original:

`tldr xz`
