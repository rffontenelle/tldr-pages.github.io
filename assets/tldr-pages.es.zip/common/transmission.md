# transmission

> Este comando es un alias de `transmission-daemon`.
> Más información: <https://transmissionbt.com/>.

- Ver documentación para el comando original:

`tldr transmission-daemon`
