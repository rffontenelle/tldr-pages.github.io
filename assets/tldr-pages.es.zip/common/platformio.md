# platformio

> Este comando es un alias de `pio`.
> Más información: <https://docs.platformio.org/en/latest/core/userguide/>.

- Ver documentación para el comando original:

`tldr pio`
