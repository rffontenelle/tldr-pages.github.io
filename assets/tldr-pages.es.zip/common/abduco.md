# abduco

> Administrador de sesión de terminal.
> Más información: <http://www.brain-dump.org/projects/abduco/>.

- Lista sesiones:

`abduco`

- Adjunta a una sesión, creándola si no existe:

`abduco -A {{nombre}} {{bash}}`

- Adjunta a una sesión con `dvtm`, creándola si no existe:

`abduco -A {{nombre}}`

- Separarse de una sesión:

`<Ctrl> + \`

- Adjunta a una sesión en modo solo-lectura:

`abduco -Ar {{nombre}}`
