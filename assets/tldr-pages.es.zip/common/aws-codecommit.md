# aws codecommit

> AWS CodeCommit es un servicio de control de origen administrado que aloja repositorios Git privados.
> Más información: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- Muestra la ayuda para un comando específico:

`aws codecommit {{comando}} help`

- Muestra la ayuda:

`aws codecommit help`
