# todoman

> Este comando es un alias de `todo`.
> Más información: <https://todoman.readthedocs.io/>.

- Muestra la documentación del comando original:

`tldr todo`
