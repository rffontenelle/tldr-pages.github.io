# todoman

> Este comando es un alias de `todo`.
> Más información: <https://todoman.readthedocs.io/>.

- Ver documentación para el comando original:

`tldr todo`
