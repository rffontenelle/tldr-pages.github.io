# pgmslice

> Este comando ha sido sustituido por `pamslice`.
> Más información: <https://netpbm.sourceforge.net/doc/pgmslice.html>.

- Vea documentación para el comando actual:

`tldr pamslice`
