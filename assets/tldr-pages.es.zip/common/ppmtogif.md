# ppmtogif

> Este comando ha sido sustituido por `pamtogif`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmtogif.html>.

- Vea documentación para el comando actual:

`tldr pamtogif`
