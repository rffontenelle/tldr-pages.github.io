# showfigfonts

> Muestra una lista de fuentes disponibles para figlet.
> Véase también `figlet`.
> Más información: <https://manned.org/showfigfonts>.

- Muestra las fuentes disponibles:

`showfigfonts`

- Muestra las fuentes disponibles usando un texto específico:

`showfigfonts {{texto_de_entrada}}`
