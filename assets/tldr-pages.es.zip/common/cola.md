# cola

> Este comando es un alias de `git-cola`.

- Ver documentación para el comando original:

`tldr git-cola`
