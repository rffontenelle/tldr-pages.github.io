# cola

> Este comando es un alias de `git-cola`.

- Muestra la documentación del comando original:

`tldr git-cola`
