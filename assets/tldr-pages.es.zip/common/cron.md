# cron

> Este comando es un alias de `crontab`.

- Muestra la documentación del comando original:

`tldr crontab`
