# cron

> Este comando es un alias de `crontab`.

- Ver documentación para el comando original:

`tldr crontab`
