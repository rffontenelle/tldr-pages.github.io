# aria2

> Este comando es un alias de `aria2c`.

- Muestra documentación para el comando actualizado:

`tldr aria2c`
