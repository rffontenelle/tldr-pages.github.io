# aria2

> Este comando es un alias de `aria2c`.

- Ver documentación para el comando actualizado:

`tldr aria2c`
