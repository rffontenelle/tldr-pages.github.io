# ppmnorm

> Este comando es reemplazado por `pnmnorm`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmnorm.html>.

- Muestra la documentación del comando actual:

`tldr pnmnorm`
