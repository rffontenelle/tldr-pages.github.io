# lzcmp

> Este comando es un alias de `xzcmp`.

- Ver documentación para el comando original:

`tldr xzcmp`
