# calc

> Una calculadora de precisión arbitraria en la terminal.
> Más información: <https://github.com/lcn2/calc>.

- Iniciar calc en modo interactivo:

`calc`

- Realizar un cálculo en modo no-interactivo:

`calc -p '{{85 * (36 / 4)}}'`
