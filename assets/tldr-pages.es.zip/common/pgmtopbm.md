# pgmtopbm

> Este comando ha sido sustituido por `pamditherbw`.
> Más información: <https://netpbm.sourceforge.net/doc/pgmtopbm.html>.

- Vea documentación del comando actual:

`tldr pamditherbw`
