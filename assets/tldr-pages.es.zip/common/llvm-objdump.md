# llvm-objdump

> Este comando es un alias de `objdump`.

- Muestra la documentación del comando original:

`tldr objdump`
