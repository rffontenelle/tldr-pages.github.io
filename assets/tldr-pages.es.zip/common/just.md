# just

> Este comando es un alias de `just.1`.

- Ver documentación para el comando original:

`tldr just.1`
