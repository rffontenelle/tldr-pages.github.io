# hx

> Este comando es un alias de `helix`.

- Ver documentación para el comando original:

`tldr helix`
