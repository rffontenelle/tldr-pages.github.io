# fossil-forget

> Este comando es un alias de `fossil rm`.
> Más información: <https://fossil-scm.org/home/help/forget>.

- Ver documentación para el comando original:

`tldr fossil rm`
