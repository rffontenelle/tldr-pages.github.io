# fossil forget

> Este comando es un alias de `fossil rm`.
> Más información: <https://fossil-scm.org/home/help/forget>.

- Muestra la documentación del comando original:

`tldr fossil rm`
