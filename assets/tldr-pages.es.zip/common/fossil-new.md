# fossil-new

> Este comando es un alias de `fossil-init`.
> Más información: <https://fossil-scm.org/home/help/new>.

- Ver documentación para el comando original:

`tldr fossil-init`
