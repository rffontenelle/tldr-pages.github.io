# azure-cli

> Este comando es un alias de `az`.
> Más información: <https://learn.microsoft.com/cli/azure>.

- Ver documentación para el comando original:

`tldr az`
