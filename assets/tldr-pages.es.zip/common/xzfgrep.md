# xzfgrep

> Este comando es un alias de `xzgrep`.

- Ver documentación para el comando original:

`tldr xzgrep`
