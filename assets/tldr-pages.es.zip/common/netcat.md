# netcat

> Este comando es un alias de `nc`.

- Ver documentación para el comando original:

`tldr nc`
