# kafkacat

> Este comando es un alias de `kcat`.

- Ver documentación para el comando original:

`tldr kcat`
