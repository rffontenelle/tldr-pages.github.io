# tldrl

> Este comando es un alias de `tldr-lint`.
> Más información: <https://github.com/tldr-pages/tldr-lint>.

- Ver documentación para el comando original:

`tldr tldr-lint`
