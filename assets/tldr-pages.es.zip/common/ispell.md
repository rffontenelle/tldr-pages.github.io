# ispell

> Corrección ortográfica interactiva.
> Más información: <https://www.cs.hmc.edu/~geoff/ispell-man.html>.

- Inicia una sesión interactiva:

`ispell`

- Comprueba si hay erratas en el archivo especificado y aplica sugerencias de forma interactiva:

`ispell {{ruta/al/archivo}}`

- Muestra la versión:

`ispell -v`
