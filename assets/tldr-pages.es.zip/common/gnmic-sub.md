# gnmic sub

> Este comando es un alias de `gnmic subscribe`.
> Más información: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Muestra la documentación del comando original:

`tldr gnmic subscribe`
