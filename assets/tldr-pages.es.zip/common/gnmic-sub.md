# gnmic-sub

> Este comando es un alias de `gnmic subscribe`.
> Más información: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Ver documentación para el comando original:

`tldr gnmic subscribe`
