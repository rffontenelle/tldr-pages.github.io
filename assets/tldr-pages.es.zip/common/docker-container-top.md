# docker-container-top

> Este comando es un alias de `docker top`.
> Más información: <https://docs.docker.com/engine/reference/commandline/top>.

- Ver documentación para el comando original:

`tldr docker top`
