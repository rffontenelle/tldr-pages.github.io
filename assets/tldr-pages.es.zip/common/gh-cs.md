# gh cs

> Este comando es un alias de `gh codespace`.
> Más información: <https://cli.github.com/manual/gh_codespace>.

- Muestra la documentación del comando original:

`tldr gh-codespace`
