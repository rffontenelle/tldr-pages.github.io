# gh-cs

> Este comando es un alias de `gh-codespace`.
> Más información: <https://cli.github.com/manual/gh_codespace>.

- Ver documentación para el comando original:

`tldr gh-codespace`
