# ptpython3

> Este comando es un alias de `ptpython`.

- Ver documentación para el comando original:

`tldr ptpython`
