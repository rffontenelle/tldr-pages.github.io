# ntl

> Este comando es un alias de `netlify`.
> Más información: <https://cli.netlify.com>.

- Ver documentación para el comando original:

`tldr netlify`
