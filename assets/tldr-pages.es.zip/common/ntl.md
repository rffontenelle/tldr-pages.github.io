# ntl

> Este comando es un alias de `netlify`.
> Más información: <https://cli.netlify.com>.

- Muestra la documentación del comando original:

`tldr netlify`
