# pnminterp

> Este comando ha sido sustituido por `pamstretch`.
> Más información: <https://netpbm.sourceforge.net/doc/pnminterp.html>.

- Ve documentación del comando actual:

`tldr pamstretch`
