# bundler

> Este comando es un alias de `bundle`.
> Más información: <https://bundler.io/man/bundle.1.html>.

- Ver documentación para el comando original:

`tldr bundle`
