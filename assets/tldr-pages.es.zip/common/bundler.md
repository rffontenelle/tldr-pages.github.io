# bundler

> Este comando es un alias de `bundle`.
> Más información: <https://bundler.io/man/bundle.1.html>.

- Muestra la documentación del comando original:

`tldr bundle`
