# mscore

> Este comando es un alias de `musescore`.
> Más información: <https://musescore.org/handbook/command-line-options>.

- Ver documentación para el comando original:

`tldr musescore`
