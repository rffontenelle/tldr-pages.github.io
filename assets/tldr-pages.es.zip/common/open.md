# open

> Este comando es un alias de `open -p osx`.

- Ver documentación para el comando original:

`tldr open -p osx`
