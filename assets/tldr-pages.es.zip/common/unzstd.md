# unzstd

> Este comando es un alias de `zstd`.

- Ver documentación para el comando original:

`tldr zstd`
