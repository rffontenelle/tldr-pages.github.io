# llvm-ar

> Este comando es un alias de `ar`.

- Muestra la documentación del comando original:

`tldr ar`
