# ppmtouil

> Este comando ha sido sustituido por `pamtouil`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmtouil.html>.

- Consulte la documentación del comando actual:

`tldr pamtouil`
