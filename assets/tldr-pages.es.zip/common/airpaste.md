# airpaste

> Comparte mesages y archivos sobre la misma red usando mDNS.
> Más información: <https://github.com/mafintosh/airpaste>.

- Espera un mensaje y lo muestra cuando se reciba:

`airpaste`

- Envía un texto:

`echo {{texto}} | airpaste`

- Envía un archivo:

`airpaste < {{ruta/al/archivo}}`

- Recibe un archivo:

`airpaste > {{ruta/al/archivo}}`

- Crea un canal o se une al mismo:

`airpaste {{nombre_canal}}`
