# docker-container-diff

> Este comando es un alias de `docker diff`.
> Más información: <https://docs.docker.com/engine/reference/commandline/diff>.

- Ver documentación para el comando original:

`tldr docker diff`
