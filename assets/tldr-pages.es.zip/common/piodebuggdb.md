# piodebuggdb

> Este comando es un alias de `pio debug`.

- Muestra la documentación del comando original:

`tldr pio debug`
