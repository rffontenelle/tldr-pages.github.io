# clamav

> Este comando es un alias de `clamdscan`.
> Más información: <https://www.clamav.net>.

- Ver documentación para el comando original:

`tldr clamdscan`
