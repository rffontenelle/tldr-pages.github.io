# hping

> Este comando es un alias de `hping3`.
> Más información: <https://github.com/antirez/hping>.

- Ver documentación para el comando original:

`tldr hping3`
