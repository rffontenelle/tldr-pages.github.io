# python3

> Este comando es un alias de `python`.

- Muestra la documentación del comando original:

`tldr python`
