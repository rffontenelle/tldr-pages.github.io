# python3

> Este comando es un alias de `python`.

- Ver documentación para el comando original:

`tldr python`
