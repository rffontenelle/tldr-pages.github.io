# lima

> Este comando es un alias de `limactl`.
> Más información: <https://github.com/lima-vm/lima>.

- Ver documentación para el comando original:

`tldr limactl`
