# llvm-strings

> Este comando es un alias de `strings`.

- Muestra la documentación del comando original:

`tldr strings`
