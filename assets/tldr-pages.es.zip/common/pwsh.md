# pwsh

> Este comando es un alias de `powershell`.

- Ver documentación para el comando original:

`tldr powershell`
