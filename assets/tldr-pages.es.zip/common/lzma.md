# lzma

> Este comando es un alias de `xz`.
> Más información: <https://manned.org/lzma>.

- Ver documentación para el comando original:

`tldr xz`
