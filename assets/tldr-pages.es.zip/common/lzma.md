# lzma

> Este comando es un alias de `xz`.
> Más información: <https://manned.org/lzma>.

- Muestra la documentación del comando original:

`tldr xz`
