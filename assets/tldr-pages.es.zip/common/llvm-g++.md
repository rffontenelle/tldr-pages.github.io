# llvm-g++

> Este comando es un alias de `clang++`.

- Muestra la documentación del comando original:

`tldr clang++`
