# clojure

> Este comando es un alias de `clj`.

- Muestra la documentación del comando original:

`tldr clj`
