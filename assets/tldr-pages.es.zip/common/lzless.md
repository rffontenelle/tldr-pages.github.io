# lzless

> Este comando es un alias de `xzless`.

- Ver documentación para el comando original:

`tldr xzless`
