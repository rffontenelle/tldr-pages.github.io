# musl-gcc

> Este comando es un alias de `gcc`.
> Más información: <https://manned.org/musl-gcc>.

- Ver documentación para el comando original:

`tldr gcc`
