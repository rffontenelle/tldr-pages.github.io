# frp

> Fast Reverse Proxy: configura rápidamente túneles de red para exponer determinados servicios a Internet o a otras redes externas.
> Más información: <https://github.com/fatedier/frp>.

- Vea documentación de `frpc`, el componente cliente `frp`:

`tldr frpc`

- Vea documentación de `frps`, el componente servidor `frp`:

`tldr frps`
