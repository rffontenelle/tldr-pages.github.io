# pcdindex

> Este comando ha sido renombrado a `pcdovtoppm`.
> Más información: <https://netpbm.sourceforge.net/doc/pcdindex.html>.

- Consulta la documentación del comando con su nombre actual:

`tldr pcdovtoppm`
