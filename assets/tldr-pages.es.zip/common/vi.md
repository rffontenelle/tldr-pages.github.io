# vi

> Este comando es un alias de `vim`.

- Muestra la documentación del comando original:

`tldr vim`
