# rcat

> Este comando es un alias de `rc`.

- Ver documentación para el comando original:

`tldr rc`
