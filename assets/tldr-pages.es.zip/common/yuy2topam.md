# yuy2topam

> Convierte bytes YUY2 a PAM.
> Más información: <https://netpbm.sourceforge.net/doc/yuy2topam.html>.

- Convierte bytes YUY2 a PAM:

`yuy2topam -width {{valor}} -height {{valor}} {{ruta/al/archivo.yuy2}} > {{ruta/al/archivo.pam}}`
