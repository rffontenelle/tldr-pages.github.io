# llvm-nm

> Este comando es un alias de `nm`.

- Ver documentación para el comando original:

`tldr nm`
