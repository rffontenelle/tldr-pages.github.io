# anki

> Potente e inteligente programa de flashcards.
> Más información: <https://docs.ankiweb.net>.

- Inicia `anki`:

`anki`

- Inicia `anki` con un perfil específico:

`anki -p {{nombre_perfil}}`

- Inicia `anki` en un idioma específico:

`anki -l {{idioma}}`

- Inicia `anki` desde un directorio específico en lugar del predeterminado (`~/Anki`):

`anki -b {{ruta/al/directorio}}`
