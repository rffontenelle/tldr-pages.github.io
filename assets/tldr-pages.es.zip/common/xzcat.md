# xzcat

> Este comando es un alias de `xz`.
> Más información: <https://manned.org/xzcat>.

- Ver documentación para el comando original:

`tldr xz`
