# btop

> Un monitor de recursos que muestra información sobra la CPU, memoria, discos, red y procesos.
> Versión en C++ de `bpytop`.
> Más información: <https://github.com/aristocratos/btop>.

- Inicia `btop`:

`btop`

- Inicia `btop` con una configuración preestablecida:

`btop --preset {{0..9}}`
