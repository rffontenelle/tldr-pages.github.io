# pio-init

> Este comando es un alias de `pio project`.

- Muestra la documentación del comando original:

`tldr pio project`
