# docker-container-remove

> Este comando es un alias de `docker rm`.
> Más información: <https://docs.docker.com/engine/reference/commandline/rm>.

- Ver documentación para el comando original:

`tldr docker rm`
