# ppmtomap

> Este comando ha sido sustituido por `pnmcolormap`.
> Más información: <https://netpbm.sourceforge.net/doc/ppmtomap.html>.

- Vea documentación del comando actual:

`tldr pnmcolormap`
