# tlmgr-arch

> Este comando es un alias de `tlmgr platform`.
> Más información: <https://www.tug.org/texlive/tlmgr.html>.

- Ver documentación para el comando original:

`tldr tlmgr platform`
