# tlmgr-arch

> Este comando es un alias de `tlmgr platform`.
> Más información: <https://www.tug.org/texlive/tlmgr.html>.

- Muestra la documentación del comando original:

`tldr tlmgr platform`
