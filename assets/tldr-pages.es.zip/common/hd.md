# hd

> Este comando es un alias de `hexdump`.
> Más información: <https://manned.org/hd.1>.

- Ver documentación para el comando original:

`tldr hexdump`
