# linode-cli

> Este comando es un alias de `linode-cli account`.
> Más información: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Ver documentación para el comando original:

`tldr linode-cli account`
