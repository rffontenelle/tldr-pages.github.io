# apm

> Editor Atom Package Manager.
> Ver `atom`.
> Más información: <https://github.com/atom/apm>.

- Instala un paquete de http://atom.io/packages o un tema de http://atom.io/themes:

`apm install {{nombre_de_paquete}}`

- Elimina un paquete/tema:

`apm remove {{nombre_de_paquete}}`

- Actualiza un paquete/tema:

`apm upgrade {{nombre_de_paquete}}`
