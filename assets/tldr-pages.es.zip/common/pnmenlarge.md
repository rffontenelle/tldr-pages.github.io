# pnmenlarge

> Este comando ha sido sustituido por `pamenlarge`.
> Más información: <https://netpbm.sourceforge.net/doc/pnmenlarge.html>.

- Vea documentación del comando actual:

`tldr pamenlarge`
