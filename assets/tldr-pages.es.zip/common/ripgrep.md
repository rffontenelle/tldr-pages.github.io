# ripgrep

> Este comando es un alias de `rg`.

- Ver documentación para el comando original:

`tldr rg`
