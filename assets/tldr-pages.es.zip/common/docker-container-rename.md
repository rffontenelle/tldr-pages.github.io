# docker-container-rename

> Este comando es un alias de `docker rename`.
> Más información: <https://docs.docker.com/engine/reference/commandline/rename>.

- Ver documentación para el comando original:

`tldr docker rename`
