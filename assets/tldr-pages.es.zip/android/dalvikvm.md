# dalvikvm

> Máquina virtual Java en Android.
> Más información: <https://source.android.com/devices/tech/dalvik>.

- Inicia un programa Java:

`dalvikvm -classpath {{ruta/al/archivo.jar}} {{classname}}`
