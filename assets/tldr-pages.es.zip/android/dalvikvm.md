# dalvikvm

> Máquina virtual Java en Android.
> Más información: <https://source.android.com/docs/core/runtime>.

- Inicia un programa Java:

`dalvikvm -classpath {{ruta/al/archivo.jar}} {{classname}}`
