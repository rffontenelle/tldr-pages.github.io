# screencap

> Toma una captura de pantalla de una pantalla móvil.
> Este comando solo se puede usar a través de `adb shell`.
> Más información: <https://developer.android.com/studio/command-line/adb#screencap>.

- Toma una captura de pantalla:

`screencap {{ruta/al/archivo}}`
