# pkg

> このコマンドは `pkg_add` のエイリアスです。
> 詳しくはこちら: <https://www.openbsd.org/faq/faq15.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr pkg_add`
