# gnl

> このコマンドは `-p linux nl` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux nl`
