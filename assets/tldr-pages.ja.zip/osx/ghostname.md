# ghostname

> このコマンドは `-p linux hostname` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux hostname`
