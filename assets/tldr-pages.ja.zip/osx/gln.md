# gln

> このコマンドは `-p linux ln` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ln`
