# gdnsdomainname

> このコマンドは `-p linux dnsdomainname` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux dnsdomainname`
