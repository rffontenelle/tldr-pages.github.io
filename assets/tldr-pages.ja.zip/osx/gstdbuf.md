# gstdbuf

> このコマンドは `-p linux stdbuf` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux stdbuf`
