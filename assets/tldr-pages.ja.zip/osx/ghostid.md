# ghostid

> このコマンドは `-p linux hostid` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux hostid`
