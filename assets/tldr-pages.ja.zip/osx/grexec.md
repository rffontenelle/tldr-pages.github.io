# grexec

> このコマンドは `-p linux rexec` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux rexec`
