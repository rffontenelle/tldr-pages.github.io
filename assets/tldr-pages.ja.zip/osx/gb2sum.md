# gb2sum

> このコマンドは `-p linux b2sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux b2sum`
