# gnohup

> このコマンドは `-p linux nohup` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux nohup`
