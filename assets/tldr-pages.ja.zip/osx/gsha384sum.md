# gsha384sum

> このコマンドは `-p linux sha384sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sha384sum`
