# grlogin

> このコマンドは `-p linux rlogin` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux rlogin`
