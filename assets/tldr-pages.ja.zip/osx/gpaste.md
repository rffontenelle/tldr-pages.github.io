# gpaste

> このコマンドは `-p linux paste` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux paste`
