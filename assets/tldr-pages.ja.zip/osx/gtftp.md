# gtftp

> このコマンドは `-p linux tftp` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tftp`
