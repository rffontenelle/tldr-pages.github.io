# gid

> このコマンドは `-p linux id` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux id`
