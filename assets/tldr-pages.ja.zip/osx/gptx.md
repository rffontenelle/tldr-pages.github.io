# gptx

> このコマンドは `-p linux ptx` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ptx`
