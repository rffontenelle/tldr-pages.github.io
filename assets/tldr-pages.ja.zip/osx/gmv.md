# gmv

> このコマンドは `-p linux mv` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux mv`
