# gtruncate

> このコマンドは `-p linux truncate` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux truncate`
