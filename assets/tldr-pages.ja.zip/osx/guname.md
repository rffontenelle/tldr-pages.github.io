# guname

> このコマンドは `-p linux uname` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux uname`
