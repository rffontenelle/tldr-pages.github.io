# gusers

> このコマンドは `-p linux users` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux users`
