# grm

> このコマンドは `-p linux rm` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux rm`
