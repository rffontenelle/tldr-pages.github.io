# gdirname

> このコマンドは `-p linux dirname` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux dirname`
