# greadlink

> このコマンドは `-p linux readlink` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux readlink`
