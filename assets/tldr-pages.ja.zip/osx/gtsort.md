# gtsort

> このコマンドは `-p linux tsort` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tsort`
