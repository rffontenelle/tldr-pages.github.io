# gcp

> このコマンドは `-p linux cp` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux cp`
