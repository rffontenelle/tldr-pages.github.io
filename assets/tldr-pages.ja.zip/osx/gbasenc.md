# gbasenc

> このコマンドは `-p linux basenc` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux basenc`
