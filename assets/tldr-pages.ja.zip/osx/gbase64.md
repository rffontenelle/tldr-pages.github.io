# gbase64

> このコマンドは `-p linux base64` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux base64`
