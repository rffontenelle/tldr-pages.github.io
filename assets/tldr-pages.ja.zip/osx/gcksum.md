# gcksum

> このコマンドは `-p linux cksum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux cksum`
