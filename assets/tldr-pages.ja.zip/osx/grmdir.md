# grmdir

> このコマンドは `-p linux rmdir` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux rmdir`
