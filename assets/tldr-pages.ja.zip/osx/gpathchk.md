# gpathchk

> このコマンドは `-p linux pathchk` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux pathchk`
