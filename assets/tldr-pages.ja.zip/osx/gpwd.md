# gpwd

> このコマンドは `-p linux pwd` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux pwd`
