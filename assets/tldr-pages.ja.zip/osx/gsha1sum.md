# gsha1sum

> このコマンドは `-p linux sha1sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sha1sum`
