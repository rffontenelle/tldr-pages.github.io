# gunexpand

> このコマンドは `-p linux unexpand` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux unexpand`
