# gseq

> このコマンドは `-p linux seq` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux seq`
