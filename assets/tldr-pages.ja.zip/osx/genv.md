# genv

> このコマンドは `-p linux env` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux env`
