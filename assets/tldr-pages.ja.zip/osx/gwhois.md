# gwhois

> このコマンドは `-p linux whois` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux whois`
