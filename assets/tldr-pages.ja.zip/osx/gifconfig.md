# gifconfig

> このコマンドは `-p linux ifconfig` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ifconfig`
