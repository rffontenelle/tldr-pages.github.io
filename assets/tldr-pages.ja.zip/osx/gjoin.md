# gjoin

> このコマンドは `-p linux join` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux join`
