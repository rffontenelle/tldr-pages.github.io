# gbase32

> このコマンドは `-p linux base32` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux base32`
