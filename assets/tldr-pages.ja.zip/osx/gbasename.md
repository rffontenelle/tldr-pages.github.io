# gbasename

> このコマンドは `-p linux basename` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux basename`
