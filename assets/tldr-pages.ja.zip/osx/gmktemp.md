# gmktemp

> このコマンドは `-p linux mktemp` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux mktemp`
