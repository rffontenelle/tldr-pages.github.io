# gsleep

> このコマンドは `-p linux sleep` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sleep`
