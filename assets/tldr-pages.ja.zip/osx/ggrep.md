# ggrep

> このコマンドは `-p linux grep` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux grep`
