# gchmod

> このコマンドは `-p linux chmod` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux chmod`
