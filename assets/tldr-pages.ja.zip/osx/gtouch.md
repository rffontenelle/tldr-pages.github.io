# gtouch

> このコマンドは `-p linux touch` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux touch`
