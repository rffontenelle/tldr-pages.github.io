# gtee

> このコマンドは `-p linux tee` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tee`
