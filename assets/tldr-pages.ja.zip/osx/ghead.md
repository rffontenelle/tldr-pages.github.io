# ghead

> このコマンドは `-p linux head` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux head`
