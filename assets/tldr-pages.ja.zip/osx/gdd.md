# gdd

> このコマンドは `-p linux dd` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux dd`
