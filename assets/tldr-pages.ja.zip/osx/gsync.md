# gsync

> このコマンドは `-p linux sync` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sync`
