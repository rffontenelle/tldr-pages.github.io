# gruncon

> このコマンドは `-p linux runcon` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux runcon`
