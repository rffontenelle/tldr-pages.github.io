# gsplit

> このコマンドは `-p linux split` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux split`
