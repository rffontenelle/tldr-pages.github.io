# gfgrep

> このコマンドは `-p linux fgrep` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux fgrep`
