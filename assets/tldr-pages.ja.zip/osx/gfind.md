# gfind

> このコマンドは `-p linux find` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux find`
