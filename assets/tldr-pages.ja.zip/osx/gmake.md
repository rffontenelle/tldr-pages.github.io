# gmake

> このコマンドは `-p linux make` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux make`
