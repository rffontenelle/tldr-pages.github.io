# gshuf

> このコマンドは `-p linux shuf` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux shuf`
