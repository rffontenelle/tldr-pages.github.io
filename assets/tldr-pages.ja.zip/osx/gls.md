# gls

> このコマンドは `-p linux ls` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ls`
