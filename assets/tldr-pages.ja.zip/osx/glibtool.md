# glibtool

> このコマンドは `-p linux libtool` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux libtool`
