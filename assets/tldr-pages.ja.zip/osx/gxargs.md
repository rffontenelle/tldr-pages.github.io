# gxargs

> このコマンドは `-p linux xargs` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux xargs`
