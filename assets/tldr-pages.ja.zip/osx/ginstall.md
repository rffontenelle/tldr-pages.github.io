# ginstall

> このコマンドは `-p linux install` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux install`
