# gfmt

> このコマンドは `-p linux fmt` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux fmt`
