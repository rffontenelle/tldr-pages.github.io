# gchcon

> このコマンドは `-p linux chcon` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux chcon`
