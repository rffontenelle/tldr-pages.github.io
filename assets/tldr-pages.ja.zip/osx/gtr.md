# gtr

> このコマンドは `-p linux tr` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tr`
