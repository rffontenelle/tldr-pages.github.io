# gmkfifo

> このコマンドは `-p linux mkfifo` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux mkfifo`
