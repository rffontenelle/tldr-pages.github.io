# gtest

> このコマンドは `-p linux test` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux test`
