# gping

> このコマンドは `-p linux ping` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ping`
