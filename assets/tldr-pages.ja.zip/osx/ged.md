# ged

> このコマンドは `-p linux ed` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ed`
