# glogname

> このコマンドは `-p linux logname` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux logname`
