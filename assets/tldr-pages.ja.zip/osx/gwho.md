# gwho

> このコマンドは `-p linux who` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux who`
