# gkill

> このコマンドは `-p linux kill` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux kill`
