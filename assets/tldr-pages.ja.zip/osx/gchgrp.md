# gchgrp

> このコマンドは `-p linux chgrp` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux chgrp`
