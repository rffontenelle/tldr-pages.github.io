# gunits

> このコマンドは `-p linux units` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux units`
