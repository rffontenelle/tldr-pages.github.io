# gupdatedb

> このコマンドは `-p linux updatedb` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux updatedb`
