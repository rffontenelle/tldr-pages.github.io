# gtalk

> このコマンドは `-p linux talk` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux talk`
