# gsort

> このコマンドは `-p linux sort` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sort`
