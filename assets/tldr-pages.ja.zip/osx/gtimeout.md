# gtimeout

> このコマンドは `-p linux timeout` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux timeout`
