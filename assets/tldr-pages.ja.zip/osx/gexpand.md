# gexpand

> このコマンドは `-p linux expand` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux expand`
