# grealpath

> このコマンドは `-p linux realpath` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux realpath`
