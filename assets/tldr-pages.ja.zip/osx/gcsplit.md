# gcsplit

> このコマンドは `-p linux csplit` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux csplit`
