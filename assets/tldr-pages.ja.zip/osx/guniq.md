# guniq

> このコマンドは `-p linux uniq` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux uniq`
