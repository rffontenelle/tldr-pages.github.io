# gegrep

> このコマンドは `-p linux egrep` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux egrep`
