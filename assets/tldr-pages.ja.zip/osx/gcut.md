# gcut

> このコマンドは `-p linux cut` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux cut`
