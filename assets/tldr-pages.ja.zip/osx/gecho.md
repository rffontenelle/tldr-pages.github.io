# gecho

> このコマンドは `-p linux echo` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux echo`
