# gtelnet

> このコマンドは `-p linux telnet` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux telnet`
