# gtac

> このコマンドは `-p linux tac` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tac`
