# gdir

> このコマンドは `-p linux dir` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux dir`
