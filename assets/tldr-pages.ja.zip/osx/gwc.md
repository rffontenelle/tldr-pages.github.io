# gwc

> このコマンドは `-p linux wc` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux wc`
