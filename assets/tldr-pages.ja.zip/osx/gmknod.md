# gmknod

> このコマンドは `-p linux mknod` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux mknod`
