# gvdir

> このコマンドは `-p linux vdir` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux vdir`
