# gsum

> このコマンドは `-p linux sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sum`
