# gwhich

> このコマンドは `-p linux which` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux which`
