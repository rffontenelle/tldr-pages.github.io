# guptime

> このコマンドは `-p linux uptime` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux uptime`
