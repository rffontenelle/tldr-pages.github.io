# gnice

> このコマンドは `-p linux nice` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux nice`
