# gdircolors

> このコマンドは `-p linux dircolors` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux dircolors`
