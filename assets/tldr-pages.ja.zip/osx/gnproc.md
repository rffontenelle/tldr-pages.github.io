# gnproc

> このコマンドは `-p linux nproc` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux nproc`
