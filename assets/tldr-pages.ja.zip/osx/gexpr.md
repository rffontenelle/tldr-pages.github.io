# gexpr

> このコマンドは `-p linux expr` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux expr`
