# gftp

> このコマンドは `-p linux ftp` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ftp`
