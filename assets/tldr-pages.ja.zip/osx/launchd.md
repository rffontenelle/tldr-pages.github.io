# launchd

> このコマンドは `launchctl` のエイリアスです。
> 詳しくはこちら: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr launchctl`
