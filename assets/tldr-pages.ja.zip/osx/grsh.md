# grsh

> このコマンドは `-p linux rsh` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux rsh`
