# gnumfmt

> このコマンドは `-p linux numfmt` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux numfmt`
