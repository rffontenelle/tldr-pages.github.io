# gping6

> このコマンドは `-p linux ping6` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux ping6`
