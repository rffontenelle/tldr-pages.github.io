# gmd5sum

> このコマンドは `-p linux md5sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux md5sum`
