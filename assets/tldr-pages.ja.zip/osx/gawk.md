# gawk

> このコマンドは `-p linux awk` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux awk`
