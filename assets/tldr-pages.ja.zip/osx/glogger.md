# glogger

> このコマンドは `-p linux logger` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux logger`
