# gprintenv

> このコマンドは `-p linux printenv` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux printenv`
