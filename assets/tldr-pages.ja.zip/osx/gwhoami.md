# gwhoami

> このコマンドは `-p linux whoami` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux whoami`
