# gindent

> このコマンドは `-p linux indent` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux indent`
