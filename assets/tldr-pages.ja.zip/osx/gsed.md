# gsed

> このコマンドは `-p linux sed` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sed`
