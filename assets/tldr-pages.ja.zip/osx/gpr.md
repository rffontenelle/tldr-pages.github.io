# gpr

> このコマンドは `-p linux pr` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux pr`
