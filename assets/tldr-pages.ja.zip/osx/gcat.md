# gcat

> このコマンドは `-p linux cat` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux cat`
