# god

> このコマンドは `-p linux od` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux od`
