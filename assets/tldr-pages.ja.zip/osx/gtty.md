# gtty

> このコマンドは `-p linux tty` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tty`
