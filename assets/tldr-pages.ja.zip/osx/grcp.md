# grcp

> このコマンドは `-p linux rcp` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux rcp`
