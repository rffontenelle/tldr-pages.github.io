# gtail

> このコマンドは `-p linux tail` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tail`
