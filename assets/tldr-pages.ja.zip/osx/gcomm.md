# gcomm

> このコマンドは `-p linux comm` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux comm`
