# gstty

> このコマンドは `-p linux stty` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux stty`
