# gsha224sum

> このコマンドは `-p linux sha224sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sha224sum`
