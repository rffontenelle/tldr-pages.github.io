# gtraceroute

> このコマンドは `-p linux traceroute` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux traceroute`
