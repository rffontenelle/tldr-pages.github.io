# gtime

> このコマンドは `-p linux time` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux time`
