# gstat

> このコマンドは `-p linux stat` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux stat`
