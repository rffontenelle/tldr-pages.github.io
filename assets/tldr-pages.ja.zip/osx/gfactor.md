# gfactor

> このコマンドは `-p linux factor` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux factor`
