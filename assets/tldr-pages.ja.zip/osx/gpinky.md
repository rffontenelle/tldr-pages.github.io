# gpinky

> このコマンドは `-p linux pinky` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux pinky`
