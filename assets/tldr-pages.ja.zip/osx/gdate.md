# gdate

> このコマンドは `-p linux date` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux date`
