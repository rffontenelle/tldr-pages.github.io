# gsha256sum

> このコマンドは `-p linux sha256sum` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux sha256sum`
