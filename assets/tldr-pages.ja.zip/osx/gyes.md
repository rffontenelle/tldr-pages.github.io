# gyes

> このコマンドは `-p linux yes` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux yes`
