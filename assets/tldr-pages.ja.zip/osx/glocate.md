# glocate

> このコマンドは `-p linux locate` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux locate`
