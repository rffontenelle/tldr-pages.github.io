# gchown

> このコマンドは `-p linux chown` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux chown`
