# glibtoolize

> このコマンドは `-p linux libtoolize` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux libtoolize`
