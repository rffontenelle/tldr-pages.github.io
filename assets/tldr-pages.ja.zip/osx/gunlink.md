# gunlink

> このコマンドは `-p linux unlink` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux unlink`
