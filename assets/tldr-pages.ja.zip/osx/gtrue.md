# gtrue

> このコマンドは `-p linux true` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux true`
