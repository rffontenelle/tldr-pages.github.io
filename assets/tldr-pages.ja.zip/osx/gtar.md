# gtar

> このコマンドは `-p linux tar` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux tar`
