# gfalse

> このコマンドは `-p linux false` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux false`
