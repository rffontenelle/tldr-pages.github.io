# glink

> このコマンドは `-p linux link` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux link`
