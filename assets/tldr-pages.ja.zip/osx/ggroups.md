# ggroups

> このコマンドは `-p linux groups` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux groups`
