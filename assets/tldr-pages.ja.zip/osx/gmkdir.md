# gmkdir

> このコマンドは `-p linux mkdir` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux mkdir`
