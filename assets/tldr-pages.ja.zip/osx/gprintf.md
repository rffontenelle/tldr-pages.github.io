# gprintf

> このコマンドは `-p linux printf` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux printf`
