# gfold

> このコマンドは `-p linux fold` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux fold`
