# gchroot

> このコマンドは `-p linux chroot` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux chroot`
