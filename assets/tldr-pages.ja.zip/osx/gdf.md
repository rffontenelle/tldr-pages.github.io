# gdf

> このコマンドは `-p linux df` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr -p linux df`
