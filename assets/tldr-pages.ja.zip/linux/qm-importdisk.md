# qm-importdisk

> このコマンドは `qm disk import` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr qm disk import`
