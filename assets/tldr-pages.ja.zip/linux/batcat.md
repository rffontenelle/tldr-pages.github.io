# batcat

> このコマンドは `bat` のエイリアスです。
> 詳しくはこちら: <https://github.com/sharkdp/bat>

- オリジナルのコマンドのドキュメントを表示する:

`tldr bat`
