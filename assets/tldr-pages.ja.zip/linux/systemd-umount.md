# systemd-umount

> このコマンドは `systemd-mount` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr systemd-mount`
