# cgroups

> このコマンドは `cgclassify` のエイリアスです。
> 詳しくはこちら: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>

- オリジナルのコマンドのドキュメントを表示する:

`tldr cgclassify`
