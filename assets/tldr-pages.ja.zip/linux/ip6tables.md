# ip6tables

> このコマンドは `iptables` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr iptables`
