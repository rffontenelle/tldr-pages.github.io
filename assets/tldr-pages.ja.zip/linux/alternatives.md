# alternatives

> このコマンドは `update-alternatives` のエイリアスです。
> 詳しくはこちら: <https://manned.org/alternatives>

- オリジナルのコマンドのドキュメントを表示する:

`tldr update-alternatives`
