# nmcli

> このコマンドは `nmcli agent` のエイリアスです。
> 詳しくはこちら: <https://networkmanager.dev/docs/api/latest/nmcli.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr nmcli agent`
