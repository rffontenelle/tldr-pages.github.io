# qm-resize

> このコマンドは `qm-disk-resize` のエイリアスです。
> 詳しくはこちら: <https://pve.proxmox.com/pve-docs/qm.1.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr qm-disk-resize`
