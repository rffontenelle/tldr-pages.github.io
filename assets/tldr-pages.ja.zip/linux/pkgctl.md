# pkgctl

> このコマンドは `pkgctl auth` のエイリアスです。
> 詳しくはこちら: <https://man.archlinux.org/man/pkgctl.1>

- オリジナルのコマンドのドキュメントを表示する:

`tldr pkgctl auth`
