# ip6tables-save

> このコマンドは `iptables-save` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr iptables-save`
