# qm-move-disk

> このコマンドは `qm-disk-move` のエイリアスです。
> 詳しくはこちら: <https://pve.proxmox.com/pve-docs/qm.1.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr qm-disk-move`
