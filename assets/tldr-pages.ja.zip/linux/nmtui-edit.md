# nmtui-edit

> このコマンドは `nmtui` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr nmtui`
