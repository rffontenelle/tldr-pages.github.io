# xbps

> このコマンドは `xbps-install` のエイリアスです。
> 詳しくはこちら: <https://docs.voidlinux.org/xbps/index.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr xbps-install`
