# mount.smb3

> このコマンドは `mount.cifs` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr mount.cifs`
