# ncal

> このコマンドは `cal` のエイリアスです。
> 詳しくはこちら: <https://manned.org/ncal>

- オリジナルのコマンドのドキュメントを表示する:

`tldr cal`
