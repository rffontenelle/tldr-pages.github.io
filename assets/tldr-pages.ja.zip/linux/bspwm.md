# bspwm

> このコマンドは `bspc` のエイリアスです。
> 詳しくはこちら: <https://github.com/baskerville/bspwm>

- オリジナルのコマンドのドキュメントを表示する:

`tldr bspc`
