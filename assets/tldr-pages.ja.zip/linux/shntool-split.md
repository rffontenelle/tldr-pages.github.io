# shntool-split

> このコマンドは `shnsplit` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr shnsplit`
