# ubuntu-bug

> このコマンドは `apport-bug` のエイリアスです。
> 詳しくはこちら: <https://manned.org/ubuntu-bug>

- オリジナルのコマンドのドキュメントを表示する:

`tldr apport-bug`
