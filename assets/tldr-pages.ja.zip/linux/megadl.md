# megadl

> このコマンドは `megatools-dl` のエイリアスです。
> 詳しくはこちら: <https://megatools.megous.com/man/megatools-dl.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr megatools-dl`
