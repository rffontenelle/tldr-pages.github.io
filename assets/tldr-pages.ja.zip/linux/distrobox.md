# distrobox

> このコマンドは `distrobox-create` のエイリアスです。
> 詳しくはこちら: <https://github.com/89luca89/distrobox>

- オリジナルのコマンドのドキュメントを表示する:

`tldr distrobox-create`
