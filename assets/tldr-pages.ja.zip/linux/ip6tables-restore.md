# ip6tables-restore

> このコマンドは `iptables-restore` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr iptables-restore`
