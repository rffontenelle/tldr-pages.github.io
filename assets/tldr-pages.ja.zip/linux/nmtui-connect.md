# nmtui-connect

> このコマンドは `nmtui` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr nmtui`
