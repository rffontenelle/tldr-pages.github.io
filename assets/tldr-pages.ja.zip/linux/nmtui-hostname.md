# nmtui-hostname

> このコマンドは `nmtui` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr nmtui`
