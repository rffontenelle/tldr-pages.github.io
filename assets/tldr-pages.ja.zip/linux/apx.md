# apx

> このコマンドは `apx pkgmanagers` のエイリアスです。
> 詳しくはこちら: <https://github.com/Vanilla-OS/apx>

- オリジナルのコマンドのドキュメントを表示する:

`tldr apx pkgmanagers`
