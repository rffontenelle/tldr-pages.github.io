# gal

> このコマンドは `get-alias` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>

- オリジナルのコマンドのドキュメントを表示する:

`tldr get-alias`
