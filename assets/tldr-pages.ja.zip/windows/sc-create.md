# sc-create

> このコマンドは `sc` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>

- オリジナルのコマンドのドキュメントを表示する:

`tldr sc`
