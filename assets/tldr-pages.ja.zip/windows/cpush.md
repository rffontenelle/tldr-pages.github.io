# cpush

> このコマンドは `choco-push` のエイリアスです。
> 詳しくはこちら: <https://docs.chocolatey.org/en-us/create/commands/push>

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco-push`
