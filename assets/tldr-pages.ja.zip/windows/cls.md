# cls

> 画面をクリアします。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>

- 画面をクリアします:

`cls`
