# chdir

> このコマンドは `cd` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>

- オリジナルのコマンドのドキュメントを表示する:

`tldr cd`
