# curl

> このコマンドは `curl -p common` のエイリアスです。
> 詳しくはこちら: <https://curl.se>

- オリジナルのコマンドのドキュメントを表示する:

`tldr curl -p common`
