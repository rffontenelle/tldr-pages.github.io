# pwsh-where

> このコマンドは `Where-Object` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>

- オリジナルのコマンドのドキュメントを表示する:

`tldr Where-Object`
