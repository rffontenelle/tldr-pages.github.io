# clist

> このコマンドは `choco list` のエイリアスです。
> 詳しくはこちら: <https://docs.chocolatey.org/en-us/choco/commands/list>

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco list`
