# sc-config

> このコマンドは `sc` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>

- オリジナルのコマンドのドキュメントを表示する:

`tldr sc`
