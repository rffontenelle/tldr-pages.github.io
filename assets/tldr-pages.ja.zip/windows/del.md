# del

> このコマンドは `remove-item` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>

- オリジナルのコマンドのドキュメントを表示する:

`tldr remove-item`
