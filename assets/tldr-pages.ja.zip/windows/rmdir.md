# rmdir

> このコマンドは `remove-item` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>

- オリジナルのコマンドのドキュメントを表示する:

`tldr remove-item`
