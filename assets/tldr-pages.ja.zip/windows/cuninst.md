# cuninst

> このコマンドは `choco uninstall` のエイリアスです。
> 詳しくはこちら: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco uninstall`
