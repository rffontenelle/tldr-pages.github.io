# wget

> このコマンドは `wget -p common` のエイリアスです。
> 詳しくはこちら: <https://www.gnu.org/software/wget>

- オリジナルのコマンドのドキュメントを表示する:

`tldr wget -p common`
