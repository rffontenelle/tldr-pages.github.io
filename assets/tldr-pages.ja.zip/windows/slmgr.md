# slmgr

> このコマンドは `slmgr.vbs` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>

- オリジナルのコマンドのドキュメントを表示する:

`tldr slmgr.vbs`
