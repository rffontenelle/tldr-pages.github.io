# sc-query

> このコマンドは `sc` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>

- オリジナルのコマンドのドキュメントを表示する:

`tldr sc`
