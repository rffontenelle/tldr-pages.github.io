# rd

> このコマンドは `rmdir` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>

- オリジナルのコマンドのドキュメントを表示する:

`tldr rmdir`
