# ri

> このコマンドは `remove-item` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>

- オリジナルのコマンドのドキュメントを表示する:

`tldr remove-item`
