# clear

> このコマンドは `clear-host` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr clear-host`
