# sl

> このコマンドは `set-location` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>

- オリジナルのコマンドのドキュメントを表示する:

`tldr set-location`
