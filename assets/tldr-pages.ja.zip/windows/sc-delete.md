# sc-delete

> このコマンドは `sc` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>

- オリジナルのコマンドのドキュメントを表示する:

`tldr sc`
