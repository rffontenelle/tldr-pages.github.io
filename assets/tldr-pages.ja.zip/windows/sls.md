# sls

> このコマンドは `Select-String` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>

- オリジナルのコマンドのドキュメントを表示する:

`tldr select-string`
