# sls

> このコマンドは `where-object` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>

- オリジナルのコマンドのドキュメントを表示する:

`tldr where-object`
