# attrib

> ファイルまたはディレクトリの属性を表示または変更します。
> 詳しくはこちら: <https://learn.microsoft.com/windows-server/administration/windows-commands/attrib>

- 現在のディレクトリ内のファイルの属性を表示します:

`attrib`
