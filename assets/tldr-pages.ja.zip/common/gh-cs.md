# gh-cs

> このコマンドは `gh-codespace` のエイリアスです。
> 詳しくはこちら: <https://cli.github.com/manual/gh_codespace>

- オリジナルのコマンドのドキュメントを表示する:

`tldr gh-codespace`
