# docker-container-rm

> このコマンドは `docker rm` のエイリアスです。
> 詳しくはこちら: <https://docs.docker.com/engine/reference/commandline/rm>

- オリジナルのコマンドのドキュメントを表示する:

`tldr docker rm`
