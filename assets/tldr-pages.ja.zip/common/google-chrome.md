# google-chrome

> このコマンドは `chromium` のエイリアスです。
> 詳しくはこちら: <https://chrome.google.com>

- オリジナルのコマンドのドキュメントを表示する:

`tldr chromium`
