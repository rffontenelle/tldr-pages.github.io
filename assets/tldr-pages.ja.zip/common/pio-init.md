# pio-init

> このコマンドは `pio project` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr pio project`
