# lzless

> このコマンドは `xzless` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr xzless`
