# fossil ci

> このコマンドは  `fossil commit`.のエイリアスです。
> 詳しくはこちら: <https://fossil-scm.org/home/help/commit>

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil-commit`
