# todoman

> このコマンドは `todo` のエイリアスです。
> 詳しくはこちら: <https://todoman.readthedocs.io/>

- オリジナルのコマンドのドキュメントを表示する:

`tldr todo`
