# ntl

> このコマンドは `netlify` のエイリアスです。
> 詳しくはこちら: <https://cli.netlify.com>

- オリジナルのコマンドのドキュメントを表示する:

`tldr netlify`
