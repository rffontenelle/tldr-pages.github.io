# open

> このコマンドは `open -p osx` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr open -p osx`
