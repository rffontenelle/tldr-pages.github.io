# arch

> システムアーキテクチャ名前を示する。
> 'uname' も参照してください。
> 詳しくはこちら: <https://www.gnu.org/software/coreutils/arch>

- システムアーキテクチャを示する:

`arch`
