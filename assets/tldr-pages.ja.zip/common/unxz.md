# unxz

> このコマンドは `xz` のエイリアスです。
> 詳しくはこちら: <https://manned.org/unxz>

- オリジナルのコマンドのドキュメントを表示する:

`tldr xz`
