# lzmore

> このコマンドは `xzmore` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr xzmore`
