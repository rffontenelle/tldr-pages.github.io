# fossil-forget

> このコマンドは `fossil rm` のエイリアスです。
> 詳しくはこちら: <https://fossil-scm.org/home/help/forget>

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil rm`
