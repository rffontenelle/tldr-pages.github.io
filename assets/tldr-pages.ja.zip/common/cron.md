# cron

> このコマンドは `crontab` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr crontab`
