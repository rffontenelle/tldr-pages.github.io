# unlzma

> このコマンドは `xz` のエイリアスです。
> 詳しくはこちら: <https://manned.org/unlzma>

- オリジナルのコマンドのドキュメントを表示する:

`tldr xz`
