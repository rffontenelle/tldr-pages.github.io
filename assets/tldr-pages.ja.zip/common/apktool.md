# apktool

> APK ファイルの解析ツールです。
> 詳しくはこちら: <https://ibotpeaches.github.io/Apktool/>

- APK ファイルのデコード:

`apktool d {{APK ファイルのパス}}`

- 指定したディレクトリから APK ファイルを生成:

`apktool b {{ディレクトリへのパス}}`

- フレームワークをインストールし、保存する:

`apktool if {{フレームワークファイルへのパス}}`
