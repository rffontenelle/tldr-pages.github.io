# lzcat

> このコマンドは `xz` のエイリアスです。
> 詳しくはこちら: <https://manned.org/lzcat>

- オリジナルのコマンドのドキュメントを表示する:

`tldr xz`
