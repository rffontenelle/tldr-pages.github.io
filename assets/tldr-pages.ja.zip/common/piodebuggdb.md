# piodebuggdb

> このコマンドは `pio debug` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr pio debug`
