# docker-container-rename

> このコマンドは `docker rename` のエイリアスです。
> 詳しくはこちら: <https://docs.docker.com/engine/reference/commandline/rename>

- オリジナルのコマンドのドキュメントを表示する:

`tldr docker rename`
