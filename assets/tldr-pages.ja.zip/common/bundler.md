# bundler

> このコマンドは `bundle` のエイリアスです。
> 詳しくはこちら: <https://bundler.io/man/bundle.1.html>

- オリジナルのコマンドのドキュメントを表示する:

`tldr bundle`
