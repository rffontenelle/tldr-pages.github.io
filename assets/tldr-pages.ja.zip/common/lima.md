# lima

> このコマンドは `limactl` のエイリアスです。
> 詳しくはこちら: <https://github.com/lima-vm/lima>

- オリジナルのコマンドのドキュメントを表示する:

`tldr limactl`
