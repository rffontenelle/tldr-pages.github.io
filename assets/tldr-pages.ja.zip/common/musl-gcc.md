# musl-gcc

> このコマンドは `gcc` のエイリアスです。
> 詳しくはこちら: <https://manned.org/musl-gcc>

- オリジナルのコマンドのドキュメントを表示する:

`tldr gcc`
