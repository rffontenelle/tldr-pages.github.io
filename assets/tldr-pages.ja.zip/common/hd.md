# hd

> このコマンドは `hexdump` のエイリアスです。
> 詳しくはこちら: <https://manned.org/hd.1>

- オリジナルのコマンドのドキュメントを表示する:

`tldr hexdump`
