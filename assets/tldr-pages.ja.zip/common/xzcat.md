# xzcat

> このコマンドは `xz` のエイリアスです。
> 詳しくはこちら: <https://manned.org/xzcat>

- オリジナルのコマンドのドキュメントを表示する:

`tldr xz`
