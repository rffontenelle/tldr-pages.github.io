# linode-cli

> このコマンドは `linode-cli account` のエイリアスです。
> 詳しくはこちら: <https://www.linode.com/docs/products/tools/cli/get-started/>

- オリジナルのコマンドのドキュメントを表示する:

`tldr linode-cli account`
