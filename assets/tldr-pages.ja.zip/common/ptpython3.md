# ptpython3

> このコマンドは `ptpython` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr ptpython`
