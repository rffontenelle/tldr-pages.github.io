# azure-cli

> このコマンドは `az` のエイリアスです。
> 詳しくはこちら: <https://learn.microsoft.com/cli/azure>

- オリジナルのコマンドのドキュメントを表示する:

`tldr az`
