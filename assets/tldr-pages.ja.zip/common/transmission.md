# transmission

> このコマンドは `transmission-daemon` のエイリアスです。
> 詳しくはこちら: <https://transmissionbt.com/>

- オリジナルのコマンドのドキュメントを表示する:

`tldr transmission-daemon`
