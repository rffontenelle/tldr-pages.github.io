# gnmic-sub

> このコマンドは `gnmic subscribe` のエイリアスです。
> 詳しくはこちら: <https://gnmic.kmrd.dev/cmd/subscribe>

- オリジナルのコマンドのドキュメントを表示する:

`tldr gnmic subscribe`
