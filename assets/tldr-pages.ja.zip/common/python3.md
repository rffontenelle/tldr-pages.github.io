# python3

> このコマンドは `python` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr python`
