# lzegrep

> このコマンドは `xzgrep` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr xzgrep`
