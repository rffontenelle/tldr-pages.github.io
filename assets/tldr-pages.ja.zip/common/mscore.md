# mscore

> このコマンドは `musescore` のエイリアスです。
> 詳しくはこちら: <https://musescore.org/handbook/command-line-options>

- オリジナルのコマンドのドキュメントを表示する:

`tldr musescore`
