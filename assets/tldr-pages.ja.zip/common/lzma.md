# lzma

> このコマンドは `xz` のエイリアスです。
> 詳しくはこちら: <https://manned.org/lzma>

- オリジナルのコマンドのドキュメントを表示する:

`tldr xz`
