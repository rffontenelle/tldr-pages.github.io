# pwsh

> このコマンドは `powershell` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr powershell`
