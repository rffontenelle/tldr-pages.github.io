# wget

> Dit commando is een alias van `wget -p common`.
> Meer informatie: <https://www.gnu.org/software/wget>.

- Bekijk de documentatie van het originele commando:

`tldr wget -p common`
