# gal

> In PowerShell is dit commando een alias van `Get-Alias`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Bekijk de documentatie van het originele commando:

`tldr get-alias`
