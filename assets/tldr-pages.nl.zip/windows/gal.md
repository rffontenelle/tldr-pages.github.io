# gal

> Dit commando is een alias van `get-alias`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Bekijk de documentatie van het originele commando:

`tldr get-alias`
