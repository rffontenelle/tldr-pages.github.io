# pushd

> Plaats een map op de stapel zodat deze later kan worden benaderd.
> Zie ook `popd` om terug te schakelen naar de originele map.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/pushd>.

- Schakel naar een map en zet deze op de stapel:

`pushd {{pad\naar\map}}`
