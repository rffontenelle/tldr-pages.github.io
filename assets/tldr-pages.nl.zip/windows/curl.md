# curl

> Dit commando is een alias van `curl -p common`.
> Meer informatie: <https://curl.se>.

- Bekijk de documentatie van het originele commando:

`tldr curl -p common`
