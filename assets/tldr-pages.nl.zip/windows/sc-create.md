# sc-create

> Dit commando is een alias van `sc.exe create`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Bekijk de documentatie van het originele commando:

`tldr sc`
