# pwsh-where

> Dit commando is een alias van `Where-Object`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Bekijk de documentatie van het originele commando:

`tldr Where-Object`
