# sc-query

> Dit commando is een alias van `sc.exe query`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Bekijk de documentatie van het originele commando:

`tldr sc`
