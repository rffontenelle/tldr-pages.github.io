# cinst

> Dit commando is een alias van `choco install`.
> Meer informatie: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Bekijk de documentatie van het originele commando:

`tldr choco install`
