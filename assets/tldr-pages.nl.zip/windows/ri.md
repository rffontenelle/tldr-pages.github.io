# ri

> Dit commando is een alias van `remove-item`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Bekijk de documentatie van het originele commando:

`tldr remove-item`
