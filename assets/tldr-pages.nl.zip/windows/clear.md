# clear

> Dit commando is een alias van `clear-host`.

- Bekijk de documentatie van het originele commando:

`tldr clear-host`
