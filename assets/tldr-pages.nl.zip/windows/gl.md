# gl

> In PowerShell is dit commando een alias van `get-location`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/get-location>.

- Bekijk de documentatie van het originele commando:

`tldr get-location`
