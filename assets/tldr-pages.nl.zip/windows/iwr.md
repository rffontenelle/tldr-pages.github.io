# iwr

> Dit commando is een alias van `invoke-webrequest`.

- Bekijk de documentatie van het originele commando:

`tldr invoke-webrequest`
