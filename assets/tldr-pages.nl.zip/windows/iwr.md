# iwr

> Dit commando is een alias van `invoke-webrequest`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Bekijk de documentatie van het originele commando:

`tldr invoke-webrequest`
