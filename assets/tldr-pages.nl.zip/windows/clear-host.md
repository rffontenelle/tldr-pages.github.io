# Clear-Host

> Wist het scherm.
> Dit commando kan alleen gebruikt worden via PowerShell.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/clear-host>.

- Wis het scherm:

`cls`
