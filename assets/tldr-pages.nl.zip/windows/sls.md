# sls

> Dit commando is een alias van `where-object`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Bekijk de documentatie van het originele commando:

`tldr where-object`
