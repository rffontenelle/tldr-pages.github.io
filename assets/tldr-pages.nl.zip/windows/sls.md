# sls

> Dit commando is een alias van `Select-String`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Bekijk de documentatie van het originele commando:

`tldr select-string`
