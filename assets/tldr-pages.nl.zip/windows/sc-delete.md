# sc-delete

> Dit commando is een alias van `sc`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Bekijk de documentatie van het originele commando:

`tldr sc`
