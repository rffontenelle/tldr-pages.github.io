# ni

> Dit commando is een alias van `new-item`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Bekijk de documentatie van het originele commando:

`tldr new-item`
