# ni

> In PowerShell is dit commando een alias van `New-Item`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Bekijk de documentatie van het originele commando:

`tldr new-item`
