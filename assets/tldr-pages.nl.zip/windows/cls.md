# cls

> Dit commando is een alias van `clear-host`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Bekijk de documentatie van het originele commando:

`tldr clear-host`
