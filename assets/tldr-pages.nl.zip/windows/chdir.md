# chdir

> Dit commando is een alias van `cd`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Bekijk de documentatie van het originele commando:

`tldr cd`
