# rd

> Deze opdracht is een alias van `rmdir` op de Command Prompt (`cmd`), en vervolgens `Remove-Item` in PowerShell.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Bekijk de documentatie van het originele commando:

`tldr rmdir`

- Bekijk de documentatie van het originele PowerShell commando:

`tldr remove-item`
