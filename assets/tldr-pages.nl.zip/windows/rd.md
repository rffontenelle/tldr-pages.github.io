# rd

> Dit commando is een alias van `rmdir`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Bekijk de documentatie van het originele commando:

`tldr rmdir`
