# rm

> In PowerShell is dit commando een alias van `Remove-Item`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Bekijk de documentatie van het originele commando:

`tldr remove-item`
