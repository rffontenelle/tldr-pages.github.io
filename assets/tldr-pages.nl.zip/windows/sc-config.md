# sc config

> Dit commando is een alias van `sc.exe config`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Bekijk de documentatie van het originele commando:

`tldr sc`
