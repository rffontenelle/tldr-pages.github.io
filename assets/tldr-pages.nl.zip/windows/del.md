# del

> Dit commando is een alias van `remove-item`.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Bekijk de documentatie van het originele commando:

`tldr remove-item`
