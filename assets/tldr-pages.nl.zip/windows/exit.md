# exit

> Verlaat de huidige CMD-instantie of het huidige batchbestand.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- Verlaat de huidige CMD-instantie:

`exit`

- Verlaat het huidige batchscript:

`exit /b`

- Verlaat met een specifieke exitcode:

`exit {{2}}`
