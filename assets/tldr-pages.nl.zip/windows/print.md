# print

> Een tekstbestand afdrukken op een printer.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/print>.

- Druk een tekstbestand af op de standaardprinter:

`print {{pad\naar\bestand}}`

- Druk een tekstbestand af op een specifieke printer:

`print /d:{{printer}} {{pad\naar\bestand}}`
