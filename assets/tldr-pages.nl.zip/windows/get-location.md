# Get-Location

> Toon de naam van de huidige/werk- map.
> Dit commando kan alleen worden uitgevoerd onder PowerShell.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/get-location>.

- Toon de huidige map:

`Get-Location`
