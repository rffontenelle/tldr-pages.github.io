# slmgr

> Dit commando is een alias van `slmgr.vbs`.
> Meer informatie: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Bekijk de documentatie van het originele commando:

`tldr slmgr.vbs`
