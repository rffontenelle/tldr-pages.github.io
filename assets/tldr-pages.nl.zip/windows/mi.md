# mi

> In PowerShell is dit commando een alias van `move-item`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/move-item>.

- Bekijk de documentatie van het originele commando:

`tldr move-item`
