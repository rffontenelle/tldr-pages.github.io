# sl

> Dit commando is een alias van `set-location`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Bekijk de documentatie van het originele commando:

`tldr set-location`
