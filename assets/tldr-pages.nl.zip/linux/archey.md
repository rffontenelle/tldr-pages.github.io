# archey

> Eenvoudige tool voor het stijlvol weergeven van systeeminformatie.
> Meer informatie: <https://lclarkmichalek.github.io/archey3/>.

- Toon systeeminformatie:

`archey`
