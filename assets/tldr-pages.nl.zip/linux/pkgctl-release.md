# pkgctl release

> Release stap om bouw artefacten te committen, taggen en uploaden.
> Meer informatie: <https://man.archlinux.org/man/pkgctl-release.1>.

- Release een bouw artefact:

`pkgctl release --repo {{repository}} --message {{commit_message}}`
