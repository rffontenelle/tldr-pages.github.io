# bspwm

> Een tegelvensterbeheerder gebaseerd op binaire ruimtepartitionering.
> Meer informatie: <https://github.com/baskerville/bspwm>.

- Start `bspwm` (houd er rekening mee dat een reeds bestaande vensterbeheerder niet geopend mag zijn wanneer dit commando wordt uitgevoerd):

`bspwm -c {{pad/naar/config}}`

- Bekijk de documentatie van `bspc`:

`tldr bspc`
