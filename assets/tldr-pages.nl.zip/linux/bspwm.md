# bspwm

> Dit commando is een alias van `bspc`.
> Meer informatie: <https://github.com/baskerville/bspwm>.

- Bekijk de documentatie van het originele commando:

`tldr bspc`
