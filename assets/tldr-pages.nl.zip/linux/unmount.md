# umount

> Het correcte commando is `umount` (u-mount).
> Meer informatie: <https://manned.org/umount.8>.

- Bekijk de documentatie van het correcte commando:

`tldr umount`
