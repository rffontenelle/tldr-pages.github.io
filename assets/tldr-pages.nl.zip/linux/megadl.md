# megadl

> Dit commando is een alias van `megatools-dl`.
> Meer informatie: <https://megatools.megous.com/man/megatools-dl.html>.

- Bekijk de documentatie van het originele commando:

`tldr megatools-dl`
