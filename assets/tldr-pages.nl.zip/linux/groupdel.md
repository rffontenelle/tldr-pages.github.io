# groupdel

> Verwijder bestaande gebruikersgroepen van het systeem.
> Bekijk ook: `groups`, `groupadd`, `groupmod`.
> Meer informatie: <https://manned.org/groupdel>.

- Verwijder een bestaande groep:

`sudo groupdel {{groepsnaam}}`
