# apx

> Dit commando is een alias van `apx pkgmanagers`.
> Meer informatie: <https://github.com/Vanilla-OS/apx>.

- Bekijk de documentatie van het originele commando:

`tldr apx pkgmanagers`
