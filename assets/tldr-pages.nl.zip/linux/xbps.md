# xbps

> Dit commando is een alias van `xbps-install`.
> Meer informatie: <https://docs.voidlinux.org/xbps/index.html>.

- Bekijk de documentatie van het originele commando:

`tldr xbps-install`
