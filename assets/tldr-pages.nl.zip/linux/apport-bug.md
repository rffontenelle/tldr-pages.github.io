# apport-bug

> Dien een bugrapport in over Ubuntu.
> Meer informatie: <https://wiki.ubuntu.com/Apport>.

- Meld een bug over het hele systeem:

`apport-bug`

- Meld een bug over een specifiek pakket:

`apport-bug {{pakket}}`

- Meld een bug over een specifiek uitvoerbaar bestand:

`apport-bug {{pad/naar/executable}}`

- Meld een bug over een specifiek proces:

`apport-bug {{PID}}`
