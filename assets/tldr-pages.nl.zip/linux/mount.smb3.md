# mount.smb3

> Dit commando is een alias van `mount.cifs`.

- Bekijk de documentatie van het originele commando:

`tldr mount.cifs`
