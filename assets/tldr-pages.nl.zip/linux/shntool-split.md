# shntool split

> Dit commando is een alias van `shnsplit`.

- Bekijk de documentatie van het originele commando:

`tldr shnsplit`
