# pkgctl db update

> Update de pacman-database als laatste stap van de release voor pakketten die zijn overgedragen en opgevoerd in <https://repos.archlinux.org>.
> Meer informatie: <https://man.archlinux.org/man/pkgctl-db-update.1>.

- Update de binary repository als laatste stap van de release:

`pkgctl db update`
