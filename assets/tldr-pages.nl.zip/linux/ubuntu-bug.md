# ubuntu-bug

> Dit commando is een alias van `apport-bug`.
> Meer informatie: <https://manned.org/ubuntu-bug>.

- Bekijk de documentatie van het originele commando:

`tldr apport-bug`
