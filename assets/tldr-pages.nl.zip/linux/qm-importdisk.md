# qm-importdisk

> Dit commando is een alias van `qm disk import`.

- Bekijk de documentatie van het originele commando:

`tldr qm disk import`
