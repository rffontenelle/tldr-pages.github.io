# iptables-restore

> Herstel de `iptables` IPv4 configuratie.
> Gebruik `ip6tables-restore` om hetzelfde te doen voor IPv6.
> Meer informatie: <https://manned.org/iptables-restore>.

- Herstel de `iptables` configuratie vanuit een bestand:

`sudo iptables-restore {{pad/naar/bestand}}`
