# xed

> Bewerk bestanden in de Cinnamon-desktopomgeving.
> Meer informatie: <https://github.com/linuxmint/xed>.

- Start de editor:

`xed`

- Open specifieke bestanden:

`xed {{pad/naar/bestand1 pad/naar/bestand2 ...}}`

- Open bestanden met een specifieke codering:

`xed --encoding {{WINDOWS-1252}} {{pad/naar/bestand1 pad/naar/bestand2 ...}}`

- Toon alle ondersteunde coderingen:

`xed --list-encodings`

- Open een bestand en ga naar een specifieke regel:

`xed +{{10}} {{pad/naar/bestand}}`
