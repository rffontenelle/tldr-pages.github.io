# systemd-resolve

> Resolve domeinnamen, IPV4 en IPv6 adressen, DNS resource records en services.
> Let op: deze tool is hernoemd naar `resolvectl` in nieuwere versies van `systemd`.
> Meer informatie: <https://manned.org/systemd-resolve>.

- Bekijk documentatie voor `resolvectl`:

`tldr resolvectl`
