# updatedb

> Maak of werk de database bij die gebruikt wordt door `locate`.
> Dit wordt meestal dagelijks uitgevoerd door cron.
> Meer informatie: <https://manned.org/updatedb>.

- Ververs de inhoud van de database:

`sudo updatedb`

- Toon bestandsnamen zodra ze gevonden zijn:

`sudo updatedb --verbose`
