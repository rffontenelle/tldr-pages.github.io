# ip route list

> Dit commando is een alias van  `ip route show`.

- Bekijk de documentatie van het originele commando:

`tldr ip-route-show`
