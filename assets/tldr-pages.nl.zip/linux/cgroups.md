# cgroups

> Dit commando is een alias van `cgclassify`.
> Meer informatie: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Bekijk de documentatie van het originele commando:

`tldr cgclassify`
