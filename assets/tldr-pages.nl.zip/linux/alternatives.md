# alternatives

> Dit commando is een alias van `update-alternatives`.
> Meer informatie: <https://manned.org/alternatives>.

- Bekijk de documentatie van het originele commando:

`tldr update-alternatives`
