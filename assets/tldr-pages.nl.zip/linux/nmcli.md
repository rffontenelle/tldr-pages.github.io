# nmcli

> Dit commando is een alias van `nmcli agent`.
> Meer informatie: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Bekijk de documentatie van het originele commando:

`tldr nmcli agent`
