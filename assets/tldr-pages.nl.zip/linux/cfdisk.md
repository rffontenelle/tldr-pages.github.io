# cfdisk

> Een programma voor het beheren van partitie tabellen en partities op een harde schijf met het gebruik van een UI.
> Meer informatie: <https://manned.org/cfdisk>.

- Start de partitie manipulator met een specifiek apparaat:

`cfdisk {{/dev/sdX}}`

- Creëer een nieuwe partitie tabel voor een specifiek apparaat en beheer het:

`cfdisk --zero {{/dev/sdX}}`
