# pkgctl

> Dit commando is een alias van `pkgctl auth`.
> Meer informatie: <https://man.archlinux.org/man/pkgctl.1>.

- Bekijk de documentatie van het originele commando:

`tldr pkgctl auth`
