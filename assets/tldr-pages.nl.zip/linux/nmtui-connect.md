# nmtui-connect

> Dit commando is een alias van `nmtui`.

- Bekijk de documentatie van het originele commando:

`tldr nmtui`
