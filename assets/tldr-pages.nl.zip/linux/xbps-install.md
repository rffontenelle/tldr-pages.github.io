# xbps-install

> XBPS hulpprogramma om pakketten te (her)installeren en bij te werken.
> Bekijk ook: `xbps`.
> Meer informatie: <https://manned.org/xbps-install.1>.

- Installeer een nieuw pakket:

`xbps-install {{pakket}}`

- Synchroniseer en update alle pakketten:

`xbps-install --sync --update`
