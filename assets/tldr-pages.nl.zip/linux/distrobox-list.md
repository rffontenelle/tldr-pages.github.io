# distrobox-list

> Toon alle distrobox containers.
> Subcommando van `distrobox`. Bekijk ook: `tldr distrobox`.
> Distrobox containers worden los van de rest van de normale Podman of Docker containers weergegeven.
> Meer informatie: <https://distrobox.privatedns.org/usage/distrobox-list.html>.

- Toon alle distrobox containers:

`distrobox-list`

- Toon alle distrobox containers met verbose informatie:

`distrobox-list --verbose`
