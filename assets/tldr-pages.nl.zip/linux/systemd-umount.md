# systemd-umount

> Dit commando is een alias van `systemd-mount`.

- Bekijk de documentatie van het originele commando:

`tldr systemd-mount`
