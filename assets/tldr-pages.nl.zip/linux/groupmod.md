# groupmod

> Wijzig bestaande gebruikersgroepen in het systeem.
> Zie ook: `groups`, `groupadd`, `groupdel`.
> Meer informatie: <https://manned.org/groupmod>.

- Wijzig de groepsnaam:

`sudo groupmod --new-name {{nieuwe_groep}} {{groepsnaam}}`

- Wijzig het groeps-ID:

`sudo groupmod --gid {{nieuwe_id}} {{groepsnaam}}`
