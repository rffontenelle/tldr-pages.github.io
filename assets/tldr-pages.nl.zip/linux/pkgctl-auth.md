# pkgctl auth

> Authenticeer `pkgctl` met diensten zoals GitLab.
> Meer informatie: <https://man.archlinux.org/man/pkgctl-auth.1>.

- Authenticeer `pkgctl` met de GitLab instantie:

`pkgctl auth login`

- Toon authenticatie status:

`pkgctl auth status`
