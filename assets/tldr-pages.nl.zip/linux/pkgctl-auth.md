# pkgctl auth

> Authenticeer `pkgctl` met diensten zoals GitLab.
> Meer informatie: <https://manned.org/pkgctl-auth.1>.

- Authenticeer `pkgctl` met de GitLab instantie:

`pkgctl auth login`

- Toon authenticatie status:

`pkgctl auth status`
