# caffeinate

> Voorkom dat de desktop in slaapstand gaat.
> Meer informatie: <https://manned.org/caffeinate>.

- Voorkom dat de desktop in slaapstand gaat (gebruik `Ctrl + C` om te stoppen):

`caffeinate`
