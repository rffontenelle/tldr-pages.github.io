# distrobox-host-exec

> Voer een commando uit op de host vanuit de distrobox container.
> Subcommando van `distrobox`. Bekijk ook: `tldr distrobox`.
> Meer informatie: <https://distrobox.privatedns.org/usage/distrobox-host-exec.html>.

- Voer een commando uit op de host vanuit de distrobox container:

`distrobox-host-exec "{{command}}"`

- Voer het `ls` commando uit op de host vanuit de distrobox container:

`distrobox-host-exec ls`
