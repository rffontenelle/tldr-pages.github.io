# qm resize

> Dit commando is een alias van `qm-disk-resize`.
> Meer informatie: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Bekijk de documentatie van het originele commando:

`tldr qm-disk-resize`
