# distrobox

> Dit commando is een alias van `distrobox-create`.
> Meer informatie: <https://github.com/89luca89/distrobox>.

- Bekijk de documentatie van het originele commando:

`tldr distrobox-create`
