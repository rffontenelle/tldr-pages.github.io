# dalvikvm

> Android Java virtuele machine.
> Meer informatie: <https://source.android.com/devices/tech/dalvik>.

- Start een specifiek Java programma:

`dalvikvm -classpath {{pad/naar/bestand.jar}} {{classname}}`
