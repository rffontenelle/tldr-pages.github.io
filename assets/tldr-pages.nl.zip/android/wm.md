# wm

> Toon informatie over het scherm van een Android-apparaat.
> Dit commando kan alleen worden gebruikt via `adb shell`.
> Meer informatie: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Toon de fysieke grootte van het scherm van een Android-apparaat:

`wm size`

- Toon de fysieke dichtheid van het scherm van een Android-apparaat:

`wm density`
