# screencap

> Maak een screenshot van een mobiel scherm.
> Dit commando kan alleen worden gebruikt via `adb shell`.
> Meer informatie: <https://developer.android.com/studio/command-line/adb#screencap>.

- Maak een screenshot:

`screencap {{pad/naar/bestand}}`
