# pkg

> Dit commando is een alias van `pkg_add`.
> Meer informatie: <https://www.openbsd.org/faq/faq15.html>.

- Bekijk de documentatie van het originele commando:

`tldr pkg_add`
