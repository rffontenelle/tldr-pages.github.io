# guptime

> Dit commando is een alias van `-p linux uptime`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux uptime`
