# arch

> Toon de naam van de systeemarchitectuur, of voer een commando uit onder een andere architectuur.
> Zie ook: `uname`.
> Meer informatie: <https://keith.github.io/xcode-man-pages/arch.1.html>.

- Toon de systeemarchitectuur:

`arch`

- Voer een commando uit met behulp van x86_64:

`arch -x86_64 "{{commando}}"`

- Voer een commando uit met behulp van arm:

`arch -arm64 "{{commando}}"`
