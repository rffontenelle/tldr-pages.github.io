# gshred

> Dit commando is een alias van `-p linux shred`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux shred`
