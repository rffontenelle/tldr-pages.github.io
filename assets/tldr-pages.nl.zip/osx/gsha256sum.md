# gsha256sum

> Dit commando is een alias van `-p linux sha256sum`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux sha256sum`
