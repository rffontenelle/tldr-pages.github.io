# gtelnet

> Dit commando is een alias van `-p linux telnet`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux telnet`
