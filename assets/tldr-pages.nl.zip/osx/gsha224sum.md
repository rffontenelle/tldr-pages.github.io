# gsha224sum

> Dit commando is een alias van `-p linux sha224sum`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux sha224sum`
