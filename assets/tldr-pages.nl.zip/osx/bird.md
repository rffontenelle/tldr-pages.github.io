# bird

> Dit ondersteunt de synchronisatie van iCloud en iCloud Drive.
> Het moet niet handmatig worden aangeroepen.
> Meer informatie: <https://keith.github.io/xcode-man-pages/bird.8.html>.

- Start de daemon:

`bird`
