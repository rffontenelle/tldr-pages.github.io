# gstdbuf

> Dit commando is een alias van `-p linux stdbuf`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux stdbuf`
