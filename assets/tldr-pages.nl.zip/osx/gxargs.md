# gxargs

> Dit commando is een alias van `-p linux xargs`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux xargs`
