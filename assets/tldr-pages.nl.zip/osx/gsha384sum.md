# gsha384sum

> Dit commando is een alias van `-p linux sha384sum`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux sha384sum`
