# grexec

> Dit commando is een alias van `-p linux rexec`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux rexec`
