# launchd

> Dit commando is een alias van `launchctl`.
> Meer informatie: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Bekijk de documentatie van het originele commando:

`tldr launchctl`
