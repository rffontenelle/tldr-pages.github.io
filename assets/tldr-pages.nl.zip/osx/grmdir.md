# grmdir

> Dit commando is een alias van `-p linux rmdir`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux rmdir`
