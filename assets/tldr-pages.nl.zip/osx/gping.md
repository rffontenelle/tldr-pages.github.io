# gping

> Dit commando is een alias van `-p linux ping`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ping`
