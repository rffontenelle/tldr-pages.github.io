# gfind

> Dit commando is een alias van `-p linux find`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux find`
