# gifconfig

> Dit commando is een alias van `-p linux ifconfig`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ifconfig`
