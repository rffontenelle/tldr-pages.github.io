# gb2sum

> Dit commando is een alias van `-p linux b2sum`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux b2sum`
