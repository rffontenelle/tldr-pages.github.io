# grlogin

> Dit commando is een alias van `-p linux rlogin`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux rlogin`
