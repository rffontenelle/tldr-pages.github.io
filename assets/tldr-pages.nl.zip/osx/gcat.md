# gcat

> Dit commando is een alias van `-p linux cat`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux cat`
