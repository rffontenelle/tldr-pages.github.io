# gwhoami

> Dit commando is een alias van `-p linux whoami`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux whoami`
