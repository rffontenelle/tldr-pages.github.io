# rename

> Hernoem een bestand of groep bestanden met een reguliere expressie.
> Meer informatie: <https://keith.github.io/xcode-man-pages/rename.2.html>.

- Vervang `from` door `to` in de bestandsnamen van de opgegeven bestanden:

`rename 's/{{from}}/{{to}}/' {{*.txt}}`
