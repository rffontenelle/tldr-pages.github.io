# ghostname

> Dit commando is een alias van `-p linux hostname`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux hostname`
