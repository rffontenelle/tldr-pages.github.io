# reboot

> Herstart het systeem.
> Meer informatie: <https://keith.github.io/xcode-man-pages/reboot.8.html>.

- Herstart onmiddellijk:

`sudo reboot`

- Herstart onmiddellijk zonder netjes af te sluiten:

`sudo reboot -q`
