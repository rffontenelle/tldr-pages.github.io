# gsplit

> Dit commando is een alias van `-p linux split`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux split`
