# gtac

> Dit commando is een alias van `-p linux tac`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux tac`
