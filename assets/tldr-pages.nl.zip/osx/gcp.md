# gcp

> Dit commando is een alias van `-p linux cp`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux cp`
