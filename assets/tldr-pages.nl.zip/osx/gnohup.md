# gnohup

> Dit commando is een alias van `-p linux nohup`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux nohup`
