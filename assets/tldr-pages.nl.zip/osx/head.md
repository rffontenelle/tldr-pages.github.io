# head

> Geef het eerste deel van bestanden weer.
> Meer informatie: <https://keith.github.io/xcode-man-pages/head.1.html>.

- Geef de eerste paar regels van een bestand weer:

`head --lines {{8}} {{pad/naar/bestand}}`

- Geef de eerste paar bytes van een bestand weer:

`head --bytes {{8}} {{pad/naar/bestand}}`

- Geef alles behalve de laatste paar regels van een bestand weer:

`head --lines -{{8}} {{pad/naar/bestand}}`

- Geef alles behalve de laatste paar bytes van een bestand weer:

`head --bytes -{{8}} {{pad/naar/bestand}}`
