# gdd

> Dit commando is een alias van `-p linux dd`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux dd`
