# gmkdir

> Dit commando is een alias van `-p linux mkdir`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux mkdir`
