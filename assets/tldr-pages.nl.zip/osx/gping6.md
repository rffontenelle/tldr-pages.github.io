# gping6

> Dit commando is een alias van `-p linux ping6`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux ping6`
