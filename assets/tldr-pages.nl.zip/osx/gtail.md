# gtail

> Dit commando is een alias van `-p linux tail`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux tail`
