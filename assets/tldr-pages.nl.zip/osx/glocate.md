# glocate

> Dit commando is een alias van `-p linux locate`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux locate`
