# uptime

> Toon hoe lang het systeem actief is en andere informatie.
> Meer informatie: <https://keith.github.io/xcode-man-pages/uptime.1.html>.

- Toon de huidige tijd, uptime, aantal ingelogde gebruikers en andere informatie:

`uptime`
