# glibtool

> Dit commando is een alias van `-p linux libtool`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux libtool`
