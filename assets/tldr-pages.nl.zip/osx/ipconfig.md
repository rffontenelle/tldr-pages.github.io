# ipconfig

> Bekijk en beheer de IP-configuratiestatus.
> Meer informatie: <https://keith.github.io/xcode-man-pages/ipconfig.8.html>.

- Lijst alle netwerkinterfaces op:

`ipconfig getiflist`

- Toon het IP-adres van een interface:

`ipconfig getifaddr {{interfacenaam}}`
