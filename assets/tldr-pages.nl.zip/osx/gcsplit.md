# gcsplit

> Dit commando is een alias van `-p linux csplit`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux csplit`
