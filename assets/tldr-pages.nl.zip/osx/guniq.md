# guniq

> Dit commando is een alias van `-p linux uniq`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux uniq`
