# gvdir

> Dit commando is een alias van `-p linux vdir`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux vdir`
