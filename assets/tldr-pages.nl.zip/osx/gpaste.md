# gpaste

> Dit commando is een alias van `-p linux paste`.

- Bekijk de documentatie van het originele commando:

`tldr -p linux paste`
