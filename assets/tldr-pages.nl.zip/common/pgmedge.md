# pgmedge

> Dit commando is vervangen door `pamedge`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pgmedge.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamedge`
