# pamdepth

> Verminder de diepte (d.w.z. kleurresolutie) in een afbeelding.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamdepth.html>.

- Lees een PBM afbeelding, stel de maxval in en sla deze op in een bestand:

`pamdepth {{maxval}} {{pad/naar/afbeelding.pbm}} > {{pad/naar/bestand.pbm}}`
