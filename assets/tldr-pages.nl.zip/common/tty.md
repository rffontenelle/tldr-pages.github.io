# tty

> Geeft de naam van de terminal terug.
> Meer informatie: <https://www.gnu.org/software/coreutils/tty>.

- Druk de bestandsnaam van deze terminal af:

`tty`
