# import

> Dit commando is een alias van `magick import`.

- Bekijk de documentatie van het originele commando:

`tldr magick import`
