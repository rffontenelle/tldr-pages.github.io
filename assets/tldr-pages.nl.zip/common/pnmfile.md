# pnmfile

> Dit commando is vervangen door `pamfile`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmfile.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamfile`
