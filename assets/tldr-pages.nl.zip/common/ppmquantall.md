# ppmquantall

> Dit commando is vervangen door `pnmquantall`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmquantall.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pnmquantall`
