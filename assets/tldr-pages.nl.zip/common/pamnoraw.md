# pamnoraw

> Dit commando is een alias van `pamtopnm -plain`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmnoraw.html>.

- Bekijk de documentatie van het originele commando:

`tldr pamtopnm`
