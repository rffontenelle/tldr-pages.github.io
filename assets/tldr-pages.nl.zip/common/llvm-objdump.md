# llvm-objdump

> Dit commando is een alias van `objdump`.

- Bekijk de documentatie van het originele commando:

`tldr objdump`
