# open

> `open` kan verwijzen naar meerdere commando's met dezelfde naam.

- Bekijk de documentatie voor het commando dat beschikbaar is in macOS:

`tldr open -p osx`

- Bekijk de documentatie voor het command beschikbaar via `fish`:

`tldr open.fish`
