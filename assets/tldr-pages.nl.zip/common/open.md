# open

> Dit commando is een alias van `open -p osx`.

- Bekijk de documentatie van het originele commando:

`tldr open -p osx`
