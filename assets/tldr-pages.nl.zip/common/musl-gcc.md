# musl-gcc

> Dit commando is een alias van `gcc`.
> Meer informatie: <https://manned.org/musl-gcc>.

- Bekijk de documentatie van het originele commando:

`tldr gcc`
