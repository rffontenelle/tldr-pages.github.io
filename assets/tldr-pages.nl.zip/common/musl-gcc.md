# musl-gcc

> Een wrapper voor `gcc` die automatisch opties instelt voor het koppelen van musl libc.
> Alle opties die gespecificeerd zijn, worden direct doorgegeven naar `gcc`.
> Meer informatie: <https://manned.org/musl-gcc>.

- Bekijk de documentatie voor `gcc`:

`tldr gcc`
