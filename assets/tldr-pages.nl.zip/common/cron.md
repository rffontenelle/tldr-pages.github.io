# cron

> Dit commando is een alias van `crontab`.
> Het commando om entries toe te voegen, aan te passen of te verwijderen in `cron` is called `crontab`.

- Bekijk de documentatie van het originele commando:

`tldr crontab`
