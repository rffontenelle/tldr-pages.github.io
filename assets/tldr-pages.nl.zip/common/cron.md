# cron

> Dit commando is een alias van `crontab`.

- Bekijk de documentatie van het originele commando:

`tldr crontab`
