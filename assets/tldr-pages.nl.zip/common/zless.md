# zless

> Bekijk gecomprimeerde bestanden.
> Meer informatie: <https://manned.org/zless>.

- Blader door een gecomprimeerd archief met `minder`:

`zless {{bestand.txt.gz}}`
