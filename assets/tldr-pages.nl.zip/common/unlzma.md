# unlzma

> Dit commando is een alias van `xz`.
> Meer informatie: <https://manned.org/unlzma>.

- Bekijk de documentatie van het originele commando:

`tldr xz`
