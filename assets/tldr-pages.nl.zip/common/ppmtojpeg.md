# ppmtojpeg

> Dit commando is vervangen door `pnmtojpeg`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmtojpeg.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pnmtojpeg`
