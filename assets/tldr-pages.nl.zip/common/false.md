# false

> Geeft een afsluitcode van 1 terug.
> Meer informatie: <https://www.gnu.org/software/coreutils/false>.

- Geeft een afsluitcode van 1 terug:

`false`
