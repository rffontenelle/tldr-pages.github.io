# unalias

> Verwijder aliassen.
> Meer informatie: <https://manned.org/unalias>.

- Verwijder een alias:

`unalias {{alias_naam}}`

- Verwijder alle aliassen:

`unalias -a`
