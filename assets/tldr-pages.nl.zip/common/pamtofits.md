# pamtofits

> Converteer een Netpbm afbeelding naar het Flexible afbeelding Transport System (FITS) formaat.
> Bekijk ook: `fitstopnm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamtofits.html>.

- Converteer een Netpbm afbeelding naar het FITS formaat:

`pamtofits {{pad/naar/afbeelding.pam}} > {{pad/naar/uitvoer.fits}}`
