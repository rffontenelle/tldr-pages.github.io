# bundler

> Dit commando is een alias van `bundle`.
> `bundler` is een gebruikelijke naam voor het commando `bundle`, maar niet een commando op zichzelf.
> Meer informatie: <https://bundler.io/man/bundle.1.html>.

- Bekijk de documentatie van het originele commando:

`tldr bundle`
