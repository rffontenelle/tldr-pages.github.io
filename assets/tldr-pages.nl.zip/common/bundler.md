# bundler

> Dit commando is een alias van `bundle`.
> Meer informatie: <https://bundler.io/man/bundle.1.html>.

- Bekijk de documentatie van het originele commando:

`tldr bundle`
