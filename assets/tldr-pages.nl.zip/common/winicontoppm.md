# winicontoppm

> Dit commando is vervangen door `winicontopam`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/winicontoppm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr winicontopam`
