# xzcat

> Dit commando is een alias van `xz`.
> Meer informatie: <https://manned.org/xzcat>.

- Bekijk de documentatie van het originele commando:

`tldr xz`
