# lzgrep

> Dit commando is een alias van `xzgrep`.

- Bekijk de documentatie van het originele commando:

`tldr xzgrep`
