# head

> Toon het eerste deel van een bestand.
> Meer informatie: <https://manned.org/head.1p>.

- Toon de eerste paar regels van een bestand:

`head -n {{aantal}} {{pad/naar/bestand}}`
