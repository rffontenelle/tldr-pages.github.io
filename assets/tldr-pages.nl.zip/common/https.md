# https

> Dit commando is een alias van `http`.

- Bekijk de documentatie van het originele commando:

`tldr http`
