# docker-container-top

> Dit commando is een alias van `docker top`.
> Meer informatie: <https://docs.docker.com/engine/reference/commandline/top>.

- Bekijk de documentatie van het originele commando:

`tldr docker top`
