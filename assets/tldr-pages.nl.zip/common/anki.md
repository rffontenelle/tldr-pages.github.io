# anki

> Krachtig, intelligent flashcardprogramma.
> Meer informatie: <https://docs.ankiweb.net>.

- Start `anki`:

`anki`

- Start `anki` met een specifiek profiel:

`anki -p {{profiel_naam}}`

- Start `anki` in een specifieke taal:

`anki -l {{taal}}`

- Start `anki` vanaf een specifieke map, in plaats van de standaardmap (`~/Anki`):

`anki -b {{pad/naar/map}}`
