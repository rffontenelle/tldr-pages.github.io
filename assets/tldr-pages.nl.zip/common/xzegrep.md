# xzegrep

> Dit commando is een alias van `xzgrep`.
> Bekijk ook: `egrep`.

- Bekijk de documentatie van het originele commando:

`tldr xzgrep`
