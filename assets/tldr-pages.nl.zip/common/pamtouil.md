# pamtouil

> Converteer een PNM of PAM bestand naar een Motif UIL icon bestand.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamtouil.html>.

- Converteer een PNM of PAM bestand naar een Motif UIL icon bestand:

`pamtouil {{pad/naar/invoer.pnm|pam}} > {{pad/naar/uitvoer.uil}}`

- Specificeer een voorvoegsel dat in het uitvoer-UIL-bestand moet worden afgedrukt:

`pamtouil -name {{uilname}} {{pad/naar/invoer.pnm|pam}} > {{pad/naar/uitvoer.uil}}`
