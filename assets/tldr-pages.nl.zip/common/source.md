# source

> Voer opdrachten uit vanuit een bestand in de huidige shell.
> Meer informatie: <https://manned.org/source>.

- Evalueer de inhoud van een bepaald bestand:

`source {{pad/naar/bestand}}`

- Evalueer de inhoud van een bepaald bestand (als alternatief ter vervanging van `source` door` .`):

`. {{pad/naar/bestand}}`
