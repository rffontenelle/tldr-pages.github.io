# fc

> Open het meest recente commando en bewerk het.
> Meer informatie: <https://manned.org/fc>.

- Open in de standaard systeemeditor:

`fc`

- Specificeer een editor om mee te openen:

`fc -e {{'emacs'}}`

- Toon recente commando's uit de geschiedenis:

`fc -l`

- Toon recente commando's in omgekeerde volgorde:

`fc -l -r`

- Toon commando's in een gegeven interval:

`fc '{{416}}' '{{420}}'`
