# cal

> Toon een kalender met de huidige dag gemarkeerd.
> Bekijk ook: `gcal`.
> Meer informatie: <https://manned.org/cal.1p>.

- Toon een kalender voor de huidige maand:

`cal`

- Toon een kalender voor een specifiek jaar:

`cal {{jaar}}`

- Toon een kalender voor een specifieke maand en jaar:

`cal {{maand}} {{jaar}}`
