# docker top

> Toon de lopende processen van een container.
> Meer informatie: <https://docs.docker.com/engine/reference/commandline/top>.

- Toon de lopende processen van een container:

`docker top {{container}}`

- Toon de help:

`docker top --help`
