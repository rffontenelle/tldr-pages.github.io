# pnmtofits

> Dit commando is vervangen door `pamtofits`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmtofits.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtofits`
