# docker-container-remove

> Dit commando is een alias van `docker rm`.
> Meer informatie: <https://docs.docker.com/engine/reference/commandline/rm>.

- Bekijk de documentatie van het originele commando:

`tldr docker rm`
