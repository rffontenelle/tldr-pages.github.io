# hd

> Dit commando is een alias van `hexdump`.
> Meer informatie: <https://manned.org/hd.1>.

- Bekijk de documentatie van het originele commando:

`tldr hexdump`
