# xzcmp

> Roep `cmp` aan op bestanden die gecomprimeerd zijn met `xz`, `lzma`, `gzip`, `bzip2`, `lzop`, or `zstd`.
> Alle opgegeven opties worden rechtstreeks doorgegeven aan `cmp`.
> Meer informatie: <https://manned.org/xzcmp>.

- Vergelijk twee specifieke bestanden:

`xzcmp {{pad/naar/bestand1}} {{pad/naar/bestand}}`
