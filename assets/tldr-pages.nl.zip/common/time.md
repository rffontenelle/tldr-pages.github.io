# time

> Kijk hoe lang een opdracht duurt.
> Meer informatie: <https://manned.org/time>.

- Tijd "ls":

`time ls`
