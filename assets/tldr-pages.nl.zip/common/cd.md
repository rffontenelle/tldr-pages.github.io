# cd

> Verander de huidige map.
> Meer informatie: <https://manned.org/cd>.

- Ga naar de gegeven map:

`cd {{pad/naar/map}}`

- Ga naar de ouder van de huidge map:

`cd ..`

- Ga naar de thuismap van de huidige gebruiker:

`cd`

- Ga naar de thuismap van de opgegeven gebruiker:

`cd ~{{gebruikersnaam}}`

- Ga naar de vorige map:

`cd -`

- Ga naar de hoofdmap:

`cd /`
