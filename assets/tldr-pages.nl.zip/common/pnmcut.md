# pnmcut

> Dit commando is vervangen door `pamcut`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmcut.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamcut`
