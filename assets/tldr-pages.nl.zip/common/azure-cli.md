# azure cli

> Dit commando is een alias van `az`.
> Meer informatie: <https://learn.microsoft.com/cli/azure>.

- Bekijk de documentatie van het originele commando:

`tldr az`
