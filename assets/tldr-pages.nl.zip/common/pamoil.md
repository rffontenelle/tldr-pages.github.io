# pamoil

> Zet een PAM afbeelding om in een olieschilderij.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamoil.html>.

- Zet een PAM afbeelding om in een olieschilderij:

`pamoil {{pad/naar/invoer_bestand.pam}} > {{pad/naar/uitvoer_bestand.pam}}`

- Beschouw een omgeving van N pixels voor het "smearing"-effect:

`pamoil -n {{N}} {{pad/naar/invoer_bestand.pam}} > {{pad/naar/uitvoer_bestand.pam}}`
