# icontopbm

> Dit commando is vervangen door `sunicontopbm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/icontopbm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr sunicontopbm`
