# gh-cs

> Dit commando is een alias van `gh-codespace`.
> Meer informatie: <https://cli.github.com/manual/gh_codespace>.

- Bekijk de documentatie van het originele commando:

`tldr gh-codespace`
