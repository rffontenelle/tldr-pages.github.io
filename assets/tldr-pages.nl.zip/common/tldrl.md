# tldrl

> Dit commando is een alias van `tldr-lint`.
> Meer informatie: <https://github.com/tldr-pages/tldr-lint>.

- Bekijk de documentatie van het originele commando:

`tldr tldr-lint`
