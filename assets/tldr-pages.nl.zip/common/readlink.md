# readlink

> Volg symlinks en verkrijg symlink-informatie.
> Meer informatie: <https://www.gnu.org/software/coreutils/readlink>.

- Toon het werkelijke bestand waarnaar de symlink verwijst:

`readlink {{pad/naar/bestand}}`

- Toon het absolute pad naar een bestand:

`readlink -f {{pad/naar/bestand}}`
