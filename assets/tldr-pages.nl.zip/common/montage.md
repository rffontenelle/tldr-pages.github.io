# montage

> Dit commando is een alias van `magick montage`.

- Bekijk de documentatie van het originele commando:

`tldr magick montage`
