# link

> Maak een harde koppeling naar een bestaand bestand.
> Voor meer opties, zie het `ln` commando.
> Meer informatie: <https://www.gnu.org/software/coreutils/link>.

- Maak een harde koppeling van een nieuw bestand naar een bestaand bestand:

`link {{pad/naar/bestaand_bestand}} {{pad/naar/nieuw_bestand}}`
