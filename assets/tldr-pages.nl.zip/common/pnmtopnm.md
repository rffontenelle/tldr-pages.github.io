# pnmtopnm

> Dit commando is een alias van `pamtopnm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmtopnm.html>.

- Bekijk de documentatie van het originele commando:

`tldr pamtopnm`
