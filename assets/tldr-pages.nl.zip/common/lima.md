# lima

> Dit commando is een alias van `limactl`.
> Meer informatie: <https://github.com/lima-vm/lima>.

- Bekijk de documentatie van het originele commando:

`tldr limactl`
