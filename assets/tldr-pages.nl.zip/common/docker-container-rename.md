# docker-container-rename

> Dit commando is een alias van `docker rename`.
> Meer informatie: <https://docs.docker.com/engine/reference/commandline/rename>.

- Bekijk de documentatie van het originele commando:

`tldr docker rename`
