# gnmic sub

> Dit commando is een alias van `gnmic subscribe`.
> Meer informatie: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Bekijk de documentatie van het originele commando:

`tldr gnmic subscribe`
