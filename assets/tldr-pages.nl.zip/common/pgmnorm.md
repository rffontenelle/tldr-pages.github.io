# pgmnorm

> Dit commando is vervangen door `pnmnorm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pgmnorm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pnmnorm`
