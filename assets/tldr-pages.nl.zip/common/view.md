# view

> Een alleen-lezen versie van `vim`.
> Dit is gelijk aan `vim -R`.
> Meer informatie: <https://www.vim.org>.

- Open een bestand:

`view {{bestand}}`
