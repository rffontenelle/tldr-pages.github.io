# pnmcomp

> Dit commando is vervangen door `pamcomp`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmcomp.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamcomp`
