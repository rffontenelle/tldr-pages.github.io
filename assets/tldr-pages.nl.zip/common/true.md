# true

> Retourneert een succesvolle exit statuscode van 0.
> Gebruik dit met de || operator om een commando altijd met 0 te laten afsluiten.
> Meer informatie: <https://www.gnu.org/software/coreutils/true>.

- Retourneer een succesvolle exit code:

`true`
