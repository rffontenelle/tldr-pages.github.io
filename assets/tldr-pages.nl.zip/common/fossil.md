# fossil

> Gedistribueerd versiebheer systeem.
> Sommige subcommando's zoals `fossil db` hebben hun eigen documentatie.
> Meer informatie: <https://fossil-scm.org/>.

- Controller de Fossil versie:

`fossil version`

- Toon algemene help (toon beschikbare subcommandos):

`fossil help`

- Toon help voor een Fossil subcommando (zoals `add`, `commit`, etc.):

`fossil help {{subcommand}}`

- Voer een Fossil subcommando uit:

`fossil {{subcommand}}`
