# docker-container-diff

> Dit commando is een alias van `docker diff`.
> Meer informatie: <https://docs.docker.com/engine/reference/commandline/diff>.

- Bekijk de documentatie van het originele commando:

`tldr docker diff`
