# sunicontopnm

> Converteer een Sun icon naar een Netpbm afbeelding.
> Meer informatie: <https://netpbm.sourceforge.net/doc/sunicontopnm.html>.

- Converteer een Sun icon naar een Netpbm afbeelding:

`sunicontopnm {{pad/naar/invoer.ico}} > {{pad/naar/uitvoer.pbm}}`
