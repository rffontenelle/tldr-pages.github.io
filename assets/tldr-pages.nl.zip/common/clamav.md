# clamav

> Dit commando is een alias van `clamdscan`.
> Meer informatie: <https://www.clamav.net>.

- Bekijk de documentatie van het originele commando:

`tldr clamdscan`
