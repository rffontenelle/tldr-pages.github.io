# lzcmp

> Dit commando is een alias van `xzcmp`.

- Bekijk de documentatie van het originele commando:

`tldr xzcmp`
