# just

> Dit commando is een alias van `just.1`.

- Bekijk de documentatie van het originele commando:

`tldr just.1`
