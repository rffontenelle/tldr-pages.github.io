# netcat

> Dit commando is een alias van `nc`.
> Meer informatie: <https://manned.org/nc>.

- Bekijk de documentatie van het originele commando:

`tldr nc`
