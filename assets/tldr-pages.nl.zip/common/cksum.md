# cksum

> Bereken de CRC checksums en het aantal bytes van een bestand.
> Opmerking: op oudere UNIX systemen kan de CRC implementatie verschillen.
> Meer informatie: <https://www.gnu.org/software/coreutils/cksum>.

- Toon een 32-bit checksum, grootte in bytes en bestandsnaam:

`cksum {{pad/naar/bestand}}`
