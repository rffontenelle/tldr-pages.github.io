# exit

> Verlaat de shell.
> Meer informatie: <https://manned.org/exit.1posix>.

- Verlaat de shell met de exitstatus van het meest recent uitgevoerde commando:

`exit`

- Verlaat de shell met een specifieke exitstatus:

`exit {{exit_code}}`
