# transmission

> Transmission is een eenvoudige torrent-client.
> Transmission is geen commando, maar een set commando's. Zie de onderstaande pagina's.
> Meer informatie: <https://transmissionbt.com/>.

- Toon de tdlr pagina voor het uitvoeren van de daemon van Transmission:

`tldr transmission-daemon`

- Toon de tldr pagina voor interactie met de daemon:

`tldr transmission-remote`

- Toon de tldr pagina voor het maken van torrent-bestanden:

`tldr transmission-create`

- Toon de tldr pagina voor het wijzigen van torrent-bestanden:

`tldr transmission-edit`

- Toon de tldr pagina voor het verkrijgen van informatie over torrent-bestanden:

`tldr transmission-show`

- Toon de tldr pagina voor de verouderde methode voor interactie met de daemon:

`tldr transmission-cli`
