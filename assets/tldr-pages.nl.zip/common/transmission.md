# transmission

> Dit commando is een alias van `transmission-daemon`.
> Meer informatie: <https://transmissionbt.com/>.

- Bekijk de documentatie van het originele commando:

`tldr transmission-daemon`
