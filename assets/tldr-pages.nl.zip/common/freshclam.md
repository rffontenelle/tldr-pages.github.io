# freshclam

> Update virus definities voor ClamAV antivirus programma.
> Meer informatie: <https://www.clamav.net>.

- Update virus definities:

`freshclam`
