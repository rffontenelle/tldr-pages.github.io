# users

> Toon een lijst van ingelogde gebruikers.
> Bekijk ook: `useradd`, `userdel`, `usermod`.
> Meer informatie: <https://www.gnu.org/software/coreutils/users>.

- Toon ingelogde gebruikersnamen:

`users`

- Toon ingelogde gebruikersnamen volgens een opgegeven bestand:

`users {{/var/log/wmtp}}`
