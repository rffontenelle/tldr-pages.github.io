# unclutter

> Verbergt de muiscursor.
> Meer informatie: <https://manned.org/unclutter.1x>.

- Verbergt de muiscursor na 3 seconden:

`unclutter -idle {{3}}`
