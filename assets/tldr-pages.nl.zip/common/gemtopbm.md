# gemtopbm

> Dit commando is vervangen door `gemtopnm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/gemtopbm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr gemtopnm`
