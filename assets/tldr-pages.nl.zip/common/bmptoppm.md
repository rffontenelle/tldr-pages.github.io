# bmptoppm

> Dit commando is vervangen door `bmptopnm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/bmptoppm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr bmptopnm`
