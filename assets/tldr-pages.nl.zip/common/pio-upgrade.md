# pio upgrade

> Update PlatformIO naar de laatste versie.
> Meer informatie: <https://docs.platformio.org/en/latest/core/userguide/cmd_upgrade.html>.

- Update PlatformIO naar de laatste versie:

`pio upgrade`

- Update PlatformIO naar de laatste ontwikkel (instabiele) versie:

`pio upgrade --dev`
