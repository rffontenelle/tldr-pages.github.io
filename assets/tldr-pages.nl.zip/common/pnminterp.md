# pnminterp

> Dit commando is vervangen door `pamstretch`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnminterp.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamstretch`
