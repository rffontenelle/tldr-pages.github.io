# linode-cli

> Dit commando is een alias van `linode-cli account`.
> Meer informatie: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Bekijk de documentatie van het originele commando:

`tldr linode-cli account`
