# ripgrep

> Dit commando is een alias van `rg`.

- Bekijk de documentatie van het originele commando:

`tldr rg`
