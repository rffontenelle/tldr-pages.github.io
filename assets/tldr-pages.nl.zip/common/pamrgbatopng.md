# pamrgbatopng

> Dit commando is vervangen door `pamtopng`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamrgbatopng.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtopng`
