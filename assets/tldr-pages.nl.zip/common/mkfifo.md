# mkfifo

> Maak FIFOs (benoemde pipes).
> Meer informatie: <https://www.gnu.org/software/coreutils/mkfifo>.

- Maak een benoemde pipe op een opgegeven pad:

`mkfifo {{pad/naar/pipe}}`
