# pnmtojpeg

> Converteer een PNM afbeelding naar het JPEG/JFIF/EXIF afbeeldingsformaat.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmtojpeg.html>.

- Lees een PNM afbeelding als invoer en produceer een JPEG/JFIF/EXIF afbeelding als uitvoer:

`pnmtojpeg {{pad/naar/bestand.pnm}} > {{pad/naar/bestand.jpg}}`

- Toon de versie:

`pnmtojpeg -version`
