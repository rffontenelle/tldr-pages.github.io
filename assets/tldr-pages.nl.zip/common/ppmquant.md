# ppmquant

> Dit commando is vervangen met `pnmquant` en `pnmremap`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmquant.html>.

- Bekijk documentatie voor `pnmquant`:

`tldr pnmquant`

- Bekijk documentatie voor `pnmremap`:

`tldr pnmremap`
