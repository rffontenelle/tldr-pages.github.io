# docker rename

> Hernoem een container.
> Meer informatie: <https://docs.docker.com/engine/reference/commandline/rename>.

- Hernoem een container:

`docker rename {{container}} {{nieuwe_naam}}`

- Toon de help:

`docker rename --help`
