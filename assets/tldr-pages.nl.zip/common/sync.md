# sync

> Schrijft alle hangende schrijfoperaties naar de juiste schijven.
> Meer informatie: <https://www.gnu.org/software/coreutils/sync>.

- Schrijf alle hangende schrijfoperaties naar alle schijven:

`sync`

- Schrijf alle hangende schrijfoperaties van een enkel bestand naar de schijf:

`sync {{pad/naar/bestand}}`
