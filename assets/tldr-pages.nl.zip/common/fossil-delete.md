# fossil delete

> Dit commando is een alias van `fossil rm`.
> Meer informatie: <https://fossil-scm.org/home/help/delete>.

- Bekijk de documentatie van het originele commando:

`tldr fossil rm`
