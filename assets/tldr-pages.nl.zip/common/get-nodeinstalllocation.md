# Get-NodeInstallLocation

> Haal de huidige Node.js installatiemap voor `ps-nvm` op.
> Part of `ps-nvm` and can only be run under PowerShell.
> Meer informatie: <https://github.com/aaronpowell/ps-nvm>.

- Haal de huidige Node.js installatiemap op:

`Get-NodeInstallLocation`
