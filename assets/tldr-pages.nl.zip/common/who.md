# who

> Toon wie er is ingelogd en gerelateerde gegevens (processen, opstarttijd).
> Meer informatie: <https://www.gnu.org/software/coreutils/who>.

- Toon de gebruikersnaam, line en tijd van alle huidige ingelogde sessies:

`who`

- Toon informatie alleen voor de huidige terminalsessie:

`who am i`

- Toon alle beschikbare informatie:

`who -a`

- Toon alle beschikbare informatie met tabelkoppen:

`who -a -H`
