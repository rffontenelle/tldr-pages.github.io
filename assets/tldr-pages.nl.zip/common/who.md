# who

> Toon wie er is ingelogd en gerelateerde gegevens (processen, opstarttijd).
> Bekijk ook: `whoami`.
> Meer informatie: <https://www.gnu.org/software/coreutils/who>.

- Toon de gebruikersnaam, line en tijd van alle huidige ingelogde sessies:

`who`

- Toon alle beschikbare informatie:

`who -a`

- Toon alle beschikbare informatie met tabelkoppen:

`who -a -H`
