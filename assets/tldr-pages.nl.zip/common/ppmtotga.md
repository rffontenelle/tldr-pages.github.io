# ppmtotga

> Dit commando is vervangen door `pamtotga`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmtotga.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtotga`
