# pnmquantall

> Voer `pnmquant` tegelijk uit op meerdere bestanden zodat deze een kleurkaart delen.
> Bekijk ook: `pnmquant`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmquantall.html>.

- Voer `pnmquant` uit op meerdere bestanden met de gespecificeerde parameters en overschrijf de originele bestanden:

`pnmquantall {{n_kleuren}} {{pad/naar/invoer1.pnm pad/naar/invoer2.pnm ...}}`

- Sla de gekwantificeerde afbeeldingen op naar bestanden met dezelfde namen als de invoerbestanden, maar met de gespecificeerde extensie:

`pnmquantall -ext {{extensie}} {{n_kleuren}} {{pad/naar/invoer1.pnm pad/naar/invoer2.pnm ...}}`
