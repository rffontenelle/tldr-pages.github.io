# ptpython3

> Dit commando is een alias van `ptpython`.

- Bekijk de documentatie van het originele commando:

`tldr ptpython`
