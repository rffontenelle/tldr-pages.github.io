# pwsh

> Dit commando is een alias van `powershell`.

- Bekijk de documentatie van het originele commando:

`tldr powershell`
