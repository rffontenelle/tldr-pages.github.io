# pwsh

> Dit commando is een alias van `powershell`.
> Meer informatie: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/about/about_pwsh>.

- Bekijk de documentatie van het originele commando:

`tldr powershell`
