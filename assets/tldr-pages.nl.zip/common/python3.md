# python3

> Dit commando is een alias van `python`.

- Bekijk de documentatie van het originele commando:

`tldr python`
