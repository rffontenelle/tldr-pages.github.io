# yes

> Print herhaaldelijk iets op het scherm.
> Meer informatie: <https://www.gnu.org/software/coreutils/yes>.

- Print herhaaldelijk "bericht":

`yes {{bericht}}`

- Print herhaaldelijk "y":

`yes`
