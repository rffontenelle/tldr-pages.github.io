# lckdo

> Dit commando is verouderd en vervangen door `flock`.
> Meer informatie: <https://joeyh.name/code/moreutils/>.

- Bekijk documentatie voor de aanbevolen vervanging:

`tldr flock`
