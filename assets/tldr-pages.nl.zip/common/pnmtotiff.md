# pnmtotiff

> Dit commando is vervangen door `pamtotiff`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmtotiff.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtotiff`
