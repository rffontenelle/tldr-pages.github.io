# ppmtouil

> Dit commando is vervangen door `pamtouil`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/ppmtouil.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamtouil`
