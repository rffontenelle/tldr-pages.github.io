# git stage

> Dit commando is een alias van `git add`.
> Meer informatie: <https://git-scm.com/docs/git-stage>.

- Bekijk de documentatie van het originele commando:

`tldr git add`
