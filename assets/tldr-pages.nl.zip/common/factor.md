# factor

> Toon de priemfactor van een getal.
> Meer informatie: <https://www.gnu.org/software/coreutils/factor>.

- Toon de priemfactor van een getal:

`factor {{nummer}}`

- Neem de invoer van `stdin` als er geen argument is opgegeven:

`echo {{nummer}} | factor`
