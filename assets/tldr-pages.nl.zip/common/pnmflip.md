# pnmflip

> Dit commando is vervangen door `pamflip`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pnmflip.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamflip`
