# todoman

> Dit commando is een alias van `todo`.
> Meer informatie: <https://todoman.readthedocs.io/>.

- Bekijk de documentatie van het originele commando:

`tldr todo`
