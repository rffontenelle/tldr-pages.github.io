# vi

> Dit commando is een alias van `vim`.

- Bekijk de documentatie voor het originele commando:

`tldr vim`
