# xzmore

> Tekst weergeven van `xz` en `lzma` gecomprimeerde bestanden.
> Bijna gelijk aan `xzless`, behalve dat het de `PAGER` omgevingsvariable respecteert, `more` standaard gebruikt en dat je geen opties kan sturen naar de pager.
> Meer informatie: <https://manned.org/xzmore>.

- Bekijk een gecomprimeerd bestand:

`xzmore {{pad/naar/bestand}}`
