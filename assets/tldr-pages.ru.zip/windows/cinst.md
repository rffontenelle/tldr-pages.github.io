# cinst

> Эта команда — псевдоним для `choco install`.
> Больше информации: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Смотри документацию для оригинальной команды:

`tldr choco install`
