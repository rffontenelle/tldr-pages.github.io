# rm

> Эта команда — псевдоним для `remove-item`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Смотри документацию для оригинальной команды:

`tldr remove-item`
