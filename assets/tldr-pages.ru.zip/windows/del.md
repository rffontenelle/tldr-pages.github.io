# del

> Эта команда — псевдоним для `remove-item`.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Смотри документацию для оригинальной команды:

`tldr remove-item`
