# sc-query

> Эта команда — псевдоним для `sc`.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Смотри документацию для оригинальной команды:

`tldr sc`
