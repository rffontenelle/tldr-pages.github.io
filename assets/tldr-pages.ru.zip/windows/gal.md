# gal

> Эта команда — псевдоним для `get-alias`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Смотри документацию для оригинальной команды:

`tldr get-alias`
