# pwsh-where

> Эта команда — псевдоним для `Where-Object`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Смотри документацию для оригинальной команды:

`tldr Where-Object`
