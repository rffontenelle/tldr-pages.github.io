# cpush

> Эта команда — псевдоним для `choco-push`.
> Больше информации: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Смотри документацию для оригинальной команды:

`tldr choco-push`
