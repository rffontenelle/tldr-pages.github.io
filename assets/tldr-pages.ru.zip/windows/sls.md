# sls

> Эта команда — псевдоним для `Select-String`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Смотри документацию для оригинальной команды:

`tldr select-string`
