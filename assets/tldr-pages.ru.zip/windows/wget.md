# wget

> Эта команда — псевдоним для `wget -p common`.
> Больше информации: <https://www.gnu.org/software/wget>.

- Смотри документацию для оригинальной команды:

`tldr wget -p common`
