# wget

> Эта команда — псевдоним для `wget -p common`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Смотри документацию для оригинальной команды:

`tldr wget -p common`
