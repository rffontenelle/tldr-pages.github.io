# sc-delete

> Эта команда — псевдоним для `sc`.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Смотри документацию для оригинальной команды:

`tldr sc`
