# ni

> Эта команда — псевдоним для `new-item`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Смотри документацию для оригинальной команды:

`tldr new-item`
