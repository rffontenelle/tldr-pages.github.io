# chdir

> Эта команда — псевдоним для `cd`.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Смотри документацию для оригинальной команды:

`tldr cd`
