# clist

> Эта команда — псевдоним для `choco list`.
> Больше информации: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Смотри документацию для оригинальной команды:

`tldr choco list`
