# rd

> Эта команда — псевдоним для `rmdir`.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Смотри документацию для оригинальной команды:

`tldr rmdir`
