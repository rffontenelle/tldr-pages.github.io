# sl

> Эта команда — псевдоним для `set-location`.
> Больше информации: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Смотри документацию для оригинальной команды:

`tldr set-location`
