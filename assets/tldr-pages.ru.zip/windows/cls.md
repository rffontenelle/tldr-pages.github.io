# cls

> Эта команда — псевдоним для `clear-host`.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Смотри документацию для оригинальной команды:

`tldr clear-host`
