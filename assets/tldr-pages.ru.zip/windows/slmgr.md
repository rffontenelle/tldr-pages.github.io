# slmgr

> Эта команда — псевдоним для `slmgr.vbs`.
> Больше информации: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Смотри документацию для оригинальной команды:

`tldr slmgr.vbs`
