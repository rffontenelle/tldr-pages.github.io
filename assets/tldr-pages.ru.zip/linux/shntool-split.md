# shntool-split

> Эта команда — псевдоним для `shnsplit`.

- Смотри документацию для оригинальной команды:

`tldr shnsplit`
