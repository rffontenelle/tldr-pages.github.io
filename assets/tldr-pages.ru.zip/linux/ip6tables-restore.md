# ip6tables-restore

> Эта команда — псевдоним для `iptables-restore`.

- Смотри документацию для оригинальной команды:

`tldr iptables-restore`
