# apx

> Эта команда — псевдоним для `apx pkgmanagers`.
> Больше информации: <https://github.com/Vanilla-OS/apx>.

- Смотри документацию для оригинальной команды:

`tldr apx pkgmanagers`
