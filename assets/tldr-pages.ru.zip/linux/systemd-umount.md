# systemd-umount

> Эта команда — псевдоним для `systemd-mount`.

- Смотри документацию для оригинальной команды:

`tldr systemd-mount`
