# bspwm

> Эта команда — псевдоним для `bspc`.
> Больше информации: <https://github.com/baskerville/bspwm>.

- Смотри документацию для оригинальной команды:

`tldr bspc`
