# distrobox

> Эта команда — псевдоним для `distrobox-create`.
> Больше информации: <https://github.com/89luca89/distrobox>.

- Смотри документацию для оригинальной команды:

`tldr distrobox-create`
