# qm-importdisk

> Эта команда — псевдоним для `qm disk import`.

- Смотри документацию для оригинальной команды:

`tldr qm disk import`
