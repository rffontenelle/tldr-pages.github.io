# alternatives

> Эта команда — псевдоним для `update-alternatives`.
> Больше информации: <https://manned.org/alternatives>.

- Смотри документацию для оригинальной команды:

`tldr update-alternatives`
