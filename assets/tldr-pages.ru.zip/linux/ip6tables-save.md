# ip6tables-save

> Эта команда — псевдоним для `iptables-save`.

- Смотри документацию для оригинальной команды:

`tldr iptables-save`
