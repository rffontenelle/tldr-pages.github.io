# xbps

> Эта команда — псевдоним для `xbps-install`.
> Больше информации: <https://docs.voidlinux.org/xbps/index.html>.

- Смотри документацию для оригинальной команды:

`tldr xbps-install`
