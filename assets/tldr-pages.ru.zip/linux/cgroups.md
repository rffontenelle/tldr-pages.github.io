# cgroups

> Эта команда — псевдоним для `cgclassify`.
> Больше информации: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Смотри документацию для оригинальной команды:

`tldr cgclassify`
