# megadl

> Эта команда — псевдоним для `megatools-dl`.
> Больше информации: <https://megatools.megous.com/man/megatools-dl.html>.

- Смотри документацию для оригинальной команды:

`tldr megatools-dl`
