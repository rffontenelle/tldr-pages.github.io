# ubuntu-bug

> Эта команда — псевдоним для `apport-bug`.
> Больше информации: <https://manned.org/ubuntu-bug>.

- Смотри документацию для оригинальной команды:

`tldr apport-bug`
