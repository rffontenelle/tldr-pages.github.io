# nmcli

> Эта команда — псевдоним для `nmcli agent`.
> Больше информации: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Смотри документацию для оригинальной команды:

`tldr nmcli agent`
