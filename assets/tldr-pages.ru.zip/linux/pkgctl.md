# pkgctl

> Эта команда — псевдоним для `pkgctl auth`.
> Больше информации: <https://man.archlinux.org/man/pkgctl.1>.

- Смотри документацию для оригинальной команды:

`tldr pkgctl auth`
