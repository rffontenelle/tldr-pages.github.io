# qm-resize

> Эта команда — псевдоним для `qm-disk-resize`.
> Больше информации: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Смотри документацию для оригинальной команды:

`tldr qm-disk-resize`
