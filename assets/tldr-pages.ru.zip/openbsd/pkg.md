# pkg

> Эта команда — псевдоним для `pkg_add`.
> Больше информации: <https://www.openbsd.org/faq/faq15.html>.

- Смотри документацию для оригинальной команды:

`tldr pkg_add`
