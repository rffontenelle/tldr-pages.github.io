# dalvikvm

> Виртуальная машина Android Java.
> Больше информации: <https://source.android.com/devices/tech/dalvik>.

- Запустить Java-программу:

`dalvikvm -classpath {{путь/к/файлу.jar}} {{classname}}`
