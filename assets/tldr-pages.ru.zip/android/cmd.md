# cmd

> Сервис менеджер Android.
> Больше информации: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- Список всех запущенных сервисов:

`cmd -l`

- Вызов конкретного сервиса:

`cmd {{alarm}}`

- Вызов сервиса с аргументами:

`cmd {{vibrator}} {{vibrate 300}}`
