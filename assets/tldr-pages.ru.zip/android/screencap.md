# screencap

> Сделать снимок экрана мобильного дисплея.
> Эту команду можно использовать только через `adb shell`.
> Больше информации: <https://developer.android.com/studio/command-line/adb#screencap>.

- Сделать снимок экрана:

`screencap {{путь/к/файлу}}`
