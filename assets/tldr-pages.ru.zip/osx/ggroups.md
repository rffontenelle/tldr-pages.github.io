# ggroups

> Эта команда — псевдоним для `-p linux groups`.

- Смотри документацию для оригинальной команды:

`tldr -p linux groups`
