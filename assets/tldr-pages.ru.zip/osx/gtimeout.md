# gtimeout

> Эта команда — псевдоним для `-p linux timeout`.

- Смотри документацию для оригинальной команды:

`tldr -p linux timeout`
