# gwhoami

> Эта команда — псевдоним для `-p linux whoami`.

- Смотри документацию для оригинальной команды:

`tldr -p linux whoami`
