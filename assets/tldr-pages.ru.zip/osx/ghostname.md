# ghostname

> Эта команда — псевдоним для `-p linux hostname`.

- Смотри документацию для оригинальной команды:

`tldr -p linux hostname`
