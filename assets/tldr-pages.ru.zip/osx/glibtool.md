# glibtool

> Эта команда — псевдоним для `-p linux libtool`.

- Смотри документацию для оригинальной команды:

`tldr -p linux libtool`
