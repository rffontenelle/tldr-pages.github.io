# ginstall

> Эта команда — псевдоним для `-p linux install`.

- Смотри документацию для оригинальной команды:

`tldr -p linux install`
