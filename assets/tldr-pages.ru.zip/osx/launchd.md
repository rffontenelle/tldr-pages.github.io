# launchd

> Эта команда — псевдоним для `launchctl`.
> Больше информации: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Смотри документацию для оригинальной команды:

`tldr launchctl`
