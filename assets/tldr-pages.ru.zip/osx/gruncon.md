# gruncon

> Эта команда — псевдоним для `-p linux runcon`.

- Смотри документацию для оригинальной команды:

`tldr -p linux runcon`
