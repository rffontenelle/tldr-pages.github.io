# glogname

> Эта команда — псевдоним для `-p linux logname`.

- Смотри документацию для оригинальной команды:

`tldr -p linux logname`
