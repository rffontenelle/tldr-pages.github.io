# gtruncate

> Эта команда — псевдоним для `-p linux truncate`.

- Смотри документацию для оригинальной команды:

`tldr -p linux truncate`
