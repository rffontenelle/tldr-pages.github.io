# glibtoolize

> Эта команда — псевдоним для `-p linux libtoolize`.

- Смотри документацию для оригинальной команды:

`tldr -p linux libtoolize`
