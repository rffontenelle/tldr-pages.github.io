# guptime

> Эта команда — псевдоним для `-p linux uptime`.

- Смотри документацию для оригинальной команды:

`tldr -p linux uptime`
