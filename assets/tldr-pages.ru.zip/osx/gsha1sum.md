# gsha1sum

> Эта команда — псевдоним для `-p linux sha1sum`.

- Смотри документацию для оригинальной команды:

`tldr -p linux sha1sum`
