# gtelnet

> Эта команда — псевдоним для `-p linux telnet`.

- Смотри документацию для оригинальной команды:

`tldr -p linux telnet`
