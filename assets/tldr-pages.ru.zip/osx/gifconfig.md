# gifconfig

> Эта команда — псевдоним для `-p linux ifconfig`.

- Смотри документацию для оригинальной команды:

`tldr -p linux ifconfig`
