# gunlink

> Эта команда — псевдоним для `-p linux unlink`.

- Смотри документацию для оригинальной команды:

`tldr -p linux unlink`
