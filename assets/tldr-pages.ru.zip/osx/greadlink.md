# greadlink

> Эта команда — псевдоним для `-p linux readlink`.

- Смотри документацию для оригинальной команды:

`tldr -p linux readlink`
