# grlogin

> Эта команда — псевдоним для `-p linux rlogin`.

- Смотри документацию для оригинальной команды:

`tldr -p linux rlogin`
