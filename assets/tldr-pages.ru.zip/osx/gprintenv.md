# gprintenv

> Эта команда — псевдоним для `-p linux printenv`.

- Смотри документацию для оригинальной команды:

`tldr -p linux printenv`
