# gdnsdomainname

> Эта команда — псевдоним для `-p linux dnsdomainname`.

- Смотри документацию для оригинальной команды:

`tldr -p linux dnsdomainname`
