# gindent

> Эта команда — псевдоним для `-p linux indent`.

- Смотри документацию для оригинальной команды:

`tldr -p linux indent`
