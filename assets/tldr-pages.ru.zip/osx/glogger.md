# glogger

> Эта команда — псевдоним для `-p linux logger`.

- Смотри документацию для оригинальной команды:

`tldr -p linux logger`
