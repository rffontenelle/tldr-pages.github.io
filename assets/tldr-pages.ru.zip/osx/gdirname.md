# gdirname

> Эта команда — псевдоним для `-p linux dirname`.

- Смотри документацию для оригинальной команды:

`tldr -p linux dirname`
