# gbasename

> Эта команда — псевдоним для `-p linux basename`.

- Смотри документацию для оригинальной команды:

`tldr -p linux basename`
