# grealpath

> Эта команда — псевдоним для `-p linux realpath`.

- Смотри документацию для оригинальной команды:

`tldr -p linux realpath`
