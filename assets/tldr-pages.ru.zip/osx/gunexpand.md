# gunexpand

> Эта команда — псевдоним для `-p linux unexpand`.

- Смотри документацию для оригинальной команды:

`tldr -p linux unexpand`
