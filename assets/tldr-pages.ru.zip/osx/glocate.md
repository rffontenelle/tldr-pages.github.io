# glocate

> Эта команда — псевдоним для `-p linux locate`.

- Смотри документацию для оригинальной команды:

`tldr -p linux locate`
