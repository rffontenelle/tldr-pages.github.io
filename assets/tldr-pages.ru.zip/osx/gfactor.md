# gfactor

> Эта команда — псевдоним для `-p linux factor`.

- Смотри документацию для оригинальной команды:

`tldr -p linux factor`
