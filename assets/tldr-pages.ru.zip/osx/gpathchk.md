# gpathchk

> Эта команда — псевдоним для `-p linux pathchk`.

- Смотри документацию для оригинальной команды:

`tldr -p linux pathchk`
