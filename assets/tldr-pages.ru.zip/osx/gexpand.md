# gexpand

> Эта команда — псевдоним для `-p linux expand`.

- Смотри документацию для оригинальной команды:

`tldr -p linux expand`
