# gupdatedb

> Эта команда — псевдоним для `-p linux updatedb`.

- Смотри документацию для оригинальной команды:

`tldr -p linux updatedb`
