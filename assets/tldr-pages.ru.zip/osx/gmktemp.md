# gmktemp

> Эта команда — псевдоним для `-p linux mktemp`.

- Смотри документацию для оригинальной команды:

`tldr -p linux mktemp`
