# gstdbuf

> Эта команда — псевдоним для `-p linux stdbuf`.

- Смотри документацию для оригинальной команды:

`tldr -p linux stdbuf`
