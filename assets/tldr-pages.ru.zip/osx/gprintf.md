# gprintf

> Эта команда — псевдоним для `-p linux printf`.

- Смотри документацию для оригинальной команды:

`tldr -p linux printf`
