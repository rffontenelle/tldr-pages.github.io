# ghostid

> Эта команда — псевдоним для `-p linux hostid`.

- Смотри документацию для оригинальной команды:

`tldr -p linux hostid`
