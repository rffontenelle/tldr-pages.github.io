# gdircolors

> Эта команда — псевдоним для `-p linux dircolors`.

- Смотри документацию для оригинальной команды:

`tldr -p linux dircolors`
