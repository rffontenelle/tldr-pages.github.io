# docker-container-diff

> Эта команда — псевдоним для `docker diff`.
> Больше информации: <https://docs.docker.com/engine/reference/commandline/diff>.

- Смотри документацию для оригинальной команды:

`tldr docker diff`
