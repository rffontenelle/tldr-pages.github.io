# fossil delete

> Эта команда — псевдоним для `fossil rm`.
> Больше информации: <https://fossil-scm.org/home/help/delete>.

- Смотри документацию для оригинальной команды:

`tldr fossil rm`
