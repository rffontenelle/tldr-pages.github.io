# fossil-forget

> Эта команда — псевдоним для `fossil rm`.
> Больше информации: <https://fossil-scm.org/home/help/forget>.

- Смотри документацию для оригинальной команды:

`tldr fossil rm`
