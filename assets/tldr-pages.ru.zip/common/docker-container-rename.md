# docker-container-rename

> Эта команда — псевдоним для `docker rename`.
> Больше информации: <https://docs.docker.com/engine/reference/commandline/rename>.

- Смотри документацию для оригинальной команды:

`tldr docker rename`
