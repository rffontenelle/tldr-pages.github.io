# azure-cli

> Эта команда — псевдоним для `az`.
> Больше информации: <https://learn.microsoft.com/cli/azure>.

- Смотри документацию для оригинальной команды:

`tldr az`
