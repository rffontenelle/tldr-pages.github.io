# docker-container-top

> Эта команда — псевдоним для `docker top`.
> Больше информации: <https://docs.docker.com/engine/reference/commandline/top>.

- Смотри документацию для оригинальной команды:

`tldr docker top`
