# hping

> Эта команда — псевдоним для `hping3`.
> Больше информации: <https://github.com/antirez/hping>.

- Смотри документацию для оригинальной команды:

`tldr hping3`
