# docker-container-remove

> Эта команда — псевдоним для `docker rm`.
> Больше информации: <https://docs.docker.com/engine/reference/commandline/rm>.

- Смотри документацию для оригинальной команды:

`tldr docker rm`
