# tlmgr arch

> Эта команда — псевдоним для `tlmgr platform`.
> Больше информации: <https://www.tug.org/texlive/tlmgr.html>.

- Смотри документацию для оригинальной команды:

`tldr tlmgr platform`
