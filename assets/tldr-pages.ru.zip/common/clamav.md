# ClamAV

> Эта команда — псевдоним для `clamdscan`.
> Больше информации: <https://www.clamav.net>.

- Смотри документацию для оригинальной команды:

`tldr clamdscan`
