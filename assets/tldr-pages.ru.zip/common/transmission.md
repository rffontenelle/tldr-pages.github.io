# transmission

> Эта команда — псевдоним для `transmission-daemon`.
> Больше информации: <https://transmissionbt.com/>.

- Смотри документацию для оригинальной команды:

`tldr transmission-daemon`
