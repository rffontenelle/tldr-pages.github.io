# todoman

> Эта команда — псевдоним для `todo`.
> Больше информации: <https://todoman.readthedocs.io/>.

- Смотри документацию для оригинальной команды:

`tldr todo`
