# linode-cli

> Эта команда — псевдоним для `linode-cli account`.
> Больше информации: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Смотри документацию для оригинальной команды:

`tldr linode-cli account`
