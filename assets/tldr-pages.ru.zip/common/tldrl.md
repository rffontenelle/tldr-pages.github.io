# tldrl

> Эта команда — псевдоним для `tldr-lint`.
> Больше информации: <https://github.com/tldr-pages/tldr-lint>.

- Смотри документацию для оригинальной команды:

`tldr tldr-lint`
