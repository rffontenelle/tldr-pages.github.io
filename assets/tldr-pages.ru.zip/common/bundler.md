# bundler

> Эта команда — псевдоним для `bundle`.
> Больше информации: <https://bundler.io/man/bundle.1.html>.

- Смотри документацию для оригинальной команды:

`tldr bundle`
