# mscore

> Эта команда — псевдоним для `musescore`.
> Больше информации: <https://musescore.org/handbook/command-line-options>.

- Смотри документацию для оригинальной команды:

`tldr musescore`
