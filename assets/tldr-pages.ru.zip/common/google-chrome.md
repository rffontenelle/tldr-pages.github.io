# google-chrome

> Эта команда — псевдоним для `chromium`.
> Больше информации: <https://chrome.google.com>.

- Смотри документацию для оригинальной команды:

`tldr chromium`
