# lima

> Эта команда — псевдоним для `limactl`.
> Больше информации: <https://github.com/lima-vm/lima>.

- Смотри документацию для оригинальной команды:

`tldr limactl`
