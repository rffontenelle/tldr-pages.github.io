# platformio

> Эта команда — псевдоним для `pio`.
> Больше информации: <https://docs.platformio.org/en/latest/core/userguide/>.

- Смотри документацию для оригинальной команды:

`tldr pio`
