# deluser

> 유저 계정 제거 또는 그룹으로부터 사용자 제거.
> 더 많은 정보: <https://manpages.debian.org/latest/adduser/deluser.html>.

- 유저 삭제:

`deluser {{이름}}`

- 사용자의 홈 디렉토리 및 메일 스풀과 함께 사용자 제거:

`deluser -r {{이름}}`

- 그룹으로부터 사용자 제거:

`deluser {{이름}} {{그룹}}`
