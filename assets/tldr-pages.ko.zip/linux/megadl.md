# megadl

> 이 명령은 `megatools-dl` 의 에일리어스 (별칭) 입니다.
> 더 많은 정보: <https://megatools.megous.com/man/megatools-dl.html>.

- 원본 명령의 도큐멘테이션 (설명서) 보기:

`tldr megatools-dl`
