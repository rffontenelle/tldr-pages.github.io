# pacman4console

> 오리지널 팩맨에서 영감을 받은 텍스트 기반 콘솔 게임.
> 더 많은 정보: <https://github.com/YoctoForBeaglebone/pacman4console>.

- 1단계에서 게임 시작:

`pacman4console`

- 특정 단계에서 게임 시작 (총 9개의 공식 단계가 있음):

`pacman4console --level={{단계_번호}}`

- 지정된 텍스트 파일에 저장하면서 pacman4console 레벨 편집기 시작:

`pacman4consoleedit {{경로/대상/레벨_파일}}`

- 사용자 정의 레벨 플레이:

`pacman4console --level={{경로/대상/레벨_파일}}`
