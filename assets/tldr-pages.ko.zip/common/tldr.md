# tldr

> 간단한 매뉴얼 페이지.
> 더 많은 정보: <https://tldr.sh>.

- 명령어 형식적 사용법 가져오기 (힌트 : 이걸 사용하는 방법입니다!):

`tldr {{명령어}}`

- Linux에서 tar에 대한 tldr 문서 표시하기:

`tldr -p {{linux}} {{tar}}`

- git 부속명령에 대한 도움말 가져오기:

`tldr {{git checkout}}`
