# anki

> 강력하고, 지능적인 플래시카드 프로그램.
> 더 많은 정보: <https://docs.ankiweb.net>.

- `anki` 실행:

`anki`

- 특정 프로필로 `anki` 실행:

`anki -p {{프로필_이름}}`

- 특정 언어로 `anki` 실행:

`anki -l {{언어}}`

- 기본값 대신 특정 디렉터리에서 `anki`를 실행 (`~/Anki`):

`anki -b {{경로/대상/디렉토리}}`
