# az feedback

> Azure CLI 팀에 피드백을 전송.
> `azure-cli`의 일부 (`az`라고도 함).
> 더 많은 정보: <https://learn.microsoft.com/cli/azure/reference-index#az_feedback>.

- Azure CLI 팀에 피드백 보내기:

`az feedback`
