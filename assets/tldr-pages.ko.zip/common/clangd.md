# clangd

> 편집자에게 IDE와 유사한 기능을 제공하는 언어 서버.
> 직접 호출하기보다는 편집기 플러그인을 통해 사용해야 함.
> 더 많은 정보: <https://clangd.llvm.org/>.

- 사용 가능한 옵션 표시:

`clangd --help`

- 사용 가능한 옵션 목록:

`clangd --help-list`

- 버전 표시:

`clangd --version`
