# cradle

> Cradle PHP 프레임워크.
> 추가 정보는 `cradle-install`, `cradle-deploy` 및 기타 페이지 참조.
> 더 많은 정보: <https://cradlephp.github.io>.

- 서버에 연결:

`cradle connect {{서버_명}}`

- 일반적인 도움말 표시:

`cradle help`

- 특정 명령에 대한 도움말 표시:

`cradle {{명령}} help`

- Cradle 명령 실행:

`cradle {{명령}}`
