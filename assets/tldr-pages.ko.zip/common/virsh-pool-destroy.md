# virsh pool-destroy

> 활성 가상 머신 스토리지 풀 중지.
> 같이 보기: `virsh`, `virsh-pool-delete`.
> 더 많은 정보: <https://manned.org/virsh>.

- 이름 또는 UUID로 지정된 스토리지 풀 중지 (`virsh pool-list`를 사용하여 결정):

`virsh pool-destroy --pool {{name|uuid}}`
