# virsh pool-info

> 가상 머신 스토리지 풀에 대한 정보를 나열합니다.
> 같이 보기: `virsh`.
> 더 많은 정보: <https://manned.org/virsh>.

- 이름 또는 UUID로 지정된 스토리지 풀에 대해 이름, UUID, 상태, 지속성 유형, 자동 시작 상태, 용량, 할당된 공간 및 사용 가능한 공간 나열 (`virsh pool-list`를 사용하여 결정):

`virsh pool-info --pool {{name|uuid}}`
