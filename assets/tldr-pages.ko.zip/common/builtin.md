# builtin

> 내장 쉘을 실행.
> 더 많은 정보: <https://manned.org/builtin.1>.

- 내장 쉘을 실행:

`builtin {{명령어}}`
