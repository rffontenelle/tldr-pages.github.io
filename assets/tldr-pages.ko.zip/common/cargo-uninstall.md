# cargo uninstall

> `cargo install`을 사용하여 설치된 Rust 바이너리를 제거.
> 더 많은 정보: <https://doc.rust-lang.org/cargo/commands/cargo-uninstall.html>.

- 설치된 바이너리를 제거:

`cargo remove {{패키지_스펙}}`
