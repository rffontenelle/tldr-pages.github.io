# virsh-help

> `virsh` 명령 또는 명령 그룹에 대한 정보 표시.
> 같이 보기: `virsh`.
> 더 많은 정보: <https://manned.org/virsh>.

- 관련 카테고리로 그룹화된 `virsh` 명령 나열:

`virsh help`

- 명령의 카테고리를 나열:

`virsh help | grep "keyword"`

- 카테고리의 명령 나열

`virsh help {{카테고리_키워드}}`

- 명령어에 대한 도움말 표시:

`virsh help {{명령어}}`
