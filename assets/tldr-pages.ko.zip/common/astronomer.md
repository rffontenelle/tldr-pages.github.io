# astronomer

> GitHub 프로젝트의 봇 계정에서 불법적인 star를 탐지하는 도구.
> 더 많은 정보: <https://github.com/Ullaakut/astronomer>.

- 저장소 스캔:

`astronomer {{tldr-pages/tldr-node-client}}`

- 레포지토리의 최대 star 스캔:

`astronomer {{tldr-pages/tldr-node-client}} --stars {{50}}`

- 비교 보고서를 포함한 리포지토리 스캔:

`astronomer {{tldr-pages/tldr-node-client}} --verbose`
