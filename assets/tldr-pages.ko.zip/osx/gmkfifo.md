# gmkfifo

> 이 명령은 `-p linux mkfifo` 의 에일리어스 (별칭) 입니다.

- 원본 명령의 도큐멘테이션 (설명서) 보기:

`tldr -p linux mkfifo`
