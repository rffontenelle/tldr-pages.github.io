# wm

> Android 기기 화면에 대한 정보 표시.
> 이 명령은 `adb shell`을 통해서만 사용할 수 있습니다.
> 더 많은 정보: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Android 기기 화면의 물리적 크기를 표시:

`wm {{크기}}`

- Android 기기 화면의 물리적 밀도를 표시:

`wm {{밀도}}`
