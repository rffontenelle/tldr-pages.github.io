# screencap

> 모바일 디스플레이의 스크린샷 찍기.
> 이 명령은 `adb shell`을 통해서만 사용할 수 있습니다.
> 더 많은 정보: <https://developer.android.com/studio/command-line/adb#screencap>.

- 스크린샷 찍기:

`screencap {{경로/대상/파일}}`
