# bugreport

> Android 장치의 버그 보고서를 표시합니다.
> 이 명령은 `adb shell`을 통해서만 사용할 수 있습니다.
> 더 많은 정보: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Android 장치의 완전한 버그 보고서를 표시:

`bugreport`
