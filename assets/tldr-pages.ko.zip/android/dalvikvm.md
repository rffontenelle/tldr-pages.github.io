# dalvikvm

> 안드로이드 자바 가상 머신.
> 더 많은 정보: <https://source.android.com/devices/tech/dalvik>.

- 특정 자바 프로그램 실행:

`dalvikvm -classpath {{경로/대상/파일.jar}} {{클래스명}}`
