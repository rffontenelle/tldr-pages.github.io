# cuninst

> 이 명령은 `choco uninstall` 의 에일리어스 (별칭) 입니다.
> 더 많은 정보: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- 원본 명령의 도큐멘테이션 (설명서) 보기:

`tldr choco uninstall`
