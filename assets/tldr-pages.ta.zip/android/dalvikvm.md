# dalvikvm

> ஆண்ட்ராய்டு ஜாவா மெய்நிகர் இயந்திரம்.
> மேலும் விவரத்திற்கு: <https://source.android.com/devices/tech/dalvik>.

- ஒரு குறிப்பிட்ட ஜாவா நிரலைத் தொடங்கவும்:

`dalvikvm -classpath {{பாதை/டு/கோப்பு.jar}} {{வகுப்புப்பெயர்}}`
