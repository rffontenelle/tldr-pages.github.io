# bugreport

> ஆண்ட்ராய்டு பிழை அறிக்கையைக் காட்டு.
> இந்தக் கட்டளையை `adb shell` மூலம் மட்டுமே பயன்படுத்த முடியும்.
> மேலும் விவரத்திற்கு: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- ஆண்ட்ராய்டு சாதனத்தின் முழுமையான பிழை அறிக்கையைக் காட்டு:

`bugreport`
