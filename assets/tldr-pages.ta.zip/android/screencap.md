# screencap

> மொபைல் டிஸ்ப்ளேவின் ஸ்கிரீன் ஷாட்டை எடுக்கவும்.
> இந்த கட்டளையை `adb shell` மூலம் மட்டுமே பயன்படுத்த முடியும்.
> மேலும் விவரத்திற்கு: <https://developer.android.com/studio/command-line/adb#screencap>.

- ஒரு ஸ்கிரீன் ஷாட்டை எடுங்கள்:

`screencap {{பாதை/டு/கோப்பு}}`
