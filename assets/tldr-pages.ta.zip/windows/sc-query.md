# sc-query

> இக்கட்டளை `sc` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr sc`
