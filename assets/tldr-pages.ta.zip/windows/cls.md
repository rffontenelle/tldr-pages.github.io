# cls

> திரையை அழிக்கிறது.
> மேலும் விவரத்திற்கு: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- திரையை அழிக்கவும்:

`cls`
