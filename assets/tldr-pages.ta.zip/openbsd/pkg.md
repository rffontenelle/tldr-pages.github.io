# pkg

> இக்கட்டளை `pkg_add` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://www.openbsd.org/faq/faq15.html>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr pkg_add`
