# pkgctl

> இக்கட்டளை `pkgctl auth` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://man.archlinux.org/man/pkgctl.1>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr pkgctl auth`
