# toolbox init-container

> இயங்கும் `toolbox` கொள்கலனைத் தொடங்கவும்.
> இந்த கட்டளை பயனரால் செயல்படுத்தப்படக்கூடாது, மேலும் ஹோஸ்டில் இயக்க முடியாது.
> மேலும் விவரத்திற்கு: <https://manned.org/toolbox-init-container.1>.

- இயங்கும் கருவிப்பெட்டியை துவக்கவும்:

`toolbox init-container --gid {{gid}} --home {{வீடு}} --home-link --media-link --mnt-link --monitor-host --shell {{ஷெல்}} --uid {{uid}} --user {{பயனர்}}`
