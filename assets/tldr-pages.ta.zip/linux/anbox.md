# anbox

> எந்த GNU/லினக்ஸ் ஆப்பரேட்டிங் சிஸ்டத்திலும் ஆண்ட்ராய்ட் அப்ளிகேஷன்களை இயக்கும்.
> மேலும் விவரத்திற்கு: <https://manned.org/anbox>.

- பயன்பாட்டு மேலாளரில் அன்பாக்ஸ் ஐத் தொடங்கவும்:

`anbox launch --package={{org.anbox.appmgr}} --component={{org.anbox.appmgr.AppViewActivity}}`
