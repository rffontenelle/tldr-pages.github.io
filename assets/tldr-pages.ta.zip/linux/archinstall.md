# archinstall

> ஒரு திருப்பத்துடன் வழிகாட்டப்பட்ட ஆர்ச் லினக்ஸ் நிறுவி.
> மேலும் விவரத்திற்கு: <https://archinstall.readthedocs.io>.

- ஊடாடும் நிறுவியைத் தொடங்கவும்:

`archinstall`

- முன்னமைக்கப்பட்ட நிறுவியைத் தொடங்கவும்:

`archinstall {{minimal|unattended}}`
