# gsha1sum

> இக்கட்டளை `-p linux sha1sum` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr -p linux sha1sum`
