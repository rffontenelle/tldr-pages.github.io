# fossil ci

> இக்கட்டளை  `fossil commit`.கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://fossil-scm.org/home/help/commit>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr fossil-commit`
