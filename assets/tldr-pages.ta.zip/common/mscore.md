# mscore

> இக்கட்டளை `musescore` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://musescore.org/handbook/command-line-options>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr musescore`
