# gnmic-sub

> இக்கட்டளை `gnmic subscribe` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://gnmic.kmrd.dev/cmd/subscribe>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr gnmic subscribe`
