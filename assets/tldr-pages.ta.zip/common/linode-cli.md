# linode-cli

> இக்கட்டளை `linode-cli account` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr linode-cli account`
