# lima

> இக்கட்டளை `limactl` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://github.com/lima-vm/lima>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr limactl`
