# docker-container-rename

> இக்கட்டளை `docker rename` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://docs.docker.com/engine/reference/commandline/rename>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr docker rename`
