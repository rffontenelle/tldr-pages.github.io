# azure-cli

> இக்கட்டளை `az` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://learn.microsoft.com/cli/azure>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr az`
