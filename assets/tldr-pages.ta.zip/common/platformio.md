# platformio

> இக்கட்டளை `pio` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://docs.platformio.org/en/latest/core/userguide/>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr pio`
