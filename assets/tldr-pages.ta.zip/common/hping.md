# hping

> இக்கட்டளை `hping3` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://github.com/antirez/hping>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr hping3`
