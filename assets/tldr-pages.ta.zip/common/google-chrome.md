# google-chrome

> இக்கட்டளை `chromium` கட்டளையின் மற்றொருப் பெயர்.
> மேலும் விவரத்திற்கு: <https://chrome.google.com>.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr chromium`
