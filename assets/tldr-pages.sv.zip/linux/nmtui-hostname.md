# nmtui-hostname

> Det här kommandot är ett alias för `nmtui`.

- Se dokumentationen för orginalkommandot:

`tldr nmtui`
