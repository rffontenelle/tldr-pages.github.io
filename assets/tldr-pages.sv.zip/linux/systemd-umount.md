# systemd-umount

> Det här kommandot är ett alias för `systemd-mount`.

- Se dokumentationen för orginalkommandot:

`tldr systemd-mount`
