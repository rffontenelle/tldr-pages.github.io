# shntool-split

> Det här kommandot är ett alias för `shnsplit`.

- Se dokumentationen för orginalkommandot:

`tldr shnsplit`
