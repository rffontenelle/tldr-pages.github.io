# pkgctl

> Det här kommandot är ett alias för `pkgctl auth`.
> Mer information: <https://man.archlinux.org/man/pkgctl.1>.

- Se dokumentationen för orginalkommandot:

`tldr pkgctl auth`
