# xbps

> Det här kommandot är ett alias för `xbps-install`.
> Mer information: <https://docs.voidlinux.org/xbps/index.html>.

- Se dokumentationen för orginalkommandot:

`tldr xbps-install`
