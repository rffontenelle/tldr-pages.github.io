# qm-resize

> Det här kommandot är ett alias för `qm-disk-resize`.
> Mer information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Se dokumentationen för orginalkommandot:

`tldr qm-disk-resize`
