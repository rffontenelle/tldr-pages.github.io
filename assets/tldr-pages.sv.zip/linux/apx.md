# apx

> Det här kommandot är ett alias för `apx pkgmanagers`.
> Mer information: <https://github.com/Vanilla-OS/apx>.

- Se dokumentationen för orginalkommandot:

`tldr apx pkgmanagers`
