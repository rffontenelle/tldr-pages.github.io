# ip6tables-restore

> Det här kommandot är ett alias för `iptables-restore`.

- Se dokumentationen för orginalkommandot:

`tldr iptables-restore`
