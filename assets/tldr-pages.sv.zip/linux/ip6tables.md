# ip6tables

> Det här kommandot är ett alias för `iptables`.

- Se dokumentationen för orginalkommandot:

`tldr iptables`
