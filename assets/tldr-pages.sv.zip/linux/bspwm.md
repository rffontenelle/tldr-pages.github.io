# bspwm

> Det här kommandot är ett alias för `bspc`.
> Mer information: <https://github.com/baskerville/bspwm>.

- Se dokumentationen för orginalkommandot:

`tldr bspc`
