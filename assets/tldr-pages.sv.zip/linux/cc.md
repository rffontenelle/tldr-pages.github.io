# cc

> Det här kommandot är ett alias för `gcc`.
> Mer information: <https://gcc.gnu.org>.

- Se dokumentationen för orginalkommandot:

`tldr gcc`
