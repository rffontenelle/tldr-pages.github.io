# ip6tables-save

> Det här kommandot är ett alias för `iptables-save`.

- Se dokumentationen för orginalkommandot:

`tldr iptables-save`
