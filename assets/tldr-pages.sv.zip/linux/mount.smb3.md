# mount.smb3

> Det här kommandot är ett alias för `mount.cifs`.

- Se dokumentationen för orginalkommandot:

`tldr mount.cifs`
