# distrobox

> Det här kommandot är ett alias för `distrobox-create`.
> Mer information: <https://github.com/89luca89/distrobox>.

- Se dokumentationen för orginalkommandot:

`tldr distrobox-create`
