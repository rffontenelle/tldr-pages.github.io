# cgroups

> Det här kommandot är ett alias för `cgclassify`.
> Mer information: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Se dokumentationen för orginalkommandot:

`tldr cgclassify`
