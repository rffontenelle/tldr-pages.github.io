# nmcli

> Det här kommandot är ett alias för `nmcli agent`.
> Mer information: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Se dokumentationen för orginalkommandot:

`tldr nmcli agent`
