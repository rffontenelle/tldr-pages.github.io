# qm-move-disk

> Det här kommandot är ett alias för `qm-disk-move`.
> Mer information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Se dokumentationen för orginalkommandot:

`tldr qm-disk-move`
