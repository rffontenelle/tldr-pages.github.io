# qm-importdisk

> Det här kommandot är ett alias för `qm disk import`.

- Se dokumentationen för orginalkommandot:

`tldr qm disk import`
