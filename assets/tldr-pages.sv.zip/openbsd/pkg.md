# pkg

> Det här kommandot är ett alias för `pkg_add`.
> Mer information: <https://www.openbsd.org/faq/faq15.html>.

- Se dokumentationen för orginalkommandot:

`tldr pkg_add`
