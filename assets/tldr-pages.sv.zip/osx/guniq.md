# guniq

> Det här kommandot är ett alias för `-p linux uniq`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux uniq`
