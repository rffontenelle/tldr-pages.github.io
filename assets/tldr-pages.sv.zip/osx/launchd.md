# launchd

> Det här kommandot är ett alias för `launchctl`.
> Mer information: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Se dokumentationen för orginalkommandot:

`tldr launchctl`
