# gfgrep

> Det här kommandot är ett alias för `-p linux fgrep`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux fgrep`
