# gxargs

> Det här kommandot är ett alias för `-p linux xargs`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux xargs`
