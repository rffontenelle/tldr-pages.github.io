# gchroot

> Det här kommandot är ett alias för `-p linux chroot`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux chroot`
