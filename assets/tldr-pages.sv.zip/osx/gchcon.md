# gchcon

> Det här kommandot är ett alias för `-p linux chcon`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux chcon`
