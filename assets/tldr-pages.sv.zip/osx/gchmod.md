# gchmod

> Det här kommandot är ett alias för `-p linux chmod`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux chmod`
