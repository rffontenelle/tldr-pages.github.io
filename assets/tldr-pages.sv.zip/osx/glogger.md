# glogger

> Det här kommandot är ett alias för `-p linux logger`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux logger`
