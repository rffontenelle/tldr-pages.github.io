# llvm-lipo

> Det här kommandot är ett alias för `lipo`.

- Se dokumentationen för orginalkommandot:

`tldr lipo`
