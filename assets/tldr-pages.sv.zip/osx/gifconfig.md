# gifconfig

> Det här kommandot är ett alias för `-p linux ifconfig`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ifconfig`
