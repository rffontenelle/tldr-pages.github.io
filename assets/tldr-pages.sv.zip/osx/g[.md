# g[

> Det här kommandot är ett alias för `-p linux [`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux [`
