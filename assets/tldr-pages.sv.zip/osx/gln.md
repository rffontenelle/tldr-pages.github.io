# gln

> Det här kommandot är ett alias för `-p linux ln`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ln`
