# glogname

> Det här kommandot är ett alias för `-p linux logname`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux logname`
