# gsed

> Det här kommandot är ett alias för `-p linux sed`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sed`
