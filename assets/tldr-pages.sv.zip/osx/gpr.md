# gpr

> Det här kommandot är ett alias för `-p linux pr`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux pr`
