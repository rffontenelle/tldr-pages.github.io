# gls

> Det här kommandot är ett alias för `-p linux ls`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ls`
