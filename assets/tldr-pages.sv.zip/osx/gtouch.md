# gtouch

> Det här kommandot är ett alias för `-p linux touch`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux touch`
