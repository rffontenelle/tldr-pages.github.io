# gnumfmt

> Det här kommandot är ett alias för `-p linux numfmt`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux numfmt`
