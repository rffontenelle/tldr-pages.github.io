# gsleep

> Det här kommandot är ett alias för `-p linux sleep`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sleep`
