# glocate

> Det här kommandot är ett alias för `-p linux locate`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux locate`
