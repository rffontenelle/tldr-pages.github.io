# gsplit

> Det här kommandot är ett alias för `-p linux split`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux split`
