# gfmt

> Det här kommandot är ett alias för `-p linux fmt`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux fmt`
