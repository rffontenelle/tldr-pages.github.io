# gtee

> Det här kommandot är ett alias för `-p linux tee`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux tee`
