# gdirname

> Det här kommandot är ett alias för `-p linux dirname`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux dirname`
