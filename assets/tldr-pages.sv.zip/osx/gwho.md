# gwho

> Det här kommandot är ett alias för `-p linux who`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux who`
