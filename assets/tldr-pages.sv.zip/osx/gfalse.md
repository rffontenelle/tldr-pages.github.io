# gfalse

> Det här kommandot är ett alias för `-p linux false`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux false`
