# gnl

> Det här kommandot är ett alias för `-p linux nl`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux nl`
