# gsha1sum

> Det här kommandot är ett alias för `-p linux sha1sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sha1sum`
