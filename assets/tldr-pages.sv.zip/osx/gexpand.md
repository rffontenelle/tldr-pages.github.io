# gexpand

> Det här kommandot är ett alias för `-p linux expand`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux expand`
