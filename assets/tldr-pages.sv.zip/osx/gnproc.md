# gnproc

> Det här kommandot är ett alias för `-p linux nproc`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux nproc`
