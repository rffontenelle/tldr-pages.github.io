# glibtool

> Det här kommandot är ett alias för `-p linux libtool`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux libtool`
