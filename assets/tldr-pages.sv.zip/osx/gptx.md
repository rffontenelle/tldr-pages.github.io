# gptx

> Det här kommandot är ett alias för `-p linux ptx`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ptx`
