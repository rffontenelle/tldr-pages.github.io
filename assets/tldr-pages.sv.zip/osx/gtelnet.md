# gtelnet

> Det här kommandot är ett alias för `-p linux telnet`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux telnet`
