# grmdir

> Det här kommandot är ett alias för `-p linux rmdir`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux rmdir`
