# gid

> Det här kommandot är ett alias för `-p linux id`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux id`
