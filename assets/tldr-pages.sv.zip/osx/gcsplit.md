# gcsplit

> Det här kommandot är ett alias för `-p linux csplit`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux csplit`
