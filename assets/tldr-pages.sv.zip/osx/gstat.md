# gstat

> Det här kommandot är ett alias för `-p linux stat`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux stat`
