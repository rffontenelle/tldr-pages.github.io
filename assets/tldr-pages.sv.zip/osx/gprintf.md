# gprintf

> Det här kommandot är ett alias för `-p linux printf`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux printf`
