# gupdatedb

> Det här kommandot är ett alias för `-p linux updatedb`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux updatedb`
