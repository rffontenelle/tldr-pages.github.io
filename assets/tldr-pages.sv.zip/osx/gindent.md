# gindent

> Det här kommandot är ett alias för `-p linux indent`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux indent`
