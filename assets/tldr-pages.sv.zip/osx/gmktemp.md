# gmktemp

> Det här kommandot är ett alias för `-p linux mktemp`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux mktemp`
