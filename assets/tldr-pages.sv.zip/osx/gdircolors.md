# gdircolors

> Det här kommandot är ett alias för `-p linux dircolors`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux dircolors`
