# gtftp

> Det här kommandot är ett alias för `-p linux tftp`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux tftp`
