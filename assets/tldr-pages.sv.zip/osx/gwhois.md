# gwhois

> Det här kommandot är ett alias för `-p linux whois`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux whois`
