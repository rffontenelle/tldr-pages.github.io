# gyes

> Det här kommandot är ett alias för `-p linux yes`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux yes`
