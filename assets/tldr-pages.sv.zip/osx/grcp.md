# grcp

> Det här kommandot är ett alias för `-p linux rcp`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux rcp`
