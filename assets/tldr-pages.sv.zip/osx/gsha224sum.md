# gsha224sum

> Det här kommandot är ett alias för `-p linux sha224sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sha224sum`
