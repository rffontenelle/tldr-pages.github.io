# gchown

> Det här kommandot är ett alias för `-p linux chown`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux chown`
