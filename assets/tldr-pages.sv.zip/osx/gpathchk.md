# gpathchk

> Det här kommandot är ett alias för `-p linux pathchk`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux pathchk`
