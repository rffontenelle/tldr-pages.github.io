# gmkfifo

> Det här kommandot är ett alias för `-p linux mkfifo`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux mkfifo`
