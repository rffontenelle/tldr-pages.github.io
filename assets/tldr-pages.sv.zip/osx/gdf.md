# gdf

> Det här kommandot är ett alias för `-p linux df`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux df`
