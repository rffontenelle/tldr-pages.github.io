# glink

> Det här kommandot är ett alias för `-p linux link`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux link`
