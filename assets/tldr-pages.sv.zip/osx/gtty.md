# gtty

> Det här kommandot är ett alias för `-p linux tty`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux tty`
