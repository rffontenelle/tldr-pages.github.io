# ggrep

> Det här kommandot är ett alias för `-p linux grep`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux grep`
