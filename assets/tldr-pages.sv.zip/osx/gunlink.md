# gunlink

> Det här kommandot är ett alias för `-p linux unlink`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux unlink`
