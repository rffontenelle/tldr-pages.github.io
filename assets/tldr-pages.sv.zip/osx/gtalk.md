# gtalk

> Det här kommandot är ett alias för `-p linux talk`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux talk`
