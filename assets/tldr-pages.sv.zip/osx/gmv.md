# gmv

> Det här kommandot är ett alias för `-p linux mv`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux mv`
