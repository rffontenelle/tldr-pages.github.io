# gunits

> Det här kommandot är ett alias för `-p linux units`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux units`
