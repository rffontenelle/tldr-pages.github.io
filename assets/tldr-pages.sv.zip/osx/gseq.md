# gseq

> Det här kommandot är ett alias för `-p linux seq`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux seq`
