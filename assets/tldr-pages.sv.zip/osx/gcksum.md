# gcksum

> Det här kommandot är ett alias för `-p linux cksum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux cksum`
