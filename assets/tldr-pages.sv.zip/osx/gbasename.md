# gbasename

> Det här kommandot är ett alias för `-p linux basename`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux basename`
