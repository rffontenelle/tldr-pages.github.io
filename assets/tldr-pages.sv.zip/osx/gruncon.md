# gruncon

> Det här kommandot är ett alias för `-p linux runcon`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux runcon`
