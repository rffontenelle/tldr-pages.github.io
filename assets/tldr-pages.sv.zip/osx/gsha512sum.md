# gsha512sum

> Det här kommandot är ett alias för `-p linux sha512sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sha512sum`
