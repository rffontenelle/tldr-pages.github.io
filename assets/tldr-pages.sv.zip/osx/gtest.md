# gtest

> Det här kommandot är ett alias för `-p linux test`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux test`
