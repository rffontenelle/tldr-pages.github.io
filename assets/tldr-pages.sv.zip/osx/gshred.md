# gshred

> Det här kommandot är ett alias för `-p linux shred`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux shred`
