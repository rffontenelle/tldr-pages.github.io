# ghead

> Det här kommandot är ett alias för `-p linux head`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux head`
