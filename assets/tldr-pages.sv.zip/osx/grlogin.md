# grlogin

> Det här kommandot är ett alias för `-p linux rlogin`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux rlogin`
