# gshuf

> Det här kommandot är ett alias för `-p linux shuf`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux shuf`
