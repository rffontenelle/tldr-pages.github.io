# ginstall

> Det här kommandot är ett alias för `-p linux install`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux install`
