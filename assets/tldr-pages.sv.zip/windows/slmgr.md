# slmgr

> Det här kommandot är ett alias för `slmgr.vbs`.
> Mer information: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Se dokumentationen för orginalkommandot:

`tldr slmgr.vbs`
