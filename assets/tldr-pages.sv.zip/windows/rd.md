# rd

> Det här kommandot är ett alias för `rmdir`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Se dokumentationen för orginalkommandot:

`tldr rmdir`
