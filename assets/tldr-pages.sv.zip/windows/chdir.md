# chdir

> Det här kommandot är ett alias för `cd`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Se dokumentationen för orginalkommandot:

`tldr cd`
