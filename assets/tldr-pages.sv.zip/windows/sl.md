# sl

> Det här kommandot är ett alias för `set-location`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Se dokumentationen för orginalkommandot:

`tldr set-location`
