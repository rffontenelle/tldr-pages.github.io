# ni

> Det här kommandot är ett alias för `new-item`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Se dokumentationen för orginalkommandot:

`tldr new-item`
