# sc-config

> Det här kommandot är ett alias för `sc`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Se dokumentationen för orginalkommandot:

`tldr sc`
