# del

> Det här kommandot är ett alias för `remove-item`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Se dokumentationen för orginalkommandot:

`tldr remove-item`
