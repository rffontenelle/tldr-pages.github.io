# sls

> Det här kommandot är ett alias för `where-object`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Se dokumentationen för orginalkommandot:

`tldr where-object`
