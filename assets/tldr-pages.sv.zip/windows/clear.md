# clear

> Det här kommandot är ett alias för `clear-host`.

- Se dokumentationen för orginalkommandot:

`tldr clear-host`
