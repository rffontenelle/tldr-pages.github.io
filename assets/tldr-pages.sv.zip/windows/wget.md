# wget

> Det här kommandot är ett alias för `wget -p common`.
> Mer information: <https://www.gnu.org/software/wget>.

- Se dokumentationen för orginalkommandot:

`tldr wget -p common`
