# cd

> Det här kommandot är ett alias för `set-location`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Se dokumentationen för orginalkommandot:

`tldr set-location`
