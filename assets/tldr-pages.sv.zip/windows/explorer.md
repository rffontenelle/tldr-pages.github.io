# explorer

> Windows Utforskaren.
> Mer information: <https://ss64.com/nt/explorer.html>.

- Öppna Utforskaren:

`explorer`

- Öppna Utforskaren i den aktuella katalogen:

`explorer .`

- Öppna Utforskaren i en specifik katalog/mapp:

`explorer {{länk/till/katalog}}`
