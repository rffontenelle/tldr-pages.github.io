# sc-query

> Det här kommandot är ett alias för `sc`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Se dokumentationen för orginalkommandot:

`tldr sc`
