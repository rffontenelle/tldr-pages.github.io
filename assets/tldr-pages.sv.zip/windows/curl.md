# curl

> Det här kommandot är ett alias för `curl -p common`.
> Mer information: <https://curl.se>.

- Se dokumentationen för orginalkommandot:

`tldr curl -p common`
