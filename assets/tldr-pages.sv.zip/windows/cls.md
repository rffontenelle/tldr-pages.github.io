# cls

> Det här kommandot är ett alias för `clear-host`.
> Mer information: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Se dokumentationen för orginalkommandot:

`tldr clear-host`
