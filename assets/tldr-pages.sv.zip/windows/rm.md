# rm

> Det här kommandot är ett alias för `remove-item`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Se dokumentationen för orginalkommandot:

`tldr remove-item`
