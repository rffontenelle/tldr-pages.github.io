# gal

> Det här kommandot är ett alias för `get-alias`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Se dokumentationen för orginalkommandot:

`tldr get-alias`
