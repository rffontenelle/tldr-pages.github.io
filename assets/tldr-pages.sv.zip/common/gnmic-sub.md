# gnmic-sub

> Det här kommandot är ett alias för `gnmic subscribe`.
> Mer information: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Se dokumentationen för orginalkommandot:

`tldr gnmic subscribe`
