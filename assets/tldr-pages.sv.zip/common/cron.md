# cron

> Det här kommandot är ett alias för `crontab`.

- Se dokumentationen för orginalkommandot:

`tldr crontab`
