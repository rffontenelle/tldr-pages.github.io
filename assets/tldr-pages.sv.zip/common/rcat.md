# rcat

> Det här kommandot är ett alias för `rc`.

- Se dokumentationen för orginalkommandot:

`tldr rc`
