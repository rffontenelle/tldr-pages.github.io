# lzmore

> Det här kommandot är ett alias för `xzmore`.

- Se dokumentationen för orginalkommandot:

`tldr xzmore`
