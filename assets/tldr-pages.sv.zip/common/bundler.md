# bundler

> Det här kommandot är ett alias för `bundle`.
> Mer information: <https://bundler.io/man/bundle.1.html>.

- Se dokumentationen för orginalkommandot:

`tldr bundle`
