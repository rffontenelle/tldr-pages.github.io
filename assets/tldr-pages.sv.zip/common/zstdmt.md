# zstdmt

> Det här kommandot är ett alias för `zstd`.

- Se dokumentationen för orginalkommandot:

`tldr zstd`
