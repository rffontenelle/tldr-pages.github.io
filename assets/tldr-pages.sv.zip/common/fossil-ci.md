# fossil-ci

> Det här kommandot är ett alias för `fossil-commit`.
> Mer information: <https://fossil-scm.org/home/help/commit>.

- Se dokumentationen för orginalkommandot:

`tldr fossil-commit`
