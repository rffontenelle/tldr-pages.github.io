# lzless

> Det här kommandot är ett alias för `xzless`.

- Se dokumentationen för orginalkommandot:

`tldr xzless`
