# fossil-delete

> Det här kommandot är ett alias för `fossil rm`.
> Mer information: <https://fossil-scm.org/home/help/delete>.

- Se dokumentationen för orginalkommandot:

`tldr fossil rm`
