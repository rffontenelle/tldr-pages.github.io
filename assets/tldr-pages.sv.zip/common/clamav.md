# clamav

> Det här kommandot är ett alias för `clamdscan`.
> Mer information: <https://www.clamav.net>.

- Se dokumentationen för orginalkommandot:

`tldr clamdscan`
