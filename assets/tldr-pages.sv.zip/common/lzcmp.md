# lzcmp

> Det här kommandot är ett alias för `xzcmp`.

- Se dokumentationen för orginalkommandot:

`tldr xzcmp`
