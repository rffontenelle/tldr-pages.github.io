# just

> Det här kommandot är ett alias för `just.1`.

- Se dokumentationen för orginalkommandot:

`tldr just.1`
