# xzegrep

> Det här kommandot är ett alias för `xzgrep`.

- Se dokumentationen för orginalkommandot:

`tldr xzgrep`
