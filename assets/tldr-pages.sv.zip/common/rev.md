# rev

> Omvänd en textrad.
> Mer information: <https://manned.org/rev>.

- Omvänd textraden "hello":

`echo "hello" | rev`

- Omvänd hel fil och skriv till `stdout`:

`rev {{fil}}`
