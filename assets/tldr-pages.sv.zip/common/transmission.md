# transmission

> Det här kommandot är ett alias för `transmission-daemon`.
> Mer information: <https://transmissionbt.com/>.

- Se dokumentationen för orginalkommandot:

`tldr transmission-daemon`
