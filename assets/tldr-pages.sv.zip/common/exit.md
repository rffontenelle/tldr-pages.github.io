# exit

> Avsluta shell.
> Mer information: <https://manned.org/exit.1posix>.

- Avsluta shell med utgångskoden från det senast utförda kommandot:

`exit`

- Avsluta shell med den angivna utgångskoden:

`exit {{utgångskoden}}`
