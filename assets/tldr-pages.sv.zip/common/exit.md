# exit

> Avsluta shell.
> Mer information: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#exit>.

- Avsluta shell med utgångskoden från det senast utförda kommandot:

`exit`

- Avsluta shell med den angivna utgångskoden:

`exit {{utgångskoden}}`
