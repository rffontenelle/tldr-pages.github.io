# open

> Det här kommandot är ett alias för `open -p osx`.

- Se dokumentationen för orginalkommandot:

`tldr open -p osx`
