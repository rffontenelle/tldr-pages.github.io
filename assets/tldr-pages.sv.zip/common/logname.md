# logname

> Visar användarens inloggningsnamn.
> Mer information: <https://www.gnu.org/software/coreutils/logname>.

- Visa den för tillfället inloggades användarnamn:

`logname`
