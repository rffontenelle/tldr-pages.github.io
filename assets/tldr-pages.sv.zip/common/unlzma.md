# unlzma

> Det här kommandot är ett alias för `xz`.
> Mer information: <https://manned.org/unlzma>.

- Se dokumentationen för orginalkommandot:

`tldr xz`
