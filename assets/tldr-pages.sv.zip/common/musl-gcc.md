# musl-gcc

> Det här kommandot är ett alias för `gcc`.
> Mer information: <https://manned.org/musl-gcc>.

- Se dokumentationen för orginalkommandot:

`tldr gcc`
