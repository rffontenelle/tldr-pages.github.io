# zless

> Visa komprimerade filer.
> Mer information: <https://manned.org/zless>.

- Bläddra igenom ett komprimerat arkiv med `less`:

`zless {{fil.txt.gz}}`
