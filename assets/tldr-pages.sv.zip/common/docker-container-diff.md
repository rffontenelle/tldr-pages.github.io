# docker-container-diff

> Det här kommandot är ett alias för `docker diff`.
> Mer information: <https://docs.docker.com/engine/reference/commandline/diff>.

- Se dokumentationen för orginalkommandot:

`tldr docker diff`
