# visudo

> Redigera sudoers-filen på säkert sätt.
> Mer information: <https://www.sudo.ws/docs/man/visudo.man>.

- Redigera sudoers-filen:

`sudo visudo`

- Sök fel i sudoers-filen:

`sudo visudo -c`
