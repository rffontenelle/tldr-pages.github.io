# docker-container-rm

> Det här kommandot är ett alias för `docker rm`.
> Mer information: <https://docs.docker.com/engine/reference/commandline/rm>.

- Se dokumentationen för orginalkommandot:

`tldr docker rm`
