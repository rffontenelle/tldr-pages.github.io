# pwsh

> Det här kommandot är ett alias för `powershell`.

- Se dokumentationen för orginalkommandot:

`tldr powershell`
