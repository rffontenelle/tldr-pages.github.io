# hping

> Det här kommandot är ett alias för `hping3`.
> Mer information: <https://github.com/antirez/hping>.

- Se dokumentationen för orginalkommandot:

`tldr hping3`
