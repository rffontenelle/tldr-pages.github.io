# llvm-objdump

> Det här kommandot är ett alias för `objdump`.

- Se dokumentationen för orginalkommandot:

`tldr objdump`
