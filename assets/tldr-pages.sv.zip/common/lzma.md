# lzma

> Det här kommandot är ett alias för `xz`.
> Mer information: <https://manned.org/lzma>.

- Se dokumentationen för orginalkommandot:

`tldr xz`
