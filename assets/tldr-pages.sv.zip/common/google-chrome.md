# google-chrome

> Det här kommandot är ett alias för `chromium`.
> Mer information: <https://chrome.google.com>.

- Se dokumentationen för orginalkommandot:

`tldr chromium`
