# docker-container-rename

> Det här kommandot är ett alias för `docker rename`.
> Mer information: <https://docs.docker.com/engine/reference/commandline/rename>.

- Se dokumentationen för orginalkommandot:

`tldr docker rename`
