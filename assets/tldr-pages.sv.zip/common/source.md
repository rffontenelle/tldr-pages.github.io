# source

> Kör kommandon från en fil i det aktuella skalet.
> Mer information: <https://manned.org/source>.

- Utvärdera innehållet i en viss fil:

`source {{väg/till/fil}}`
