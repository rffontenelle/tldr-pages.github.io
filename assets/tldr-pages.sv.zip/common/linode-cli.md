# linode-cli

> Det här kommandot är ett alias för `linode-cli account`.
> Mer information: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Se dokumentationen för orginalkommandot:

`tldr linode-cli account`
