# azure-cli

> Det här kommandot är ett alias för `az`.
> Mer information: <https://learn.microsoft.com/cli/azure>.

- Se dokumentationen för orginalkommandot:

`tldr az`
