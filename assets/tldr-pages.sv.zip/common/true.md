# true

> Returnerar en lyckad utgångsstatuskod på 0.
> Använd detta med || operatör för att göra att ett kommando alltid stänger med 0.
> Mer information: <https://www.gnu.org/software/coreutils/true>.

- Returnera en lyckad utgångskod:

`true`
