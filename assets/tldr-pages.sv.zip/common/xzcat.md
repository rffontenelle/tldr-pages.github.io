# xzcat

> Det här kommandot är ett alias för `xz`.
> Mer information: <https://manned.org/xzcat>.

- Se dokumentationen för orginalkommandot:

`tldr xz`
