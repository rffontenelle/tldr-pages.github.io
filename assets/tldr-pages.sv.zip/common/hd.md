# hd

> Det här kommandot är ett alias för `hexdump`.
> Mer information: <https://manned.org/hd.1>.

- Se dokumentationen för orginalkommandot:

`tldr hexdump`
