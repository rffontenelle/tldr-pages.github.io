# netcat

> Det här kommandot är ett alias för `nc`.

- Se dokumentationen för orginalkommandot:

`tldr nc`
