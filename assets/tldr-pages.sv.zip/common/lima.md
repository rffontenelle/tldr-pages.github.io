# lima

> Det här kommandot är ett alias för `limactl`.
> Mer information: <https://github.com/lima-vm/lima>.

- Se dokumentationen för orginalkommandot:

`tldr limactl`
