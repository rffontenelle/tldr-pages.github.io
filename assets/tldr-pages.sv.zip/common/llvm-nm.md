# llvm-nm

> Det här kommandot är ett alias för `nm`.

- Se dokumentationen för orginalkommandot:

`tldr nm`
