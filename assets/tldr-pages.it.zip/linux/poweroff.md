# poweroff

> Chiude il sistema.
> Maggiori informazioni: <https://www.manned.org/poweroff>.

- Spegne il sistema:

`sudo poweroff`
