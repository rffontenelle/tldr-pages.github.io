# ubuntu-bug

> Questo comando è un alias per `apport-bug`.
> Maggiori informazioni: <https://manned.org/ubuntu-bug>.

- Consulta la documentazione del comando originale:

`tldr apport-bug`
