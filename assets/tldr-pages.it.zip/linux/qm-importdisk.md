# qm-importdisk

> Questo comando è un alias per `qm disk import`.

- Consulta la documentazione del comando originale:

`tldr qm disk import`
