# cgroups

> Questo comando è un alias per `cgclassify`.
> Maggiori informazioni: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Consulta la documentazione del comando originale:

`tldr cgclassify`
