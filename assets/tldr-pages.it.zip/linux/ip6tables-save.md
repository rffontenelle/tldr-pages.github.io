# ip6tables-save

> Questo comando è un alias per `iptables-save`.

- Consulta la documentazione del comando originale:

`tldr iptables-save`
