# halt

> Arresta, spegne o riavvia la macchina.
> Maggiori informazioni: <https://www.man7.org/linux/man-pages/man8/halt.8.html>.

- Arresta la macchina:

`halt`

- Spegne la macchina:

`halt --poweroff`

- Riavvia la macchina:

`halt --reboot`
