# apx

> Questo comando è un alias per `apx pkgmanagers`.
> Maggiori informazioni: <https://github.com/Vanilla-OS/apx>.

- Consulta la documentazione del comando originale:

`tldr apx pkgmanagers`
