# ip-route-list

> Questo comando è un alias per `ip-route-show`.

- Consulta la documentazione del comando originale:

`tldr ip-route-show`
