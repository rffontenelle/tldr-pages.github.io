# shntool-split

> Questo comando è un alias per `shnsplit`.

- Consulta la documentazione del comando originale:

`tldr shnsplit`
