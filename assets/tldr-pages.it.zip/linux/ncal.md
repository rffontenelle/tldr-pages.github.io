# ncal

> Questo comando è un alias per `cal`.
> Maggiori informazioni: <https://manned.org/ncal>.

- Consulta la documentazione del comando originale:

`tldr cal`
