# cc

> Questo comando è un alias per `gcc`.
> Maggiori informazioni: <https://gcc.gnu.org>.

- Consulta la documentazione del comando originale:

`tldr gcc`
