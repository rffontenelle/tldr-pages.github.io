# nmtui-connect

> Questo comando è un alias per `nmtui`.

- Consulta la documentazione del comando originale:

`tldr nmtui`
