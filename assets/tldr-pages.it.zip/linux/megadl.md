# megadl

> Questo comando è un alias per `megatools-dl`.
> Maggiori informazioni: <https://megatools.megous.com/man/megatools-dl.html>.

- Consulta la documentazione del comando originale:

`tldr megatools-dl`
