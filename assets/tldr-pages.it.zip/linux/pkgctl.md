# pkgctl

> Questo comando è un alias per `pkgctl auth`.
> Maggiori informazioni: <https://man.archlinux.org/man/pkgctl.1>.

- Consulta la documentazione del comando originale:

`tldr pkgctl auth`
