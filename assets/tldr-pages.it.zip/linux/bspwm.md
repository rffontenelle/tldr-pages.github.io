# bspwm

> Questo comando è un alias per `bspc`.
> Maggiori informazioni: <https://github.com/baskerville/bspwm>.

- Consulta la documentazione del comando originale:

`tldr bspc`
