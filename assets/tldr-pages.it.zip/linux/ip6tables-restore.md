# ip6tables-restore

> Questo comando è un alias per `iptables-restore`.

- Consulta la documentazione del comando originale:

`tldr iptables-restore`
