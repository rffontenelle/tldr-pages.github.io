# gtraceroute

> Questo comando è un alias per `-p linux traceroute`.

- Consulta la documentazione del comando originale:

`tldr -p linux traceroute`
