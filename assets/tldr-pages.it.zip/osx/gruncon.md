# gruncon

> Questo comando è un alias per `-p linux runcon`.

- Consulta la documentazione del comando originale:

`tldr -p linux runcon`
