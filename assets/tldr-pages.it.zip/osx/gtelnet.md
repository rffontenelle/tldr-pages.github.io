# gtelnet

> Questo comando è un alias per `-p linux telnet`.

- Consulta la documentazione del comando originale:

`tldr -p linux telnet`
