# gsha512sum

> Questo comando è un alias per `-p linux sha512sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux sha512sum`
