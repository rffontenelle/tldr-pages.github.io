# gpr

> Questo comando è un alias per `-p linux pr`.

- Consulta la documentazione del comando originale:

`tldr -p linux pr`
