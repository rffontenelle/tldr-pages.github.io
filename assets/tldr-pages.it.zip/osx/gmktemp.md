# gmktemp

> Questo comando è un alias per `-p linux mktemp`.

- Consulta la documentazione del comando originale:

`tldr -p linux mktemp`
