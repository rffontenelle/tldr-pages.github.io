# gfind

> Questo comando è un alias per `-p linux find`.

- Consulta la documentazione del comando originale:

`tldr -p linux find`
