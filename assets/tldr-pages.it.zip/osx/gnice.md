# gnice

> Questo comando è un alias per `-p linux nice`.

- Consulta la documentazione del comando originale:

`tldr -p linux nice`
