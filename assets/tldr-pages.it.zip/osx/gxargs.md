# gxargs

> Questo comando è un alias per `-p linux xargs`.

- Consulta la documentazione del comando originale:

`tldr -p linux xargs`
