# ggrep

> Questo comando è un alias per `-p linux grep`.

- Consulta la documentazione del comando originale:

`tldr -p linux grep`
