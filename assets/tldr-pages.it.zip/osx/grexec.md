# grexec

> Questo comando è un alias per `-p linux rexec`.

- Consulta la documentazione del comando originale:

`tldr -p linux rexec`
