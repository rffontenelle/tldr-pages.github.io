# gping

> Questo comando è un alias per `-p linux ping`.

- Consulta la documentazione del comando originale:

`tldr -p linux ping`
