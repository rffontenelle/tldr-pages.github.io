# gsleep

> Questo comando è un alias per `-p linux sleep`.

- Consulta la documentazione del comando originale:

`tldr -p linux sleep`
