# grmdir

> Questo comando è un alias per `-p linux rmdir`.

- Consulta la documentazione del comando originale:

`tldr -p linux rmdir`
