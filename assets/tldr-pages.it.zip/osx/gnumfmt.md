# gnumfmt

> Questo comando è un alias per `-p linux numfmt`.

- Consulta la documentazione del comando originale:

`tldr -p linux numfmt`
