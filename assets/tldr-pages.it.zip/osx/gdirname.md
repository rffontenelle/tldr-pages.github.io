# gdirname

> Questo comando è un alias per `-p linux dirname`.

- Consulta la documentazione del comando originale:

`tldr -p linux dirname`
