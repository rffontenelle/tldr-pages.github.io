# glibtool

> Questo comando è un alias per `-p linux libtool`.

- Consulta la documentazione del comando originale:

`tldr -p linux libtool`
