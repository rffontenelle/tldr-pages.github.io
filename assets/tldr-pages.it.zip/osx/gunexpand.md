# gunexpand

> Questo comando è un alias per `-p linux unexpand`.

- Consulta la documentazione del comando originale:

`tldr -p linux unexpand`
