# gyes

> Questo comando è un alias per `-p linux yes`.

- Consulta la documentazione del comando originale:

`tldr -p linux yes`
