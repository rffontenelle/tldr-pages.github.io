# apachectl

> Interfaccia di controllo del server HTTP Apache per macOS.
> Maggiori informazioni: <https://keith.github.io/xcode-man-pages/apachectl.8.html>.

- Avvia il demone `org.apache.httpd`:

`apachectl start`

- Ferma il demone:

`apachectl stop`

- Riavvia il demone:

`apachectl restart`
