# gstat

> Questo comando è un alias per `-p linux stat`.

- Consulta la documentazione del comando originale:

`tldr -p linux stat`
