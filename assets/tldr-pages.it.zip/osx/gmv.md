# gmv

> Questo comando è un alias per `-p linux mv`.

- Consulta la documentazione del comando originale:

`tldr -p linux mv`
