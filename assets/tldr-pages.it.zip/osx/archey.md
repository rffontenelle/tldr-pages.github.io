# archey

> Semplice strumento per mostrare con stile le informazioni di sistema.
> Maggiori informazioni: <https://github.com/joshfinnie/archey-osx>.

- Mostra le informazioni di sistema:

`archey`

- Mostra le informazioni di sistema (senza colorazione del testo):

`archey --nocolor`

- Mostra le informazioni di sistema usando MacPorts invece di Homebrew:

`archey --macports`

- Mostra le informazioni di sistema senza controllare l'indirizzo IP:

`archey --offline`
