# gtail

> Questo comando è un alias per `-p linux tail`.

- Consulta la documentazione del comando originale:

`tldr -p linux tail`
