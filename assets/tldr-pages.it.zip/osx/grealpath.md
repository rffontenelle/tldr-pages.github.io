# grealpath

> Questo comando è un alias per `-p linux realpath`.

- Consulta la documentazione del comando originale:

`tldr -p linux realpath`
