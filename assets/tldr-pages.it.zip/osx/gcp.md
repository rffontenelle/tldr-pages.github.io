# gcp

> Questo comando è un alias per `-p linux cp`.

- Consulta la documentazione del comando originale:

`tldr -p linux cp`
