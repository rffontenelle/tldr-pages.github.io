# gbase64

> Questo comando è un alias per `-p linux base64`.

- Consulta la documentazione del comando originale:

`tldr -p linux base64`
