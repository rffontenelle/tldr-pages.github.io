# gstdbuf

> Questo comando è un alias per `-p linux stdbuf`.

- Consulta la documentazione del comando originale:

`tldr -p linux stdbuf`
