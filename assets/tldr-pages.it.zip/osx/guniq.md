# guniq

> Questo comando è un alias per `-p linux uniq`.

- Consulta la documentazione del comando originale:

`tldr -p linux uniq`
