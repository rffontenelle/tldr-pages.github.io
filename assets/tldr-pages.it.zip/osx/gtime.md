# gtime

> Questo comando è un alias per `-p linux time`.

- Consulta la documentazione del comando originale:

`tldr -p linux time`
