# gsort

> Questo comando è un alias per `-p linux sort`.

- Consulta la documentazione del comando originale:

`tldr -p linux sort`
