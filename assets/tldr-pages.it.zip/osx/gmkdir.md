# gmkdir

> Questo comando è un alias per `-p linux mkdir`.

- Consulta la documentazione del comando originale:

`tldr -p linux mkdir`
