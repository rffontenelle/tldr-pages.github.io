# gls

> Questo comando è un alias per `-p linux ls`.

- Consulta la documentazione del comando originale:

`tldr -p linux ls`
