# greadlink

> Questo comando è un alias per `-p linux readlink`.

- Consulta la documentazione del comando originale:

`tldr -p linux readlink`
