# gtar

> Questo comando è un alias per `-p linux tar`.

- Consulta la documentazione del comando originale:

`tldr -p linux tar`
