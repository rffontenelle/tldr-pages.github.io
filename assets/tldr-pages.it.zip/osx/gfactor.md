# gfactor

> Questo comando è un alias per `-p linux factor`.

- Consulta la documentazione del comando originale:

`tldr -p linux factor`
