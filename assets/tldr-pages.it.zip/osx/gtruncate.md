# gtruncate

> Questo comando è un alias per `-p linux truncate`.

- Consulta la documentazione del comando originale:

`tldr -p linux truncate`
