# gsum

> Questo comando è un alias per `-p linux sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux sum`
