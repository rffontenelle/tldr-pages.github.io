# gfold

> Questo comando è un alias per `-p linux fold`.

- Consulta la documentazione del comando originale:

`tldr -p linux fold`
