# gb2sum

> Questo comando è un alias per `-p linux b2sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux b2sum`
