# ged

> Questo comando è un alias per `-p linux ed`.

- Consulta la documentazione del comando originale:

`tldr -p linux ed`
