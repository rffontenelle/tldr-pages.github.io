# gmd5sum

> Questo comando è un alias per `-p linux md5sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux md5sum`
