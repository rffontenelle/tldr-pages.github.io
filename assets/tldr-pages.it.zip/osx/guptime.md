# guptime

> Questo comando è un alias per `-p linux uptime`.

- Consulta la documentazione del comando originale:

`tldr -p linux uptime`
