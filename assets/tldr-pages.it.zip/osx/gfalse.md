# gfalse

> Questo comando è un alias per `-p linux false`.

- Consulta la documentazione del comando originale:

`tldr -p linux false`
