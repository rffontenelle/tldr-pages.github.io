# grm

> Questo comando è un alias per `-p linux rm`.

- Consulta la documentazione del comando originale:

`tldr -p linux rm`
