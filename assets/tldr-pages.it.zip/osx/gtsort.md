# gtsort

> Questo comando è un alias per `-p linux tsort`.

- Consulta la documentazione del comando originale:

`tldr -p linux tsort`
