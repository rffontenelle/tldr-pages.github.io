# gchmod

> Questo comando è un alias per `-p linux chmod`.

- Consulta la documentazione del comando originale:

`tldr -p linux chmod`
