# gdate

> Questo comando è un alias per `-p linux date`.

- Consulta la documentazione del comando originale:

`tldr -p linux date`
