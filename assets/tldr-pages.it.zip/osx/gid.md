# gid

> Questo comando è un alias per `-p linux id`.

- Consulta la documentazione del comando originale:

`tldr -p linux id`
