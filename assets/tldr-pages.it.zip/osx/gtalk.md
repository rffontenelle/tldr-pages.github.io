# gtalk

> Questo comando è un alias per `-p linux talk`.

- Consulta la documentazione del comando originale:

`tldr -p linux talk`
