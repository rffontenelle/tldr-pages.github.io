# gtftp

> Questo comando è un alias per `-p linux tftp`.

- Consulta la documentazione del comando originale:

`tldr -p linux tftp`
