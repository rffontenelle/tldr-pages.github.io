# gexpr

> Questo comando è un alias per `-p linux expr`.

- Consulta la documentazione del comando originale:

`tldr -p linux expr`
