# gsha384sum

> Questo comando è un alias per `-p linux sha384sum`.

- Consulta la documentazione del comando originale:

`tldr -p linux sha384sum`
