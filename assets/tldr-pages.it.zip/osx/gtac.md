# gtac

> Questo comando è un alias per `-p linux tac`.

- Consulta la documentazione del comando originale:

`tldr -p linux tac`
