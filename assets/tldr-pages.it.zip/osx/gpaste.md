# gpaste

> Questo comando è un alias per `-p linux paste`.

- Consulta la documentazione del comando originale:

`tldr -p linux paste`
