# gawk

> Questo comando è un alias per `-p linux awk`.

- Consulta la documentazione del comando originale:

`tldr -p linux awk`
