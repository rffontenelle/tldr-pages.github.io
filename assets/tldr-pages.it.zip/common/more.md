# more

> Aprire un file per la lettura interattiva, con scorrimento e ricerca.
> Maggiori informazioni: <https://manned.org/more>.

- Apri un file:

`more {{percorso/del/file}}`

- Apri un file visualizzato da una riga specifica:

`more +{{linea_numero}} {{percorso/del/file}}`

- Mostra aiuto:

`more --help`

- Prossima pagina:

`<Spazio>`

- Cerca una stringa (tocca `n` per passare alla corrispondenza successiva):

`/{{qualcose}}`

- Smettere:

`q`

- Mostra aiuto per comando interattivo:

`h`
