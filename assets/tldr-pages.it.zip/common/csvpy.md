# csvpy

> Carica un file CSV in una shell Python.
> Incluso in csvkit.
> Maggiori informazioni: <https://csvkit.readthedocs.io/en/latest/scripts/csvpy.html>.

- Carica un file CSV in un oggetto `CSVKitReader`:

`csvpy {{data.csv}}`

- Carica un file CSV in un oggetto `CSVKitDictReader`:

`csvpy --dict {{data.csv}}`
