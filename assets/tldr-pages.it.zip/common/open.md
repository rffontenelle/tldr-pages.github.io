# open

> Questo comando è un alias per `open -p osx`.

- Consulta la documentazione del comando originale:

`tldr open -p osx`
