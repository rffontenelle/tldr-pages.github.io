# hping

> Questo comando è un alias per `hping3`.
> Maggiori informazioni: <https://github.com/antirez/hping>.

- Consulta la documentazione del comando originale:

`tldr hping3`
