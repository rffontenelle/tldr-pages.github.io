# docker-container-rename

> Questo comando è un alias per `docker rename`.
> Maggiori informazioni: <https://docs.docker.com/engine/reference/commandline/rename>.

- Consulta la documentazione del comando originale:

`tldr docker rename`
