# bastet

> Clone di Tetris nel Terminale.
> Maggiori informazioni: <https://fph.altervista.org/prog/bastet.html>.

- Invia un gioco tetris:

`bastet`

- Sposta il pezzo a sinistra o a destra:

`{{Sinistra|Destra}} freccia`

- Ruota in senso orario o inverso:

`{{Spazio|tasto freccia su}}`

- Caduta lenta:

`tasto freccia giù`

- Caduta veloce:

`<Invio>`

- Pausa:

`p`

- Lasciare il gioco:

`<Ctrl> + C`
