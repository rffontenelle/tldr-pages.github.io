# gh-cs

> Questo comando è un alias per `gh-codespace`.
> Maggiori informazioni: <https://cli.github.com/manual/gh_codespace>.

- Consulta la documentazione del comando originale:

`tldr gh-codespace`
