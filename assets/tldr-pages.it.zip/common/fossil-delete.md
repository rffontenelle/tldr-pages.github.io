# fossil delete

> Questo comando è un alias per `fossil rm`.
> Maggiori informazioni: <https://fossil-scm.org/home/help/delete>.

- Consulta la documentazione del comando originale:

`tldr fossil rm`
