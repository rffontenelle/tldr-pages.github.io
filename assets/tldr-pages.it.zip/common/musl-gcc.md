# musl-gcc

> Questo comando è un alias per `gcc`.
> Maggiori informazioni: <https://manned.org/musl-gcc>.

- Consulta la documentazione del comando originale:

`tldr gcc`
