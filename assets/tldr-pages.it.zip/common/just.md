# just

> Questo comando è un alias per `just.1`.

- Consulta la documentazione del comando originale:

`tldr just.1`
