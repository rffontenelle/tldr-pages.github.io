# tac

> Stampa e concatena file al contrario.
> Maggiori informazioni: <https://www.gnu.org/software/coreutils/tac>.

- Stampa il contenuto di *file1* al contrario su standard output:

`tac {{file1}}`

- Concatena multipli file al contrario in un nuovo file:

`tac {{file1}} {{file2}} > {{nuovo_file}}`
