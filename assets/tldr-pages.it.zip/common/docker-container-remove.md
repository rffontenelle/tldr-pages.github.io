# docker-container-remove

> Questo comando è un alias per `docker rm`.
> Maggiori informazioni: <https://docs.docker.com/engine/reference/commandline/rm>.

- Consulta la documentazione del comando originale:

`tldr docker rm`
