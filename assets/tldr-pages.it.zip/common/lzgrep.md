# lzgrep

> Questo comando è un alias per `xzgrep`.

- Consulta la documentazione del comando originale:

`tldr xzgrep`
