# azure-cli

> Questo comando è un alias per `az`.
> Maggiori informazioni: <https://learn.microsoft.com/cli/azure>.

- Consulta la documentazione del comando originale:

`tldr az`
