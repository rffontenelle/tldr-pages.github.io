# hd

> Questo comando è un alias per `hexdump`.
> Maggiori informazioni: <https://manned.org/hd.1>.

- Consulta la documentazione del comando originale:

`tldr hexdump`
