# netcat

> Questo comando è un alias per `nc`.

- Consulta la documentazione del comando originale:

`tldr nc`
