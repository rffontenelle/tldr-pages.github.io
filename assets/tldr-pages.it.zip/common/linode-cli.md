# linode-cli

> Questo comando è un alias per `linode-cli account`.
> Maggiori informazioni: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Consulta la documentazione del comando originale:

`tldr linode-cli account`
