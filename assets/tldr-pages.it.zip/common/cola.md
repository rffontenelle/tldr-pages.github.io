# cola

> Questo comando è un alias per `git-cola`.

- Consulta la documentazione del comando originale:

`tldr git-cola`
