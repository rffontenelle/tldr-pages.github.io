# aria2

> Questo comando è un alias per `aria2c`.

- Consulta la documentazione del comando originale:

`tldr aria2c`
