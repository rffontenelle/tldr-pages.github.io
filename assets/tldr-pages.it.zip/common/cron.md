# cron

> Questo comando è un alias per `crontab`.

- Consulta la documentazione del comando originale:

`tldr crontab`
