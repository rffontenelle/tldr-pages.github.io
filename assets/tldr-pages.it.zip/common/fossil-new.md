# fossil-new

> Questo comando è un alias per `fossil-init`.
> Maggiori informazioni: <https://fossil-scm.org/home/help/new>.

- Consulta la documentazione del comando originale:

`tldr fossil-init`
