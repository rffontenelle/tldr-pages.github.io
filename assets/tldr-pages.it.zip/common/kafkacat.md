# kafkacat

> Questo comando è un alias per `kcat`.

- Consulta la documentazione del comando originale:

`tldr kcat`
