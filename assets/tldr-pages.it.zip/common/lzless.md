# lzless

> Questo comando è un alias per `xzless`.

- Consulta la documentazione del comando originale:

`tldr xzless`
