# git stage

> Questo comando è un alias per `git add`.
> Maggiori informazioni: <https://git-scm.com/docs/git-stage>.

- Consulta la documentazione del comando originale:

`tldr git-add`
