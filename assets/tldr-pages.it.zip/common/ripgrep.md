# ripgrep

> Questo comando è un alias per `rg`.

- Consulta la documentazione del comando originale:

`tldr rg`
