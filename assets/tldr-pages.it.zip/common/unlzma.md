# unlzma

> Questo comando è un alias per `xz`.
> Maggiori informazioni: <https://manned.org/unlzma>.

- Consulta la documentazione del comando originale:

`tldr xz`
