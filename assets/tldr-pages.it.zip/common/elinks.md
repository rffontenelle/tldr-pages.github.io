# elinks

> Un browser testuale simile a lynx.
> Maggiori informazioni: <http://elinks.or.cz>.

- Avvia elinks:

`elinks`

- Termina elinks:

`<Ctrl> + C`

- Stampa l'output di una pagina web nella console, colorando il testo con codici di controllo ANSI:

`elinks -dump -dump-color-mode {{1}} {{url}}`
