# google-chrome

> Questo comando è un alias per `chromium`.
> Maggiori informazioni: <https://chrome.google.com>.

- Consulta la documentazione del comando originale:

`tldr chromium`
