# hx

> Questo comando è un alias per `helix`.

- Consulta la documentazione del comando originale:

`tldr helix`
