# unzstd

> Questo comando è un alias per `zstd`.

- Consulta la documentazione del comando originale:

`tldr zstd`
