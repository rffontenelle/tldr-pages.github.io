# llvm-nm

> Questo comando è un alias per `nm`.

- Consulta la documentazione del comando originale:

`tldr nm`
