# todoman

> Questo comando è un alias per `todo`.
> Maggiori informazioni: <https://todoman.readthedocs.io/>.

- Consulta la documentazione del comando originale:

`tldr todo`
