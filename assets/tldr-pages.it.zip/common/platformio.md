# platformio

> Questo comando è un alias per `pio`.
> Maggiori informazioni: <https://docs.platformio.org/en/latest/core/userguide/>.

- Consulta la documentazione del comando originale:

`tldr pio`
