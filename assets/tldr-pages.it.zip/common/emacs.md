# emacs

> Editor di testo in tempo reale, estendibile, personalizzabile e auto documentato.
> Maggiori informazioni: <https://www.gnu.org/software/emacs>.

- Avvia emacs in modalità console (senza finestra X):

`emacs -nw`

- Apri un file in emacs:

`emacs {{nome_file}}`

- Esci da emacs (salva i buffer e termina):

`<Ctrl> + X, <Ctrl> + C`
