# atrm

> Rimuovi job programmati dai comandi `at` o `batch`.
> Per trovare i numeri dei job utilizzare `atq`.
> Maggiori informazioni: <https://manned.org/atrm>.

- Rimuovi il job numero 10:

`atrm {{10}}`

- Rimuovi più job, separati da spazi:

`atrm {{15}} {{17}} {{22}}`
