# ntl

> Questo comando è un alias per `netlify`.
> Maggiori informazioni: <https://cli.netlify.com>.

- Consulta la documentazione del comando originale:

`tldr netlify`
