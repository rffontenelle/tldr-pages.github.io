# lima

> Questo comando è un alias per `limactl`.
> Maggiori informazioni: <https://github.com/lima-vm/lima>.

- Consulta la documentazione del comando originale:

`tldr limactl`
