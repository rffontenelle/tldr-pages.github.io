# deluged

> Un processo demone per il client BitTorrent Deluge.
> Maggiori informazioni: <https://deluge-torrent.org>.

- Avvia il demone di Deluge:

`deluged`

- Avvia il demone di Deluge su di una specifica porta:

`deluged -p {{porta}}`

- Avvia il demone di Deluge utilizzando uno specifico file di configurazione:

`deluged -c {{percorso/del/file_configurazione}}`

- Avvia il demone di Deluge e scrivi il log in un file:

`deluged -l {{percorso/del/file_log}}`
