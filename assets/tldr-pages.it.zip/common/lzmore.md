# lzmore

> Questo comando è un alias per `xzmore`.

- Consulta la documentazione del comando originale:

`tldr xzmore`
