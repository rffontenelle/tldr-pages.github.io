# tlmgr-arch

> Questo comando è un alias per `tlmgr platform`.
> Maggiori informazioni: <https://www.tug.org/texlive/tlmgr.html>.

- Consulta la documentazione del comando originale:

`tldr tlmgr platform`
