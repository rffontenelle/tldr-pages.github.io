# clamav

> Questo comando è un alias per `clamdscan`.
> Maggiori informazioni: <https://www.clamav.net>.

- Consulta la documentazione del comando originale:

`tldr clamdscan`
