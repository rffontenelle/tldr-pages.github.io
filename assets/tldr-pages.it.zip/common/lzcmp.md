# lzcmp

> Questo comando è un alias per `xzcmp`.

- Consulta la documentazione del comando originale:

`tldr xzcmp`
