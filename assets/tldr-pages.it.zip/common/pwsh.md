# pwsh

> Questo comando è un alias per `powershell`.

- Consulta la documentazione del comando originale:

`tldr powershell`
