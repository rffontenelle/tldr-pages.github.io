# docker-container-diff

> Questo comando è un alias per `docker diff`.
> Maggiori informazioni: <https://docs.docker.com/engine/reference/commandline/diff>.

- Consulta la documentazione del comando originale:

`tldr docker diff`
