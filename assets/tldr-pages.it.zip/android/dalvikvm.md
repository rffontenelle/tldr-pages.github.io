# dalvikvm

> Macchina virtuale Java per Android.
> Maggiori informazioni: <https://source.android.com/devices/tech/dalvik>.

- Lancia un programma Java:

`dalvikvm -classpath {{percorso/del/file.jar}} {{nomeclasse}}`
