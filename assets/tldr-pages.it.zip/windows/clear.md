# clear

> Questo comando è un alias per `clear-host`.

- Consulta la documentazione del comando originale:

`tldr clear-host`
