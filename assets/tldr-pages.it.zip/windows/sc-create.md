# sc-create

> Questo comando è un alias per `sc`.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Consulta la documentazione del comando originale:

`tldr sc`
