# wget

> Questo comando è un alias per `wget -p common`.
> Maggiori informazioni: <https://www.gnu.org/software/wget>.

- Consulta la documentazione del comando originale:

`tldr wget -p common`
