# wget

> Questo comando è un alias per `wget -p common`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Consulta la documentazione del comando originale:

`tldr wget -p common`
