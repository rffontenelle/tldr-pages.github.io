# del

> Questo comando è un alias per `remove-item`.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Consulta la documentazione del comando originale:

`tldr remove-item`
