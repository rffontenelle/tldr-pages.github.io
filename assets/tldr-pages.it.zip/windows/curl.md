# curl

> Questo comando è un alias per `curl -p common`.
> Maggiori informazioni: <https://curl.se>.

- Consulta la documentazione del comando originale:

`tldr curl -p common`
