# slmgr

> Questo comando è un alias per `slmgr.vbs`.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Consulta la documentazione del comando originale:

`tldr slmgr.vbs`
