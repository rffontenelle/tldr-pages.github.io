# cls

> Pulisce lo schermo del terminale.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Pulisce lo schermo:

`cls`
