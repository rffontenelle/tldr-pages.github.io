# cls

> Questo comando è un alias per `clear-host`.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Consulta la documentazione del comando originale:

`tldr clear-host`
