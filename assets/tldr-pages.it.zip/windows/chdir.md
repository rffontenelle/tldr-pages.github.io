# chdir

> Questo comando è un alias per `cd`.
> Maggiori informazioni: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Consulta la documentazione del comando originale:

`tldr cd`
