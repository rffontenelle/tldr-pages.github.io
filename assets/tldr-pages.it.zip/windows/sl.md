# sl

> Questo comando è un alias per `set-location`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Consulta la documentazione del comando originale:

`tldr set-location`
