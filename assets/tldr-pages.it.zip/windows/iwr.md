# iwr

> Questo comando è un alias per `invoke-webrequest`.

- Consulta la documentazione del comando originale:

`tldr invoke-webrequest`
