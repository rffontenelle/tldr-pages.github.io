# gal

> Questo comando è un alias per `get-alias`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Consulta la documentazione del comando originale:

`tldr get-alias`
