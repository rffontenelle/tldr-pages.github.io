# sls

> Questo comando è un alias per `where-object`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Consulta la documentazione del comando originale:

`tldr where-object`
