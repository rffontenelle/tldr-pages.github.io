# ni

> Questo comando è un alias per `new-item`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Consulta la documentazione del comando originale:

`tldr new-item`
