# ri

> Questo comando è un alias per `remove-item`.
> Maggiori informazioni: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Consulta la documentazione del comando originale:

`tldr remove-item`
