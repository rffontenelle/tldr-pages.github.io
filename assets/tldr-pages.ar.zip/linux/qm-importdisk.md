# qm-importdisk

> هذا الأمر هو اسم مستعار لـ `qm disk import`.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm disk import`
