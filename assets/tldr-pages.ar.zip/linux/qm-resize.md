# qm-resize

> هذا الأمر هو اسم مستعار لـ `qm-disk-resize`.
> لمزيد من التفاصيل: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm-disk-resize`
