# nmcli

> هذا الأمر هو اسم مستعار لـ `nmcli agent`.
> لمزيد من التفاصيل: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr nmcli agent`
