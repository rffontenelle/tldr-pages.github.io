# mount.smb3

> هذا الأمر هو اسم مستعار لـ `mount.cifs`.

- إعرض التوثيقات للأمر الأصلي:

`tldr mount.cifs`
