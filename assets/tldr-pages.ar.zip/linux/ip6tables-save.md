# ip6tables-save

> هذا الأمر هو اسم مستعار لـ `iptables-save`.

- إعرض التوثيقات للأمر الأصلي:

`tldr iptables-save`
