# ip6tables-restore

> هذا الأمر هو اسم مستعار لـ `iptables-restore`.

- إعرض التوثيقات للأمر الأصلي:

`tldr iptables-restore`
