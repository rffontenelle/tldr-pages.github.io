# ip6tables

> هذا الأمر هو اسم مستعار لـ `iptables`.

- إعرض التوثيقات للأمر الأصلي:

`tldr iptables`
