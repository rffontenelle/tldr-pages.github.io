# qm-move-disk

> هذا الأمر هو اسم مستعار لـ `qm-disk-move`.
> لمزيد من التفاصيل: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm-disk-move`
