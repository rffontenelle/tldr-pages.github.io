# batcat

> هذا الأمر هو اسم مستعار لـ `bat`.
> لمزيد من التفاصيل: <https://github.com/sharkdp/bat>.

- إعرض التوثيقات للأمر الأصلي:

`tldr bat`
