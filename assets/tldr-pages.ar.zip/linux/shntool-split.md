# shntool-split

> هذا الأمر هو اسم مستعار لـ `shnsplit`.

- إعرض التوثيقات للأمر الأصلي:

`tldr shnsplit`
