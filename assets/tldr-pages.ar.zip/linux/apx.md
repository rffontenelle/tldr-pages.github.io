# apx

> هذا الأمر هو اسم مستعار لـ `apx pkgmanagers`.
> لمزيد من التفاصيل: <https://github.com/Vanilla-OS/apx>.

- إعرض التوثيقات للأمر الأصلي:

`tldr apx pkgmanagers`
