# distrobox

> هذا الأمر هو اسم مستعار لـ `distrobox-create`.
> لمزيد من التفاصيل: <https://github.com/89luca89/distrobox>.

- إعرض التوثيقات للأمر الأصلي:

`tldr distrobox-create`
