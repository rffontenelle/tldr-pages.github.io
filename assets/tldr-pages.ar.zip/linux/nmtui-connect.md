# nmtui-connect

> هذا الأمر هو اسم مستعار لـ `nmtui`.

- إعرض التوثيقات للأمر الأصلي:

`tldr nmtui`
