# cgroups

> هذا الأمر هو اسم مستعار لـ `cgclassify`.
> لمزيد من التفاصيل: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- إعرض التوثيقات للأمر الأصلي:

`tldr cgclassify`
