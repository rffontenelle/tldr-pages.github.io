# systemd-umount

> هذا الأمر هو اسم مستعار لـ `systemd-mount`.

- إعرض التوثيقات للأمر الأصلي:

`tldr systemd-mount`
