# megadl

> هذا الأمر هو اسم مستعار لـ `megatools-dl`.
> لمزيد من التفاصيل: <https://megatools.megous.com/man/megatools-dl.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr megatools-dl`
