# xbps

> هذا الأمر هو اسم مستعار لـ `xbps-install`.
> لمزيد من التفاصيل: <https://docs.voidlinux.org/xbps/index.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr xbps-install`
