# pkgctl

> هذا الأمر هو اسم مستعار لـ `pkgctl auth`.
> لمزيد من التفاصيل: <https://man.archlinux.org/man/pkgctl.1>.

- إعرض التوثيقات للأمر الأصلي:

`tldr pkgctl auth`
