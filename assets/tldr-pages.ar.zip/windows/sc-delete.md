# sc-delete

> هذا الأمر هو اسم مستعار لـ `sc`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- إعرض التوثيقات للأمر الأصلي:

`tldr sc`
