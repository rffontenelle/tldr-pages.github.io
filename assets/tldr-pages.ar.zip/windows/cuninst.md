# cuninst

> هذا الأمر هو اسم مستعار لـ `choco uninstall`.
> لمزيد من التفاصيل: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco uninstall`
