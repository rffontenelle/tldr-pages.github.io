# ni

> هذا الأمر هو اسم مستعار لـ `new-item`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- إعرض التوثيقات للأمر الأصلي:

`tldr new-item`
