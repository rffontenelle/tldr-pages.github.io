# rmdir

> هذا الأمر هو اسم مستعار لـ `remove-item`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- إعرض التوثيقات للأمر الأصلي:

`tldr remove-item`
