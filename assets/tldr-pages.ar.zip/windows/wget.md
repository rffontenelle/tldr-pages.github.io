# wget

> هذا الأمر هو اسم مستعار لـ `wget -p common`.
> لمزيد من التفاصيل: <https://www.gnu.org/software/wget>.

- إعرض التوثيقات للأمر الأصلي:

`tldr wget -p common`
