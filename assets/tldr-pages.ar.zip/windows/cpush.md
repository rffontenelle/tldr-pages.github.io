# cpush

> هذا الأمر هو اسم مستعار لـ `choco-push`.
> لمزيد من التفاصيل: <https://docs.chocolatey.org/en-us/create/commands/push>.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco-push`
