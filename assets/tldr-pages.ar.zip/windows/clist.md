# clist

> هذا الأمر هو اسم مستعار لـ `choco list`.
> لمزيد من التفاصيل: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco list`
