# cd

> هذا الأمر هو اسم مستعار لـ `set-location`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- إعرض التوثيقات للأمر الأصلي:

`tldr set-location`
