# gal

> هذا الأمر هو اسم مستعار لـ `get-alias`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- إعرض التوثيقات للأمر الأصلي:

`tldr get-alias`
