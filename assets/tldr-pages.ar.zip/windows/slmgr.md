# slmgr

> هذا الأمر هو اسم مستعار لـ `slmgr.vbs`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- إعرض التوثيقات للأمر الأصلي:

`tldr slmgr.vbs`
