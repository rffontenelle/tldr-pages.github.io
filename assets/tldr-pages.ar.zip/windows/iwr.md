# iwr

> هذا الأمر هو اسم مستعار لـ `invoke-webrequest`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- إعرض التوثيقات للأمر الأصلي:

`tldr invoke-webrequest`
