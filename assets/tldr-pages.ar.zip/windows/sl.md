# sl

> هذا الأمر هو اسم مستعار لـ `set-location`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- إعرض التوثيقات للأمر الأصلي:

`tldr set-location`
