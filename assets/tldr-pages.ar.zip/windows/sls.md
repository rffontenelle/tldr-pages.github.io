# sls

> هذا الأمر هو اسم مستعار لـ `Select-String`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- إعرض التوثيقات للأمر الأصلي:

`tldr select-string`
