# chdir

> هذا الأمر هو اسم مستعار لـ `cd`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- إعرض التوثيقات للأمر الأصلي:

`tldr cd`
