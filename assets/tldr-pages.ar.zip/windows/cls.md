# cls

> هذا الأمر هو اسم مستعار لـ `clear-host`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- إعرض التوثيقات للأمر الأصلي:

`tldr clear-host`
