# chrome

> هذا الأمر هو اسم مستعار لـ `chromium`.
> لمزيد من التفاصيل: <https://chrome.google.com>.

- إعرض التوثيقات للأمر الأصلي:

`tldr chromium`
