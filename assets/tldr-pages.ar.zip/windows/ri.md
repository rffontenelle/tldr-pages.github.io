# ri

> هذا الأمر هو اسم مستعار لـ `remove-item`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- إعرض التوثيقات للأمر الأصلي:

`tldr remove-item`
