# clear

> هذا الأمر هو اسم مستعار لـ `clear-host`.

- إعرض التوثيقات للأمر الأصلي:

`tldr clear-host`
