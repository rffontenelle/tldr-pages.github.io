# pkg

> هذا الأمر هو اسم مستعار لـ `pkg_add`.
> لمزيد من التفاصيل: <https://www.openbsd.org/faq/faq15.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr pkg_add`
