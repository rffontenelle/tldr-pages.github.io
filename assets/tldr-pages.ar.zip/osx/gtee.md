# gtee

> هذا الأمر هو اسم مستعار لـ `-p linux tee`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux tee`
