# gchroot

> هذا الأمر هو اسم مستعار لـ `-p linux chroot`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux chroot`
