# gtest

> هذا الأمر هو اسم مستعار لـ `-p linux test`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux test`
