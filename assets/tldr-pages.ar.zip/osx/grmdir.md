# grmdir

> هذا الأمر هو اسم مستعار لـ `-p linux rmdir`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux rmdir`
