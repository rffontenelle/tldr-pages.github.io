# gseq

> هذا الأمر هو اسم مستعار لـ `-p linux seq`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux seq`
