# gprintenv

> هذا الأمر هو اسم مستعار لـ `-p linux printenv`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux printenv`
