# gchcon

> هذا الأمر هو اسم مستعار لـ `-p linux chcon`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux chcon`
