# gsed

> هذا الأمر هو اسم مستعار لـ `-p linux sed`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sed`
