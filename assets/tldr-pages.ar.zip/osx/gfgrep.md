# gfgrep

> هذا الأمر هو اسم مستعار لـ `-p linux fgrep`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux fgrep`
