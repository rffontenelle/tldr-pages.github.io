# gtouch

> هذا الأمر هو اسم مستعار لـ `-p linux touch`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux touch`
