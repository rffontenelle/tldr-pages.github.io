# gmktemp

> هذا الأمر هو اسم مستعار لـ `-p linux mktemp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux mktemp`
