# gpathchk

> هذا الأمر هو اسم مستعار لـ `-p linux pathchk`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux pathchk`
