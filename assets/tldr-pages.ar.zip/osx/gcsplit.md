# gcsplit

> هذا الأمر هو اسم مستعار لـ `-p linux csplit`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux csplit`
