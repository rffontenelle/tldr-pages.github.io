# gwho

> هذا الأمر هو اسم مستعار لـ `-p linux who`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux who`
