# gdate

> هذا الأمر هو اسم مستعار لـ `-p linux date`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux date`
