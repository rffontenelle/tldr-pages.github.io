# guptime

> هذا الأمر هو اسم مستعار لـ `-p linux uptime`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux uptime`
