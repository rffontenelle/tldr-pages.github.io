# gyes

> هذا الأمر هو اسم مستعار لـ `-p linux yes`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux yes`
