# gcomm

> هذا الأمر هو اسم مستعار لـ `-p linux comm`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux comm`
