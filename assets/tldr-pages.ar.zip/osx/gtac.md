# gtac

> هذا الأمر هو اسم مستعار لـ `-p linux tac`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux tac`
