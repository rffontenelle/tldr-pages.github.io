# gruncon

> هذا الأمر هو اسم مستعار لـ `-p linux runcon`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux runcon`
