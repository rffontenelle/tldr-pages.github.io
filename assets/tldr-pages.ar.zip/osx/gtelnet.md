# gtelnet

> هذا الأمر هو اسم مستعار لـ `-p linux telnet`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux telnet`
