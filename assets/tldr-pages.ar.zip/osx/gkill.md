# gkill

> هذا الأمر هو اسم مستعار لـ `-p linux kill`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux kill`
