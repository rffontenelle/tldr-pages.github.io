# gfmt

> هذا الأمر هو اسم مستعار لـ `-p linux fmt`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux fmt`
