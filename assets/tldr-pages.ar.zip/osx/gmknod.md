# gmknod

> هذا الأمر هو اسم مستعار لـ `-p linux mknod`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux mknod`
