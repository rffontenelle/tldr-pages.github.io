# gvdir

> هذا الأمر هو اسم مستعار لـ `-p linux vdir`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux vdir`
