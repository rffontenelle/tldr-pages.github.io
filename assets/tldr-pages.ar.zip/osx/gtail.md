# gtail

> هذا الأمر هو اسم مستعار لـ `-p linux tail`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux tail`
