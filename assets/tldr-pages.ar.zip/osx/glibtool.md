# glibtool

> هذا الأمر هو اسم مستعار لـ `-p linux libtool`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux libtool`
