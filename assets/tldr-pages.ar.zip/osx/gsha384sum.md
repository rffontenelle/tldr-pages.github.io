# gsha384sum

> هذا الأمر هو اسم مستعار لـ `-p linux sha384sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sha384sum`
