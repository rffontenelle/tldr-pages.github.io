# gb2sum

> هذا الأمر هو اسم مستعار لـ `-p linux b2sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux b2sum`
