# ghostid

> هذا الأمر هو اسم مستعار لـ `-p linux hostid`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux hostid`
