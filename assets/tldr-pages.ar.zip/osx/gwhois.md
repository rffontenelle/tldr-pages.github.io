# gwhois

> هذا الأمر هو اسم مستعار لـ `-p linux whois`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux whois`
