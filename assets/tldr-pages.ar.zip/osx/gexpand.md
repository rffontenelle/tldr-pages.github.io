# gexpand

> هذا الأمر هو اسم مستعار لـ `-p linux expand`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux expand`
