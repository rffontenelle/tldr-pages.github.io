# gbase32

> هذا الأمر هو اسم مستعار لـ `-p linux base32`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux base32`
