# gfind

> هذا الأمر هو اسم مستعار لـ `-p linux find`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux find`
