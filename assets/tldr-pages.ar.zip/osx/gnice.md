# gnice

> هذا الأمر هو اسم مستعار لـ `-p linux nice`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux nice`
