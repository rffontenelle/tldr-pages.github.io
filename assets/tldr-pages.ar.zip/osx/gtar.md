# gtar

> هذا الأمر هو اسم مستعار لـ `-p linux tar`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux tar`
