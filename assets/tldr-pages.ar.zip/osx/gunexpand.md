# gunexpand

> هذا الأمر هو اسم مستعار لـ `-p linux unexpand`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux unexpand`
