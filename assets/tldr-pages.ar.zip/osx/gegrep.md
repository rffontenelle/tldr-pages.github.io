# gegrep

> هذا الأمر هو اسم مستعار لـ `-p linux egrep`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux egrep`
