# gping6

> هذا الأمر هو اسم مستعار لـ `-p linux ping6`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux ping6`
