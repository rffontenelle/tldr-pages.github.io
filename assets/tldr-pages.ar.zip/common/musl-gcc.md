# musl-gcc

> هذا الأمر هو اسم مستعار لـ `gcc`.
> لمزيد من التفاصيل: <https://manned.org/musl-gcc>.

- إعرض التوثيقات للأمر الأصلي:

`tldr gcc`
