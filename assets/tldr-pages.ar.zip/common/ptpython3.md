# ptpython3

> هذا الأمر هو اسم مستعار لـ `ptpython`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ptpython`
