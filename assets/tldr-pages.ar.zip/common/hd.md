# hd

> هذا الأمر هو اسم مستعار لـ `hexdump`.
> لمزيد من التفاصيل: <https://manned.org/hd.1>.

- إعرض التوثيقات للأمر الأصلي:

`tldr hexdump`
