# transmission

> هذا الأمر هو اسم مستعار لـ `transmission-daemon`.
> لمزيد من التفاصيل: <https://transmissionbt.com/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr transmission-daemon`
