# docker-container-rm

> هذا الأمر هو اسم مستعار لـ `docker rm`.
> لمزيد من التفاصيل: <https://docs.docker.com/engine/reference/commandline/rm>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker rm`
