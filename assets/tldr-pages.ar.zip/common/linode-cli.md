# linode-cli

> هذا الأمر هو اسم مستعار لـ `linode-cli account`.
> لمزيد من التفاصيل: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr linode-cli account`
