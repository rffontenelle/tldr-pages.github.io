# fossil-ci

> هذا الأمر هو اسم مستعار لـ `fossil-commit`.
> لمزيد من التفاصيل: <https://fossil-scm.org/home/help/commit>.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil-commit`
