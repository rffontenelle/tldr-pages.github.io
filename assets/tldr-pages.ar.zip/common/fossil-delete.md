# fossil-delete

> هذا الأمر هو اسم مستعار لـ `fossil rm`.
> لمزيد من التفاصيل: <https://fossil-scm.org/home/help/delete>.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil rm`
