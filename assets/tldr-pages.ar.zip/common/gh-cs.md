# gh-cs

> هذا الأمر هو اسم مستعار لـ `gh-codespace`.
> لمزيد من التفاصيل: <https://cli.github.com/manual/gh_codespace>.

- إعرض التوثيقات للأمر الأصلي:

`tldr gh-codespace`
