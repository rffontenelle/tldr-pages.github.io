# docker-container-rename

> هذا الأمر هو اسم مستعار لـ `docker rename`.
> لمزيد من التفاصيل: <https://docs.docker.com/engine/reference/commandline/rename>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker rename`
