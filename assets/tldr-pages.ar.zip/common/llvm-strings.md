# llvm-strings

> هذا الأمر هو اسم مستعار لـ `strings`.

- إعرض التوثيقات للأمر الأصلي:

`tldr strings`
