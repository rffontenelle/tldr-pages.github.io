# todoman

> هذا الأمر هو اسم مستعار لـ `todo`.
> لمزيد من التفاصيل: <https://todoman.readthedocs.io/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr todo`
