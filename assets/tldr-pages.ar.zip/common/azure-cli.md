# azure-cli

> هذا الأمر هو اسم مستعار لـ `az`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/cli/azure>.

- إعرض التوثيقات للأمر الأصلي:

`tldr az`
