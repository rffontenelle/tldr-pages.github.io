# pwsh

> هذا الأمر هو اسم مستعار لـ `powershell`.

- إعرض التوثيقات للأمر الأصلي:

`tldr powershell`
