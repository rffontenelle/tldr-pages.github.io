# lima

> هذا الأمر هو اسم مستعار لـ `limactl`.
> لمزيد من التفاصيل: <https://github.com/lima-vm/lima>.

- إعرض التوثيقات للأمر الأصلي:

`tldr limactl`
