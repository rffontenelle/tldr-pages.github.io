# hping

> هذا الأمر هو اسم مستعار لـ `hping3`.
> لمزيد من التفاصيل: <https://github.com/antirez/hping>.

- إعرض التوثيقات للأمر الأصلي:

`tldr hping3`
