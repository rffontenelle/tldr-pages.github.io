# docker-container-top

> هذا الأمر هو اسم مستعار لـ `docker top`.
> لمزيد من التفاصيل: <https://docs.docker.com/engine/reference/commandline/top>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker top`
