# fossil-new

> هذا الأمر هو اسم مستعار لـ `fossil-init`.
> لمزيد من التفاصيل: <https://fossil-scm.org/home/help/new>.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil-init`
