# docker-container-diff

> هذا الأمر هو اسم مستعار لـ `docker diff`.
> لمزيد من التفاصيل: <https://docs.docker.com/engine/reference/commandline/diff>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker diff`
