# platformio

> هذا الأمر هو اسم مستعار لـ `pio`.
> لمزيد من التفاصيل: <https://docs.platformio.org/en/latest/core/userguide/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr pio`
