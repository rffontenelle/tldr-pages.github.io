# pkg

> Bu komut `pkg_add` için bir takma addır.
> Daha fazla bilgi için: <https://www.openbsd.org/faq/faq15.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr pkg_add`
