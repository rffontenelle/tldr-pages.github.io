# sc-delete

> Bu komut `sc` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Asıl komutun belgelerini görüntüleyin:

`tldr sc`
