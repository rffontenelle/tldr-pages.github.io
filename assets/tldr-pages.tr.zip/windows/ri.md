# ri

> Bu komut `remove-item` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Asıl komutun belgelerini görüntüleyin:

`tldr remove-item`
