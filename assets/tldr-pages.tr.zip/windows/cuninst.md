# cuninst

> Bu komut `choco uninstall` için bir takma addır.
> Daha fazla bilgi için: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco uninstall`
