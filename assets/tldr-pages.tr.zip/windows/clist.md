# clist

> Bu komut `choco list` için bir takma addır.
> Daha fazla bilgi için: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco list`
