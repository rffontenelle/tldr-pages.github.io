# rd

> Bu komut `rmdir` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Asıl komutun belgelerini görüntüleyin:

`tldr rmdir`
