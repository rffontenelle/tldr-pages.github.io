# cls

> Bu komut `clear-host` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Asıl komutun belgelerini görüntüleyin:

`tldr clear-host`
