# curl

> Bu komut `curl -p common` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Asıl komutun belgelerini görüntüleyin:

`tldr curl -p common`
