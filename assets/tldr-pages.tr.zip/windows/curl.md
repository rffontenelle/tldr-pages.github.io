# curl

> Bu komut `curl -p common` için bir takma addır.
> Daha fazla bilgi için: <https://curl.se>.

- Asıl komutun belgelerini görüntüleyin:

`tldr curl -p common`
