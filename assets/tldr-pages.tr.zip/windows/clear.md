# clear

> Bu komut `clear-host` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr clear-host`
