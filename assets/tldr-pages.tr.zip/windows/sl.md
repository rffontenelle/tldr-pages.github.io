# sl

> Bu komut `set-location` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Asıl komutun belgelerini görüntüleyin:

`tldr set-location`
