# pwsh-where

> Bu komut `Where-Object` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Asıl komutun belgelerini görüntüleyin:

`tldr Where-Object`
