# sc-config

> Bu komut `sc` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Asıl komutun belgelerini görüntüleyin:

`tldr sc`
