# wget

> Bu komut `wget -p common` için bir takma addır.
> Daha fazla bilgi için: <https://www.gnu.org/software/wget>.

- Asıl komutun belgelerini görüntüleyin:

`tldr wget -p common`
