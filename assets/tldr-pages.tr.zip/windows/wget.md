# wget

> Bu komut `wget -p common` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Asıl komutun belgelerini görüntüleyin:

`tldr wget -p common`
