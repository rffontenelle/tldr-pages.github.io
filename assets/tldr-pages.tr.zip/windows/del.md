# del

> Bu komut `remove-item` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Asıl komutun belgelerini görüntüleyin:

`tldr remove-item`
