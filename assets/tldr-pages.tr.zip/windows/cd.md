# cd

> Bu komut `set-location` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Asıl komutun belgelerini görüntüleyin:

`tldr set-location`
