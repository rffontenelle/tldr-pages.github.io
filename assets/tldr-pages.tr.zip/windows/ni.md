# ni

> Bu komut `new-item` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Asıl komutun belgelerini görüntüleyin:

`tldr new-item`
