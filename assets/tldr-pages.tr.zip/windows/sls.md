# sls

> Bu komut `where-object` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Asıl komutun belgelerini görüntüleyin:

`tldr where-object`
