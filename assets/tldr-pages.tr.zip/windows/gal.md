# gal

> Bu komut `get-alias` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Asıl komutun belgelerini görüntüleyin:

`tldr get-alias`
