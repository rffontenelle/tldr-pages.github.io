# cpush

> Bu komut `choco-push` için bir takma addır.
> Daha fazla bilgi için: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco-push`
