# sc-create

> Bu komut `sc` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Asıl komutun belgelerini görüntüleyin:

`tldr sc`
