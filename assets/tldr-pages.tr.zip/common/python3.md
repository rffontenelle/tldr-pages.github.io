# python3

> Bu komut `python` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr python`
