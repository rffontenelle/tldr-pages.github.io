# lzcmp

> Bu komut `xzcmp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr xzcmp`
