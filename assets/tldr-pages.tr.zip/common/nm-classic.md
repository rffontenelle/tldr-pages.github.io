# nm-classic

> Bu komut `nm` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr nm`
