# azure-cli

> Bu komut `az` için bir takma addır.
> Daha fazla bilgi için: <https://learn.microsoft.com/cli/azure>.

- Asıl komutun belgelerini görüntüleyin:

`tldr az`
