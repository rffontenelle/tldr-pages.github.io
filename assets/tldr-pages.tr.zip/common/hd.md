# hd

> Bu komut `hexdump` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/hd.1>.

- Asıl komutun belgelerini görüntüleyin:

`tldr hexdump`
