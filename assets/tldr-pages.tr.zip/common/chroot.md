# chroot

> Komut veya etkileşimli komut satırını özel kök diziniyle çalıştırır.
> Daha fazla bilgi için: <https://www.gnu.org/software/coreutils/chroot>.

- Komutu yeni kök dizini olarak çalıştır:

`chroot {{yeni/kok/yolu}} {{komut}}`

- Kullanılacak kullanıcı ve grubu (ID veya isim) belirle:

`chroot --userspec={{kullanici:grup}}`
