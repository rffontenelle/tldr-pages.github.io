# musl-gcc

> Bu komut `gcc` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/musl-gcc>.

- Asıl komutun belgelerini görüntüleyin:

`tldr gcc`
