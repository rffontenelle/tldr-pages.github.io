# cron

> Bu komut `crontab` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr crontab`
