# llvm-gcc

> Bu komut `clang` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr clang`
