# unxz

> Bu komut `xz` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/unxz>.

- Asıl komutun belgelerini görüntüleyin:

`tldr xz`
