# fossil ci

> Bu komut  `fossil commit`.için bir takma addır.
> Daha fazla bilgi için: <https://fossil-scm.org/home/help/commit>.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil-commit`
