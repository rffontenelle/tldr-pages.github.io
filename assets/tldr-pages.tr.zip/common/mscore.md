# mscore

> Bu komut `musescore` için bir takma addır.
> Daha fazla bilgi için: <https://musescore.org/handbook/command-line-options>.

- Asıl komutun belgelerini görüntüleyin:

`tldr musescore`
