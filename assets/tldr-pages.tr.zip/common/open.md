# open

> Bu komut `open -p osx` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr open -p osx`
