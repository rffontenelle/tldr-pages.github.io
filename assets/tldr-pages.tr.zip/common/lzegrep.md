# lzegrep

> Bu komut `xzgrep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr xzgrep`
