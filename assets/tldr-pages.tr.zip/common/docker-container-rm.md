# docker-container-rm

> Bu komut `docker rm` için bir takma addır.
> Daha fazla bilgi için: <https://docs.docker.com/engine/reference/commandline/rm>.

- Asıl komutun belgelerini görüntüleyin:

`tldr docker rm`
