# gnmic-sub

> Bu komut `gnmic subscribe` için bir takma addır.
> Daha fazla bilgi için: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Asıl komutun belgelerini görüntüleyin:

`tldr gnmic subscribe`
