# linode-cli

> Bu komut `linode-cli account` için bir takma addır.
> Daha fazla bilgi için: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Asıl komutun belgelerini görüntüleyin:

`tldr linode-cli account`
