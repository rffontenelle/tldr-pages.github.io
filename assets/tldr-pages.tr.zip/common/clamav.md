# clamav

> Bu komut `clamdscan` için bir takma addır.
> Daha fazla bilgi için: <https://www.clamav.net>.

- Asıl komutun belgelerini görüntüleyin:

`tldr clamdscan`
