# bundler

> Bu komut `bundle` için bir takma addır.
> Daha fazla bilgi için: <https://bundler.io/man/bundle.1.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr bundle`
