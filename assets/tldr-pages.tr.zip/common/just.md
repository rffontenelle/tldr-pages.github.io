# just

> Bu komut `just.1` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr just.1`
