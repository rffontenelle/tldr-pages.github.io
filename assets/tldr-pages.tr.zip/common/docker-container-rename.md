# docker-container-rename

> Bu komut `docker rename` için bir takma addır.
> Daha fazla bilgi için: <https://docs.docker.com/engine/reference/commandline/rename>.

- Asıl komutun belgelerini görüntüleyin:

`tldr docker rename`
