# tlmgr arch

> Bu komut `tlmgr platform` için bir takma addır.
> Daha fazla bilgi için: <https://www.tug.org/texlive/tlmgr.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr tlmgr platform`
