# fossil-new

> Bu komut `fossil-init` için bir takma addır.
> Daha fazla bilgi için: <https://fossil-scm.org/home/help/new>.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil-init`
