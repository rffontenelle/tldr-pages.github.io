# unzstd

> Bu komut `zstd` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr zstd`
