# minetest

> Çok oyunculu sınırsız dünyalı bloklu sandbox oyun motoru.
> Ayrıca `minetestserver` sayfasına bakılması önerilir.
> Daha fazla bilgi için: <https://wiki.minetest.org/Minetest>.

- Minetest'i kullanıcı modunda başlat:

`minetest`

- Minetest'i belirtilen dünyayı host edecek şekilde sunucu modunda başlat:

`minetest --server --world {{isim}}`

- Belirtilmiş bir dosyaya geçmişi yaz:

`minetest --logfile {{örnek/dosya}}`

- Hataları yalnızca konsola yaz:

`minetest --quiet`
