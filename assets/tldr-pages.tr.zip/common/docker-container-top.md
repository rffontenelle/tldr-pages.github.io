# docker-container-top

> Bu komut `docker top` için bir takma addır.
> Daha fazla bilgi için: <https://docs.docker.com/engine/reference/commandline/top>.

- Asıl komutun belgelerini görüntüleyin:

`tldr docker top`
