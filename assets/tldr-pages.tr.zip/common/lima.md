# lima

> Bu komut `limactl` için bir takma addır.
> Daha fazla bilgi için: <https://github.com/lima-vm/lima>.

- Asıl komutun belgelerini görüntüleyin:

`tldr limactl`
