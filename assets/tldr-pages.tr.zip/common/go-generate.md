# go generate

> Kaynak dosyaları içinde komut çalıştırarak Go dosyaları oluştur.
> Daha fazla bilgi için: <https://golang.org/cmd/go/#hdr-Generate_Go_files_by_processing_source>.

- Kaynak dosyaları içinde komut çalıştırarak Go dosyaları oluştur:

`go generate`
