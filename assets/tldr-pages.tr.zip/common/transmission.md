# transmission

> Bu komut `transmission-daemon` için bir takma addır.
> Daha fazla bilgi için: <https://transmissionbt.com/>.

- Asıl komutun belgelerini görüntüleyin:

`tldr transmission-daemon`
