# pwsh

> Bu komut `powershell` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr powershell`
