# unlzma

> Bu komut `xz` için bir takma addır.
> Daha fazla bilgi için: <https://manned.org/unlzma>.

- Asıl komutun belgelerini görüntüleyin:

`tldr xz`
