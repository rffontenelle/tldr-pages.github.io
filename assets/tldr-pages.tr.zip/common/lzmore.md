# lzmore

> Bu komut `xzmore` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr xzmore`
