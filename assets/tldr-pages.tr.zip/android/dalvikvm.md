# dalvikvm

> Android Java sanal makinesi.
> Daha fazla bilgi için: <https://source.android.com/docs/core/runtime>.

- Bir Java programı başlar:

`dalvikvm -classpath {{örnek/dosya.jar}} {{sınıf_ismi}}`
