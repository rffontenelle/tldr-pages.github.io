# dalvikvm

> Android Java sanal makinesi.
> Daha fazla bilgi için: <https://source.android.com/devices/tech/dalvik>.

- Bir Java programı başlar:

`dalvikvm -classpath {{örnek/dosya.jar}} {{sınıf_ismi}}`
