# cmd

> Android servis yöneticisi.
> Daha fazla bilgi için: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- Tüm çalışan servisleri sırala:

`cmd -l`

- Belirtilen servisi çağır:

`cmd {{alarm}}`

- Belirtilen argümanlar ile servis çağır:

`cmd {{vibrator}} {{vibrate 300}}`
