# screencap

> Bir mobil ekranın ekran görüntüsünü al.
> Bu komut sadece `adb shell` üzerinden kullanılabilir.
> Daha fazla bilgi için: <https://developer.android.com/studio/command-line/adb#screencap>.

- Bir ekran görüntüsü al:

`screencap {{dosya/yolu}}`
