# logcat

> Sistem mesajlarının kaydını görüntüle.
> Daha fazla bilgi için: <https://developer.android.com/studio/command-line/logcat>.

- Sistem kaydını görüntüle:

`logcat`

- Sistem kayıtlarını bir dosyaya yaz:

`logcat -f {{örnek/dosya}}`

- Düzenli ifadeye uyan satırları görüntüle:

`logcat --regex {{düzenli_ifade}}`
