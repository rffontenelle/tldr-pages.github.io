# pwdx

> Bir işlemin çalışan dizinini yazdır.
> Daha fazla bilgi için: <https://manned.org/pwdx>.

- Bir işlemin mevcut çalışan dizinini yazdır:

`pwdx {{işlem_id'si}}`
