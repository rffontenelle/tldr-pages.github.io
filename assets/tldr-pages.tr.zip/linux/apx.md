# apx

> Bu komut `apx pkgmanagers` için bir takma addır.
> Daha fazla bilgi için: <https://github.com/Vanilla-OS/apx>.

- Asıl komutun belgelerini görüntüleyin:

`tldr apx pkgmanagers`
