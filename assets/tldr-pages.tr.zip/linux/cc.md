# cc

> Bu komut `gcc` için bir takma addır.
> Daha fazla bilgi için: <https://gcc.gnu.org>.

- Asıl komutun belgelerini görüntüleyin:

`tldr gcc`
