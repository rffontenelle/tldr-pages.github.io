# qm-importdisk

> Bu komut `qm disk import` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr qm disk import`
