# wl-copy

> Wayland için pano değiştirme aracı.
> Ayrıca bakın: `wl-paste`.
> Daha fazla bilgi için: <https://github.com/bugaevc/wl-clipboard>.

- Metni panoya kopyala:

`wl-copy {{metin}}`

- Komutun çıktısını panoya kopyala:

`{{komut}} | wl-copy`

- Yalnızca bir yapıştırma için kopyala ve ardından temizle:

`wl-copy --paste-once`

- Panoyu temizle:

`wl-copy --clear`
