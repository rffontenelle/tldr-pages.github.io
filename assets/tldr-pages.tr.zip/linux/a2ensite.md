# a2ensite

> Debian tabanlı işletim sistemlerinde Apache sanal hostu etkinleştir.
> Daha fazla bilgi için: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Bir sanal hostu etkinleştir:

`sudo a2ensite {{sanal_host}}`

- Bilgilendirici mesajları gösterme:

`sudo a2ensite --quiet {{sanal_host}}`
