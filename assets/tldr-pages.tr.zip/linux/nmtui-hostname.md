# nmtui-hostname

> Bu komut `nmtui` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr nmtui`
