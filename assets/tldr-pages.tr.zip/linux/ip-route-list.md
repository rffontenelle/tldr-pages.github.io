# ip route list

> Bu komut  `ip route show`.için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ip-route-show`
