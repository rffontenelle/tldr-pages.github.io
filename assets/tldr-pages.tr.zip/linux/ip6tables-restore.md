# ip6tables-restore

> Bu komut `iptables-restore` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr iptables-restore`
