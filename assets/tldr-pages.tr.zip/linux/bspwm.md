# bspwm

> Bu komut `bspc` için bir takma addır.
> Daha fazla bilgi için: <https://github.com/baskerville/bspwm>.

- Asıl komutun belgelerini görüntüleyin:

`tldr bspc`
