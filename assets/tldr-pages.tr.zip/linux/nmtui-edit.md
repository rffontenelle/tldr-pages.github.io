# nmtui-edit

> Bu komut `nmtui` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr nmtui`
