# pkgctl

> Bu komut `pkgctl auth` için bir takma addır.
> Daha fazla bilgi için: <https://man.archlinux.org/man/pkgctl.1>.

- Asıl komutun belgelerini görüntüleyin:

`tldr pkgctl auth`
