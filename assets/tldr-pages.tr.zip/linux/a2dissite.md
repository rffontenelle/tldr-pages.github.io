# a2dissite

> Debian tabanlı işletim sistemlerinde bir Apache sanal hostunu devre dışı bırak.
> Daha fazla bilgi için: <https://manpages.debian.org/latest/apache2/a2dissite.8.en.html>.

- Uzak hostu devre dışı bırak:

`sudo a2dissite {{sanal_host}}`

- Bilgilendirici mesajları gösterme:

`sudo a2dissite --quiet {{sanal_host}}`
