# qm-move-disk

> Bu komut `qm-disk-move` için bir takma addır.
> Daha fazla bilgi için: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr qm-disk-move`
