# systemd-umount

> Bu komut `systemd-mount` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr systemd-mount`
