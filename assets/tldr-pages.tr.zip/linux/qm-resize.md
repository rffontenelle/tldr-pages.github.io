# qm-resize

> Bu komut `qm-disk-resize` için bir takma addır.
> Daha fazla bilgi için: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr qm-disk-resize`
