# wpa_passphrase

> Belirtilen SSID için bir ASCII paroladan bir WPA-PSK anahtarı oluşturun.
> Daha fazla bilgi için: <https://manned.org/wpa_passphrase.1>.

- Standart girişten parolayı okuyarak belirtilen SSID için WPA-PSK anahtarını hesapla ve görüntüle:

`wpa_passphrase {{SSID}}`

- Parolayı argüman olarak belirterek belirtilen SSID için WPA-PSK anahtarını hesapla ve görüntüle:

`wpa_passphrase {{SSID}} {{parola}}`
