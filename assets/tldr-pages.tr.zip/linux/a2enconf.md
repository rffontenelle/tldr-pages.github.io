# a2enconf

> Debian tabanlı işletim sistemlerinde Apache konfigürasyon dosyasını etkinleştir.
> Daha fazla bilgi için: <https://manned.org/a2enconf.8>.

- Bir konfigürasyon dosyasını etkinleştir:

`sudo a2enconf {{konfigürasyon_dosyası}}`

- Bilgilendirici mesajları gösterme:

`sudo a2enconf --quiet {{konfigürasyon_dosyası}}`
