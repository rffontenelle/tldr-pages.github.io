# a2enconf

> Debian tabanlı işletim sistemlerinde Apache konfigürasyon dosyasını etkinleştir.
> Daha fazla bilgi için: <https://manpages.debian.org/latest/apache2/a2enconf.8.en.html>.

- Bir konfigürasyon dosyasını etkinleştir:

`sudo a2enconf {{konfigürasyon_dosyası}}`

- Bilgilendirici mesajları gösterme:

`sudo a2enconf --quiet {{konfigürasyon_dosyası}}`
