# a2enmod

> Debian tabanlı işletim sistemlerinde Apache modülünü etkinleştir.
> Daha fazla bilgi için: <https://manpages.debian.org/latest/apache2/a2enmod.8.en.html>.

- Bir modülü etkinleştir:

`sudo a2enmod {{modül}}`

- Bilgilendirici mesajları gösterme:

`sudo a2enmod --quiet {{modül}}`
