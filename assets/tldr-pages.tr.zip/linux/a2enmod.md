# a2enmod

> Debian tabanlı işletim sistemlerinde Apache modülünü etkinleştir.
> Daha fazla bilgi için: <https://manned.org/a2enmod.8>.

- Bir modülü etkinleştir:

`sudo a2enmod {{modül}}`

- Bilgilendirici mesajları gösterme:

`sudo a2enmod --quiet {{modül}}`
