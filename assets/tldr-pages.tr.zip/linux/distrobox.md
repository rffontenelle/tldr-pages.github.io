# distrobox

> Bu komut `distrobox-create` için bir takma addır.
> Daha fazla bilgi için: <https://github.com/89luca89/distrobox>.

- Asıl komutun belgelerini görüntüleyin:

`tldr distrobox-create`
