# ip6tables-save

> Bu komut `iptables-save` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr iptables-save`
