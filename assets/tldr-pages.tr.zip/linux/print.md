# print

> `run-mailcap` komutunun print özelliğinin öbür adı.
> Normalde `run-mailcap` komutu mime-tarzı/dosya işlemek için kullanılır.
> Daha fazla bilgi için: <https://manned.org/print>.

- Bir dosyayı yazdır:

`print {{dosya_ismi}}`

- `run-mailcap` ile yazdır:

`run-mailcap --action=print {{dosya_ismi}}`
