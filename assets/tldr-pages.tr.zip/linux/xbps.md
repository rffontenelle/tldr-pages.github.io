# xbps

> Bu komut `xbps-install` için bir takma addır.
> Daha fazla bilgi için: <https://docs.voidlinux.org/xbps/index.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr xbps-install`
