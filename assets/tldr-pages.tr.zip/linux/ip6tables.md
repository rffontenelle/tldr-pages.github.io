# ip6tables

> Bu komut `iptables` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr iptables`
