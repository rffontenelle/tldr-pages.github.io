# pw-cli

> Pipewire komut satır arayüzü.
> Daha fazla bilgi için: <https://docs.pipewire.org/page_man_pw-cli_1.html>.

- Tüm düğümleri (taban ve kaynakları) ID'leri ile birlikte yazdır:

`pw-cli list-objects Node`

- Belirtilen ID'ye sahip objeye dair bilgileri yazdır:

`pw-cli info {{4}}`

- Tüm objelerin bilgilerini yazdır:

`pw-cli info all`
