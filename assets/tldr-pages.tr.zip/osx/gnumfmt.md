# gnumfmt

> Bu komut `-p linux numfmt` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux numfmt`
