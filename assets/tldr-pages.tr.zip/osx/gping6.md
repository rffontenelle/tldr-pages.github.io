# gping6

> Bu komut `-p linux ping6` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux ping6`
