# gnohup

> Bu komut `-p linux nohup` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux nohup`
