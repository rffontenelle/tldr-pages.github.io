# gtest

> Bu komut `-p linux test` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux test`
