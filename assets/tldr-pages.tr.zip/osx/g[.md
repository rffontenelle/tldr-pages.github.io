# g[

> Bu komut `-p linux [` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux [`
