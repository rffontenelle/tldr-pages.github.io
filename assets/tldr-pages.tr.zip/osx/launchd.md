# launchd

> Bu komut `launchctl` için bir takma addır.
> Daha fazla bilgi için: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Asıl komutun belgelerini görüntüleyin:

`tldr launchctl`
