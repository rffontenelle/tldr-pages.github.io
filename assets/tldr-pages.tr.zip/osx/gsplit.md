# gsplit

> Bu komut `-p linux split` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux split`
