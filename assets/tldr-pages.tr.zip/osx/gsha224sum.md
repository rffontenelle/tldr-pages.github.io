# gsha224sum

> Bu komut `-p linux sha224sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sha224sum`
