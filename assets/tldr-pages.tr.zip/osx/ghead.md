# ghead

> Bu komut `-p linux head` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux head`
