# gid

> Bu komut `-p linux id` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux id`
