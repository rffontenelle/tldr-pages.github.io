# gtee

> Bu komut `-p linux tee` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tee`
