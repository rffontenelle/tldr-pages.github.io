# gtail

> Bu komut `-p linux tail` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tail`
