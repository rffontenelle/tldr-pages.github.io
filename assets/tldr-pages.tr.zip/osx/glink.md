# glink

> Bu komut `-p linux link` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux link`
