# gyes

> Bu komut `-p linux yes` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux yes`
