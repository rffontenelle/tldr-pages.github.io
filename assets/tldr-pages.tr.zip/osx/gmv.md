# gmv

> Bu komut `-p linux mv` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux mv`
