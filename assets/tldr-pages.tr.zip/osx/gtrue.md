# gtrue

> Bu komut `-p linux true` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux true`
