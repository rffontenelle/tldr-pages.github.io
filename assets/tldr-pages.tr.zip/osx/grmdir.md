# grmdir

> Bu komut `-p linux rmdir` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux rmdir`
