# ghostid

> Bu komut `-p linux hostid` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux hostid`
