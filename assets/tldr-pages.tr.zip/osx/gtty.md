# gtty

> Bu komut `-p linux tty` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux tty`
