# gbase32

> Bu komut `-p linux base32` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux base32`
