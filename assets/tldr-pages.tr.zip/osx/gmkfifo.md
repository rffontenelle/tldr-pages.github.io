# gmkfifo

> Bu komut `-p linux mkfifo` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux mkfifo`
