# grm

> Bu komut `-p linux rm` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux rm`
