# gfold

> Bu komut `-p linux fold` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux fold`
