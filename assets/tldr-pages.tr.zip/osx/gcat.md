# gcat

> Bu komut `-p linux cat` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux cat`
