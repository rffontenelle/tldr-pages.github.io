# gsync

> Bu komut `-p linux sync` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sync`
