# llvm-lipo

> Bu komut `lipo` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr lipo`
