# gnice

> Bu komut `-p linux nice` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux nice`
