# gvdir

> Bu komut `-p linux vdir` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux vdir`
