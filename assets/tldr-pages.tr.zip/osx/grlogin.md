# grlogin

> Bu komut `-p linux rlogin` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux rlogin`
