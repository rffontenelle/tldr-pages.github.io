# gsha1sum

> Bu komut `-p linux sha1sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux sha1sum`
