# gfind

> Bu komut `-p linux find` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux find`
