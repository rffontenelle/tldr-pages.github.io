# grealpath

> Bu komut `-p linux realpath` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux realpath`
