# gprintenv

> Bu komut `-p linux printenv` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux printenv`
