# gnl

> Bu komut `-p linux nl` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux nl`
