# greadlink

> Bu komut `-p linux readlink` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux readlink`
