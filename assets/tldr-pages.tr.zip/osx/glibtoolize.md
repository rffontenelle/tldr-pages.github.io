# glibtoolize

> Bu komut `-p linux libtoolize` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux libtoolize`
