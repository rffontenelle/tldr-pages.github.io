# gnproc

> Bu komut `-p linux nproc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux nproc`
