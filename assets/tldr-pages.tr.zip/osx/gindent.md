# gindent

> Bu komut `-p linux indent` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux indent`
