# gdircolors

> Bu komut `-p linux dircolors` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux dircolors`
