# gwhich

> Bu komut `-p linux which` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux which`
