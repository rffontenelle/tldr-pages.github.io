# grexec

> Bu komut `-p linux rexec` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux rexec`
