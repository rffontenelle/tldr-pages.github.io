# glogger

> Bu komut `-p linux logger` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux logger`
