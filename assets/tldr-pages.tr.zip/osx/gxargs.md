# gxargs

> Bu komut `-p linux xargs` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux xargs`
