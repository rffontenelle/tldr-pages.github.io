# gcomm

> Bu komut `-p linux comm` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux comm`
