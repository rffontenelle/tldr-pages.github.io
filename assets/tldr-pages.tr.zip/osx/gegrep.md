# gegrep

> Bu komut `-p linux egrep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux egrep`
