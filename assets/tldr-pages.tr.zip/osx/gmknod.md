# gmknod

> Bu komut `-p linux mknod` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux mknod`
