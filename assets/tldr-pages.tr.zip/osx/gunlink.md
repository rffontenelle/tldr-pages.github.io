# gunlink

> Bu komut `-p linux unlink` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux unlink`
