# gpinky

> Bu komut `-p linux pinky` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux pinky`
