# gtraceroute

> Bu komut `-p linux traceroute` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux traceroute`
