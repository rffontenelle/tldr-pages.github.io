# gfactor

> Bu komut `-p linux factor` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux factor`
