# grsh

> Bu komut `-p linux rsh` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux rsh`
