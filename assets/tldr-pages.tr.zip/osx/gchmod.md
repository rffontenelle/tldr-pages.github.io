# gchmod

> Bu komut `-p linux chmod` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux chmod`
