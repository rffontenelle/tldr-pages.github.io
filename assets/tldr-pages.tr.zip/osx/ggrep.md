# ggrep

> Bu komut `-p linux grep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr -p linux grep`
