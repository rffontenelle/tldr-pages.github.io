# dalvikvm

> Android Java virtual machine.
> More information: <https://developer.android.com/tools/#art_and_dalvik>.

- Start a specific Java program:

`dalvikvm -classpath {{path/to/file.jar}} {{classname}}`
