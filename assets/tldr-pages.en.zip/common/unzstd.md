# unzstd

> This command is an alias of `zstd --decompress`.

- View documentation for the original command:

`tldr zstd`
