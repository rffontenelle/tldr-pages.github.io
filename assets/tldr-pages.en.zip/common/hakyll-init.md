# hakyll-init

> Generate a new Hakyll sample blog.
> More information: <https://github.com/jaspervdj/hakyll-init>.

- Generate a new Hakyll sample blog:

`hakyll-init {{path/to/directory}}`

- Display help:

`hakyll-init --help`
