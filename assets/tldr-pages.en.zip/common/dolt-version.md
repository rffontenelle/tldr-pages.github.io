# dolt version

> Displays the current dolt CLI version.
> More information: <https://docs.dolthub.com/cli-reference/cli#dolt-version>.

- Display version:

`dolt version`
