# ppmtopict

> Convert a PPM image to a Macintosh PICT file.
> More information: <https://netpbm.sourceforge.net/doc/ppmtopict.html>.

- Convert a PPM image to a PICT file:

`ppmtopict {{path/to/file.ppm}} > {{path/to/file.pict}}`
