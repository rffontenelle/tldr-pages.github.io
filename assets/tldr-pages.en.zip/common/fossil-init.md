# fossil init

> Initialize a new repository for a project.
> See also: `fossil clone`.
> More information: <https://fossil-scm.org/home/help/init>.

- Create a new repository in a named file:

`fossil init {{path/to/filename}}`
