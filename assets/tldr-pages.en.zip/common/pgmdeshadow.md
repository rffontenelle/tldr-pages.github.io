# pgmdeshadow

> Deshadow a PGM image.
> More information: <https://netpbm.sourceforge.net/doc/pgmdeshadow.html>.

- Remove grey shadows from a PGM image:

`pgmdeshadow {{path/to/input_file.pgm}} > {{path/to/output_file.pgm}}`
