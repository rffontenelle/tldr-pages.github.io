# qm list

> List all virtual machines.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- List all virtual machines:

`qm list`

- List all virtual machines with a full status about the ones which are currently running:

`qm list --full 1`
