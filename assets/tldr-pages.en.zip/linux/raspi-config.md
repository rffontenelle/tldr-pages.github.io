# raspi-config

> An `ncurses` terminal GUI to config a Raspberry Pi.
> More information: <https://www.raspberrypi.org/documentation/computers/configuration.html>.

- Start `raspi-config`:

`sudo raspi-config`
