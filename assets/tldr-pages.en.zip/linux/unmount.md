# umount

> The correct command is `umount` (u-mount).
> More information: <https://manned.org/umount.8>.

- View documentation for the correct command:

`tldr umount`
