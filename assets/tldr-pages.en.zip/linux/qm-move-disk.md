# qm move_disk

> This command and `qm move-disk` is an alias of `qm disk move`.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- View documentation for the original command:

`tldr qm-disk-move`
