# cuyo

> Tetris like game.
> More information: <https://www.karimmi.de/cuyo/>.

- Start a new game:

`cuyo`

- Navigate the piece horizontally:

`{{A|D|Left arrow key|Right arrow key}}`

- Turn the piece:

`{{W|Up arrow key}}`

- Hard drop the piece:

`{{S|Down arrow key}}`
