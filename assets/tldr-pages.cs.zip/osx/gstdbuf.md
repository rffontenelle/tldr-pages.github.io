# gstdbuf

> Tento příkaz je aliasem pro `-p linux stdbuf`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux stdbuf`
