# gsha1sum

> Tento příkaz je aliasem pro `-p linux sha1sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sha1sum`
