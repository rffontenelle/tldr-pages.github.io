# gtrue

> Tento příkaz je aliasem pro `-p linux true`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux true`
