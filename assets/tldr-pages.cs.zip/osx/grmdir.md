# grmdir

> Tento příkaz je aliasem pro `-p linux rmdir`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux rmdir`
