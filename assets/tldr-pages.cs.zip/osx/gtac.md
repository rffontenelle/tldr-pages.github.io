# gtac

> Tento příkaz je aliasem pro `-p linux tac`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux tac`
