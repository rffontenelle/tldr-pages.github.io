# gpinky

> Tento příkaz je aliasem pro `-p linux pinky`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux pinky`
