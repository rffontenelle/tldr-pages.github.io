# gdircolors

> Tento příkaz je aliasem pro `-p linux dircolors`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux dircolors`
