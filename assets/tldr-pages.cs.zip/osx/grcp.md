# grcp

> Tento příkaz je aliasem pro `-p linux rcp`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux rcp`
