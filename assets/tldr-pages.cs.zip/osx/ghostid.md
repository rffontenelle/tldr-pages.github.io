# ghostid

> Tento příkaz je aliasem pro `-p linux hostid`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux hostid`
