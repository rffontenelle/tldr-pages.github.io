# gcp

> Tento příkaz je aliasem pro `-p linux cp`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux cp`
