# glocate

> Tento příkaz je aliasem pro `-p linux locate`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux locate`
