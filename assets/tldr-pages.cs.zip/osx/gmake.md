# gmake

> Tento příkaz je aliasem pro `-p linux make`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux make`
