# gmkfifo

> Tento příkaz je aliasem pro `-p linux mkfifo`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux mkfifo`
