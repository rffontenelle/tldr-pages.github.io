# gftp

> Tento příkaz je aliasem pro `-p linux ftp`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ftp`
