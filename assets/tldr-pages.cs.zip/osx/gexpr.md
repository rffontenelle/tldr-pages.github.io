# gexpr

> Tento příkaz je aliasem pro `-p linux expr`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux expr`
