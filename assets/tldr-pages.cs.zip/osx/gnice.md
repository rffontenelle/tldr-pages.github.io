# gnice

> Tento příkaz je aliasem pro `-p linux nice`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux nice`
