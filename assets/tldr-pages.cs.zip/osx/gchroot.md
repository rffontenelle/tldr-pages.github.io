# gchroot

> Tento příkaz je aliasem pro `-p linux chroot`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux chroot`
