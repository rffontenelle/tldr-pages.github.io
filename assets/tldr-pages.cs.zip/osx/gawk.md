# gawk

> Tento příkaz je aliasem pro `-p linux awk`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux awk`
