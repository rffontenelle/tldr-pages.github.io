# gchmod

> Tento příkaz je aliasem pro `-p linux chmod`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux chmod`
