# grealpath

> Tento příkaz je aliasem pro `-p linux realpath`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux realpath`
