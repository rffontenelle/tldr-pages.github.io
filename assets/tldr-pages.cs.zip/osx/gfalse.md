# gfalse

> Tento příkaz je aliasem pro `-p linux false`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux false`
