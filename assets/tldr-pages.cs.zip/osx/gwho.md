# gwho

> Tento příkaz je aliasem pro `-p linux who`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux who`
