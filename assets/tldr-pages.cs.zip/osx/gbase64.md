# gbase64

> Tento příkaz je aliasem pro `-p linux base64`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux base64`
