# gtraceroute

> Tento příkaz je aliasem pro `-p linux traceroute`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux traceroute`
