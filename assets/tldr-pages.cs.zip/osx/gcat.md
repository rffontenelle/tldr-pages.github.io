# gcat

> Tento příkaz je aliasem pro `-p linux cat`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux cat`
