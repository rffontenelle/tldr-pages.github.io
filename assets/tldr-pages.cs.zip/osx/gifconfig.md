# gifconfig

> Tento příkaz je aliasem pro `-p linux ifconfig`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ifconfig`
