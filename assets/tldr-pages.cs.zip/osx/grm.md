# grm

> Tento příkaz je aliasem pro `-p linux rm`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux rm`
