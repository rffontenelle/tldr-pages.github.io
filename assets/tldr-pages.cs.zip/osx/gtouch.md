# gtouch

> Tento příkaz je aliasem pro `-p linux touch`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux touch`
