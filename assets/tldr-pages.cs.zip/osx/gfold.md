# gfold

> Tento příkaz je aliasem pro `-p linux fold`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux fold`
