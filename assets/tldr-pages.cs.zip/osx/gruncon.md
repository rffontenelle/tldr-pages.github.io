# gruncon

> Tento příkaz je aliasem pro `-p linux runcon`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux runcon`
