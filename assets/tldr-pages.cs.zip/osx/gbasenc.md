# gbasenc

> Tento příkaz je aliasem pro `-p linux basenc`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux basenc`
