# ggrep

> Tento příkaz je aliasem pro `-p linux grep`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux grep`
