# god

> Tento příkaz je aliasem pro `-p linux od`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux od`
