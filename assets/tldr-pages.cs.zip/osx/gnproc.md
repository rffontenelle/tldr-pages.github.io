# gnproc

> Tento příkaz je aliasem pro `-p linux nproc`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux nproc`
