# gptx

> Tento příkaz je aliasem pro `-p linux ptx`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ptx`
