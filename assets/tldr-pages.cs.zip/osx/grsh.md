# grsh

> Tento příkaz je aliasem pro `-p linux rsh`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux rsh`
