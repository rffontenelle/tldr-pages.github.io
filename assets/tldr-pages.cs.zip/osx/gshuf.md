# gshuf

> Tento příkaz je aliasem pro `-p linux shuf`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux shuf`
