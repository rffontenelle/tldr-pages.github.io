# gtalk

> Tento příkaz je aliasem pro `-p linux talk`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux talk`
