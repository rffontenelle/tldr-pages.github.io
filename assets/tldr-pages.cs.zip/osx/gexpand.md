# gexpand

> Tento příkaz je aliasem pro `-p linux expand`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux expand`
