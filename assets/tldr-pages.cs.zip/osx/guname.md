# guname

> Tento příkaz je aliasem pro `-p linux uname`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux uname`
