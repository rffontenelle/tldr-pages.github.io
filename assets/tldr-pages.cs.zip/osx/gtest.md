# gtest

> Tento příkaz je aliasem pro `-p linux test`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux test`
