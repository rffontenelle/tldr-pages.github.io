# gmv

> Tento příkaz je aliasem pro `-p linux mv`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux mv`
