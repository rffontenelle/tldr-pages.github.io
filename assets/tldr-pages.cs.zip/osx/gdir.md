# gdir

> Tento příkaz je aliasem pro `-p linux dir`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux dir`
