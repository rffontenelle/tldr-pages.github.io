# gunlink

> Tento příkaz je aliasem pro `-p linux unlink`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux unlink`
