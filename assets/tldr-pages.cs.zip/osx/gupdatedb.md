# gupdatedb

> Tento příkaz je aliasem pro `-p linux updatedb`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux updatedb`
