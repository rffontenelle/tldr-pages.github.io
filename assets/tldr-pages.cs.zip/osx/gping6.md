# gping6

> Tento příkaz je aliasem pro `-p linux ping6`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ping6`
