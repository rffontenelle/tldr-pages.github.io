# gfmt

> Tento příkaz je aliasem pro `-p linux fmt`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux fmt`
