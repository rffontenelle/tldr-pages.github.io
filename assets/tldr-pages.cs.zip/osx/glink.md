# glink

> Tento příkaz je aliasem pro `-p linux link`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux link`
