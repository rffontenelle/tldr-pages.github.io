# gseq

> Tento příkaz je aliasem pro `-p linux seq`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux seq`
