# llvm-lipo

> Tento příkaz je aliasem pro `lipo`.

- Podívejte se na dokumentaci původního příkazu:

`tldr lipo`
