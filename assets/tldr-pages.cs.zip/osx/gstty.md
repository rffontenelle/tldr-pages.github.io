# gstty

> Tento příkaz je aliasem pro `-p linux stty`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux stty`
