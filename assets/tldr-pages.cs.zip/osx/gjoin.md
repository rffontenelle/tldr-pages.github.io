# gjoin

> Tento příkaz je aliasem pro `-p linux join`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux join`
