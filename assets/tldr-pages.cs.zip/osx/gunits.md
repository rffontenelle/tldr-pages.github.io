# gunits

> Tento příkaz je aliasem pro `-p linux units`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux units`
