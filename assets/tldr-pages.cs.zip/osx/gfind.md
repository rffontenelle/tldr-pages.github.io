# gfind

> Tento příkaz je aliasem pro `-p linux find`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux find`
