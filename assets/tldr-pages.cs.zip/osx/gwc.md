# gwc

> Tento příkaz je aliasem pro `-p linux wc`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux wc`
