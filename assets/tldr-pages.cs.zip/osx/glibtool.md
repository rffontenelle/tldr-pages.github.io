# glibtool

> Tento příkaz je aliasem pro `-p linux libtool`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux libtool`
