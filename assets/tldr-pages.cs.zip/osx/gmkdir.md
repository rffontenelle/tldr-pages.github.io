# gmkdir

> Tento příkaz je aliasem pro `-p linux mkdir`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux mkdir`
