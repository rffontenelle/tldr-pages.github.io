# gsha256sum

> Tento příkaz je aliasem pro `-p linux sha256sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sha256sum`
