# gtr

> Tento příkaz je aliasem pro `-p linux tr`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux tr`
