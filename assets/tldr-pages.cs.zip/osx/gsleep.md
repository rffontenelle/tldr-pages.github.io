# gsleep

> Tento příkaz je aliasem pro `-p linux sleep`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sleep`
