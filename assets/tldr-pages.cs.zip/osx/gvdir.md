# gvdir

> Tento příkaz je aliasem pro `-p linux vdir`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux vdir`
