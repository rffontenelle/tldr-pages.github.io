# ghead

> Tento příkaz je aliasem pro `-p linux head`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux head`
