# gwhich

> Tento příkaz je aliasem pro `-p linux which`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux which`
