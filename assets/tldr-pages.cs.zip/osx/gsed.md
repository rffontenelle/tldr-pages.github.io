# gsed

> Tento příkaz je aliasem pro `-p linux sed`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sed`
