# gwhoami

> Tento příkaz je aliasem pro `-p linux whoami`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux whoami`
