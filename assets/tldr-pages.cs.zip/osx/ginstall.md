# ginstall

> Tento příkaz je aliasem pro `-p linux install`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux install`
