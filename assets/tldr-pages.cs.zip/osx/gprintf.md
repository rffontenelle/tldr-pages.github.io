# gprintf

> Tento příkaz je aliasem pro `-p linux printf`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux printf`
