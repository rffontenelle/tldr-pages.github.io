# gpr

> Tento příkaz je aliasem pro `-p linux pr`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux pr`
