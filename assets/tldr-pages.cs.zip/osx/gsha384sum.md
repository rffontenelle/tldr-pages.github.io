# gsha384sum

> Tento příkaz je aliasem pro `-p linux sha384sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sha384sum`
