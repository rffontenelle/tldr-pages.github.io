# guniq

> Tento příkaz je aliasem pro `-p linux uniq`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux uniq`
