# g[

> Tento příkaz je aliasem pro `-p linux [`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux [`
