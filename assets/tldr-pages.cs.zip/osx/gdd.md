# gdd

> Tento příkaz je aliasem pro `-p linux dd`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux dd`
