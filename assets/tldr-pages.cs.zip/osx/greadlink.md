# greadlink

> Tento příkaz je aliasem pro `-p linux readlink`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux readlink`
