# gsha512sum

> Tento příkaz je aliasem pro `-p linux sha512sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sha512sum`
