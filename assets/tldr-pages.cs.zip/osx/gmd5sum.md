# gmd5sum

> Tento příkaz je aliasem pro `-p linux md5sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux md5sum`
