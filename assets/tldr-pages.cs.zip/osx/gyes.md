# gyes

> Tento příkaz je aliasem pro `-p linux yes`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux yes`
