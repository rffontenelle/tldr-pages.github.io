# gping

> Tento příkaz je aliasem pro `-p linux ping`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ping`
