# gtruncate

> Tento příkaz je aliasem pro `-p linux truncate`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux truncate`
