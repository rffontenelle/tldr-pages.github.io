# gshred

> Tento příkaz je aliasem pro `-p linux shred`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux shred`
