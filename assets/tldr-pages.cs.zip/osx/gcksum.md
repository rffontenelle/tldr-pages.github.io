# gcksum

> Tento příkaz je aliasem pro `-p linux cksum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux cksum`
