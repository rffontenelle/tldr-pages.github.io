# gindent

> Tento příkaz je aliasem pro `-p linux indent`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux indent`
