# gcsplit

> Tento příkaz je aliasem pro `-p linux csplit`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux csplit`
