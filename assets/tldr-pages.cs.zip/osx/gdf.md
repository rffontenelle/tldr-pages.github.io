# gdf

> Tento příkaz je aliasem pro `-p linux df`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux df`
