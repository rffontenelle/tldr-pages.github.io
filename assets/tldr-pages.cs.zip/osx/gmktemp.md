# gmktemp

> Tento příkaz je aliasem pro `-p linux mktemp`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux mktemp`
