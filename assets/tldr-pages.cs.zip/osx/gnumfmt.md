# gnumfmt

> Tento příkaz je aliasem pro `-p linux numfmt`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux numfmt`
