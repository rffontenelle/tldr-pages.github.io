# gprintenv

> Tento příkaz je aliasem pro `-p linux printenv`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux printenv`
