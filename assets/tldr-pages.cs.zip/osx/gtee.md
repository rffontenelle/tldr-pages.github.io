# gtee

> Tento příkaz je aliasem pro `-p linux tee`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux tee`
