# gwhois

> Tento příkaz je aliasem pro `-p linux whois`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux whois`
