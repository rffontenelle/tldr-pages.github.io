# gegrep

> Tento příkaz je aliasem pro `-p linux egrep`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux egrep`
