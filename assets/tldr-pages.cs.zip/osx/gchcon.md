# gchcon

> Tento příkaz je aliasem pro `-p linux chcon`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux chcon`
