# gtar

> Tento příkaz je aliasem pro `-p linux tar`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux tar`
