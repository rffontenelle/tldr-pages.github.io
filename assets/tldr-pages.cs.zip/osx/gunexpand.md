# gunexpand

> Tento příkaz je aliasem pro `-p linux unexpand`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux unexpand`
