# gdate

> Tento příkaz je aliasem pro `-p linux date`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux date`
