# gsha224sum

> Tento příkaz je aliasem pro `-p linux sha224sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sha224sum`
