# gfgrep

> Tento příkaz je aliasem pro `-p linux fgrep`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux fgrep`
