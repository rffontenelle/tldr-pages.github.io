# genv

> Tento příkaz je aliasem pro `-p linux env`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux env`
