# gfactor

> Tento příkaz je aliasem pro `-p linux factor`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux factor`
