# gstat

> Tento příkaz je aliasem pro `-p linux stat`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux stat`
