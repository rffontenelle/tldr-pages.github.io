# gnl

> Tento příkaz je aliasem pro `-p linux nl`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux nl`
