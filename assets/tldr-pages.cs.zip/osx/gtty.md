# gtty

> Tento příkaz je aliasem pro `-p linux tty`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux tty`
