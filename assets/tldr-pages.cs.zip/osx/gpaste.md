# gpaste

> Tento příkaz je aliasem pro `-p linux paste`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux paste`
