# ghostname

> Tento příkaz je aliasem pro `-p linux hostname`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux hostname`
