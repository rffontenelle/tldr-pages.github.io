# gln

> Tento příkaz je aliasem pro `-p linux ln`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ln`
