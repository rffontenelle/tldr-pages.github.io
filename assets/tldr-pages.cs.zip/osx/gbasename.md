# gbasename

> Tento příkaz je aliasem pro `-p linux basename`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux basename`
