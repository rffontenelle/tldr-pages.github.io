# gmknod

> Tento příkaz je aliasem pro `-p linux mknod`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux mknod`
