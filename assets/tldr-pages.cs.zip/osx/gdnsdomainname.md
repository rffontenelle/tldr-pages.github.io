# gdnsdomainname

> Tento příkaz je aliasem pro `-p linux dnsdomainname`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux dnsdomainname`
