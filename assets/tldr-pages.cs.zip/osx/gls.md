# gls

> Tento příkaz je aliasem pro `-p linux ls`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ls`
