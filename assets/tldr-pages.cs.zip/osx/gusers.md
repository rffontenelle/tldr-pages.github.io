# gusers

> Tento příkaz je aliasem pro `-p linux users`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux users`
