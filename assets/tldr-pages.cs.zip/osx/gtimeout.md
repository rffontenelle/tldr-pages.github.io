# gtimeout

> Tento příkaz je aliasem pro `-p linux timeout`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux timeout`
