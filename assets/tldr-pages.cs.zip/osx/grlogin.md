# grlogin

> Tento příkaz je aliasem pro `-p linux rlogin`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux rlogin`
