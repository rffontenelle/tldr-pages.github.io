# gbase32

> Tento příkaz je aliasem pro `-p linux base32`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux base32`
