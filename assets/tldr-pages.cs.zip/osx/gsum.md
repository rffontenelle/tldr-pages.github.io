# gsum

> Tento příkaz je aliasem pro `-p linux sum`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux sum`
