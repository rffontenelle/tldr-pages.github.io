# glibtoolize

> Tento příkaz je aliasem pro `-p linux libtoolize`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux libtoolize`
