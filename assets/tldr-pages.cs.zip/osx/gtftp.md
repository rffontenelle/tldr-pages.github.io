# gtftp

> Tento příkaz je aliasem pro `-p linux tftp`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux tftp`
