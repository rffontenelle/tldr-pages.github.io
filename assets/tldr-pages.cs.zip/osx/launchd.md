# launchd

> Tento příkaz je aliasem pro `launchctl`.
> Více informací: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr launchctl`
