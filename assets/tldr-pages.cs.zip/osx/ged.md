# ged

> Tento příkaz je aliasem pro `-p linux ed`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux ed`
