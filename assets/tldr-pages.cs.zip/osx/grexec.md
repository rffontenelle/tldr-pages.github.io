# grexec

> Tento příkaz je aliasem pro `-p linux rexec`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux rexec`
