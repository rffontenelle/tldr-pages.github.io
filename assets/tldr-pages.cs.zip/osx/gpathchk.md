# gpathchk

> Tento příkaz je aliasem pro `-p linux pathchk`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux pathchk`
