# gcut

> Tento příkaz je aliasem pro `-p linux cut`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux cut`
