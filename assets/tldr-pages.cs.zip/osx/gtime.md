# gtime

> Tento příkaz je aliasem pro `-p linux time`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux time`
