# gsplit

> Tento příkaz je aliasem pro `-p linux split`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux split`
