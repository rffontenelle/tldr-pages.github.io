# gtelnet

> Tento příkaz je aliasem pro `-p linux telnet`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux telnet`
