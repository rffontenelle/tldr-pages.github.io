# aa

> Tento příkaz je aliasem pro `yaa`.

- Podívejte se na dokumentaci původního příkazu:

`tldr yaa`
