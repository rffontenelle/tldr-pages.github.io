# ggroups

> Tento příkaz je aliasem pro `-p linux groups`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux groups`
