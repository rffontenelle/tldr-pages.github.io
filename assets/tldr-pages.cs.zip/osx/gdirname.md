# gdirname

> Tento příkaz je aliasem pro `-p linux dirname`.

- Podívejte se na dokumentaci původního příkazu:

`tldr -p linux dirname`
