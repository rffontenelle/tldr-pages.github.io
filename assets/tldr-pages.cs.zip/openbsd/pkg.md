# pkg

> Tento příkaz je aliasem pro `pkg_add`.
> Více informací: <https://www.openbsd.org/faq/faq15.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr pkg_add`
