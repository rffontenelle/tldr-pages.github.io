# mscore

> Tento příkaz je aliasem pro `musescore`.
> Více informací: <https://musescore.org/handbook/command-line-options>.

- Podívejte se na dokumentaci původního příkazu:

`tldr musescore`
