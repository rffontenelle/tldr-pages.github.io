# llvm-strings

> Tento příkaz je aliasem pro `strings`.

- Podívejte se na dokumentaci původního příkazu:

`tldr strings`
