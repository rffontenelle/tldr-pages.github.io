# musl-gcc

> Tento příkaz je aliasem pro `gcc`.
> Více informací: <https://manned.org/musl-gcc>.

- Podívejte se na dokumentaci původního příkazu:

`tldr gcc`
