# gnmic-sub

> Tento příkaz je aliasem pro `gnmic subscribe`.
> Více informací: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Podívejte se na dokumentaci původního příkazu:

`tldr gnmic subscribe`
