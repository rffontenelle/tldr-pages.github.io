# llvm-objdump

> Tento příkaz je aliasem pro `objdump`.

- Podívejte se na dokumentaci původního příkazu:

`tldr objdump`
