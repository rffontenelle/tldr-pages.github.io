# pwsh

> Tento příkaz je aliasem pro `powershell`.

- Podívejte se na dokumentaci původního příkazu:

`tldr powershell`
