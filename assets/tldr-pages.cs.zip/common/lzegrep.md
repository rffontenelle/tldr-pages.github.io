# lzegrep

> Tento příkaz je aliasem pro `xzgrep`.

- Podívejte se na dokumentaci původního příkazu:

`tldr xzgrep`
