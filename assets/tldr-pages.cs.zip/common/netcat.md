# netcat

> Tento příkaz je aliasem pro `nc`.

- Podívejte se na dokumentaci původního příkazu:

`tldr nc`
