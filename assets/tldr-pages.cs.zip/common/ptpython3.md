# ptpython3

> Tento příkaz je aliasem pro `ptpython`.

- Podívejte se na dokumentaci původního příkazu:

`tldr ptpython`
