# hd

> Tento příkaz je aliasem pro `hexdump`.
> Více informací: <https://manned.org/hd.1>.

- Podívejte se na dokumentaci původního příkazu:

`tldr hexdump`
