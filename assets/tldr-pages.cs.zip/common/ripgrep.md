# ripgrep

> Tento příkaz je aliasem pro `rg`.

- Podívejte se na dokumentaci původního příkazu:

`tldr rg`
