# piodebuggdb

> Tento příkaz je aliasem pro `pio debug`.

- Podívejte se na dokumentaci původního příkazu:

`tldr pio debug`
