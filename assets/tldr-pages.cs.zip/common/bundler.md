# bundler

> Tento příkaz je aliasem pro `bundle`.
> Více informací: <https://bundler.io/man/bundle.1.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr bundle`
