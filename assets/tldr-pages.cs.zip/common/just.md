# just

> Tento příkaz je aliasem pro `just.1`.

- Podívejte se na dokumentaci původního příkazu:

`tldr just.1`
