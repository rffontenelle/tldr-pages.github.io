# fossil-ci

> Tento příkaz je aliasem pro `fossil-commit`.
> Více informací: <https://fossil-scm.org/home/help/commit>.

- Podívejte se na dokumentaci původního příkazu:

`tldr fossil-commit`
