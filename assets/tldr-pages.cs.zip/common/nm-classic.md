# nm-classic

> Tento příkaz je aliasem pro `nm`.

- Podívejte se na dokumentaci původního příkazu:

`tldr nm`
