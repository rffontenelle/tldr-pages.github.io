# lzless

> Tento příkaz je aliasem pro `xzless`.

- Podívejte se na dokumentaci původního příkazu:

`tldr xzless`
