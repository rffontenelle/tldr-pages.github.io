# fossil-forget

> Tento příkaz je aliasem pro `fossil rm`.
> Více informací: <https://fossil-scm.org/home/help/forget>.

- Podívejte se na dokumentaci původního příkazu:

`tldr fossil rm`
