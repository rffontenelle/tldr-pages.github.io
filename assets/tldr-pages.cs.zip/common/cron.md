# cron

> Tento příkaz je aliasem pro `crontab`.

- Podívejte se na dokumentaci původního příkazu:

`tldr crontab`
