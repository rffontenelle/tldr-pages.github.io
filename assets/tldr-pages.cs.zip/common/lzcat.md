# lzcat

> Tento příkaz je aliasem pro `xz`.
> Více informací: <https://manned.org/lzcat>.

- Podívejte se na dokumentaci původního příkazu:

`tldr xz`
