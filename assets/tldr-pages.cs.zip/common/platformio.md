# platformio

> Tento příkaz je aliasem pro `pio`.
> Více informací: <https://docs.platformio.org/en/latest/core/userguide/>.

- Podívejte se na dokumentaci původního příkazu:

`tldr pio`
