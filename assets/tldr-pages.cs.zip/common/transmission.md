# transmission

> Tento příkaz je aliasem pro `transmission-daemon`.
> Více informací: <https://transmissionbt.com/>.

- Podívejte se na dokumentaci původního příkazu:

`tldr transmission-daemon`
