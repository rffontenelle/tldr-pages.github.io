# rcat

> Tento příkaz je aliasem pro `rc`.

- Podívejte se na dokumentaci původního příkazu:

`tldr rc`
