# unlzma

> Tento příkaz je aliasem pro `xz`.
> Více informací: <https://manned.org/unlzma>.

- Podívejte se na dokumentaci původního příkazu:

`tldr xz`
