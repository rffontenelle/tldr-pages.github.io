# fossil-delete

> Tento příkaz je aliasem pro `fossil rm`.
> Více informací: <https://fossil-scm.org/home/help/delete>.

- Podívejte se na dokumentaci původního příkazu:

`tldr fossil rm`
