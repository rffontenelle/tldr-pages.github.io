# todoman

> Tento příkaz je aliasem pro `todo`.
> Více informací: <https://todoman.readthedocs.io/>.

- Podívejte se na dokumentaci původního příkazu:

`tldr todo`
