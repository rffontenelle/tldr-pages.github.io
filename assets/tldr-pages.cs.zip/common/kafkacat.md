# kafkacat

> Tento příkaz je aliasem pro `kcat`.

- Podívejte se na dokumentaci původního příkazu:

`tldr kcat`
