# docker-container-diff

> Tento příkaz je aliasem pro `docker diff`.
> Více informací: <https://docs.docker.com/engine/reference/commandline/diff>.

- Podívejte se na dokumentaci původního příkazu:

`tldr docker diff`
