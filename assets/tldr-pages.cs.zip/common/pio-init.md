# pio-init

> Tento příkaz je aliasem pro `pio project`.

- Podívejte se na dokumentaci původního příkazu:

`tldr pio project`
