# ntl

> Tento příkaz je aliasem pro `netlify`.
> Více informací: <https://cli.netlify.com>.

- Podívejte se na dokumentaci původního příkazu:

`tldr netlify`
