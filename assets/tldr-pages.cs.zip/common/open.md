# open

> Tento příkaz je aliasem pro `open -p osx`.

- Podívejte se na dokumentaci původního příkazu:

`tldr open -p osx`
