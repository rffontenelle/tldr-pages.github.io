# azure-cli

> Tento příkaz je aliasem pro `az`.
> Více informací: <https://learn.microsoft.com/cli/azure>.

- Podívejte se na dokumentaci původního příkazu:

`tldr az`
