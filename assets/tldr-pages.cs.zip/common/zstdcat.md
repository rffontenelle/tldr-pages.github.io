# zstdcat

> Tento příkaz je aliasem pro `zstd`.

- Podívejte se na dokumentaci původního příkazu:

`tldr zstd`
