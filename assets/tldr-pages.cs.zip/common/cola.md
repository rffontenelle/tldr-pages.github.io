# cola

> Tento příkaz je aliasem pro `git-cola`.

- Podívejte se na dokumentaci původního příkazu:

`tldr git-cola`
