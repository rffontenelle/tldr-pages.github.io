# linode-cli

> Tento příkaz je aliasem pro `linode-cli account`.
> Více informací: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Podívejte se na dokumentaci původního příkazu:

`tldr linode-cli account`
