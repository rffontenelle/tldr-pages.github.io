# hping

> Tento příkaz je aliasem pro `hping3`.
> Více informací: <https://github.com/antirez/hping>.

- Podívejte se na dokumentaci původního příkazu:

`tldr hping3`
