# lzcmp

> Tento příkaz je aliasem pro `xzcmp`.

- Podívejte se na dokumentaci původního příkazu:

`tldr xzcmp`
