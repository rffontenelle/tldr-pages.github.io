# vi

> Tento příkaz je aliasem pro `vim`.

- Podívejte se na dokumentaci původního příkazu:

`tldr vim`
