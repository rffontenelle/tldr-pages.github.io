# clojure

> Tento příkaz je aliasem pro `clj`.

- Podívejte se na dokumentaci původního příkazu:

`tldr clj`
