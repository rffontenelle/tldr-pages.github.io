# clamav

> Tento příkaz je aliasem pro `clamdscan`.
> Více informací: <https://www.clamav.net>.

- Podívejte se na dokumentaci původního příkazu:

`tldr clamdscan`
