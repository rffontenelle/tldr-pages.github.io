# fossil-new

> Tento příkaz je aliasem pro `fossil-init`.
> Více informací: <https://fossil-scm.org/home/help/new>.

- Podívejte se na dokumentaci původního příkazu:

`tldr fossil-init`
