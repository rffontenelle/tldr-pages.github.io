# google-chrome

> Tento příkaz je aliasem pro `chromium`.
> Více informací: <https://chrome.google.com>.

- Podívejte se na dokumentaci původního příkazu:

`tldr chromium`
