# python3

> Tento příkaz je aliasem pro `python`.

- Podívejte se na dokumentaci původního příkazu:

`tldr python`
