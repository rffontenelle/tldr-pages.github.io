# hx

> Tento příkaz je aliasem pro `helix`.

- Podívejte se na dokumentaci původního příkazu:

`tldr helix`
