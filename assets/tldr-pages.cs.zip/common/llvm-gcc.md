# llvm-gcc

> Tento příkaz je aliasem pro `clang`.

- Podívejte se na dokumentaci původního příkazu:

`tldr clang`
