# lzma

> Tento příkaz je aliasem pro `xz`.
> Více informací: <https://manned.org/lzma>.

- Podívejte se na dokumentaci původního příkazu:

`tldr xz`
