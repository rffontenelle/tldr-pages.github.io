# docker-container-rm

> Tento příkaz je aliasem pro `docker rm`.
> Více informací: <https://docs.docker.com/engine/reference/commandline/rm>.

- Podívejte se na dokumentaci původního příkazu:

`tldr docker rm`
