# lima

> Tento příkaz je aliasem pro `limactl`.
> Více informací: <https://github.com/lima-vm/lima>.

- Podívejte se na dokumentaci původního příkazu:

`tldr limactl`
