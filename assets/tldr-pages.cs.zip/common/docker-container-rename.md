# docker-container-rename

> Tento příkaz je aliasem pro `docker rename`.
> Více informací: <https://docs.docker.com/engine/reference/commandline/rename>.

- Podívejte se na dokumentaci původního příkazu:

`tldr docker rename`
