# lzmore

> Tento příkaz je aliasem pro `xzmore`.

- Podívejte se na dokumentaci původního příkazu:

`tldr xzmore`
