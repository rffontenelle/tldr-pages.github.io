# xzcat

> Tento příkaz je aliasem pro `xz`.
> Více informací: <https://manned.org/xzcat>.

- Podívejte se na dokumentaci původního příkazu:

`tldr xz`
