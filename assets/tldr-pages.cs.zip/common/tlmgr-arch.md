# tlmgr-arch

> Tento příkaz je aliasem pro `tlmgr platform`.
> Více informací: <https://www.tug.org/texlive/tlmgr.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr tlmgr platform`
