# gh-cs

> Tento příkaz je aliasem pro `gh-codespace`.
> Více informací: <https://cli.github.com/manual/gh_codespace>.

- Podívejte se na dokumentaci původního příkazu:

`tldr gh-codespace`
