# llvm-ar

> Tento příkaz je aliasem pro `ar`.

- Podívejte se na dokumentaci původního příkazu:

`tldr ar`
