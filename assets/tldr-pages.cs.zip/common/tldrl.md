# tldrl

> Tento příkaz je aliasem pro `tldr-lint`.
> Více informací: <https://github.com/tldr-pages/tldr-lint>.

- Podívejte se na dokumentaci původního příkazu:

`tldr tldr-lint`
