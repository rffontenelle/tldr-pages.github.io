# clist

> Tento příkaz je aliasem pro `choco list`.
> Více informací: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Podívejte se na dokumentaci původního příkazu:

`tldr choco list`
