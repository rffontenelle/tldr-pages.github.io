# wget

> Tento příkaz je aliasem pro `wget -p common`.
> Více informací: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Podívejte se na dokumentaci původního příkazu:

`tldr wget -p common`
