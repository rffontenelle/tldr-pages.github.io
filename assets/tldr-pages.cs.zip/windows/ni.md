# ni

> Tento příkaz je aliasem pro `new-item`.
> Více informací: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Podívejte se na dokumentaci původního příkazu:

`tldr new-item`
