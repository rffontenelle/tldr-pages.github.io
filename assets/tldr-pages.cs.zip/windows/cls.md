# cls

> Tento příkaz je aliasem pro `clear-host`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Podívejte se na dokumentaci původního příkazu:

`tldr clear-host`
