# rd

> Tento příkaz je aliasem pro `rmdir`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Podívejte se na dokumentaci původního příkazu:

`tldr rmdir`
