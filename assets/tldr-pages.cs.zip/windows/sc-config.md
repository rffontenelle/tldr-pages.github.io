# sc-config

> Tento příkaz je aliasem pro `sc`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Podívejte se na dokumentaci původního příkazu:

`tldr sc`
