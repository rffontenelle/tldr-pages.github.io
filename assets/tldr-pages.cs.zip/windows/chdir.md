# chdir

> Tento příkaz je aliasem pro `cd`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Podívejte se na dokumentaci původního příkazu:

`tldr cd`
