# cpush

> Tento příkaz je aliasem pro `choco-push`.
> Více informací: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Podívejte se na dokumentaci původního příkazu:

`tldr choco-push`
