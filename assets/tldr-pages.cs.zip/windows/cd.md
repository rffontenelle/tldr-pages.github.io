# cd

> Tento příkaz je aliasem pro `set-location`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Podívejte se na dokumentaci původního příkazu:

`tldr set-location`
