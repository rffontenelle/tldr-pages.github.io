# sc-delete

> Tento příkaz je aliasem pro `sc`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Podívejte se na dokumentaci původního příkazu:

`tldr sc`
