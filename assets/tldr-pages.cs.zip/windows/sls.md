# sls

> Tento příkaz je aliasem pro `where-object`.
> Více informací: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Podívejte se na dokumentaci původního příkazu:

`tldr where-object`
