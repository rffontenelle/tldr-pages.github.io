# pwsh-where

> Tento příkaz je aliasem pro `Where-Object`.
> Více informací: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Podívejte se na dokumentaci původního příkazu:

`tldr Where-Object`
