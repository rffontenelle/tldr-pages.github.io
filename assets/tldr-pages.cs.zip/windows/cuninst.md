# cuninst

> Tento příkaz je aliasem pro `choco uninstall`.
> Více informací: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Podívejte se na dokumentaci původního příkazu:

`tldr choco uninstall`
