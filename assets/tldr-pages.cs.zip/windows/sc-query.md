# sc-query

> Tento příkaz je aliasem pro `sc`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Podívejte se na dokumentaci původního příkazu:

`tldr sc`
