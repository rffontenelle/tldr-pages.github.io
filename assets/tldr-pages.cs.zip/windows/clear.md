# clear

> Tento příkaz je aliasem pro `clear-host`.

- Podívejte se na dokumentaci původního příkazu:

`tldr clear-host`
