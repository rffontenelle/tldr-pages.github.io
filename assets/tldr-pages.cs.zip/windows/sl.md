# sl

> Tento příkaz je aliasem pro `set-location`.
> Více informací: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Podívejte se na dokumentaci původního příkazu:

`tldr set-location`
