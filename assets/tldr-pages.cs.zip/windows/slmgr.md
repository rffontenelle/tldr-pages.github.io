# slmgr

> Tento příkaz je aliasem pro `slmgr.vbs`.
> Více informací: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Podívejte se na dokumentaci původního příkazu:

`tldr slmgr.vbs`
