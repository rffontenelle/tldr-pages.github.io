# sc-create

> Tento příkaz je aliasem pro `sc`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Podívejte se na dokumentaci původního příkazu:

`tldr sc`
