# gal

> Tento příkaz je aliasem pro `get-alias`.
> Více informací: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Podívejte se na dokumentaci původního příkazu:

`tldr get-alias`
