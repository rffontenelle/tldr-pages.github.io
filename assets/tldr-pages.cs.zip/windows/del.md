# del

> Tento příkaz je aliasem pro `remove-item`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Podívejte se na dokumentaci původního příkazu:

`tldr remove-item`
