# rmdir

> Tento příkaz je aliasem pro `remove-item`.
> Více informací: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Podívejte se na dokumentaci původního příkazu:

`tldr remove-item`
