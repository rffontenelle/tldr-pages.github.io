# cinst

> Tento příkaz je aliasem pro `choco install`.
> Více informací: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Podívejte se na dokumentaci původního příkazu:

`tldr choco install`
