# ip6tables-restore

> Tento příkaz je aliasem pro `iptables-restore`.

- Podívejte se na dokumentaci původního příkazu:

`tldr iptables-restore`
