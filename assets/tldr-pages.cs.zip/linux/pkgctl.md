# pkgctl

> Tento příkaz je aliasem pro `pkgctl auth`.
> Více informací: <https://man.archlinux.org/man/pkgctl.1>.

- Podívejte se na dokumentaci původního příkazu:

`tldr pkgctl auth`
