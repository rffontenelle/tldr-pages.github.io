# mount.smb3

> Tento příkaz je aliasem pro `mount.cifs`.

- Podívejte se na dokumentaci původního příkazu:

`tldr mount.cifs`
