# shntool-split

> Tento příkaz je aliasem pro `shnsplit`.

- Podívejte se na dokumentaci původního příkazu:

`tldr shnsplit`
