# megadl

> Tento příkaz je aliasem pro `megatools-dl`.
> Více informací: <https://megatools.megous.com/man/megatools-dl.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr megatools-dl`
