# ncal

> Tento příkaz je aliasem pro `cal`.
> Více informací: <https://manned.org/ncal>.

- Podívejte se na dokumentaci původního příkazu:

`tldr cal`
