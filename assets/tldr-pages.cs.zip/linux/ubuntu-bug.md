# ubuntu-bug

> Tento příkaz je aliasem pro `apport-bug`.
> Více informací: <https://manned.org/ubuntu-bug>.

- Podívejte se na dokumentaci původního příkazu:

`tldr apport-bug`
