# ip6tables-save

> Tento příkaz je aliasem pro `iptables-save`.

- Podívejte se na dokumentaci původního příkazu:

`tldr iptables-save`
