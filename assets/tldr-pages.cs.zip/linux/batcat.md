# batcat

> Tento příkaz je aliasem pro `bat`.
> Více informací: <https://github.com/sharkdp/bat>.

- Podívejte se na dokumentaci původního příkazu:

`tldr bat`
