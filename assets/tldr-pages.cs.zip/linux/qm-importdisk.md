# qm-importdisk

> Tento příkaz je aliasem pro `qm disk import`.

- Podívejte se na dokumentaci původního příkazu:

`tldr qm disk import`
