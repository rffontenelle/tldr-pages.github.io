# alternatives

> Tento příkaz je aliasem pro `update-alternatives`.
> Více informací: <https://manned.org/alternatives>.

- Podívejte se na dokumentaci původního příkazu:

`tldr update-alternatives`
