# nmcli

> Tento příkaz je aliasem pro `nmcli agent`.
> Více informací: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr nmcli agent`
