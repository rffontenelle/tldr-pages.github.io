# ip-route-list

> Tento příkaz je aliasem pro `ip-route-show`.

- Podívejte se na dokumentaci původního příkazu:

`tldr ip-route-show`
