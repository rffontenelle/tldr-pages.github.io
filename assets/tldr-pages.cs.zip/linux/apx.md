# apx

> Tento příkaz je aliasem pro `apx pkgmanagers`.
> Více informací: <https://github.com/Vanilla-OS/apx>.

- Podívejte se na dokumentaci původního příkazu:

`tldr apx pkgmanagers`
