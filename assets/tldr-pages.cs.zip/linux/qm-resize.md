# qm-resize

> Tento příkaz je aliasem pro `qm-disk-resize`.
> Více informací: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr qm-disk-resize`
