# cgroups

> Tento příkaz je aliasem pro `cgclassify`.
> Více informací: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Podívejte se na dokumentaci původního příkazu:

`tldr cgclassify`
