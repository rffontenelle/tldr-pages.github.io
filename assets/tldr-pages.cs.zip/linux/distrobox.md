# distrobox

> Tento příkaz je aliasem pro `distrobox-create`.
> Více informací: <https://github.com/89luca89/distrobox>.

- Podívejte se na dokumentaci původního příkazu:

`tldr distrobox-create`
