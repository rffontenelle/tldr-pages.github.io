# bspwm

> Tento příkaz je aliasem pro `bspc`.
> Více informací: <https://github.com/baskerville/bspwm>.

- Podívejte se na dokumentaci původního příkazu:

`tldr bspc`
