# xbps

> Tento příkaz je aliasem pro `xbps-install`.
> Více informací: <https://docs.voidlinux.org/xbps/index.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr xbps-install`
