# ip6tables

> Tento příkaz je aliasem pro `iptables`.

- Podívejte se na dokumentaci původního příkazu:

`tldr iptables`
