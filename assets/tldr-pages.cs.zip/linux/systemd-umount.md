# systemd-umount

> Tento příkaz je aliasem pro `systemd-mount`.

- Podívejte se na dokumentaci původního příkazu:

`tldr systemd-mount`
