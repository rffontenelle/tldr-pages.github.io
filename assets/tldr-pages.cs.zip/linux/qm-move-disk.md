# qm-move-disk

> Tento příkaz je aliasem pro `qm-disk-move`.
> Více informací: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Podívejte se na dokumentaci původního příkazu:

`tldr qm-disk-move`
