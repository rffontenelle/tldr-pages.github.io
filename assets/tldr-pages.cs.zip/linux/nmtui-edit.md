# nmtui-edit

> Tento příkaz je aliasem pro `nmtui`.

- Podívejte se na dokumentaci původního příkazu:

`tldr nmtui`
