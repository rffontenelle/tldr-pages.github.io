# cc

> Tento příkaz je aliasem pro `gcc`.
> Více informací: <https://gcc.gnu.org>.

- Podívejte se na dokumentaci původního příkazu:

`tldr gcc`
