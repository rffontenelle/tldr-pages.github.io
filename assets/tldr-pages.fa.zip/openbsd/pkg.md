# pkg

> این دستور یک نام مستعار از `pkg_add` است.
> اطلاعات بیشتر: <https://www.openbsd.org/faq/faq15.html>.

- مشاهده مستندات دستور اصلی :

`tldr pkg_add`
