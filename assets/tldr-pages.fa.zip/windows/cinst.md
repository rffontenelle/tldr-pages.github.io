# cinst

> این دستور یک نام مستعار از `choco install` است.
> اطلاعات بیشتر: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- مشاهده مستندات دستور اصلی :

`tldr choco install`
