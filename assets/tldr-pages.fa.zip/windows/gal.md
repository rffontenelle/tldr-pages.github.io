# gal

> این دستور یک نام مستعار از `get-alias` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- مشاهده مستندات دستور اصلی :

`tldr get-alias`
