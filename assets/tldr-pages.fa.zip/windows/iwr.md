# iwr

> این دستور یک نام مستعار از `invoke-webrequest` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- مشاهده مستندات دستور اصلی :

`tldr invoke-webrequest`
