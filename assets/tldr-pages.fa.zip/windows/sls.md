# sls

> این دستور یک نام مستعار از `where-object` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- مشاهده مستندات دستور اصلی :

`tldr where-object`
