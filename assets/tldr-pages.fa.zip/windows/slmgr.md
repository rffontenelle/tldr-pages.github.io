# slmgr

> این دستور یک نام مستعار از `slmgr.vbs` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- مشاهده مستندات دستور اصلی :

`tldr slmgr.vbs`
