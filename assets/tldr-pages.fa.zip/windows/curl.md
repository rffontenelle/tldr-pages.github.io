# curl

> این دستور یک نام مستعار از `curl -p common` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- مشاهده مستندات دستور اصلی :

`tldr curl -p common`
