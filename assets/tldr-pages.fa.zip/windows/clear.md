# clear

> این دستور یک نام مستعار از `clear-host` است.

- مشاهده مستندات دستور اصلی :

`tldr clear-host`
