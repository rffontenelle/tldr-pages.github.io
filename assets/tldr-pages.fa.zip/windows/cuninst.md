# cuninst

> این دستور یک نام مستعار از `choco uninstall` است.
> اطلاعات بیشتر: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- مشاهده مستندات دستور اصلی :

`tldr choco uninstall`
