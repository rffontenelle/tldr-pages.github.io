# cpush

> این دستور یک نام مستعار از `choco-push` است.
> اطلاعات بیشتر: <https://docs.chocolatey.org/en-us/create/commands/push>.

- مشاهده مستندات دستور اصلی :

`tldr choco-push`
