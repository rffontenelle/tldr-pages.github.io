# del

> این دستور یک نام مستعار از `remove-item` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- مشاهده مستندات دستور اصلی :

`tldr remove-item`
