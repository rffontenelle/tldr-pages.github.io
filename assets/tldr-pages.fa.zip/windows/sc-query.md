# sc-query

> این دستور یک نام مستعار از `sc` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- مشاهده مستندات دستور اصلی :

`tldr sc`
