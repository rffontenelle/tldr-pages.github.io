# pwsh-where

> این دستور یک نام مستعار از `Where-Object` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- مشاهده مستندات دستور اصلی :

`tldr Where-Object`
