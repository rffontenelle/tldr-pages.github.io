# rd

> این دستور یک نام مستعار از `rmdir` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- مشاهده مستندات دستور اصلی :

`tldr rmdir`
