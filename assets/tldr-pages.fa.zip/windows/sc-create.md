# sc-create

> این دستور یک نام مستعار از `sc` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- مشاهده مستندات دستور اصلی :

`tldr sc`
