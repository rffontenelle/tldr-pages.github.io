# clist

> این دستور یک نام مستعار از `choco list` است.
> اطلاعات بیشتر: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- مشاهده مستندات دستور اصلی :

`tldr choco list`
