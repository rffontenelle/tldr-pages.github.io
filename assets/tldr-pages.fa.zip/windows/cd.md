# cd

> این دستور یک نام مستعار از `set-location` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- مشاهده مستندات دستور اصلی :

`tldr set-location`
