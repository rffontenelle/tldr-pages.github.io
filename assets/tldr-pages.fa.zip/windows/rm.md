# rm

> این دستور یک نام مستعار از `remove-item` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- مشاهده مستندات دستور اصلی :

`tldr remove-item`
