# chdir

> این دستور یک نام مستعار از `cd` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- مشاهده مستندات دستور اصلی :

`tldr cd`
