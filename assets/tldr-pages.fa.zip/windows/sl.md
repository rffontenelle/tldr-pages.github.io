# sl

> این دستور یک نام مستعار از `set-location` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- مشاهده مستندات دستور اصلی :

`tldr set-location`
