# sc-config

> این دستور یک نام مستعار از `sc` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- مشاهده مستندات دستور اصلی :

`tldr sc`
