# ni

> این دستور یک نام مستعار از `new-item` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- مشاهده مستندات دستور اصلی :

`tldr new-item`
