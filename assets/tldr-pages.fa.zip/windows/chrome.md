# chrome

> این دستور یک نام مستعار از `chromium` است.
> اطلاعات بیشتر: <https://chrome.google.com>.

- مشاهده مستندات دستور اصلی :

`tldr chromium`
