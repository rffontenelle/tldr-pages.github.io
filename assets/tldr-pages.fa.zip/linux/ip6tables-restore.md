# ip6tables-restore

> این دستور یک نام مستعار از `iptables-restore` است.

- مشاهده مستندات دستور اصلی :

`tldr iptables-restore`
