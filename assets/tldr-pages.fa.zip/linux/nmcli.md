# nmcli

> این دستور یک نام مستعار از `nmcli agent` است.
> اطلاعات بیشتر: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- مشاهده مستندات دستور اصلی :

`tldr nmcli agent`
