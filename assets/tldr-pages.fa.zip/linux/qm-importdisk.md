# qm-importdisk

> این دستور یک نام مستعار از `qm disk import` است.

- مشاهده مستندات دستور اصلی :

`tldr qm disk import`
