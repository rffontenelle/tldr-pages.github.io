# mount.smb3

> این دستور یک نام مستعار از `mount.cifs` است.

- مشاهده مستندات دستور اصلی :

`tldr mount.cifs`
