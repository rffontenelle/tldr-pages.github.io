# ubuntu-bug

> این دستور یک نام مستعار از `apport-bug` است.
> اطلاعات بیشتر: <https://manned.org/ubuntu-bug>.

- مشاهده مستندات دستور اصلی :

`tldr apport-bug`
