# batcat

> این دستور یک نام مستعار از `bat` است.
> اطلاعات بیشتر: <https://github.com/sharkdp/bat>.

- مشاهده مستندات دستور اصلی :

`tldr bat`
