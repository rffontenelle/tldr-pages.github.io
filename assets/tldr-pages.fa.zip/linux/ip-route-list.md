# ip-route-list

> این دستور یک نام مستعار از `ip-route-show` است.

- مشاهده مستندات دستور اصلی :

`tldr ip-route-show`
