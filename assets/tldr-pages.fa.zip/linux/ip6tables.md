# ip6tables

> این دستور یک نام مستعار از `iptables` است.

- مشاهده مستندات دستور اصلی :

`tldr iptables`
