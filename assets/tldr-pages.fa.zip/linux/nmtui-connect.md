# nmtui-connect

> این دستور یک نام مستعار از `nmtui` است.

- مشاهده مستندات دستور اصلی :

`tldr nmtui`
