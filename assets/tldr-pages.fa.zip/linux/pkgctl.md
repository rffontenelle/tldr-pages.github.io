# pkgctl

> این دستور یک نام مستعار از `pkgctl auth` است.
> اطلاعات بیشتر: <https://man.archlinux.org/man/pkgctl.1>.

- مشاهده مستندات دستور اصلی :

`tldr pkgctl auth`
