# xbps

> این دستور یک نام مستعار از `xbps-install` است.
> اطلاعات بیشتر: <https://docs.voidlinux.org/xbps/index.html>.

- مشاهده مستندات دستور اصلی :

`tldr xbps-install`
