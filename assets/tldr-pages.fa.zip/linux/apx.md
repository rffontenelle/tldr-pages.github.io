# apx

> این دستور یک نام مستعار از `apx pkgmanagers` است.
> اطلاعات بیشتر: <https://github.com/Vanilla-OS/apx>.

- مشاهده مستندات دستور اصلی :

`tldr apx pkgmanagers`
