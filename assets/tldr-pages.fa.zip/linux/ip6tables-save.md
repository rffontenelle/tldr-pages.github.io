# ip6tables-save

> این دستور یک نام مستعار از `iptables-save` است.

- مشاهده مستندات دستور اصلی :

`tldr iptables-save`
