# qm-move-disk

> این دستور یک نام مستعار از `qm-disk-move` است.
> اطلاعات بیشتر: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- مشاهده مستندات دستور اصلی :

`tldr qm-disk-move`
