# qm-resize

> این دستور یک نام مستعار از `qm-disk-resize` است.
> اطلاعات بیشتر: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- مشاهده مستندات دستور اصلی :

`tldr qm-disk-resize`
