# alternatives

> این دستور یک نام مستعار از `update-alternatives` است.
> اطلاعات بیشتر: <https://manned.org/alternatives>.

- مشاهده مستندات دستور اصلی :

`tldr update-alternatives`
