# bspwm

> این دستور یک نام مستعار از `bspc` است.
> اطلاعات بیشتر: <https://github.com/baskerville/bspwm>.

- مشاهده مستندات دستور اصلی :

`tldr bspc`
