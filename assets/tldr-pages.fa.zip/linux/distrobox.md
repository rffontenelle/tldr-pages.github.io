# distrobox

> این دستور یک نام مستعار از `distrobox-create` است.
> اطلاعات بیشتر: <https://github.com/89luca89/distrobox>.

- مشاهده مستندات دستور اصلی :

`tldr distrobox-create`
