# cgroups

> این دستور یک نام مستعار از `cgclassify` است.
> اطلاعات بیشتر: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- مشاهده مستندات دستور اصلی :

`tldr cgclassify`
