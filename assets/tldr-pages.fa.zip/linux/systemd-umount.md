# systemd-umount

> این دستور یک نام مستعار از `systemd-mount` است.

- مشاهده مستندات دستور اصلی :

`tldr systemd-mount`
