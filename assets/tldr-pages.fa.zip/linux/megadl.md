# megadl

> این دستور یک نام مستعار از `megatools-dl` است.
> اطلاعات بیشتر: <https://megatools.megous.com/man/megatools-dl.html>.

- مشاهده مستندات دستور اصلی :

`tldr megatools-dl`
