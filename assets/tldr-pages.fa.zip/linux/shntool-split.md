# shntool-split

> این دستور یک نام مستعار از `shnsplit` است.

- مشاهده مستندات دستور اصلی :

`tldr shnsplit`
