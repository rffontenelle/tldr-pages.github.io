# docker-container-remove

> این دستور یک نام مستعار از `docker rm` است.
> اطلاعات بیشتر: <https://docs.docker.com/engine/reference/commandline/rm>.

- مشاهده مستندات دستور اصلی :

`tldr docker rm`
