# gh-cs

> این دستور یک نام مستعار از `gh-codespace` است.
> اطلاعات بیشتر: <https://cli.github.com/manual/gh_codespace>.

- مشاهده مستندات دستور اصلی :

`tldr gh-codespace`
