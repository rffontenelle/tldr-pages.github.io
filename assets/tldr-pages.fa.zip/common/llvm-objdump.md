# llvm-objdump

> این دستور یک نام مستعار از `objdump` است.

- مشاهده مستندات دستور اصلی :

`tldr objdump`
