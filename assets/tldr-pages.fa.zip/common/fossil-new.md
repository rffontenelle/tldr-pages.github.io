# fossil-new

> این دستور یک نام مستعار از `fossil-init` است.
> اطلاعات بیشتر: <https://fossil-scm.org/home/help/new>.

- مشاهده مستندات دستور اصلی :

`tldr fossil-init`
