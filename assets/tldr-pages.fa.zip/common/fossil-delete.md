# fossil-delete

> این دستور یک نام مستعار از `fossil rm` است.
> اطلاعات بیشتر: <https://fossil-scm.org/home/help/delete>.

- مشاهده مستندات دستور اصلی :

`tldr fossil rm`
