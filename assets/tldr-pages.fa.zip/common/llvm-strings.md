# llvm-strings

> این دستور یک نام مستعار از `strings` است.

- مشاهده مستندات دستور اصلی :

`tldr strings`
