# azure-cli

> این دستور یک نام مستعار از `az` است.
> اطلاعات بیشتر: <https://learn.microsoft.com/cli/azure>.

- مشاهده مستندات دستور اصلی :

`tldr az`
