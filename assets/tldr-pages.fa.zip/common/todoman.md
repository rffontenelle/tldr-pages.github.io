# todoman

> این دستور یک نام مستعار از `todo` است.
> اطلاعات بیشتر: <https://todoman.readthedocs.io/>.

- مشاهده مستندات دستور اصلی :

`tldr todo`
