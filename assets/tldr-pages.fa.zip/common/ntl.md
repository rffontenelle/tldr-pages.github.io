# ntl

> این دستور یک نام مستعار از `netlify` است.
> اطلاعات بیشتر: <https://cli.netlify.com>.

- مشاهده مستندات دستور اصلی :

`tldr netlify`
