# docker-container-top

> این دستور یک نام مستعار از `docker top` است.
> اطلاعات بیشتر: <https://docs.docker.com/engine/reference/commandline/top>.

- مشاهده مستندات دستور اصلی :

`tldr docker top`
