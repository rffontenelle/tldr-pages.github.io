# fossil-ci

> این دستور یک نام مستعار از `fossil-commit` است.
> اطلاعات بیشتر: <https://fossil-scm.org/home/help/commit>.

- مشاهده مستندات دستور اصلی :

`tldr fossil-commit`
