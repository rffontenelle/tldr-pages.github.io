# piodebuggdb

> این دستور یک نام مستعار از `pio debug` است.

- مشاهده مستندات دستور اصلی :

`tldr pio debug`
