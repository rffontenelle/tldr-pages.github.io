# hd

> این دستور یک نام مستعار از `hexdump` است.
> اطلاعات بیشتر: <https://manned.org/hd.1>.

- مشاهده مستندات دستور اصلی :

`tldr hexdump`
