# musl-gcc

> این دستور یک نام مستعار از `gcc` است.
> اطلاعات بیشتر: <https://manned.org/musl-gcc>.

- مشاهده مستندات دستور اصلی :

`tldr gcc`
