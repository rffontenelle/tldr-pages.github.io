# transmission

> این دستور یک نام مستعار از `transmission-daemon` است.
> اطلاعات بیشتر: <https://transmissionbt.com/>.

- مشاهده مستندات دستور اصلی :

`tldr transmission-daemon`
