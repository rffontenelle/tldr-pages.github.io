# tlmgr-arch

> این دستور یک نام مستعار از `tlmgr platform` است.
> اطلاعات بیشتر: <https://www.tug.org/texlive/tlmgr.html>.

- مشاهده مستندات دستور اصلی :

`tldr tlmgr platform`
