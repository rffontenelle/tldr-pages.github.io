# export

> دستور تغییر متغییرهای محلی سیستم موجود برای پروسه های جدید.
> اطلاعات بیشتر: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#export>.

- ایجاد و تعیین مقدار یک متغییر جدید:

`export {{VARIABLE}}={{value}}`

- افزودن یک مسیر به متغییر $PATH:

`export PATH=$PATH:{{path/to/append}}`
