# view

> نسخه فقط خواندنی vim.
> معادل vim -R.
> اطلاعات بیشتر: <https://www.vim.org>.

- باز کردن فایل:

`view {{file}}`
