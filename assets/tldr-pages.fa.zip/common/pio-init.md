# pio-init

> این دستور یک نام مستعار از `pio project` است.

- مشاهده مستندات دستور اصلی :

`tldr pio project`
