# lima

> این دستور یک نام مستعار از `limactl` است.
> اطلاعات بیشتر: <https://github.com/lima-vm/lima>.

- مشاهده مستندات دستور اصلی :

`tldr limactl`
