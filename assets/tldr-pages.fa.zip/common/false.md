# false

> برگرداندن 1 به عنوان کد خروجی.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/false>.

- برگرداندن 1 به عنوان کد خروجی:

`false`
