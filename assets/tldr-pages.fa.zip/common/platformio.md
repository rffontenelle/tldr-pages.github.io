# platformio

> این دستور یک نام مستعار از `pio` است.
> اطلاعات بیشتر: <https://docs.platformio.org/en/latest/core/userguide/>.

- مشاهده مستندات دستور اصلی :

`tldr pio`
