# hping

> این دستور یک نام مستعار از `hping3` است.
> اطلاعات بیشتر: <https://github.com/antirez/hping>.

- مشاهده مستندات دستور اصلی :

`tldr hping3`
