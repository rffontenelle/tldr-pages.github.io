# docker-container-rename

> این دستور یک نام مستعار از `docker rename` است.
> اطلاعات بیشتر: <https://docs.docker.com/engine/reference/commandline/rename>.

- مشاهده مستندات دستور اصلی :

`tldr docker rename`
