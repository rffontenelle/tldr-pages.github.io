# sleep

> ایجاد تاخیر بر اساس زمان.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/sleep>.

- تاخیر به ثانیه:

`sleep {{seconds}}`

- تاخیر به دقیقه:

`sleep {{minutes}}m`

- تاخیر به ساعت:

`sleep {{hours}}h`
