# unlzma

> این دستور یک نام مستعار از `xz` است.
> اطلاعات بیشتر: <https://manned.org/unlzma>.

- مشاهده مستندات دستور اصلی :

`tldr xz`
