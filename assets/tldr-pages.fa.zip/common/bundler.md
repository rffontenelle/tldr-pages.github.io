# bundler

> این دستور یک نام مستعار از `bundle` است.
> اطلاعات بیشتر: <https://bundler.io/man/bundle.1.html>.

- مشاهده مستندات دستور اصلی :

`tldr bundle`
