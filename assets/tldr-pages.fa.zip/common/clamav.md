# clamav

> این دستور یک نام مستعار از `clamdscan` است.
> اطلاعات بیشتر: <https://www.clamav.net>.

- مشاهده مستندات دستور اصلی :

`tldr clamdscan`
