# tldrl

> این دستور یک نام مستعار از `tldr-lint` است.
> اطلاعات بیشتر: <https://github.com/tldr-pages/tldr-lint>.

- مشاهده مستندات دستور اصلی :

`tldr tldr-lint`
