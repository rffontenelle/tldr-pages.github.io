# docker-container-diff

> این دستور یک نام مستعار از `docker diff` است.
> اطلاعات بیشتر: <https://docs.docker.com/engine/reference/commandline/diff>.

- مشاهده مستندات دستور اصلی :

`tldr docker diff`
