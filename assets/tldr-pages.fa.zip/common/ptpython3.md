# ptpython3

> این دستور یک نام مستعار از `ptpython` است.

- مشاهده مستندات دستور اصلی :

`tldr ptpython`
