# pwsh

> این دستور یک نام مستعار از `powershell` است.

- مشاهده مستندات دستور اصلی :

`tldr powershell`
