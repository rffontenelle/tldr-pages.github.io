# gnmic-sub

> این دستور یک نام مستعار از `gnmic subscribe` است.
> اطلاعات بیشتر: <https://gnmic.kmrd.dev/cmd/subscribe>.

- مشاهده مستندات دستور اصلی :

`tldr gnmic subscribe`
