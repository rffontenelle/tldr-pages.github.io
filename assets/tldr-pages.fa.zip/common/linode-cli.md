# linode-cli

> این دستور یک نام مستعار از `linode-cli account` است.
> اطلاعات بیشتر: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- مشاهده مستندات دستور اصلی :

`tldr linode-cli account`
