# users

> نمایش لیست کاربران لاگین شده.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/users>.

- نمایش لیست کاربران لاگین شده:

`users`

- نمایش لیست کاربران لاگین شده بر اساس یک لاگ فایل خاص:

`users {{/var/log/wmtp}}`
