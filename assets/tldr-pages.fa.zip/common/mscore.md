# mscore

> این دستور یک نام مستعار از `musescore` است.
> اطلاعات بیشتر: <https://musescore.org/handbook/command-line-options>.

- مشاهده مستندات دستور اصلی :

`tldr musescore`
