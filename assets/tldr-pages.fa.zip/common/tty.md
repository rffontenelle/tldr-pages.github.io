# tty

> نمایش نام ترمینال.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/tty>.

- نمایش نام فایل ترمینال جاری:

`tty`
