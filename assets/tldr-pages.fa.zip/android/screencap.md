# screencap

> ضبط یک اسکرین شات از صفحه یک موبایل.
> این دستور فقط از طریق `adb shell` قابل اجراست.
> اطلاعات بیشتر: <https://developer.android.com/studio/command-line/adb#screencap>.

- ضبط یک اسکرین شات :

`screencap {{path/to/file}}`
