# bugreportz

> تولید یک گزارش خطای اندروید فشرده شده.
> این دستور فقط از طریق `adb shell` قابل اجراست.
> اطلاعات بیشتر: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreportz>.

- تولید که گزارش خطای کامل از یک دستگاه اندرویدی :

`bugreportz`

- نمایش فرایند اجرای دستور `bugreportz` :

`bugreportz -p`

- نمایش نسخه `bugreportz` :

`bugreportz -v`

- نمایش راهنمایی :

`bugreportz -h`
