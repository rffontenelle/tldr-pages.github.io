# getprop

> نمایش اطلاعات مربوط به مشخصات سیستم اندروید.
> اطلاعات بیشتر: <https://manned.org/getprop>.

- نمایش اطلاعات مربوط به مشخصات سیستم اندروید :

`getprop`

- نمایش اطلاعات مربوط به یک مشخصه :

`getprop {{ویژگی}}`

- نمایش سطح SDK رابط برنامه نویسی :

`getprop {{ro.build.version.sdk}}`

- نمایش نسخه اندروید :

`getprop {{ro.build.version.release}}`

- نمایش مدل دستگاه اندروید :

`getprop {{ro.vendor.product.model}}`

- نمایش اطلاعات قفل OEM :

`getprop {{ro.oem_unlock_supported}}`

- نمایش آدرس مک کارت وای فای اندروید :

`getprop {{ro.boot.wifimacaddr}}`
