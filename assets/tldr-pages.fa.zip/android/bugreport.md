# bugreport

> نمایش یک گزارش خطا اندروید.
> این دستور فقط از طریق `adb shell` قابل اجراست.
> اطلاعات بیشتر: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- یک گزارش خطای کامل از دستگاه مورد نظر نمایش میدهد :

`bugreport`
