# cmd

> مدیر سرویس اندروید.
> اطلاعات بیشتر: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- فهرست تمام سرویس های درحال اجرا :

`cmd -l`

- فراخوان یک سرویس :

`cmd {{سرویس}}`

- فراخوان یک سرویس با مقادیر ورودی :

`cmd {{سرویس}} {{استدلال 1 استدلال 2 ...}}`
