# dalvikvm

> ماشین مجازی اندروید.
> اطلاعات بیشتر: <https://source.android.com/devices/tech/dalvik>.

- اجرای یک برنامه جاوا :

`dalvikvm -classpath {{مسیر/به/فایل.jar}} {{classname}}`
