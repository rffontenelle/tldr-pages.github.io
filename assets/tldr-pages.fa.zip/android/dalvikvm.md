# dalvikvm

> ماشین مجازی اندروید.
> اطلاعات بیشتر: <https://source.android.com/docs/core/runtime>.

- اجرای یک برنامه جاوا :

`dalvikvm -classpath {{path/to/file.jar}} {{classname}}`
