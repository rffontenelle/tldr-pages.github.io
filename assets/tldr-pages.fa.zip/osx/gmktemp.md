# gmktemp

> این دستور یک نام مستعار از `-p linux mktemp` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux mktemp`
