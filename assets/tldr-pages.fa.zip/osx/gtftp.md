# gtftp

> این دستور یک نام مستعار از `-p linux tftp` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux tftp`
