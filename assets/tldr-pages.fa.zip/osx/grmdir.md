# grmdir

> این دستور یک نام مستعار از `-p linux rmdir` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux rmdir`
