# gchown

> این دستور یک نام مستعار از `-p linux chown` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux chown`
