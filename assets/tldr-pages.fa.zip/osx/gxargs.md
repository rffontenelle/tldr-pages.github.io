# gxargs

> این دستور یک نام مستعار از `-p linux xargs` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux xargs`
