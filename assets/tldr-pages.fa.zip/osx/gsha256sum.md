# gsha256sum

> این دستور یک نام مستعار از `-p linux sha256sum` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux sha256sum`
