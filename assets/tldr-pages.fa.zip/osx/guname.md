# guname

> این دستور یک نام مستعار از `-p linux uname` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux uname`
