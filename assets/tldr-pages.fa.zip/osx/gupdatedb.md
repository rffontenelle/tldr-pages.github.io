# gupdatedb

> این دستور یک نام مستعار از `-p linux updatedb` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux updatedb`
