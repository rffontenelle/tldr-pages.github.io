# gstat

> این دستور یک نام مستعار از `-p linux stat` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux stat`
