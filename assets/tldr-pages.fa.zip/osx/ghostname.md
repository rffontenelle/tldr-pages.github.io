# ghostname

> این دستور یک نام مستعار از `-p linux hostname` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux hostname`
