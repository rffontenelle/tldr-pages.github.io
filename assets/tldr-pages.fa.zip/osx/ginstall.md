# ginstall

> این دستور یک نام مستعار از `-p linux install` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux install`
