# gbasename

> این دستور یک نام مستعار از `-p linux basename` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux basename`
