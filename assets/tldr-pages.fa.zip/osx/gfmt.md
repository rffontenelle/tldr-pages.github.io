# gfmt

> این دستور یک نام مستعار از `-p linux fmt` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux fmt`
