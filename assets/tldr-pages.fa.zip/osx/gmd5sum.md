# gmd5sum

> این دستور یک نام مستعار از `-p linux md5sum` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux md5sum`
