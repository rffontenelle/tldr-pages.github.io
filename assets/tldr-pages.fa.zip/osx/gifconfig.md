# gifconfig

> این دستور یک نام مستعار از `-p linux ifconfig` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux ifconfig`
