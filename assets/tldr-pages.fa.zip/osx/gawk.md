# gawk

> این دستور یک نام مستعار از `-p linux awk` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux awk`
