# launchd

> این دستور یک نام مستعار از `launchctl` است.
> اطلاعات بیشتر: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- مشاهده مستندات دستور اصلی :

`tldr launchctl`
