# gdir

> این دستور یک نام مستعار از `-p linux dir` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux dir`
