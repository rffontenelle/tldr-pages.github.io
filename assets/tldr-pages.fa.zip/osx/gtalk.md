# gtalk

> این دستور یک نام مستعار از `-p linux talk` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux talk`
