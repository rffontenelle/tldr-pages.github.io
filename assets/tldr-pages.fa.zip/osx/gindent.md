# gindent

> این دستور یک نام مستعار از `-p linux indent` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux indent`
