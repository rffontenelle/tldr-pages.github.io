# gtraceroute

> این دستور یک نام مستعار از `-p linux traceroute` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux traceroute`
