# greadlink

> این دستور یک نام مستعار از `-p linux readlink` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux readlink`
