# gsplit

> این دستور یک نام مستعار از `-p linux split` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux split`
