# gbase32

> این دستور یک نام مستعار از `-p linux base32` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux base32`
