# gtelnet

> این دستور یک نام مستعار از `-p linux telnet` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux telnet`
