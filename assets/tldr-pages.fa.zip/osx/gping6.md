# gping6

> این دستور یک نام مستعار از `-p linux ping6` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux ping6`
