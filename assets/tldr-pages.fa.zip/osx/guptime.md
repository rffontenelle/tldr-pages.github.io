# guptime

> این دستور یک نام مستعار از `-p linux uptime` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux uptime`
