# gnumfmt

> این دستور یک نام مستعار از `-p linux numfmt` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux numfmt`
