# gcomm

> این دستور یک نام مستعار از `-p linux comm` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux comm`
