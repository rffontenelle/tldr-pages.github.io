# ggrep

> این دستور یک نام مستعار از `-p linux grep` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux grep`
