# grealpath

> این دستور یک نام مستعار از `-p linux realpath` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux realpath`
