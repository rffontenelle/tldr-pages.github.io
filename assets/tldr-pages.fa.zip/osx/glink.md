# glink

> این دستور یک نام مستعار از `-p linux link` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux link`
