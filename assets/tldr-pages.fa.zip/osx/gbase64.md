# gbase64

> این دستور یک نام مستعار از `-p linux base64` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux base64`
