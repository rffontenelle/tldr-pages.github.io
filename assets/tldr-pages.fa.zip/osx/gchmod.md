# gchmod

> این دستور یک نام مستعار از `-p linux chmod` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux chmod`
