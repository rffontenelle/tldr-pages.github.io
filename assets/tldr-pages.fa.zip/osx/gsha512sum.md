# gsha512sum

> این دستور یک نام مستعار از `-p linux sha512sum` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux sha512sum`
