# gunlink

> این دستور یک نام مستعار از `-p linux unlink` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux unlink`
