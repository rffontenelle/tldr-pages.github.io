# gtest

> این دستور یک نام مستعار از `-p linux test` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux test`
