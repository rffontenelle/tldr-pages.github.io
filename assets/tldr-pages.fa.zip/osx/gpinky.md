# gpinky

> این دستور یک نام مستعار از `-p linux pinky` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux pinky`
