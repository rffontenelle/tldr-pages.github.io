# gchgrp

> این دستور یک نام مستعار از `-p linux chgrp` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux chgrp`
