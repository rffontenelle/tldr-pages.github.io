# gtty

> این دستور یک نام مستعار از `-p linux tty` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux tty`
