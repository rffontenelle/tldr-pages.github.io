# gchcon

> این دستور یک نام مستعار از `-p linux chcon` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux chcon`
