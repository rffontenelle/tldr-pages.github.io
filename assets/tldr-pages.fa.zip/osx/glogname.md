# glogname

> این دستور یک نام مستعار از `-p linux logname` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux logname`
