# gruncon

> این دستور یک نام مستعار از `-p linux runcon` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux runcon`
