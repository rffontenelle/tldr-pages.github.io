# ghead

> این دستور یک نام مستعار از `-p linux head` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux head`
