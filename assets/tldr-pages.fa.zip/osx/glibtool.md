# glibtool

> این دستور یک نام مستعار از `-p linux libtool` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux libtool`
