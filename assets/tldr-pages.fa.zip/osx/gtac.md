# gtac

> این دستور یک نام مستعار از `-p linux tac` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux tac`
