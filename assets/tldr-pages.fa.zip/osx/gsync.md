# gsync

> این دستور یک نام مستعار از `-p linux sync` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux sync`
