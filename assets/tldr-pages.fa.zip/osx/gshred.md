# gshred

> این دستور یک نام مستعار از `-p linux shred` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux shred`
