# gstty

> این دستور یک نام مستعار از `-p linux stty` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux stty`
