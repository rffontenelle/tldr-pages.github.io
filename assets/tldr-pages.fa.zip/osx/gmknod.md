# gmknod

> این دستور یک نام مستعار از `-p linux mknod` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux mknod`
