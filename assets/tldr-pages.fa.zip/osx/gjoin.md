# gjoin

> این دستور یک نام مستعار از `-p linux join` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux join`
