# gpwd

> این دستور یک نام مستعار از `-p linux pwd` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux pwd`
