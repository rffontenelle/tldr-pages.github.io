# gwho

> این دستور یک نام مستعار از `-p linux who` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux who`
