# gtrue

> این دستور یک نام مستعار از `-p linux true` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux true`
