# gtee

> این دستور یک نام مستعار از `-p linux tee` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux tee`
