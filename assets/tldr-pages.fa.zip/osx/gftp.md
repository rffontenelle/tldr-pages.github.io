# gftp

> این دستور یک نام مستعار از `-p linux ftp` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux ftp`
