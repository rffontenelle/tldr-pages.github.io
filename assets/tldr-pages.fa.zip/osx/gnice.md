# gnice

> این دستور یک نام مستعار از `-p linux nice` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux nice`
