# gprintenv

> این دستور یک نام مستعار از `-p linux printenv` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux printenv`
