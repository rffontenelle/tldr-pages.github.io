# grexec

> این دستور یک نام مستعار از `-p linux rexec` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux rexec`
