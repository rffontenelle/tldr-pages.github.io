# gvdir

> این دستور یک نام مستعار از `-p linux vdir` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux vdir`
