# gwhoami

> این دستور یک نام مستعار از `-p linux whoami` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux whoami`
