# gseq

> این دستور یک نام مستعار از `-p linux seq` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux seq`
