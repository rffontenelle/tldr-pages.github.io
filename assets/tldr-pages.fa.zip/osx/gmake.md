# gmake

> این دستور یک نام مستعار از `-p linux make` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux make`
