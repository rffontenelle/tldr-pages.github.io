# gshuf

> این دستور یک نام مستعار از `-p linux shuf` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux shuf`
