# gexpr

> این دستور یک نام مستعار از `-p linux expr` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux expr`
