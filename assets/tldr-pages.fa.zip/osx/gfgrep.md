# gfgrep

> این دستور یک نام مستعار از `-p linux fgrep` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux fgrep`
