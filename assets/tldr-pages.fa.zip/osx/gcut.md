# gcut

> این دستور یک نام مستعار از `-p linux cut` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux cut`
