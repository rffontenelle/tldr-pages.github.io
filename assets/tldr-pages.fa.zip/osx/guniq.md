# guniq

> این دستور یک نام مستعار از `-p linux uniq` است.

- مشاهده مستندات دستور اصلی :

`tldr -p linux uniq`
