# cinst

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `choco install`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr choco install`
