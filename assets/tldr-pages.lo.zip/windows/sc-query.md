# sc-query

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `sc`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr sc`
