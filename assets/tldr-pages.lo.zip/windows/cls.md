# cls

> ລ້າງຕົວອັກສອນທັງໝົດເທິງໜ້າຈໍ
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- ລ້າງຕົວອັກສອນທັງໝົດເທິງໜ້າຈໍ

`cls`
