# wget

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `wget -p common`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.gnu.org/software/wget>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr wget -p common`
