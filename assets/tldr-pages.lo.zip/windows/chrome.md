# chrome

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `chromium`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://chrome.google.com>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr chromium`
