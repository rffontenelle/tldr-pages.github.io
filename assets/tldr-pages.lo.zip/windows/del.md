# del

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `remove-item`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr remove-item`
