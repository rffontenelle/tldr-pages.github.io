# cpush

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `choco-push`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.chocolatey.org/en-us/create/commands/push>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr choco-push`
