# slmgr

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `slmgr.vbs`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr slmgr.vbs`
