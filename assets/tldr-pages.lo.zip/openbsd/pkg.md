# pkg

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `pkg_add`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.openbsd.org/faq/faq15.html>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr pkg_add`
