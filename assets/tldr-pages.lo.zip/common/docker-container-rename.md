# docker-container-rename

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `docker rename`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.docker.com/engine/reference/commandline/rename>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr docker rename`
