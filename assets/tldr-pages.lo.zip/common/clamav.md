# ClamAV

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `clamdscan`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.clamav.net>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr clamdscan`
