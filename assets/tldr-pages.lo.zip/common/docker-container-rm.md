# docker-container-rm

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `docker rm`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.docker.com/engine/reference/commandline/rm>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr docker rm`
