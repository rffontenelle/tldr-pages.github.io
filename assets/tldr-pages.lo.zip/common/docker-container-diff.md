# docker-container-diff

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `docker diff`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.docker.com/engine/reference/commandline/diff>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr docker diff`
