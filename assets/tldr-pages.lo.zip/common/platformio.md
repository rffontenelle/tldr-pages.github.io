# platformio

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `pio`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.platformio.org/en/latest/core/userguide/>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr pio`
