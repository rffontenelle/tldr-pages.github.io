# fossil-delete

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `fossil rm`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://fossil-scm.org/home/help/delete>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr fossil rm`
