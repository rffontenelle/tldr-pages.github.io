# hping

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `hping3`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://github.com/antirez/hping>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr hping3`
