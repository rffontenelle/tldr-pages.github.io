# gh cs

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ  `gh codespace`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://cli.github.com/manual/gh_codespace>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr gh-codespace`
