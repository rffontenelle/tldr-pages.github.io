# linode-cli

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `linode-cli account`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr linode-cli account`
