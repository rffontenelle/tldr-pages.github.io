# gnmic sub

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `gnmic subscribe`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://gnmic.kmrd.dev/cmd/subscribe>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr gnmic subscribe`
