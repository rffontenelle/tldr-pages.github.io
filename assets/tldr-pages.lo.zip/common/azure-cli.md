# azure-cli

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `az`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://learn.microsoft.com/cli/azure>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr az`
