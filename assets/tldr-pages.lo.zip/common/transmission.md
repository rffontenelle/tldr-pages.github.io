# transmission

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `transmission-daemon`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://transmissionbt.com/>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr transmission-daemon`
