# lima

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `limactl`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://github.com/lima-vm/lima>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr limactl`
