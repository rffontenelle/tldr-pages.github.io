# tlmgr-arch

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `tlmgr platform`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.tug.org/texlive/tlmgr.html>.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr tlmgr platform`
