# todoman

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `todo`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://todoman.readthedocs.io/>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr todo`
