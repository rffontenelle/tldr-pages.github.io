# bundler

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `bundle`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://bundler.io/man/bundle.1.html>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr bundle`
