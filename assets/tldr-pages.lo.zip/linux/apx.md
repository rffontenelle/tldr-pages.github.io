# apx

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `apx pkgmanagers`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://github.com/Vanilla-OS/apx>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr apx pkgmanagers`
