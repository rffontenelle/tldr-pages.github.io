# distrobox

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `distrobox-create`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://github.com/89luca89/distrobox>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr distrobox-create`
