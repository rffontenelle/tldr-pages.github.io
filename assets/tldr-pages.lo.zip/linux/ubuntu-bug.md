# ubuntu-bug

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `apport-bug`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://manned.org/ubuntu-bug>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr apport-bug`
