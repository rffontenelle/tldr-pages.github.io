# cgroups

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `cgclassify`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr cgclassify`
