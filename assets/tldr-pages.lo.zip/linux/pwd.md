# pwd

> ສະແດງຊື່ directory ທີ່ໃຊ້ຢູ່
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.gnu.org/software/coreutils/pwd>.

- ສະແດງຊື່ directory ທີ່ໃຊ້ຢູ່:

`pwd`

- ສະແດງຊື່ directory ທີ່ໃຊ້ຢູ່ໂດຍບໍ່ລວມ symlinks:

`pwd --physical`

- ສະແດງຊື່ directory ທີ່ໃຊ້ຢູ່ໂດຍໃຊ້ PWD ຈາກ environment ເຖິງຈະລວມ symlinks:

`pwd --logical`
