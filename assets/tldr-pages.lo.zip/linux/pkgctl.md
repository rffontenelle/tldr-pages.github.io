# pkgctl

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `pkgctl auth`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://man.archlinux.org/man/pkgctl.1>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr pkgctl auth`
