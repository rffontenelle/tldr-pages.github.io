# nmcli

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `nmcli agent`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr nmcli agent`
