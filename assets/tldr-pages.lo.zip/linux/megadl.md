# megadl

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `megatools-dl`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://megatools.megous.com/man/megatools-dl.html>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr megatools-dl`
