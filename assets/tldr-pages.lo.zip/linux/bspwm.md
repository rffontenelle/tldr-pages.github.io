# bspwm

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `bspc`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://github.com/baskerville/bspwm>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr bspc`
