# xbps

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `xbps-install`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://docs.voidlinux.org/xbps/index.html>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr xbps-install`
