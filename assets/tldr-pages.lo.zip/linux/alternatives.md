# alternatives

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `update-alternatives`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://manned.org/alternatives>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr update-alternatives`
