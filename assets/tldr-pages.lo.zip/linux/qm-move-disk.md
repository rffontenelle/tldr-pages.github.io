# qm-move-disk

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `qm-disk-move`.
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- ເປີດເບິ່ງລາຍລະອຽດຂອງຄຳສັ່ງແບບເຕັມ:

`tldr qm-disk-move`
