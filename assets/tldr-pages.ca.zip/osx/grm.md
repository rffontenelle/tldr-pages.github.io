# grm

> Aquest comandament és un àlies de `-p linux rm`.

- Veure documentació pel comandament original:

`tldr -p linux rm`
