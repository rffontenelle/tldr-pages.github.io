# gnl

> Aquest comandament és un àlies de `-p linux nl`.

- Veure documentació pel comandament original:

`tldr -p linux nl`
