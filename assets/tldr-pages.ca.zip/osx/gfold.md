# gfold

> Aquest comandament és un àlies de `-p linux fold`.

- Veure documentació pel comandament original:

`tldr -p linux fold`
