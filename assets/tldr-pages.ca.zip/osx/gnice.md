# gnice

> Aquest comandament és un àlies de `-p linux nice`.

- Veure documentació pel comandament original:

`tldr -p linux nice`
