# gruncon

> Aquest comandament és un àlies de `-p linux runcon`.

- Veure documentació pel comandament original:

`tldr -p linux runcon`
