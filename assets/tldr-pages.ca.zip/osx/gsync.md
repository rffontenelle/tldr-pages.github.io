# gsync

> Aquest comandament és un àlies de `-p linux sync`.

- Veure documentació pel comandament original:

`tldr -p linux sync`
