# gbase32

> Aquest comandament és un àlies de `-p linux base32`.

- Veure documentació pel comandament original:

`tldr -p linux base32`
