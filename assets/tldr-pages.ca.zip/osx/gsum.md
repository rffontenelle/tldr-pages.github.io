# gsum

> Aquest comandament és un àlies de `-p linux sum`.

- Veure documentació pel comandament original:

`tldr -p linux sum`
