# gunexpand

> Aquest comandament és un àlies de `-p linux unexpand`.

- Veure documentació pel comandament original:

`tldr -p linux unexpand`
