# gping

> Aquest comandament és un àlies de `-p linux ping`.

- Veure documentació pel comandament original:

`tldr -p linux ping`
