# gsleep

> Aquest comandament és un àlies de `-p linux sleep`.

- Veure documentació pel comandament original:

`tldr -p linux sleep`
