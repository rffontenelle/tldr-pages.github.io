# llvm-lipo

> Aquest comandament és un àlies de `lipo`.

- Veure documentació pel comandament original:

`tldr lipo`
