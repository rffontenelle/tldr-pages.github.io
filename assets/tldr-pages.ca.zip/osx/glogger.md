# glogger

> Aquest comandament és un àlies de `-p linux logger`.

- Veure documentació pel comandament original:

`tldr -p linux logger`
