# g[

> Aquest comandament és un àlies de `-p linux [`.

- Veure documentació pel comandament original:

`tldr -p linux [`
