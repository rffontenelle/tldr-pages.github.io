# gtime

> Aquest comandament és un àlies de `-p linux time`.

- Veure documentació pel comandament original:

`tldr -p linux time`
