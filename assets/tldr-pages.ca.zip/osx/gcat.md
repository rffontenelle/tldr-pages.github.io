# gcat

> Aquest comandament és un àlies de `-p linux cat`.

- Veure documentació pel comandament original:

`tldr -p linux cat`
