# gcut

> Aquest comandament és un àlies de `-p linux cut`.

- Veure documentació pel comandament original:

`tldr -p linux cut`
