# guname

> Aquest comandament és un àlies de `-p linux uname`.

- Veure documentació pel comandament original:

`tldr -p linux uname`
