# gdnsdomainname

> Aquest comandament és un àlies de `-p linux dnsdomainname`.

- Veure documentació pel comandament original:

`tldr -p linux dnsdomainname`
