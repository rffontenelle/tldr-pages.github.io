# gb2sum

> Aquest comandament és un àlies de `-p linux b2sum`.

- Veure documentació pel comandament original:

`tldr -p linux b2sum`
