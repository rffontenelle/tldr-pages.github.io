# gdate

> Aquest comandament és un àlies de `-p linux date`.

- Veure documentació pel comandament original:

`tldr -p linux date`
