# gjoin

> Aquest comandament és un àlies de `-p linux join`.

- Veure documentació pel comandament original:

`tldr -p linux join`
