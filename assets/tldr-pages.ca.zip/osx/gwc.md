# gwc

> Aquest comandament és un àlies de `-p linux wc`.

- Veure documentació pel comandament original:

`tldr -p linux wc`
