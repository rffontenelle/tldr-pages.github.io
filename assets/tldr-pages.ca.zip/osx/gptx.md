# gptx

> Aquest comandament és un àlies de `-p linux ptx`.

- Veure documentació pel comandament original:

`tldr -p linux ptx`
