# gwhois

> Aquest comandament és un àlies de `-p linux whois`.

- Veure documentació pel comandament original:

`tldr -p linux whois`
