# gindent

> Aquest comandament és un àlies de `-p linux indent`.

- Veure documentació pel comandament original:

`tldr -p linux indent`
