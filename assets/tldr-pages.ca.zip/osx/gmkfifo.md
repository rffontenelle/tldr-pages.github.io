# gmkfifo

> Aquest comandament és un àlies de `-p linux mkfifo`.

- Veure documentació pel comandament original:

`tldr -p linux mkfifo`
