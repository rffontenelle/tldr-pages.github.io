# gawk

> Aquest comandament és un àlies de `-p linux awk`.

- Veure documentació pel comandament original:

`tldr -p linux awk`
