# aa

> Aquest comandament és un àlies de `yaa`.

- Veure documentació pel comandament original:

`tldr yaa`
