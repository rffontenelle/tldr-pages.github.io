# gdircolors

> Aquest comandament és un àlies de `-p linux dircolors`.

- Veure documentació pel comandament original:

`tldr -p linux dircolors`
