# gping6

> Aquest comandament és un àlies de `-p linux ping6`.

- Veure documentació pel comandament original:

`tldr -p linux ping6`
