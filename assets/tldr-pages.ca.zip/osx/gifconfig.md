# gifconfig

> Aquest comandament és un àlies de `-p linux ifconfig`.

- Veure documentació pel comandament original:

`tldr -p linux ifconfig`
