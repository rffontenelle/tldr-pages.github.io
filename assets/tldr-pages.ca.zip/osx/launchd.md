# launchd

> Aquest comandament és un àlies de `launchctl`.
> Més informació: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Veure documentació pel comandament original:

`tldr launchctl`
