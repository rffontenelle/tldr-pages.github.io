# gcp

> Aquest comandament és un àlies de `-p linux cp`.

- Veure documentació pel comandament original:

`tldr -p linux cp`
