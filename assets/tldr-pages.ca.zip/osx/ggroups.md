# ggroups

> Aquest comandament és un àlies de `-p linux groups`.

- Veure documentació pel comandament original:

`tldr -p linux groups`
