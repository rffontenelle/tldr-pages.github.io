# gexpr

> Aquest comandament és un àlies de `-p linux expr`.

- Veure documentació pel comandament original:

`tldr -p linux expr`
