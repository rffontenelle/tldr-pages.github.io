# gwhich

> Aquest comandament és un àlies de `-p linux which`.

- Veure documentació pel comandament original:

`tldr -p linux which`
