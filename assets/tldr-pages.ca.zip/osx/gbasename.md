# gbasename

> Aquest comandament és un àlies de `-p linux basename`.

- Veure documentació pel comandament original:

`tldr -p linux basename`
