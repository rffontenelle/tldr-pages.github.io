# gtr

> Aquest comandament és un àlies de `-p linux tr`.

- Veure documentació pel comandament original:

`tldr -p linux tr`
