# gfactor

> Aquest comandament és un àlies de `-p linux factor`.

- Veure documentació pel comandament original:

`tldr -p linux factor`
