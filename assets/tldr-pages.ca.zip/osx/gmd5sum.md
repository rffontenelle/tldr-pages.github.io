# gmd5sum

> Aquest comandament és un àlies de `-p linux md5sum`.

- Veure documentació pel comandament original:

`tldr -p linux md5sum`
