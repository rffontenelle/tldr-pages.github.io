# gcksum

> Aquest comandament és un àlies de `-p linux cksum`.

- Veure documentació pel comandament original:

`tldr -p linux cksum`
