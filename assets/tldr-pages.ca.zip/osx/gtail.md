# gtail

> Aquest comandament és un àlies de `-p linux tail`.

- Veure documentació pel comandament original:

`tldr -p linux tail`
