# ghostname

> Aquest comandament és un àlies de `-p linux hostname`.

- Veure documentació pel comandament original:

`tldr -p linux hostname`
