# gtar

> Aquest comandament és un àlies de `-p linux tar`.

- Veure documentació pel comandament original:

`tldr -p linux tar`
