# gsha384sum

> Aquest comandament és un àlies de `-p linux sha384sum`.

- Veure documentació pel comandament original:

`tldr -p linux sha384sum`
