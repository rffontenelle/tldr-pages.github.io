# ghostid

> Aquest comandament és un àlies de `-p linux hostid`.

- Veure documentació pel comandament original:

`tldr -p linux hostid`
