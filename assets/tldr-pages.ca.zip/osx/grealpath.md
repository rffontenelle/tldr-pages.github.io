# grealpath

> Aquest comandament és un àlies de `-p linux realpath`.

- Veure documentació pel comandament original:

`tldr -p linux realpath`
