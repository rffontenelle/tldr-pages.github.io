# gmknod

> Aquest comandament és un àlies de `-p linux mknod`.

- Veure documentació pel comandament original:

`tldr -p linux mknod`
