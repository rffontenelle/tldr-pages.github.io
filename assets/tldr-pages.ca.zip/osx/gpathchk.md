# gpathchk

> Aquest comandament és un àlies de `-p linux pathchk`.

- Veure documentació pel comandament original:

`tldr -p linux pathchk`
