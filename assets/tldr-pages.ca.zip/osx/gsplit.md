# gsplit

> Aquest comandament és un àlies de `-p linux split`.

- Veure documentació pel comandament original:

`tldr -p linux split`
