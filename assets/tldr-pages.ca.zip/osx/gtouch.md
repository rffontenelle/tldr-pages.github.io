# gtouch

> Aquest comandament és un àlies de `-p linux touch`.

- Veure documentació pel comandament original:

`tldr -p linux touch`
