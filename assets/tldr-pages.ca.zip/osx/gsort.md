# gsort

> Aquest comandament és un àlies de `-p linux sort`.

- Veure documentació pel comandament original:

`tldr -p linux sort`
