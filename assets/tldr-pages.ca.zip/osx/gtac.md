# gtac

> Aquest comandament és un àlies de `-p linux tac`.

- Veure documentació pel comandament original:

`tldr -p linux tac`
