# grcp

> Aquest comandament és un àlies de `-p linux rcp`.

- Veure documentació pel comandament original:

`tldr -p linux rcp`
