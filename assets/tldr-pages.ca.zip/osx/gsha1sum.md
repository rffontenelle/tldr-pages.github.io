# gsha1sum

> Aquest comandament és un àlies de `-p linux sha1sum`.

- Veure documentació pel comandament original:

`tldr -p linux sha1sum`
