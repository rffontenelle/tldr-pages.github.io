# gftp

> Aquest comandament és un àlies de `-p linux ftp`.

- Veure documentació pel comandament original:

`tldr -p linux ftp`
