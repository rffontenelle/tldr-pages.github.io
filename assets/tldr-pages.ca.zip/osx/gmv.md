# gmv

> Aquest comandament és un àlies de `-p linux mv`.

- Veure documentació pel comandament original:

`tldr -p linux mv`
