# gfind

> Aquest comandament és un àlies de `-p linux find`.

- Veure documentació pel comandament original:

`tldr -p linux find`
