# gegrep

> Aquest comandament és un àlies de `-p linux egrep`.

- Veure documentació pel comandament original:

`tldr -p linux egrep`
