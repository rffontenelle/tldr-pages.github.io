# gsha256sum

> Aquest comandament és un àlies de `-p linux sha256sum`.

- Veure documentació pel comandament original:

`tldr -p linux sha256sum`
