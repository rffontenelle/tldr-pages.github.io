# gbase64

> Aquest comandament és un àlies de `-p linux base64`.

- Veure documentació pel comandament original:

`tldr -p linux base64`
