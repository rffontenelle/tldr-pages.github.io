# gls

> Aquest comandament és un àlies de `-p linux ls`.

- Veure documentació pel comandament original:

`tldr -p linux ls`
