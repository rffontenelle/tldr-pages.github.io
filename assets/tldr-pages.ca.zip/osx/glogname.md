# glogname

> Aquest comandament és un àlies de `-p linux logname`.

- Veure documentació pel comandament original:

`tldr -p linux logname`
