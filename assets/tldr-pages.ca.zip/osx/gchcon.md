# gchcon

> Aquest comandament és un àlies de `-p linux chcon`.

- Veure documentació pel comandament original:

`tldr -p linux chcon`
