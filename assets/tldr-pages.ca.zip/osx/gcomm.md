# gcomm

> Aquest comandament és un àlies de `-p linux comm`.

- Veure documentació pel comandament original:

`tldr -p linux comm`
