# ncal

> Aquest comandament és un àlies de `cal`.
> Més informació: <https://manned.org/ncal>.

- Veure documentació per el comandament original:

`tldr cal`
