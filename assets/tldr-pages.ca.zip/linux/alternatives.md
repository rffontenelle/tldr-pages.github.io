# alternatives

> Aquest comandament és un àlies de `update-alternatives`.
> Més informació: <https://manned.org/alternatives>.

- Veure documentació pel comandament original:

`tldr update-alternatives`
