# line

> Llegeix una única línia d'entrada.
> Més informació: <https://manned.org/line.1>.

- Llegeix una entrada:

`line`
