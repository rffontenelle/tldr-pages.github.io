# a2dismod

> Desactiva un mòdul Apache en sistemes operatius basats en Debian.
> Més informació: <https://manned.org/a2dismod.8>.

- Desactiva un mòdul:

`sudo a2dismod {{mòdul}}`

- No mostrius missatges informatius:

`sudo a2dismod --quiet {{mòdul}}`
