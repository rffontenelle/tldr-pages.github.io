# nmcli

> Aquest comandament és un àlies de `nmcli agent`.
> Més informació: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Veure documentació pel comandament original:

`tldr nmcli agent`
