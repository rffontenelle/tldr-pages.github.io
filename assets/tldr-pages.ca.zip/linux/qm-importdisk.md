# qm-importdisk

> Aquest comandament és un àlies de `qm disk import`.

- Veure documentació pel comandament original:

`tldr qm disk import`
