# mount.smb3

> Aquest comandament és un àlies de `mount.cifs`.

- Veure documentació pel comandament original:

`tldr mount.cifs`
