# systemd-umount

> Aquest comandament és un àlies de `systemd-mount`.

- Veure documentació pel comandament original:

`tldr systemd-mount`
