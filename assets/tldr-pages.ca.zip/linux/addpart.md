# addpart

> Comunica al linux kernel l'existència de la partició especificada.
> El commandament és un simple embolcall de `add partition` ioctl.
> Més informació: <https://manned.org/addpart>.

- Comunica al kernel l'existència de la partició especificada:

`addpart {{dispositiu}} {{partició}} {{inici}} {{llargada}}`
