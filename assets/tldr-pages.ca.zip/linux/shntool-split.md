# shntool-split

> Aquest comandament és un àlies de `shnsplit`.

- Veure documentació pel comandament original:

`tldr shnsplit`
