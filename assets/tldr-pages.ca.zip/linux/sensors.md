# sensors

> Proporciona informació dels sensors.
> Més informació: <https://manned.org/sensors>.

- Mostra les lectures actuals de tots els sensors:

`sensors`

- Mostra les temperatures en graus Fahrenheit:

`sensors --fahrenheit`
