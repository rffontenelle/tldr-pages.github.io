# batcat

> Aquest comandament és un àlies de `bat`.
> Més informació: <https://github.com/sharkdp/bat>.

- Veure documentació pel comandament original:

`tldr bat`
