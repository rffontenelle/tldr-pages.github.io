# vmstat

> Reporta informació sobre processos, memòria, paginació, IO en bloc, traps, discos i activitat de la CPU.
> Més informació: <https://manned.org/vmstat>.

- Mostra les estadístiques de la memòria virtual:

`vmstat`

- Mostra informes cada 2 segons 5 vegades:

`vmstat {{2}} {{5}}`
