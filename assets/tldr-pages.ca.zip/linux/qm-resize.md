# qm-resize

> Aquest comandament és un àlies de `qm-disk-resize`.
> Més informació: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Veure documentació pel comandament original:

`tldr qm-disk-resize`
