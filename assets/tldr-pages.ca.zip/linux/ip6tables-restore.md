# ip6tables-restore

> Aquest comandament és un àlies de `iptables-restore`.

- Veure documentació pel comandament original:

`tldr iptables-restore`
