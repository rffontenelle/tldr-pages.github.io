# cc

> Aquest comandament és un àlies de `gcc`.
> Més informació: <https://gcc.gnu.org>.

- Veure documentació pel comandament original:

`tldr gcc`
