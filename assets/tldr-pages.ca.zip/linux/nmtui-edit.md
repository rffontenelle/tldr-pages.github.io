# nmtui-edit

> Aquest comandament és un àlies de `nmtui`.

- Veure documentació pel comandament original:

`tldr nmtui`
