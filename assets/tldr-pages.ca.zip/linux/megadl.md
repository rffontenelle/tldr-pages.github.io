# megadl

> Aquest comandament es un àlies de `megatools-dl`.
> Més informació: <https://megatools.megous.com/man/megatools-dl.html>.

- Veure documentació per el comandament original:

`tldr megatools-dl`
