# pkgctl

> Aquest comandament és un àlies de `pkgctl auth`.
> Més informació: <https://man.archlinux.org/man/pkgctl.1>.

- Veure documentació pel comandament original:

`tldr pkgctl auth`
