# cgroups

> Aquest comandament és un àlies de `cgclassify`.
> Més informació: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Veure documentació pel comandament original:

`tldr cgclassify`
