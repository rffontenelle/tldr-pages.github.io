# lsmod

> Mostra l'estat dels mòduls carregats en el kernel de linux.
> Vegeu també `modprobe`, el qual carrega mòduls de kernel.
> Més informació: <https://manned.org/lsmod>.

- Llista tots els mòduls de kernel carregats:

`lsmod`
