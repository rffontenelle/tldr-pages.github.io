# qm-move-disk

> Aquest comandament és un àlies de `qm-disk-move`.
> Més informació: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Veure documentació pel comandament original:

`tldr qm-disk-move`
