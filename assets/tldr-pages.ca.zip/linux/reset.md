# reset

> Reinicialitza la terminal actual. Borra tota la pantalla de la terminal.
> Més informació: <https://manned.org/reset>.

- Reinicialitza la terminal actual:

`reset`

- Mostra el tipus de terminal:

`reset -q`
