# distrobox

> Aquest comandament és un àlies de `distrobox-create`.
> Més informació: <https://github.com/89luca89/distrobox>.

- Veure documentació pel comandament original:

`tldr distrobox-create`
