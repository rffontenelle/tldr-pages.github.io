# bspwm

> Aquest comandament és un àlies de `bspc`.
> Més informació: <https://github.com/baskerville/bspwm>.

- Veure documentació pel comandament original:

`tldr bspc`
