# a2dissite

> Desactiva un host virtual d'Apache en sistemes operatius basats en Debian.
> Més informació: <https://manpages.debian.org/latest/apache2/a2dissite.8.en.html>.

- Desactiva un host virtual:

`sudo a2dissite {{host_virtual}}`

- No mostris missatges informatius:

`sudo a2dissite --quiet {{host_virtual}}`
