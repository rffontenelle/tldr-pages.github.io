# xbps

> Aquest comandament és un àlies de `xbps-install`.
> Més informació: <https://docs.voidlinux.org/xbps/index.html>.

- Veure documentació pel comandament original:

`tldr xbps-install`
