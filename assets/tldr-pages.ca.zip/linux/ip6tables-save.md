# ip6tables-save

> Aquest comandament és un àlies de `iptables-save`.

- Veure documentació pel comandament original:

`tldr iptables-save`
