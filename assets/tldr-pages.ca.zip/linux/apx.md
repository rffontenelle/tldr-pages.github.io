# apx

> Aquest comandament és un àlies de `apx pkgmanagers`.
> Més informació: <https://github.com/Vanilla-OS/apx>.

- Veure documentació pel comandament original:

`tldr apx pkgmanagers`
