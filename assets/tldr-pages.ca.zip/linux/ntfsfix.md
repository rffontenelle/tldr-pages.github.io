# ntfsfix

> Arregla problemes habituals d'una partició NTFS.
> Més informació: <https://manned.org/ntfsfix>.

- Arregla una partició NTFS donada:

`sudo ntfsfix {{/dev/sdXN}}`
