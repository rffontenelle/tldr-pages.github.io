# ip6tables

> Aquest comandament és un àlies de `iptables`.

- Veure documentació pel comandament original:

`tldr iptables`
