# pkg

> Aquest comandament és un àlies de `pkg_add`.
> Més informació: <https://www.openbsd.org/faq/faq15.html>.

- Veure documentació pel comandament original:

`tldr pkg_add`
