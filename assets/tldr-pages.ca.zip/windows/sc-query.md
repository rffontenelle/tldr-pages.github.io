# sc-query

> Aquest comandament és un àlies de `sc`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Veure documentació pel comandament original:

`tldr sc`
