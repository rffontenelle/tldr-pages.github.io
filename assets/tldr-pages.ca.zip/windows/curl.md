# curl

> Aquest comandament és un àlies de `curl -p common`.
> Més informació: <https://curl.se>.

- Veure documentació pel comandament original:

`tldr curl -p common`
