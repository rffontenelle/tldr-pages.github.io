# cuninst

> Aquest comandament és un àlies de `choco uninstall`.
> Més informació: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Veure documentació pel comandament original:

`tldr choco uninstall`
