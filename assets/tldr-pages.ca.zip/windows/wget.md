# wget

> Aquest comandament és un àlies de `wget -p common`.
> Més informació: <https://www.gnu.org/software/wget>.

- Veure documentació pel comandament original:

`tldr wget -p common`
