# chrome

> Aquest comandament és un àlies de `chromium`.
> Més informació: <https://chrome.google.com>.

- Veure documentació pel comandament original:

`tldr chromium`
