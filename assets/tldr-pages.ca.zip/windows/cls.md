# cls

> Aquest comandament és un àlies de `clear-host`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Veure documentació pel comandament original:

`tldr clear-host`
