# clist

> Aquest comandament és un àlies de `choco list`.
> Més informació: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Veure documentació pel comandament original:

`tldr choco list`
