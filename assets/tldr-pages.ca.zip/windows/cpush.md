# cpush

> Aquest comandament és un àlies de `choco-push`.
> Més informació: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Veure documentació pel comandament original:

`tldr choco-push`
