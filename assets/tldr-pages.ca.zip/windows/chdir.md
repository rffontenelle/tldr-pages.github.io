# chdir

> Aquest comandament és un àlies de `cd`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Veure documentació pel comandament original:

`tldr cd`
