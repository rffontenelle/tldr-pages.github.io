# sc-delete

> Aquest comandament és un àlies de `sc`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Veure documentació pel comandament original:

`tldr sc`
