# sc-config

> Aquest comandament és un àlies de `sc`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Veure documentació pel comandament original:

`tldr sc`
