# ni

> Aquest comandament és un àlies de `new-item`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Veure documentació pel comandament original:

`tldr new-item`
