# slmgr

> Aquest comandament és un àlies de `slmgr.vbs`.
> Més informació: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Veure documentació pel comandament original:

`tldr slmgr.vbs`
