# ri

> Aquest comandament és un àlies de `remove-item`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Veure documentació pel comandament original:

`tldr remove-item`
