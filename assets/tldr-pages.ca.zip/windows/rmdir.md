# rmdir

> Aquest comandament és un àlies de `remove-item`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Veure documentació pel comandament original:

`tldr remove-item`
