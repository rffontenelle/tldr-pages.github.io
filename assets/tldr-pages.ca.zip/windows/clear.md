# clear

> Aquest comandament és un àlies de `clear-host`.

- Veure documentació pel comandament original:

`tldr clear-host`
