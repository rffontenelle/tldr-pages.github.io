# gal

> Aquest comandament és un àlies de `get-alias`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Veure documentació pel comandament original:

`tldr get-alias`
