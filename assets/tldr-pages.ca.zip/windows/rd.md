# rd

> Aquest comandament és un àlies de `rmdir`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Veure documentació pel comandament original:

`tldr rmdir`
