# cd

> Aquest comandament és un àlies de `set-location`.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Veure documentació pel comandament original:

`tldr set-location`
