# sls

> Aquest comandament és un àlies de `where-object`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Veure documentació pel comandament original:

`tldr where-object`
