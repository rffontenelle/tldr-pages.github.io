# sl

> Aquest comandament és un àlies de `set-location`.
> Més informació: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Veure documentació pel comandament original:

`tldr set-location`
