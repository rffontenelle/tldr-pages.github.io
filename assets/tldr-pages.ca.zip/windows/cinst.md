# cinst

> Aquest comandament és un àlies de `choco install`.
> Més informació: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Veure documentació pel comandament original:

`tldr choco install`
