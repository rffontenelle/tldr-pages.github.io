# nm-classic

> Aquest comandament és un àlies de `nm`.

- Veure documentació pel comandament original:

`tldr nm`
