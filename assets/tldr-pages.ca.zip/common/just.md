# just

> Aquest comandament és un àlies de `just.1`.

- Veure documentació pel comandament original:

`tldr just.1`
