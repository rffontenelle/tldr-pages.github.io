# bundler

> Aquest comandament és un àlies de `bundle`.
> Més informació: <https://bundler.io/man/bundle.1.html>.

- Veure documentació pel comandament original:

`tldr bundle`
