# docker-container-diff

> Aquest comandament és un àlies de `docker diff`.
> Més informació: <https://docs.docker.com/engine/reference/commandline/diff>.

- Veure documentació pel comandament original:

`tldr docker diff`
