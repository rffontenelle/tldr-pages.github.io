# unxz

> Aquest comandament és un àlies de `xz`.
> Més informació: <https://manned.org/unxz>.

- Veure documentació pel comandament original:

`tldr xz`
