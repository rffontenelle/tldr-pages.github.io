# clojure

> Aquest comandament és un àlies de `clj`.

- Veure documentació pel comandament original:

`tldr clj`
