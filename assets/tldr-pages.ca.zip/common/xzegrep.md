# xzegrep

> Aquest comandament és un àlies de `xzgrep`.

- Veure documentació pel comandament original:

`tldr xzgrep`
