# open

> Aquest comandament és un àlies de `open -p osx`.

- Veure documentació pel comandament original:

`tldr open -p osx`
