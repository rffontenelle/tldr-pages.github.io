# netcat

> Aquest comandament és un àlies de `nc`.

- Veure documentació pel comandament original:

`tldr nc`
