# tlmgr-arch

> Aquest comandament és un àlies de `tlmgr platform`.
> Més informació: <https://www.tug.org/texlive/tlmgr.html>.

- Veure documentació pel comandament original:

`tldr tlmgr platform`
