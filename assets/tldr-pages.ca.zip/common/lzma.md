# lzma

> Aquest comandament és un àlies de `xz`.
> Més informació: <https://manned.org/lzma>.

- Veure documentació pel comandament original:

`tldr xz`
