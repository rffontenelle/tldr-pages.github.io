# docker-container-top

> Aquest comandament és un àlies de `docker top`.
> Més informació: <https://docs.docker.com/engine/reference/commandline/top>.

- Veure documentació pel comandament original:

`tldr docker top`
