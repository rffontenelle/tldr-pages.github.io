# fossil ci

> Aquest comandament es un àlies de `fossil commit`.
> Més informació: <https://fossil-scm.org/home/help/commit>.

- Veure documentació per el comandament original:

`tldr fossil-commit`
