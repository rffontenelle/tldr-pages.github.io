# ntl

> Aquest comandament és un àlies de `netlify`.
> Més informació: <https://cli.netlify.com>.

- Veure documentació pel comandament original:

`tldr netlify`
