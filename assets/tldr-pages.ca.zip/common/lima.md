# lima

> Aquest comandament és un àlies de `limactl`.
> Més informació: <https://github.com/lima-vm/lima>.

- Veure documentació pel comandament original:

`tldr limactl`
