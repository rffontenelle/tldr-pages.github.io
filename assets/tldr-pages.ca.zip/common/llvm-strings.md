# llvm-strings

> Aquest comandament és un àlies de `strings`.

- Veure documentació pel comandament original:

`tldr strings`
