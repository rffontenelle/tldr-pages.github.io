# azure-cli

> Aquest comandament és un àlies de `az`.
> Més informació: <https://learn.microsoft.com/cli/azure>.

- Veure documentació pel comandament original:

`tldr az`
