# lzcmp

> Aquest comandament és un àlies de `xzcmp`.

- Veure documentació pel comandament original:

`tldr xzcmp`
