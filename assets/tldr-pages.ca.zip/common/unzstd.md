# unzstd

> Aquest comandament és un àlies de `zstd`.

- Veure documentació pel comandament original:

`tldr zstd`
