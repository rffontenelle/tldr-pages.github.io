# rcat

> Aquest comandament és un àlies de `rc`.

- Veure documentació pel comandament original:

`tldr rc`
