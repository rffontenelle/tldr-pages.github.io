# ripgrep

> Aquest comandament és un àlies de `rg`.

- Veure documentació pel comandament original:

`tldr rg`
