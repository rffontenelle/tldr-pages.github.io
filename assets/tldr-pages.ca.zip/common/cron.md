# cron

> Aquest comandament és un àlies de `crontab`.

- Veure documentació pel comandament original:

`tldr crontab`
