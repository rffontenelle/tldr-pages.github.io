# pwsh

> Aquest comandament és un àlies de `powershell`.

- Veure documentació pel comandament original:

`tldr powershell`
