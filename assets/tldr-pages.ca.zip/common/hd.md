# hd

> Aquest comandament és un àlies de `hexdump`.
> Més informació: <https://manned.org/hd.1>.

- Veure documentació pel comandament original:

`tldr hexdump`
