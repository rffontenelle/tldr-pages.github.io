# lzmore

> Aquest comandament és un àlies de `xzmore`.

- Veure documentació pel comandament original:

`tldr xzmore`
