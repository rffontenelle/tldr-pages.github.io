# transmission

> Aquest comandament és un àlies de `transmission-daemon`.
> Més informació: <https://transmissionbt.com/>.

- Veure documentació pel comandament original:

`tldr transmission-daemon`
