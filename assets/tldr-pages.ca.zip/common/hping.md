# hping

> Aquest comandament és un àlies de `hping3`.
> Més informació: <https://github.com/antirez/hping>.

- Veure documentació pel comandament original:

`tldr hping3`
