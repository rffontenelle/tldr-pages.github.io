# fossil-delete

> Aquest comandament és un àlies de `fossil rm`.
> Més informació: <https://fossil-scm.org/home/help/delete>.

- Veure documentació pel comandament original:

`tldr fossil rm`
