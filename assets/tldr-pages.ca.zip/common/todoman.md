# todoman

> Aquest comandament és un àlies de `todo`.
> Més informació: <https://todoman.readthedocs.io/>.

- Veure documentació pel comandament original:

`tldr todo`
