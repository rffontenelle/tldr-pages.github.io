# mscore

> Aquest comandament és un àlies de `musescore`.
> Més informació: <https://musescore.org/handbook/command-line-options>.

- Veure documentació pel comandament original:

`tldr musescore`
