# docker-container-remove

> Aquest comandament és un àlies de `docker rm`.
> Més informació: <https://docs.docker.com/engine/reference/commandline/rm>.

- Veure documentació pel comandament original:

`tldr docker rm`
