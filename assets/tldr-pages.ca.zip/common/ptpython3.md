# ptpython3

> Aquest comandament és un àlies de `ptpython`.

- Veure documentació pel comandament original:

`tldr ptpython`
