# docker-container-rename

> Aquest comandament és un àlies de `docker rename`.
> Més informació: <https://docs.docker.com/engine/reference/commandline/rename>.

- Veure documentació pel comandament original:

`tldr docker rename`
