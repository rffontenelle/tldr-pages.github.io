# vi

> Aquest comandament és un àlies de `vim`.

- Veure documentació pel comandament original:

`tldr vim`
