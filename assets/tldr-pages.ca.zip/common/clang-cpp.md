# clang-cpp

> Aquest comandament és un àlies de `clang++`.

- Veure documentació pel comandament original:

`tldr clang++`
