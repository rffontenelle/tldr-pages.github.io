# python3

> Aquest comandament és un àlies de `python`.

- Veure documentació pel comandament original:

`tldr python`
