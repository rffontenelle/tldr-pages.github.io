# piodebuggdb

> Aquest comandament és un àlies de `pio debug`.

- Veure documentació pel comandament original:

`tldr pio debug`
