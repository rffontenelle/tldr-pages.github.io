# platformio

> Aquest comandament és un àlies de `pio`.
> Més informació: <https://docs.platformio.org/en/latest/core/userguide/>.

- Veure documentació pel comandament original:

`tldr pio`
