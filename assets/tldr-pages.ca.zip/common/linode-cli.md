# linode-cli

> Aquest comandament és un àlies de `linode-cli account`.
> Més informació: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Veure documentació pel comandament original:

`tldr linode-cli account`
