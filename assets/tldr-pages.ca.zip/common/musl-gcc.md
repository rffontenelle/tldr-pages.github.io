# musl-gcc

> Aquest comandament és un àlies de `gcc`.
> Més informació: <https://manned.org/musl-gcc>.

- Veure documentació pel comandament original:

`tldr gcc`
