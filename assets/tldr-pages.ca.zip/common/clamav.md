# clamav

> Aquest comandament és un àlies de `clamdscan`.
> Més informació: <https://www.clamav.net>.

- Veure documentació pel comandament original:

`tldr clamdscan`
