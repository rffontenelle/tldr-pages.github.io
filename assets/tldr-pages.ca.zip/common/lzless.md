# lzless

> Aquest comandament és un àlies de `xzless`.

- Veure documentació pel comandament original:

`tldr xzless`
