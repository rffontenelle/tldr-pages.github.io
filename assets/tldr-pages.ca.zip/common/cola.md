# cola

> Aquest comandament és un àlies de `git-cola`.

- Veure documentació pel comandament original:

`tldr git-cola`
