# tldrl

> Aquest comandament és un àlies de `tldr-lint`.
> Més informació: <https://github.com/tldr-pages/tldr-lint>.

- Veure documentació pel comandament original:

`tldr tldr-lint`
