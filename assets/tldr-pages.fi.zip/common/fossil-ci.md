# fossil-ci

> Tämä komento on `fossil-commit`:n alias.
> Lisätietoja: <https://fossil-scm.org/home/help/commit>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr fossil-commit`
