# llvm-strings

> Tämä komento on `strings`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr strings`
