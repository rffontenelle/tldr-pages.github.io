# xzfgrep

> Tämä komento on `xzgrep`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xzgrep`
