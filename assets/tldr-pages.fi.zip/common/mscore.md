# mscore

> Tämä komento on `musescore`:n alias.
> Lisätietoja: <https://musescore.org/handbook/command-line-options>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr musescore`
