# lima

> Tämä komento on `limactl`:n alias.
> Lisätietoja: <https://github.com/lima-vm/lima>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr limactl`
