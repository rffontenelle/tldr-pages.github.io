# todoman

> Tämä komento on `todo`:n alias.
> Lisätietoja: <https://todoman.readthedocs.io/>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr todo`
