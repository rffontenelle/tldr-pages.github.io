# platformio

> Tämä komento on `pio`:n alias.
> Lisätietoja: <https://docs.platformio.org/en/latest/core/userguide/>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr pio`
