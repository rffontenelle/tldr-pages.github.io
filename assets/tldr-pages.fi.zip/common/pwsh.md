# pwsh

> Tämä komento on `powershell`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr powershell`
