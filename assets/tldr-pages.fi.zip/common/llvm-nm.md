# llvm-nm

> Tämä komento on `nm`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr nm`
