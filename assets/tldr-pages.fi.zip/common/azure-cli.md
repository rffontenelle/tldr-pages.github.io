# azure-cli

> Tämä komento on `az`:n alias.
> Lisätietoja: <https://learn.microsoft.com/cli/azure>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr az`
