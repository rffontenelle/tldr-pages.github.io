# cola

> Tämä komento on `git-cola`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr git-cola`
