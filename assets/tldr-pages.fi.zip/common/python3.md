# python3

> Tämä komento on `python`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr python`
