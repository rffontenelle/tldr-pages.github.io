# fossil-new

> Tämä komento on `fossil-init`:n alias.
> Lisätietoja: <https://fossil-scm.org/home/help/new>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr fossil-init`
