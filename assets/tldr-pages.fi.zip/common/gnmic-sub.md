# gnmic-sub

> Tämä komento on `gnmic subscribe`:n alias.
> Lisätietoja: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr gnmic subscribe`
