# ripgrep

> Tämä komento on `rg`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr rg`
