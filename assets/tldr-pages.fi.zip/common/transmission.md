# transmission

> Tämä komento on `transmission-daemon`:n alias.
> Lisätietoja: <https://transmissionbt.com/>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr transmission-daemon`
