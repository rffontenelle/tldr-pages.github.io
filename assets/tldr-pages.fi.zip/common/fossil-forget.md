# fossil-forget

> Tämä komento on `fossil rm`:n alias.
> Lisätietoja: <https://fossil-scm.org/home/help/forget>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr fossil rm`
