# clamav

> Tämä komento on `clamdscan`:n alias.
> Lisätietoja: <https://www.clamav.net>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr clamdscan`
