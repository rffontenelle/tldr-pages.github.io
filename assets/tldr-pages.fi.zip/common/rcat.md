# rcat

> Tämä komento on `rc`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr rc`
