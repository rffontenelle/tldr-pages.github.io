# lzless

> Tämä komento on `xzless`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xzless`
