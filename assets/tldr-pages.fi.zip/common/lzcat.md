# lzcat

> Tämä komento on `xz`:n alias.
> Lisätietoja: <https://manned.org/lzcat>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xz`
