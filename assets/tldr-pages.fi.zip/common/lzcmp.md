# lzcmp

> Tämä komento on `xzcmp`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xzcmp`
