# hd

> Tämä komento on `hexdump`:n alias.
> Lisätietoja: <https://manned.org/hd.1>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr hexdump`
