# hx

> Tämä komento on `helix`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr helix`
