# fossil-delete

> Tämä komento on `fossil rm`:n alias.
> Lisätietoja: <https://fossil-scm.org/home/help/delete>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr fossil rm`
