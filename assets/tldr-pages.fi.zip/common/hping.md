# hping

> Tämä komento on `hping3`:n alias.
> Lisätietoja: <https://github.com/antirez/hping>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr hping3`
