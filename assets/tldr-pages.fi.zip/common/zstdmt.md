# zstdmt

> Tämä komento on `zstd`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr zstd`
