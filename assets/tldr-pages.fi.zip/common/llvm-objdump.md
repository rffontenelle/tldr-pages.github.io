# llvm-objdump

> Tämä komento on `objdump`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr objdump`
