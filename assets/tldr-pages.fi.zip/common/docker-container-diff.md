# docker-container-diff

> Tämä komento on `docker diff`:n alias.
> Lisätietoja: <https://docs.docker.com/engine/reference/commandline/diff>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr docker diff`
