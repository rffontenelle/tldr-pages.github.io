# netcat

> Tämä komento on `nc`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr nc`
