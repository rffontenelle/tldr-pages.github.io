# docker-container-rename

> Tämä komento on `docker rename`:n alias.
> Lisätietoja: <https://docs.docker.com/engine/reference/commandline/rename>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr docker rename`
