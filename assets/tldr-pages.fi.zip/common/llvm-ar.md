# llvm-ar

> Tämä komento on `ar`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr ar`
