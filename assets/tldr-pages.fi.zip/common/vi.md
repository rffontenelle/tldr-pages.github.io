# vi

> Tämä komento on `vim`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr vim`
