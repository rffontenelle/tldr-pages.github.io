# cron

> Tämä komento on `crontab`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr crontab`
