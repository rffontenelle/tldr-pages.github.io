# clojure

> Tämä komento on `clj`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr clj`
