# ptpython3

> Tämä komento on `ptpython`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr ptpython`
