# lzmore

> Tämä komento on `xzmore`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xzmore`
