# musl-gcc

> Tämä komento on `gcc`:n alias.
> Lisätietoja: <https://manned.org/musl-gcc>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr gcc`
