# gh-cs

> Tämä komento on `gh-codespace`:n alias.
> Lisätietoja: <https://cli.github.com/manual/gh_codespace>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr gh-codespace`
