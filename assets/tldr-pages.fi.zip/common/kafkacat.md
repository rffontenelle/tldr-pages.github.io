# kafkacat

> Tämä komento on `kcat`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr kcat`
