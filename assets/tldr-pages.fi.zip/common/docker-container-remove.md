# docker-container-remove

> Tämä komento on `docker rm`:n alias.
> Lisätietoja: <https://docs.docker.com/engine/reference/commandline/rm>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr docker rm`
