# linode-cli

> Tämä komento on `linode-cli account`:n alias.
> Lisätietoja: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr linode-cli account`
