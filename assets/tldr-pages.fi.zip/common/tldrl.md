# tldrl

> Tämä komento on `tldr-lint`:n alias.
> Lisätietoja: <https://github.com/tldr-pages/tldr-lint>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr tldr-lint`
