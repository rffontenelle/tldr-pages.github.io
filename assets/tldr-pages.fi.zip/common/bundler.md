# bundler

> Tämä komento on `bundle`:n alias.
> Lisätietoja: <https://bundler.io/man/bundle.1.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr bundle`
