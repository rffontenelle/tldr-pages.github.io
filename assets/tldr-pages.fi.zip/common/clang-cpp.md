# clang-cpp

> Tämä komento on `clang++`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr clang++`
