# ntl

> Tämä komento on `netlify`:n alias.
> Lisätietoja: <https://cli.netlify.com>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr netlify`
