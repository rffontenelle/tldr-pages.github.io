# unlzma

> Tämä komento on `xz`:n alias.
> Lisätietoja: <https://manned.org/unlzma>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xz`
