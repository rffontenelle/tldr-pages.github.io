# just

> Tämä komento on `just.1`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr just.1`
