# piodebuggdb

> Tämä komento on `pio debug`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr pio debug`
