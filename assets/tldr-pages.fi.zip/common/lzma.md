# lzma

> Tämä komento on `xz`:n alias.
> Lisätietoja: <https://manned.org/lzma>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xz`
