# tlmgr-arch

> Tämä komento on `tlmgr platform`:n alias.
> Lisätietoja: <https://www.tug.org/texlive/tlmgr.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr tlmgr platform`
