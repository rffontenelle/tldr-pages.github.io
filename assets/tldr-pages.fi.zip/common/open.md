# open

> Tämä komento on `open -p osx`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr open -p osx`
