# pio-init

> Tämä komento on `pio project`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr pio project`
