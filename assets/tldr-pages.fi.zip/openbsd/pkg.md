# pkg

> Tämä komento on `pkg_add`:n alias.
> Lisätietoja: <https://www.openbsd.org/faq/faq15.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr pkg_add`
