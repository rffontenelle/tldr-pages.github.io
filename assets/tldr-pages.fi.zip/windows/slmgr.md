# slmgr

> Tämä komento on `slmgr.vbs`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr slmgr.vbs`
