# cuninst

> Tämä komento on `choco uninstall`:n alias.
> Lisätietoja: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr choco uninstall`
