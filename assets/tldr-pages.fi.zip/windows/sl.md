# sl

> Tämä komento on `set-location`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr set-location`
