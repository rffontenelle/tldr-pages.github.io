# sc-query

> Tämä komento on `sc`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr sc`
