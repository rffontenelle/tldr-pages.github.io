# gal

> Tämä komento on `get-alias`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr get-alias`
