# chdir

> Tämä komento on `cd`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr cd`
