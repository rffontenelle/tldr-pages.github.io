# sls

> Tämä komento on `where-object`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr where-object`
