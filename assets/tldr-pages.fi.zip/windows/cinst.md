# cinst

> Tämä komento on `choco install`:n alias.
> Lisätietoja: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr choco install`
