# sc-config

> Tämä komento on `sc`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr sc`
