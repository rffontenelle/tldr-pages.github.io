# sc-delete

> Tämä komento on `sc`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr sc`
