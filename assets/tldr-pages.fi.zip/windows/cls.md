# cls

> Tämä komento on `clear-host`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr clear-host`
