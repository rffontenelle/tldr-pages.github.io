# cd

> Tämä komento on `set-location`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr set-location`
