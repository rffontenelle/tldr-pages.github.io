# chrome

> Tämä komento on `chromium`:n alias.
> Lisätietoja: <https://chrome.google.com>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr chromium`
