# curl

> Tämä komento on `curl -p common`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr curl -p common`
