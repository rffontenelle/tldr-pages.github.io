# del

> Tämä komento on `remove-item`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr remove-item`
