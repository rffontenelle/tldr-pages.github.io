# sc-create

> Tämä komento on `sc`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr sc`
