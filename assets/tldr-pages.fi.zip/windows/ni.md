# ni

> Tämä komento on `new-item`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr new-item`
