# cpush

> Tämä komento on `choco-push`:n alias.
> Lisätietoja: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr choco-push`
