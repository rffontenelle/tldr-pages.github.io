# clear

> Tämä komento on `clear-host`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr clear-host`
