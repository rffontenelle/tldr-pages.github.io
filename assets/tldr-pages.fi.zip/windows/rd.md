# rd

> Tämä komento on `rmdir`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr rmdir`
