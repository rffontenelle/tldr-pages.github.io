# rmdir

> Tämä komento on `remove-item`:n alias.
> Lisätietoja: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr remove-item`
