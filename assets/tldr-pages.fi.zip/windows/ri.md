# ri

> Tämä komento on `remove-item`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr remove-item`
