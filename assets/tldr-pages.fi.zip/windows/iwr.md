# iwr

> Tämä komento on `invoke-webrequest`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr invoke-webrequest`
