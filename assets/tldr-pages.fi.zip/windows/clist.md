# clist

> Tämä komento on `choco list`:n alias.
> Lisätietoja: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr choco list`
