# pwsh-where

> Tämä komento on `Where-Object`:n alias.
> Lisätietoja: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr Where-Object`
