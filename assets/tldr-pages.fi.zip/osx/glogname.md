# glogname

> Tämä komento on `-p linux logname`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux logname`
