# gmknod

> Tämä komento on `-p linux mknod`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux mknod`
