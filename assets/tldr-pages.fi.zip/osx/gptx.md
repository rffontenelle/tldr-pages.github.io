# gptx

> Tämä komento on `-p linux ptx`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ptx`
