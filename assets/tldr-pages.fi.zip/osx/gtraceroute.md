# gtraceroute

> Tämä komento on `-p linux traceroute`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux traceroute`
