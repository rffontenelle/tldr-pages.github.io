# ggrep

> Tämä komento on `-p linux grep`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux grep`
