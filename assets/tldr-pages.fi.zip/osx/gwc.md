# gwc

> Tämä komento on `-p linux wc`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux wc`
