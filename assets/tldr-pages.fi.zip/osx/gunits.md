# gunits

> Tämä komento on `-p linux units`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux units`
