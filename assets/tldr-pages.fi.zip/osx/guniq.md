# guniq

> Tämä komento on `-p linux uniq`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux uniq`
