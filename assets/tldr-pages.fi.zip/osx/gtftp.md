# gtftp

> Tämä komento on `-p linux tftp`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tftp`
