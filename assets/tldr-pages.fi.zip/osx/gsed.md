# gsed

> Tämä komento on `-p linux sed`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sed`
