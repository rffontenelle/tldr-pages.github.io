# grealpath

> Tämä komento on `-p linux realpath`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux realpath`
