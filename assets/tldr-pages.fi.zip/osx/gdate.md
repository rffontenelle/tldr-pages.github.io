# gdate

> Tämä komento on `-p linux date`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux date`
