# gawk

> Tämä komento on `-p linux awk`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux awk`
