# gdd

> Tämä komento on `-p linux dd`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux dd`
