# gfmt

> Tämä komento on `-p linux fmt`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux fmt`
