# gwhois

> Tämä komento on `-p linux whois`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux whois`
