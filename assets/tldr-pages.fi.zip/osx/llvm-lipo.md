# llvm-lipo

> Tämä komento on `lipo`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr lipo`
