# gexpr

> Tämä komento on `-p linux expr`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux expr`
