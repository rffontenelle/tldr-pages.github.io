# gpaste

> Tämä komento on `-p linux paste`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux paste`
