# gxargs

> Tämä komento on `-p linux xargs`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux xargs`
