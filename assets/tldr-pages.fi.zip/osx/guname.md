# guname

> Tämä komento on `-p linux uname`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux uname`
