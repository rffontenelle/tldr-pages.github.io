# gbasenc

> Tämä komento on `-p linux basenc`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux basenc`
