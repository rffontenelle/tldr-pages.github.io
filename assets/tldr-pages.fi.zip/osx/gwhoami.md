# gwhoami

> Tämä komento on `-p linux whoami`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux whoami`
