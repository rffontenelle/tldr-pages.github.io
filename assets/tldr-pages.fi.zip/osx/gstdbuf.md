# gstdbuf

> Tämä komento on `-p linux stdbuf`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux stdbuf`
