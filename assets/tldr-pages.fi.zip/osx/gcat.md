# gcat

> Tämä komento on `-p linux cat`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux cat`
