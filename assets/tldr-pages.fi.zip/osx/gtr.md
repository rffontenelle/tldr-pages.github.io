# gtr

> Tämä komento on `-p linux tr`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tr`
