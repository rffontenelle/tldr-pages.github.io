# gwho

> Tämä komento on `-p linux who`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux who`
