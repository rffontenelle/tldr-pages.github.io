# gfind

> Tämä komento on `-p linux find`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux find`
