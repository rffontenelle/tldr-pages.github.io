# gsum

> Tämä komento on `-p linux sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sum`
