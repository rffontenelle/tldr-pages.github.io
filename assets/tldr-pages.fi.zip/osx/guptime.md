# guptime

> Tämä komento on `-p linux uptime`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux uptime`
