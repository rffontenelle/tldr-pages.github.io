# ginstall

> Tämä komento on `-p linux install`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux install`
