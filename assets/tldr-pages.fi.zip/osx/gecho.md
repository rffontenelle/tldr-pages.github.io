# gecho

> Tämä komento on `-p linux echo`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux echo`
