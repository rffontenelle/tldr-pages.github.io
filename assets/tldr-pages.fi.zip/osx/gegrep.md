# gegrep

> Tämä komento on `-p linux egrep`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux egrep`
