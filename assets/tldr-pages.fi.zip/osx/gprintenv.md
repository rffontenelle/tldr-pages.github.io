# gprintenv

> Tämä komento on `-p linux printenv`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux printenv`
