# gdir

> Tämä komento on `-p linux dir`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux dir`
