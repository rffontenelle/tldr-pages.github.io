# gsha384sum

> Tämä komento on `-p linux sha384sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sha384sum`
