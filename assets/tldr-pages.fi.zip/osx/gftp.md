# gftp

> Tämä komento on `-p linux ftp`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ftp`
