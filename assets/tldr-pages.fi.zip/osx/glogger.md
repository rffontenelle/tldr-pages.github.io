# glogger

> Tämä komento on `-p linux logger`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux logger`
