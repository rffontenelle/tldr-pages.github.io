# gmd5sum

> Tämä komento on `-p linux md5sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux md5sum`
