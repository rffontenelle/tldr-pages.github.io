# gsleep

> Tämä komento on `-p linux sleep`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sleep`
