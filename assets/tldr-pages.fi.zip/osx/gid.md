# gid

> Tämä komento on `-p linux id`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux id`
