# gtty

> Tämä komento on `-p linux tty`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tty`
