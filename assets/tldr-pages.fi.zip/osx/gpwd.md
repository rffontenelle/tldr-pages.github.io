# gpwd

> Tämä komento on `-p linux pwd`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux pwd`
