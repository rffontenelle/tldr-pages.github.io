# grmdir

> Tämä komento on `-p linux rmdir`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux rmdir`
