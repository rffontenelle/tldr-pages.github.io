# gcksum

> Tämä komento on `-p linux cksum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux cksum`
