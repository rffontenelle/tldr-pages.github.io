# gmkfifo

> Tämä komento on `-p linux mkfifo`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux mkfifo`
