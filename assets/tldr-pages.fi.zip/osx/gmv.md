# gmv

> Tämä komento on `-p linux mv`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux mv`
