# grexec

> Tämä komento on `-p linux rexec`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux rexec`
