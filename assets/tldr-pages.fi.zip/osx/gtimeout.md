# gtimeout

> Tämä komento on `-p linux timeout`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux timeout`
