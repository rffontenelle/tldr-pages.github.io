# gsha1sum

> Tämä komento on `-p linux sha1sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sha1sum`
