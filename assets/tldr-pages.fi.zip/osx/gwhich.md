# gwhich

> Tämä komento on `-p linux which`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux which`
