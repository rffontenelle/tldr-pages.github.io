# gtsort

> Tämä komento on `-p linux tsort`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tsort`
