# gcomm

> Tämä komento on `-p linux comm`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux comm`
