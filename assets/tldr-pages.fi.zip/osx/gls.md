# gls

> Tämä komento on `-p linux ls`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ls`
