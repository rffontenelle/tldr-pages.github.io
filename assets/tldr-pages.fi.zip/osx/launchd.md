# launchd

> Tämä komento on `launchctl`:n alias.
> Lisätietoja: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr launchctl`
