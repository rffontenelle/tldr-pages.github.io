# gruncon

> Tämä komento on `-p linux runcon`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux runcon`
