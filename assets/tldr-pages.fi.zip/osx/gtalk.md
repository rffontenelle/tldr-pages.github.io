# gtalk

> Tämä komento on `-p linux talk`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux talk`
