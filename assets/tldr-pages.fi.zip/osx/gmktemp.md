# gmktemp

> Tämä komento on `-p linux mktemp`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux mktemp`
