# gcsplit

> Tämä komento on `-p linux csplit`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux csplit`
