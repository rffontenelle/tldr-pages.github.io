# gtrue

> Tämä komento on `-p linux true`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux true`
