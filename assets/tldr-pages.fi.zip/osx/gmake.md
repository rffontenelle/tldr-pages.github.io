# gmake

> Tämä komento on `-p linux make`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux make`
