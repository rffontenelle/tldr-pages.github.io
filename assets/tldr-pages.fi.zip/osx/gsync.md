# gsync

> Tämä komento on `-p linux sync`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sync`
