# gbase64

> Tämä komento on `-p linux base64`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux base64`
