# gexpand

> Tämä komento on `-p linux expand`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux expand`
