# gpr

> Tämä komento on `-p linux pr`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux pr`
