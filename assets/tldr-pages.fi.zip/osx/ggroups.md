# ggroups

> Tämä komento on `-p linux groups`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux groups`
