# gdf

> Tämä komento on `-p linux df`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux df`
