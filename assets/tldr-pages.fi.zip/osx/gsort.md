# gsort

> Tämä komento on `-p linux sort`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sort`
