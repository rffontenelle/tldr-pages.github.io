# gln

> Tämä komento on `-p linux ln`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ln`
