# gmkdir

> Tämä komento on `-p linux mkdir`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux mkdir`
