# greadlink

> Tämä komento on `-p linux readlink`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux readlink`
