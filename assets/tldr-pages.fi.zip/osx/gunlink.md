# gunlink

> Tämä komento on `-p linux unlink`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux unlink`
