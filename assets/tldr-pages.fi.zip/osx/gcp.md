# gcp

> Tämä komento on `-p linux cp`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux cp`
