# gtac

> Tämä komento on `-p linux tac`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tac`
