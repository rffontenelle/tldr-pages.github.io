# ghostname

> Tämä komento on `-p linux hostname`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux hostname`
