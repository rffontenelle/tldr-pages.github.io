# gdnsdomainname

> Tämä komento on `-p linux dnsdomainname`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux dnsdomainname`
