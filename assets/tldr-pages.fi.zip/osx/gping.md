# gping

> Tämä komento on `-p linux ping`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ping`
