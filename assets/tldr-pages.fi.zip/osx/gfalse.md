# gfalse

> Tämä komento on `-p linux false`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux false`
