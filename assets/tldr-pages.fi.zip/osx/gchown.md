# gchown

> Tämä komento on `-p linux chown`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux chown`
