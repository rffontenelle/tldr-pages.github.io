# gshred

> Tämä komento on `-p linux shred`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux shred`
