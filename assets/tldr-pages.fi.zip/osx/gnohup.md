# gnohup

> Tämä komento on `-p linux nohup`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux nohup`
