# gusers

> Tämä komento on `-p linux users`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux users`
