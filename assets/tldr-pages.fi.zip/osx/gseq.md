# gseq

> Tämä komento on `-p linux seq`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux seq`
