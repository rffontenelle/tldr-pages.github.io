# gupdatedb

> Tämä komento on `-p linux updatedb`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux updatedb`
