# gnl

> Tämä komento on `-p linux nl`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux nl`
