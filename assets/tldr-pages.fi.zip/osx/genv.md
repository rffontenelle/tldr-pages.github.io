# genv

> Tämä komento on `-p linux env`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux env`
