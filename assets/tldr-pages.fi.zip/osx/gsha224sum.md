# gsha224sum

> Tämä komento on `-p linux sha224sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sha224sum`
