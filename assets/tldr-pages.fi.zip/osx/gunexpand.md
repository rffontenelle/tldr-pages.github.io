# gunexpand

> Tämä komento on `-p linux unexpand`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux unexpand`
