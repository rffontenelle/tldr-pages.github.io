# gtest

> Tämä komento on `-p linux test`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux test`
