# glocate

> Tämä komento on `-p linux locate`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux locate`
