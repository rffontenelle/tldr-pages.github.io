# grlogin

> Tämä komento on `-p linux rlogin`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux rlogin`
