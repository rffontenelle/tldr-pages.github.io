# aa

> Tämä komento on `yaa`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr yaa`
