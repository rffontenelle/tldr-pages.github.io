# gbasename

> Tämä komento on `-p linux basename`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux basename`
