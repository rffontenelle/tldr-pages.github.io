# gindent

> Tämä komento on `-p linux indent`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux indent`
