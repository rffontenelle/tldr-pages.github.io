# gbase32

> Tämä komento on `-p linux base32`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux base32`
