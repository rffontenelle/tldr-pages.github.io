# gstat

> Tämä komento on `-p linux stat`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux stat`
