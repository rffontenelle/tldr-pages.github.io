# gsha512sum

> Tämä komento on `-p linux sha512sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sha512sum`
