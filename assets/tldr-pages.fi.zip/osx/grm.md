# grm

> Tämä komento on `-p linux rm`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux rm`
