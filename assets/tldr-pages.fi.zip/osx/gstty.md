# gstty

> Tämä komento on `-p linux stty`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux stty`
