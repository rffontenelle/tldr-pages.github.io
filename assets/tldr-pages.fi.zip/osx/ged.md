# ged

> Tämä komento on `-p linux ed`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ed`
