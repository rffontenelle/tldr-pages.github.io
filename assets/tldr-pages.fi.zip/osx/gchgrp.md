# gchgrp

> Tämä komento on `-p linux chgrp`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux chgrp`
