# gnumfmt

> Tämä komento on `-p linux numfmt`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux numfmt`
