# gpathchk

> Tämä komento on `-p linux pathchk`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux pathchk`
