# ghostid

> Tämä komento on `-p linux hostid`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux hostid`
