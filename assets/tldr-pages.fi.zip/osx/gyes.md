# gyes

> Tämä komento on `-p linux yes`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux yes`
