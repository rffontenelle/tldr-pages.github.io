# gpinky

> Tämä komento on `-p linux pinky`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux pinky`
