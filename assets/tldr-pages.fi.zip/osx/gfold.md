# gfold

> Tämä komento on `-p linux fold`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux fold`
