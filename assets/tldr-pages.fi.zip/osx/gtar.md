# gtar

> Tämä komento on `-p linux tar`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tar`
