# gping6

> Tämä komento on `-p linux ping6`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux ping6`
