# ghead

> Tämä komento on `-p linux head`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux head`
