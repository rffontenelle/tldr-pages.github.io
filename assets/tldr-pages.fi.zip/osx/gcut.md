# gcut

> Tämä komento on `-p linux cut`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux cut`
