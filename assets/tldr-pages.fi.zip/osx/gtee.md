# gtee

> Tämä komento on `-p linux tee`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux tee`
