# gsha256sum

> Tämä komento on `-p linux sha256sum`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr -p linux sha256sum`
