# qm-resize

> Tämä komento on `qm-disk-resize`:n alias.
> Lisätietoja: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr qm-disk-resize`
