# ubuntu-bug

> Tämä komento on `apport-bug`:n alias.
> Lisätietoja: <https://manned.org/ubuntu-bug>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr apport-bug`
