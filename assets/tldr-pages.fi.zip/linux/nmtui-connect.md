# nmtui-connect

> Tämä komento on `nmtui`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr nmtui`
