# mount.smb3

> Tämä komento on `mount.cifs`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr mount.cifs`
