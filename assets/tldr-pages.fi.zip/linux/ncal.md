# ncal

> Tämä komento on `cal`:n alias.
> Lisätietoja: <https://manned.org/ncal>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr cal`
