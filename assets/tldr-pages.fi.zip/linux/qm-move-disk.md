# qm-move-disk

> Tämä komento on `qm-disk-move`:n alias.
> Lisätietoja: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr qm-disk-move`
