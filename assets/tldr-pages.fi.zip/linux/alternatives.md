# alternatives

> Tämä komento on `update-alternatives`:n alias.
> Lisätietoja: <https://manned.org/alternatives>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr update-alternatives`
