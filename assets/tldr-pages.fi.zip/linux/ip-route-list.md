# ip-route-list

> Tämä komento on `ip-route-show`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr ip-route-show`
