# cgroups

> Tämä komento on `cgclassify`:n alias.
> Lisätietoja: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr cgclassify`
