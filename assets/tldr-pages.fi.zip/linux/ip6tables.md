# ip6tables

> Tämä komento on `iptables`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr iptables`
