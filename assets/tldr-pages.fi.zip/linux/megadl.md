# megadl

> Tämä komento on `megatools-dl`:n alias.
> Lisätietoja: <https://megatools.megous.com/man/megatools-dl.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr megatools-dl`
