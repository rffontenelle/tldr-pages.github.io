# qm-importdisk

> Tämä komento on `qm disk import`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr qm disk import`
