# shntool-split

> Tämä komento on `shnsplit`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr shnsplit`
