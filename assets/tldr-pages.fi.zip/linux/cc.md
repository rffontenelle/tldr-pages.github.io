# cc

> Tämä komento on `gcc`:n alias.
> Lisätietoja: <https://gcc.gnu.org>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr gcc`
