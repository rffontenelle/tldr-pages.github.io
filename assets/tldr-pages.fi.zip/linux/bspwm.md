# bspwm

> Tämä komento on `bspc`:n alias.
> Lisätietoja: <https://github.com/baskerville/bspwm>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr bspc`
