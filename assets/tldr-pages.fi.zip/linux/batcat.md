# batcat

> Tämä komento on `bat`:n alias.
> Lisätietoja: <https://github.com/sharkdp/bat>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr bat`
