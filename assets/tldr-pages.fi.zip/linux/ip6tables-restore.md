# ip6tables-restore

> Tämä komento on `iptables-restore`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr iptables-restore`
