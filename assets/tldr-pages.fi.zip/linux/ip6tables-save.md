# ip6tables-save

> Tämä komento on `iptables-save`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr iptables-save`
