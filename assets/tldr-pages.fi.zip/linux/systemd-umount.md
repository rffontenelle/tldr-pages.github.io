# systemd-umount

> Tämä komento on `systemd-mount`:n alias.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr systemd-mount`
