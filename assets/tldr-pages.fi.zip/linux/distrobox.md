# distrobox

> Tämä komento on `distrobox-create`:n alias.
> Lisätietoja: <https://github.com/89luca89/distrobox>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr distrobox-create`
