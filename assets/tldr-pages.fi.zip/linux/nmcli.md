# nmcli

> Tämä komento on `nmcli agent`:n alias.
> Lisätietoja: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr nmcli agent`
