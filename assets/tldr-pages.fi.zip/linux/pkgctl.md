# pkgctl

> Tämä komento on `pkgctl auth`:n alias.
> Lisätietoja: <https://man.archlinux.org/man/pkgctl.1>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr pkgctl auth`
