# apx

> Tämä komento on `apx pkgmanagers`:n alias.
> Lisätietoja: <https://github.com/Vanilla-OS/apx>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr apx pkgmanagers`
