# xbps

> Tämä komento on `xbps-install`:n alias.
> Lisätietoja: <https://docs.voidlinux.org/xbps/index.html>.

- Katso alkuperäisen komennon dokumentaatiossa:

`tldr xbps-install`
