# distrobox

> यह आदेश `distrobox-create` का उपनाम है।
> अधिक जानकारी: <https://github.com/89luca89/distrobox>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr distrobox-create`
