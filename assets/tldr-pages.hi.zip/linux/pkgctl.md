# pkgctl

> यह आदेश `pkgctl auth` का उपनाम है।
> अधिक जानकारी: <https://man.archlinux.org/man/pkgctl.1>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr pkgctl auth`
