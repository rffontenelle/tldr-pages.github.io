# nmcli

> यह आदेश `nmcli agent` का उपनाम है।
> अधिक जानकारी: <https://networkmanager.dev/docs/api/latest/nmcli.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr nmcli agent`
