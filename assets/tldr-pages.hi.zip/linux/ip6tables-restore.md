# ip6tables-restore

> यह आदेश `iptables-restore` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr iptables-restore`
