# qm-importdisk

> यह आदेश `qm disk import` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr qm disk import`
