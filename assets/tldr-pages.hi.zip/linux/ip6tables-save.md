# ip6tables-save

> यह आदेश `iptables-save` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr iptables-save`
