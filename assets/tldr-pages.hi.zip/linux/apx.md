# apx

> यह आदेश `apx pkgmanagers` का उपनाम है।
> अधिक जानकारी: <https://github.com/Vanilla-OS/apx>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr apx pkgmanagers`
