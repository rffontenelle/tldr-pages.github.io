# xbps

> यह आदेश `xbps-install` का उपनाम है।
> अधिक जानकारी: <https://docs.voidlinux.org/xbps/index.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr xbps-install`
