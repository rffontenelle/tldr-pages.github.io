# qm-move-disk

> यह आदेश `qm-disk-move` का उपनाम है।
> अधिक जानकारी: <https://pve.proxmox.com/pve-docs/qm.1.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr qm-disk-move`
