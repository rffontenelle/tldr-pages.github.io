# bspwm

> यह आदेश `bspc` का उपनाम है।
> अधिक जानकारी: <https://github.com/baskerville/bspwm>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr bspc`
