# checkupdates

> आर्क लिनक्स में लंबित अद्यतनों की जाँच करने के लिए उपकरण।
> अधिक जानकारी: <https://man.archlinux.org/man/checkupdates.8>.

- लंबित अद्यतनों की सूची बनाएं:

`checkupdates`

- लंबित अद्यतनों की सूची बनाएं और पैकेजों को पैक्मैन कैश में डाउनलोड करें:

`checkupdates --download`

- विशिष्ट पैक्मैन डेटाबेस का उपयोग करके लंबित अद्यतनों की सूची बनाएं:

`CHECKUPDATES_DB={{निर्देशिका/का/पथ}} checkupdates`

- सहायता प्रदर्शित करें:

`checkupdates --help`
