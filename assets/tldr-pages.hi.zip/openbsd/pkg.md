# pkg

> यह आदेश `pkg_add` का उपनाम है।
> अधिक जानकारी: <https://www.openbsd.org/faq/faq15.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr pkg_add`
