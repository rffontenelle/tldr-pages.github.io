# gpinky

> यह आदेश `-p linux pinky` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr -p linux pinky`
