# launchd

> यह आदेश `launchctl` का उपनाम है।
> अधिक जानकारी: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr launchctl`
