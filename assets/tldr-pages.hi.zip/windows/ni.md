# ni

> यह आदेश `new-item` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr new-item`
