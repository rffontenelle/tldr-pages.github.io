# wget

> यह आदेश `wget -p common` का उपनाम है।
> अधिक जानकारी: <https://www.gnu.org/software/wget>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr wget -p common`
