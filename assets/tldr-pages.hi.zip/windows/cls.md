# cls

> यह आदेश `clear-host` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr clear-host`
