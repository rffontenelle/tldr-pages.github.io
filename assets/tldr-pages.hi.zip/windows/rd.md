# rd

> यह आदेश `rmdir` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr rmdir`
