# pwsh where

> यह आदेश `Where-Object` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr Where-Object`
