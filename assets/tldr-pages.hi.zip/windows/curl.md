# curl

> यह आदेश `curl -p common` का उपनाम है।
> अधिक जानकारी: <https://curl.se>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr curl -p common`
