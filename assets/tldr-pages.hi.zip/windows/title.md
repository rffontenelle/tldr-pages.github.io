# title

> कमांड प्रॉम्प्ट विंडो का शीर्षक सेट करें।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/title>.

- वर्तमान कमांड प्रॉम्प्ट विंडो का शीर्षक सेट करें:

`title {{नया_शीर्षक}}`
