# exit

> वर्तमान सीएमडी इंस्टेंस या वर्तमान बैच फ़ाइल से बाहर निकलें।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- वर्तमान सीएमडी उदाहरण से बाहर निकलें:

`exit`

- वर्तमान बैच स्क्रिप्ट से बाहर निकलें:

`exit /b`

- विशिष्ट निकास कोड का उपयोग करना बंद करें:

`exit {{2}}`
