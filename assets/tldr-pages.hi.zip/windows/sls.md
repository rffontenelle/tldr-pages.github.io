# sls

> यह आदेश `Select-String` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr select-string`
