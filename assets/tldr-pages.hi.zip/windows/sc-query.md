# sc-query

> यह आदेश `sc` का उपनाम है।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr sc`
