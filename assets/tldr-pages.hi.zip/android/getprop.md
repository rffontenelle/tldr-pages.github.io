# getprop

> एंड्रॉइड सिस्टम गुणों के बारे में जानकारी दिखाएं।
> अधिक जानकारी: <https://manned.org/getprop>।

- एंड्रॉइड सिस्टम गुणों के बारे में जानकारी प्रदर्शित करें:

`getprop`

- किसी विशिष्ट गुण के बारे में जानकारी प्रदर्शित करें:

`getprop {{गुण}}`

- एसडीके एपीआई स्तर प्रदर्शित करें:

`getprop {{ro.build.version.sdk}}`

- एंड्रॉइड संस्करण प्रदर्शित करें:

`getprop {{ro.build.version.release}}`

- एंड्रॉइड डिवाइस मॉडल प्रदर्शित करें:

`getprop {{ro.vendor.product.model}}`

- ओईएम अनलॉक स्थिति प्रदर्शित करें:

`getprop {{ro.oem_unlock_supported}}`

- एंड्रॉइड के वाईफ़ाई कार्ड का मैक पता प्रदर्शित करें:

`getprop {{ro.boot.wifimacaddr}}`
