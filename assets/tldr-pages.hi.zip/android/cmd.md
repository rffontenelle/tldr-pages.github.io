# cmd

> एंड्रॉइड सेवा प्रबंधक।
> अधिक जानकारी: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- सभी चल रही सेवाओं की सूची[l] बनाएं:

`cmd -l`

- किसी विशिष्ट सेवा को कॉल करें:

`cmd {{सेवा}}`

- विशिष्ट तर्कों के साथ किसी सेवा को कॉल करें:

`cmd {{सेवा}} {{तर्क1 तर्क2 ...}}`
