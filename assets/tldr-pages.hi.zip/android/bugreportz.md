# bugreportz

> एक ज़िप्ड एंड्रॉइड बग रिपोर्ट तैयार करें।
> इस कमांड का उपयोग केवल `adb shell` के माध्यम से किया जा सकता है।
> अधिक जानकारी: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>।

- एंड्रॉइड डिवाइस की संपूर्ण ज़िप्ड बग रिपोर्ट तैयार करें:

`bugreportz`

- चल रहे `bugreportz` ऑपरेशन की प्रगति दिखाएं:

`bugreportz -p`

- `bugreportz` का संस्करण दिखाएँ:

`bugreportz -v`

- सहायता प्रदर्शित करें:

`bugreportz -h`
