# docker-container-rename

> यह आदेश `docker rename` का उपनाम है।
> अधिक जानकारी: <https://docs.docker.com/engine/reference/commandline/rename>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker rename`
