# hping

> यह आदेश `hping3` का उपनाम है।
> अधिक जानकारी: <https://github.com/antirez/hping>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr hping3`
