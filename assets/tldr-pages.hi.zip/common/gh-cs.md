# gh-cs

> यह आदेश `gh-codespace` का उपनाम है।
> अधिक जानकारी: <https://cli.github.com/manual/gh_codespace>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr gh-codespace`
