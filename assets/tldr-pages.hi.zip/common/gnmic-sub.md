# gnmic-sub

> यह आदेश `gnmic subscribe` का उपनाम है।
> अधिक जानकारी: <https://gnmic.kmrd.dev/cmd/subscribe>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr gnmic subscribe`
