# todoman

> यह आदेश `todo` का उपनाम है।
> अधिक जानकारी: <https://todoman.readthedocs.io/>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr todo`
