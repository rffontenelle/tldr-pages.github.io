# fossil-ci

> यह आदेश `fossil-commit` का उपनाम है।
> अधिक जानकारी: <https://fossil-scm.org/home/help/commit>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr fossil-commit`
