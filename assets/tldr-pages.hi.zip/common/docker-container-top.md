# docker-container-top

> यह आदेश `docker top` का उपनाम है।
> अधिक जानकारी: <https://docs.docker.com/engine/reference/commandline/top>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker top`
