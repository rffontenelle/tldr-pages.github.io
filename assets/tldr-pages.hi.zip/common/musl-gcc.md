# musl-gcc

> यह आदेश `gcc` का उपनाम है।
> अधिक जानकारी: <https://manned.org/musl-gcc>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr gcc`
