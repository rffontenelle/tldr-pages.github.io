# docker-container-rm

> यह आदेश `docker rm` का उपनाम है।
> अधिक जानकारी: <https://docs.docker.com/engine/reference/commandline/rm>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker rm`
