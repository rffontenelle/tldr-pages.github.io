# sleep

> निर्दिष्ट समय के लिए विलंब जोड़ें।
> अधिक जानकारी: <https://www.gnu.org/software/coreutils/sleep>।

- सेकंड में देरी:

`sleep {{सेकंड}}`

- मिनटों में देरी:

`sleep {{मिनट}}m`

- घंटों में देरी:

`sleep {{घंटे}}h`
