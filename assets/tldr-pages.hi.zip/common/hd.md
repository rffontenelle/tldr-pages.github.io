# hd

> यह आदेश `hexdump` का उपनाम है।
> अधिक जानकारी: <https://manned.org/hd.1>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr hexdump`
