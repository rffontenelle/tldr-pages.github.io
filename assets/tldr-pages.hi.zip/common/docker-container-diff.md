# docker-container-diff

> यह आदेश `docker diff` का उपनाम है।
> अधिक जानकारी: <https://docs.docker.com/engine/reference/commandline/diff>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker diff`
