# arch

> सिस्टम आर्किटेक्चर का नाम प्रदर्शित करें।
> `uname` भी देखें।
> अधिक जानकारी: <https://www.gnu.org/software/coreutils/arch>।

- सिस्टम आर्किटेक्चर प्रदर्शित करें:

`arch`
