# lima

> यह आदेश `limactl` का उपनाम है।
> अधिक जानकारी: <https://github.com/lima-vm/lima>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr limactl`
