# false

> 1 का एग्जिट कोड लौटाता है।
> अधिक जानकारी: <https://www.gnu.org/software/coreutils/false>।

- 1 का निकास कोड लौटाएँ:

`false`
