# platformio

> यह आदेश `pio` का उपनाम है।
> अधिक जानकारी: <https://docs.platformio.org/en/latest/core/userguide/>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr pio`
