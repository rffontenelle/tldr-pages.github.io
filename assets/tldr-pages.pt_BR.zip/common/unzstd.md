# unzstd

> Este comando é um pseudônimo de `zstd`.

- Ver documentação sobre o comando original:

`tldr zstd`
