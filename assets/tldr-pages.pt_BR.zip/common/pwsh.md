# pwsh

> Este comando é um pseudônimo de `powershell`.

- Ver documentação sobre o comando original:

`tldr powershell`
