# llvm-strings

> Este comando é um pseudônimo de `strings`.

- Ver documentação sobre o comando original:

`tldr strings`
