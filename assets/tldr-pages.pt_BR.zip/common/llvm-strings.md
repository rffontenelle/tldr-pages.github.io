# llvm-strings

> Este comando é um pseudônimo de `strings`.

- Exibe documentação sobre o comando original:

`tldr strings`
