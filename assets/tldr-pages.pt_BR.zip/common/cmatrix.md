# cmatrix

> Exibe um padrão semelhante à Matrix rolando na tela do terminal.
> Mais informações: <https://github.com/abishekvashok/cmatrix>.

- Habilita rolagem assincrona:

`cmatrix -a`

- Exibe texto em vermelho:

`cmatrix -C {{red}}`

- Habilita modo arco-iris:

`cmatrix -r`

- Determina um atraso de 2 centisegundos (20 milisegundos) na atualização da tela:

`cmatrix -u {{2}}`
