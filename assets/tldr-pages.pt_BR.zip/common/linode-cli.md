# linode-cli

> Este comando é um pseudônimo de `linode-cli account`.
> Mais informações: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Ver documentação sobre o comando original:

`tldr linode-cli account`
