# clang-cpp

> Este comando é um pseudônimo de `clang++`.

- Exibe documentação sobre o comando original:

`tldr clang++`
