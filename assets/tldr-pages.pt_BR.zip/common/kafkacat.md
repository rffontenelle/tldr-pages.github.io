# kafkacat

> Este comando é um pseudônimo de `kcat`.

- Exibe documentação sobre o comando original:

`tldr kcat`
