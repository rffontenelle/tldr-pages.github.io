# mscore

> Este comando é um pseudônimo de `musescore`.
> Mais informações: <https://musescore.org/handbook/command-line-options>.

- Ver documentação sobre o comando original:

`tldr musescore`
