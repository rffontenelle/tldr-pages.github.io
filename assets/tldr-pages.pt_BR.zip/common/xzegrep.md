# xzegrep

> Este comando é um pseudônimo de `xzgrep`.

- Ver documentação sobre o comando original:

`tldr xzgrep`
