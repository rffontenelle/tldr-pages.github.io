# llvm-nm

> Este comando é um pseudônimo de `nm`.

- Exibe documentação sobre o comando original:

`tldr nm`
