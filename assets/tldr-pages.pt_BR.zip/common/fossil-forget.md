# fossil-forget

> Este comando é um pseudônimo de `fossil rm`.
> Mais informações: <https://fossil-scm.org/home/help/forget>.

- Ver documentação sobre o comando original:

`tldr fossil rm`
