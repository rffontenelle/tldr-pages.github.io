# fossil forget

> Este comando é um apelido de `fossil rm`.
> Mais informações: <https://fossil-scm.org/home/help/forget>.

- Exibe documentação sobre o comando original:

`tldr fossil rm`
