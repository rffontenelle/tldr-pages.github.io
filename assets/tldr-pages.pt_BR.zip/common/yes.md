# yes

> Exibe algo na tela repetidamente.
> Mais informações: <https://www.gnu.org/software/coreutils/yes>.

- Exibir na tela a palavra "mensagem" repetidamente:

`yes {{mensagem}}`

- Exibir na tela a letra "y" repetidamente:

`yes`
