# bundler

> Este comando é um pseudônimo de `bundle`.
> Mais informações: <https://bundler.io/man/bundle.1.html>.

- Exibe documentação sobre o comando original:

`tldr bundle`
