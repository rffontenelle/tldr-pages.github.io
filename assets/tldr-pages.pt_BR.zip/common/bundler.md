# bundler

> Este comando é um pseudônimo de `bundle`.
> Mais informações: <https://bundler.io/man/bundle.1.html>.

- Ver documentação sobre o comando original:

`tldr bundle`
