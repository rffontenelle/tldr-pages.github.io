# fc

> Abre o último comando executado em um editor de texto.
> Mais informações: <https://manned.org/fc>.

- Abre o último comando executado no editor de texto padrão do sistema:

`fc`

- Especifica o editor de texto que será utilizado ao executar o comando:

`fc -e {{'emacs'}}`

- Exibe um histórico dos últimos comandos executados:

`fc -l`
