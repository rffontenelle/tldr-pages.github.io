# musl-gcc

> Este comando é um pseudônimo de `gcc`.
> Mais informações: <https://manned.org/musl-gcc>.

- Ver documentação sobre o comando original:

`tldr gcc`
