# lzcat

> Este comando é um apelido de `xz`.
> Mais informações: <https://manned.org/lzcat>.

- Exibe documentação sobre o comando original:

`tldr xz`
