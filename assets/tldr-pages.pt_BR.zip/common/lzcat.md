# lzcat

> Este comando é um pseudônimo de `xz`.
> Mais informações: <https://manned.org/lzcat>.

- Ver documentação sobre o comando original:

`tldr xz`
