# lzma

> Este comando é um apelido de `xz`.
> Mais informações: <https://manned.org/lzma>.

- Exibe documentação sobre o comando original:

`tldr xz`
