# gh-cs

> Este comando é um pseudônimo de `gh-codespace`.
> Mais informações: <https://cli.github.com/manual/gh_codespace>.

- Ver documentação sobre o comando original:

`tldr gh-codespace`
