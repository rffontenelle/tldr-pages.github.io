# piodebuggdb

> Este comando é um pseudônimo de `pio debug`.

- Ver documentação sobre o comando original:

`tldr pio debug`
