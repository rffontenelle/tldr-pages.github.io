# piodebuggdb

> Este comando é um pseudônimo de `pio debug`.

- Exibe documentação sobre o comando original:

`tldr pio debug`
