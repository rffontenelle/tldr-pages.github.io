# fossil-delete

> Este comando é um apelido de `fossil rm`.
> Mais informações: <https://fossil-scm.org/home/help/delete>.

- Exibe documentação sobre o comando original:

`tldr fossil rm`
