# fossil-delete

> Este comando é um pseudônimo de `fossil rm`.
> Mais informações: <https://fossil-scm.org/home/help/delete>.

- Ver documentação sobre o comando original:

`tldr fossil rm`
