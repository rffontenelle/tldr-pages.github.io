# llvm-ar

> Este comando é um pseudônimo de `ar`.

- Exibe documentação sobre o comando original:

`tldr ar`
