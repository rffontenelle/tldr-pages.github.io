# llvm-ar

> Este comando é um apelido de `ar`.

- Exibe documentação sobre o comando original:

`tldr ar`
