# just

> Este comando é um pseudônimo de `just.1`.

- Ver documentação sobre o comando original:

`tldr just.1`
