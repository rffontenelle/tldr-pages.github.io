# rcat

> Este comando é um pseudônimo de `rc`.

- Ver documentação sobre o comando original:

`tldr rc`
