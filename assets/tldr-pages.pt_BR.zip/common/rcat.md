# rcat

> Este comando é um apelido de `rc`.

- Exibe documentação sobre o comando original:

`tldr rc`
