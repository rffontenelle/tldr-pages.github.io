# fossil-new

> Este comando é um pseudônimo de `fossil-init`.
> Mais informações: <https://fossil-scm.org/home/help/new>.

- Ver documentação sobre o comando original:

`tldr fossil-init`
