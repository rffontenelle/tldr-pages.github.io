# fossil new

> Este comando é um apelido de  `fossil init`.
> Mais informações: <https://fossil-scm.org/home/help/new>.

- Exibe documentação sobre o comando original:

`tldr fossil-init`
