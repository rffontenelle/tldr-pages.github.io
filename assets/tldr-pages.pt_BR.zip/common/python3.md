# python3

> Este comando é um pseudônimo de `python`.

- Exibe documentação sobre o comando original:

`tldr python`
