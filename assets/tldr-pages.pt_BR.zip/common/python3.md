# python3

> Este comando é um pseudônimo de `python`.

- Ver documentação sobre o comando original:

`tldr python`
