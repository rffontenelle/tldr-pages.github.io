# sl

> Locomotiva a vapor passando pelo seu terminal.
> Mais informações: <https://github.com/mtoyoda/sl>.

- Faz uma locomotiva a vapor passar pelo seu terminal:

`sl`

- O trem pega fogo e pessoas gritam:

`sl -a`

- Faz o trem voar:

`sl -F`

- Faz o trem pequeno:

`sl -l`

- Deixa o usuário sair (CTRL + C):

`sl -e`
