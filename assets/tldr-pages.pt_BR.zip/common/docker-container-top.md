# docker-container-top

> Este comando é um pseudônimo de `docker top`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/top>.

- Ver documentação sobre o comando original:

`tldr docker top`
