# llvm-objdump

> Este comando é um pseudônimo de `objdump`.

- Exibe documentação sobre o comando original:

`tldr objdump`
