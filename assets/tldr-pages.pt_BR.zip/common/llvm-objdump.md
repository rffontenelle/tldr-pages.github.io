# llvm-objdump

> Este comando é um pseudônimo de `objdump`.

- Ver documentação sobre o comando original:

`tldr objdump`
