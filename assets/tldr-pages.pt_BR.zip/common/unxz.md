# unxz

> Este comando é um pseudônimo de `xz`.
> Mais informações: <https://manned.org/unxz>.

- Exibe documentação sobre o comando original:

`tldr xz`
