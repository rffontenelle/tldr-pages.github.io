# lima

> Este comando é um pseudônimo de `limactl`.
> Mais informações: <https://github.com/lima-vm/lima>.

- Ver documentação sobre o comando original:

`tldr limactl`
