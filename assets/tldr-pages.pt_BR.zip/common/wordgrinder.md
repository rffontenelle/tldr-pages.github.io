# wordgrinder

> Processador de texto em linha de comando.
> Mais informações: <https://cowlark.com/wordgrinder>.

- Iniciar o wordgrinder (carrega um documento vazio por padrão):

`wordgrinder`

- Abrir um arquivo específico:

`wordgrinder {{nome_do_arquivo}}`

- Mostrar o menu:

`Alt + M`
