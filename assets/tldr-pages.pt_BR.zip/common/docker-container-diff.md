# docker-container-diff

> Este comando é um pseudônimo de `docker diff`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/diff>.

- Ver documentação sobre o comando original:

`tldr docker diff`
