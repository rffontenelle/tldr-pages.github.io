# vi

> Este comando é um pseudônimo de `vim`.

- Exibe documentação sobre o comando original:

`tldr vim`
