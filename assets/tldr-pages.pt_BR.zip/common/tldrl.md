# tldrl

> Este comando é um pseudônimo de `tldr-lint`.
> Mais informações: <https://github.com/tldr-pages/tldr-lint>.

- Ver documentação sobre o comando original:

`tldr tldr-lint`
