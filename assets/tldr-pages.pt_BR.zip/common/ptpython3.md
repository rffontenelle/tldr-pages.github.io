# ptpython3

> Este comando é um pseudônimo de `ptpython`.

- Ver documentação sobre o comando original:

`tldr ptpython`
