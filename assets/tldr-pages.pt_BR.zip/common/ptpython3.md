# ptpython3

> Este comando é um pseudônimo de `ptpython`.

- Exibe documentação sobre o comando original:

`tldr ptpython`
