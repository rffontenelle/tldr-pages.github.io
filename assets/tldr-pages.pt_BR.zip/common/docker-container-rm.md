# docker-container-rm

> Este comando é um pseudônimo de `docker rm`.
> Mais informações: <https://docs.docker.com/engine/reference/commandline/rm>.

- Ver documentação sobre o comando original:

`tldr docker rm`
