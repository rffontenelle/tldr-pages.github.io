# hd

> Este comando é um pseudônimo de `hexdump`.
> Mais informações: <https://manned.org/hd.1>.

- Ver documentação sobre o comando original:

`tldr hexdump`
