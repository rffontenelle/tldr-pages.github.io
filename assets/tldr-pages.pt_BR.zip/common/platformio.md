# platformio

> Este comando é um pseudônimo de `pio`.
> Mais informações: <https://docs.platformio.org/en/latest/core/userguide/>.

- Ver documentação sobre o comando original:

`tldr pio`
