# lzmore

> Este comando é um pseudônimo de `xzmore`.

- Ver documentação sobre o comando original:

`tldr xzmore`
