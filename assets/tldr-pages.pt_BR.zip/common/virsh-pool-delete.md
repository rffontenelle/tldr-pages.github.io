# virsh pool-delete

> Exclui o sistema de armazenamento subjacente de um pool de armazenamento de máquina virtual inativo.
> Veja também: `virsh`, `virsh-pool-destroy`, `virsh-pool-undefine`.
> Mais informações: <https://manned.org/virsh>.

- Exclui o sistema de armazenamento subjacente para o pool de armazenamento especificado pelo nome ou UUID (determinado usando `virsh pool-list`):

`virsh pool-delete --pool {{nome|uuid}}`
