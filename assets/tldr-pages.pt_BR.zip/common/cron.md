# cron

> Este comando é um pseudônimo de `crontab`.

- Exibe documentação sobre o comando original:

`tldr crontab`
