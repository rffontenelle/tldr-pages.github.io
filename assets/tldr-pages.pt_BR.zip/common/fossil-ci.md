# fossil-ci

> Este comando é um pseudônimo de `fossil-commit`.
> Mais informações: <https://fossil-scm.org/home/help/commit>.

- Ver documentação sobre o comando original:

`tldr fossil-commit`
