# ntl

> Este comando é um apelido de `netlify`.
> Mais informações: <https://cli.netlify.com>.

- Exibe documentação sobre o comando original:

`tldr netlify`
