# ntl

> Este comando é um pseudônimo de `netlify`.
> Mais informações: <https://cli.netlify.com>.

- Exibe documentação sobre o comando original:

`tldr netlify`
