# yarn-why

> Identifica por que um pacote Yarn foi instalado.
> Mais informações: <https://github.com/amio/yarn-why>.

- Exibe na tela o motivo de um pacote Yarn estar instalado:

`yarn-why {{nome_do_pacote}}`
