# lzless

> Este comando é um pseudônimo de `xzless`.

- Ver documentação sobre o comando original:

`tldr xzless`
