# open

> Este comando é um pseudônimo de `open -p osx`.

- Ver documentação sobre o comando original:

`tldr open -p osx`
