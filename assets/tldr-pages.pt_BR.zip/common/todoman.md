# todoman

> Este comando é um pseudônimo de `todo`.
> Mais informações: <https://todoman.readthedocs.io/>.

- Exibe documentação sobre o comando original:

`tldr todo`
