# todoman

> Este comando é um apelido de `todo`.
> Mais informações: <https://todoman.readthedocs.io/>.

- Exibe documentação sobre o comando original:

`tldr todo`
