# xzcat

> Este comando é um pseudônimo de `xz`.
> Mais informações: <https://manned.org/xzcat>.

- Exibe documentação sobre o comando original:

`tldr xz`
