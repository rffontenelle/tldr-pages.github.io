# xzcat

> Este comando é um apelido de `xz`.
> Mais informações: <https://manned.org/xzcat>.

- Exibe documentação sobre o comando original:

`tldr xz`
