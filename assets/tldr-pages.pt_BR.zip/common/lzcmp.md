# lzcmp

> Este comando é um pseudônimo de `xzcmp`.

- Ver documentação sobre o comando original:

`tldr xzcmp`
