# tlmgr arch

> Este comando é um apelido de `tlmgr platform`.
> Mais informações: <https://www.tug.org/texlive/tlmgr.html>.

- Exibe documentação sobre o comando original:

`tldr tlmgr platform`
