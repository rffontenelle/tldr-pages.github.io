# tlmgr-arch

> Este comando é um pseudônimo de `tlmgr platform`.
> Mais informações: <https://www.tug.org/texlive/tlmgr.html>.

- Exibe documentação sobre o comando original:

`tldr tlmgr platform`
