# ripgrep

> Este comando é um pseudônimo de `rg`.

- Ver documentação sobre o comando original:

`tldr rg`
