# ripgrep

> Este comando é um apelido de `rg`.

- Exibe documentação sobre o comando original:

`tldr rg`
