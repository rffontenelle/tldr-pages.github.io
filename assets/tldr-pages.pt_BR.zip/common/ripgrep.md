# ripgrep

> Este comando é um pseudônimo de `rg`.

- Exibe documentação sobre o comando original:

`tldr rg`
