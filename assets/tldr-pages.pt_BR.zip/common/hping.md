# hping

> Este comando é um pseudônimo de `hping3`.
> Mais informações: <https://github.com/antirez/hping>.

- Ver documentação sobre o comando original:

`tldr hping3`
