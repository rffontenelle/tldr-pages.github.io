# gnmic-sub

> Este comando é um apelido de `gnmic subscribe`.
> Mais informações: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Exibe documentação sobre o comando original:

`tldr gnmic subscribe`
