# azure-cli

> Este comando é um pseudônimo de `az`.
> Mais informações: <https://learn.microsoft.com/cli/azure>.

- Ver documentação sobre o comando original:

`tldr az`
