# transmission

> Um cliente de torrent simples.
> O Transmission não é um comando, mas um conjunto de comandos. Veja as páginas abaixo.
> Mais informações: <https://transmissionbt.com/>.

- Mostra a página tldr para executar o daemon do Transmission:

`tldr transmission-daemon`

- Mostra a página tldr para interagir com o daemon:

`tldr transmission-remote`

- Mostra a página tldr para criar arquivos torrent:

`tldr transmission-create`

- Mostra a página tldr para modificar arquivos torrent:

`tldr transmission-edit`

- Mostra a página tldr para obter informações sobre arquivos torrent:

`tldr transmission-show`

- Mostra a página tldr para o método descontinuado de interagir com o daemon:

`tldr transmission-cli`
