# transmission

> Este comando é um pseudônimo de `transmission-daemon`.
> Mais informações: <https://transmissionbt.com/>.

- Ver documentação sobre o comando original:

`tldr transmission-daemon`
