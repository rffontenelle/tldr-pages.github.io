# cola

> Este comando é um pseudônimo de `git-cola`.

- Ver documentação sobre o comando original:

`tldr git-cola`
