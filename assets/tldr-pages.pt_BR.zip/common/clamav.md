# ClamAV

> Programa antivírus de código aberto.
> O ClamAV não é um comando, mas um conjunto de comandos.
> Mais informações: <https://www.clamav.net>.

- Mostra a página tldr para escanear arquivos usando o daemon `clamd`:

`tldr clamdscan`

- Mostra a página tldr para escanear arquivos sem o daemon `clamd` em execução:

`tldr clamscan`

- Mostra a página tldr para atualizar as definições de vírus:

`tldr freshclam`
