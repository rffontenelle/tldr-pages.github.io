# clamav

> Este comando é um pseudônimo de `clamdscan`.
> Mais informações: <https://www.clamav.net>.

- Ver documentação sobre o comando original:

`tldr clamdscan`
