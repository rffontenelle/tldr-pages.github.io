# calc

> Calculadora interativa de precisão arbitrária no terminal.
> Mais informações: <https://github.com/lcn2/calc>.

- Iniciar a calculadora em modo interativo:

`calc`

- Realizar o cálculo em modo não interativo:

`calc -p '{{85 * (36 / 4)}}'`
