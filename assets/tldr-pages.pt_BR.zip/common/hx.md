# hx

> Este comando é um pseudônimo de `helix`.

- Ver documentação sobre o comando original:

`tldr helix`
