# google-chrome

> Este comando é um pseudônimo de `chromium`.
> Mais informações: <https://chrome.google.com>.

- Exibe documentação sobre o comando original:

`tldr chromium`
