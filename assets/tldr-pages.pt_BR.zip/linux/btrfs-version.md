# btrfs version

> Exibe a versão do btrfs-progs.
> Mais informações: <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Exibir a versão do btrfs-progs:

`btrfs version`

- Exibir a ajuda:

`btrfs version --help`
