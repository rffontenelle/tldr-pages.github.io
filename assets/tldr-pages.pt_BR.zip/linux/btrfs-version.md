# btrfs version

> Exibe a versão do btrfs-progs.
> Mais informações: <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Exibe a ajuda:

`btrfs version --help`

- Exibe a versão do btrfs-progs:

`btrfs version`
