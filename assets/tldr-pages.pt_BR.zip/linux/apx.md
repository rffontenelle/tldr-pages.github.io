# apx

> Este comando é um pseudônimo de `apx pkgmanagers`.
> Mais informações: <https://github.com/Vanilla-OS/apx>.

- Ver documentação sobre o comando original:

`tldr apx pkgmanagers`
