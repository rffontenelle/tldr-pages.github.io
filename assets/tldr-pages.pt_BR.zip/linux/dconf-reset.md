# dconf reset

> Redefine chaves valores nos bancos de dados dconf.
> Veja também: `dconf`.
> Mais informações: <https://manned.org/dconf>.

- Redefine um valor de chave específico:

`dconf read {{/caminho/para/chave}}`

- Redefine um diretório específico:

`dconf read -d {{/caminho/para/diretório/}}`
