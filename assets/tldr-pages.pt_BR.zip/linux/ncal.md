# ncal

> Este comando é um apelido de `cal`.
> Mais informações: <https://manned.org/ncal>.

- Exibe documentação sobre o comando original:

`tldr cal`
