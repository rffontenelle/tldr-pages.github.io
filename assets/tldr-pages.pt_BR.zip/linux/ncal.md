# ncal

> Este comando é um pseudônimo de `cal`.
> Mais informações: <https://manned.org/ncal>.

- Exibe documentação sobre o comando original:

`tldr cal`
