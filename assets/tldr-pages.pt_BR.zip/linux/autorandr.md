# autorandr

> Altera o layout da tela automaticamente.
> Mais informações: <https://github.com/phillipberndt/autorandr>.

- Salva o layout da tela em uso:

`autorandr -s {{nome_do_perfil}}`

- Exibe os perfis salvos:

`autorandr`

- Altera o perfil:

`autorandr -l {{nome_do_perfil}}`

- Define o perfil padrão:

`autorandr -d {{nome_do_perfil}}`
