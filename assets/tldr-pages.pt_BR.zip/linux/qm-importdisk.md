# qm-importdisk

> Este comando é um pseudônimo de `qm disk import`.

- Ver documentação sobre o comando original:

`tldr qm disk import`
