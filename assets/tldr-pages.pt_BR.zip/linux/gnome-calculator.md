# gnome-calculator

> A calculadora oficial para o ambiente de desktop GNOME.
> Mais informações: <https://wiki.gnome.org/Apps/Calculator>.

- Inicia a GNOME Calculator GUI:

`gnome-calculator`

- Resolve uma equação específica na linha de comando sem iniciar o aplicativo de desktop:

`gnome-calculator --solve {{2^5 * 2 + 5}}`

- Exibe a versão:

`gnome-calculator --version`
