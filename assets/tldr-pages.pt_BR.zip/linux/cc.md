# cc

> Este comando é um pseudônimo de `gcc`.
> Mais informações: <https://gcc.gnu.org>.

- Exibe documentação sobre o comando original:

`tldr gcc`
