# ip6tables-restore

> Este comando é um pseudônimo de `iptables-restore`.

- Ver documentação sobre o comando original:

`tldr iptables-restore`
