# distrobox-list

> Listar todos os contêineres distrobox. Veja também: `tldr distrobox`.
> Os contêineres distrobox são listados separadamente dos demais contêineres normais do Podman ou Docker.
> Mais informações: <https://distrobox.it/usage/distrobox-list>.

- Lista todos os contêineres distrobox:

`distrobox-list`

- Lista todos os contêineres distrobox com informações detalhadas:

`distrobox-list --verbose`
