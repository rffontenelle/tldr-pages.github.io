# a2ensite

> Ativa um host virtual do Apache em sistemas operacionais baseados no Debian.
> Mais informações: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Ativa um host virtual:

`sudo a2ensite {{host_virtual}}`

- Não mostra mensagens informativas:

`sudo a2ensite --quiet {{host_virtual}}`
