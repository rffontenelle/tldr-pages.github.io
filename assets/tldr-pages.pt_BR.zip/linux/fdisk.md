# fdisk

> Gerenciador de tabelas de partições e partições no disco rígido.
> Mais informações: <https://manned.org/fdisk>.

- Exibe as partições:

`fdisk -l`

- Inicia o manipulador de partições:

`fdisk {{/dev/sda}}`
