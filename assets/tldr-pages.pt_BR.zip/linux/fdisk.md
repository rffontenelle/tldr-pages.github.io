# fdisk

> Gerenciador de tabelas de partições e partições no disco rígido.
> Mais informações: <https://manned.org/fdisk>.

- Exibir as partições:

`fdisk -l`

- Iniciar o manipulador de partições:

`fdisk {{/dev/sda}}`
