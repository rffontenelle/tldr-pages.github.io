# batcat

> Este comando é um pseudônimo de `bat`.
> Mais informações: <https://github.com/sharkdp/bat>.

- Ver documentação sobre o comando original:

`tldr bat`
