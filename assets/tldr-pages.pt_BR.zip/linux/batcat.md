# batcat

> Este comando é um apelido de `bat`.
> Mais informações: <https://github.com/sharkdp/bat>.

- Exibe documentação sobre o comando original:

`tldr bat`
