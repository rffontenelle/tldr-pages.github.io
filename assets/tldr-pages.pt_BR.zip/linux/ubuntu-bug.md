# ubuntu-bug

> Este comando é um pseudônimo de `apport-bug`.
> Mais informações: <https://manned.org/ubuntu-bug>.

- Exibe documentação sobre o comando original:

`tldr apport-bug`
