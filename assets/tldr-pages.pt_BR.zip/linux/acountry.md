# acountry

> Imprime o país onde um endereço IPv4 ou nome do servidor estão localizados.
> Mais informações: <https://manned.org/acountry>.

- Imprime um país onde um endereço IPv4 ou host está localizado:

`acountry {{examplo.com}}`

- Imprime uma saída de [d]epuração extra:

`acountry -d {{examplo.com}}`

- Imprime informações mais [v]erbosas:

`acountry -v {{examplo.com}}`
