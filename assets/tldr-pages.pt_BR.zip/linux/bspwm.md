# bspwm

> Este comando é um apelido de `bspc`.
> Mais informações: <https://github.com/baskerville/bspwm>.

- Exibe documentação sobre o comando original:

`tldr bspc`
