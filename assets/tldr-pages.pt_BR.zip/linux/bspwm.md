# bspwm

> Este comando é um pseudônimo de `bspc`.
> Mais informações: <https://github.com/baskerville/bspwm>.

- Exibe documentação sobre o comando original:

`tldr bspc`
