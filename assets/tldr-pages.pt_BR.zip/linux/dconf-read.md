# dconf read

> Lê valores de chave dos bancos de dados dconf.
> Veja também: `dconf`.
> Mais informações: <https://manned.org/dconf>.

- Imprime um valor de chave específico:

`dconf read {{/caminho/para/chave}}`

- Imprime o valor padrão de uma chave específica:

`dconf read -d {{/caminho/para/chave}}`
