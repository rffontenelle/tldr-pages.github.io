# cgroups

> Este comando é um pseudônimo de `cgclassify`.
> Mais informações: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Ver documentação sobre o comando original:

`tldr cgclassify`
