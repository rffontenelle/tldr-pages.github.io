# nmtui-hostname

> Este comando é um pseudônimo de `nmtui`.

- Ver documentação sobre o comando original:

`tldr nmtui`
