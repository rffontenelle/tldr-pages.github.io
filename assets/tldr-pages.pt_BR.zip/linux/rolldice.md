# rolldice

> Rola dados virtuais.
> Mais informações: <https://manned.org/rolldice>.

- Rola um dado de 20 lados:

`rolldice d{{20}}`

- Rola dois dados de seis lados e descarta o menor valor:

`rolldice {{2}}d{{6}}s{{1}}`

- Rola dois dados de vite lados e adiciona um modificador ao resultado:

`rolldice {{2}}d{{20}}{{+5}}`

- Rola um dado de vinte lados duas vezes:

`rolldice {{2}}xd{{20}}`
