# alternatives

> Este comando é um pseudônimo de `update-alternatives`.
> Mais informações: <https://manned.org/alternatives>.

- Ver documentação sobre o comando original:

`tldr update-alternatives`
