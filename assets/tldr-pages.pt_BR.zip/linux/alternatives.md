# alternatives

> Este comando é um pseudônimo de `update-alternatives`.
> Mais informações: <https://manned.org/alternatives>.

- Exibe documentação sobre o comando original:

`tldr update-alternatives`
