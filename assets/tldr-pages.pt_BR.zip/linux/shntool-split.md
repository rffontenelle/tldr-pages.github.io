# shntool-split

> Este comando é um pseudônimo de `shnsplit`.

- Ver documentação sobre o comando original:

`tldr shnsplit`
