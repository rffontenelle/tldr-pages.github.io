# ip-route-list

> Este comando é um pseudônimo de `ip-route-show`.

- Ver documentação sobre o comando original:

`tldr ip-route-show`
