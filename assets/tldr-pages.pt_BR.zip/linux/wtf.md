# wtf

> Mostra a expansão de acrônimos.
> Mais informações: <https://manned.org/wtf.6>.

- Expande um acrônimo:

`wtf {{IMO}}`

- Especifica um tipo de busca computacional:

`wtf -t {{comp}} {{WWW}}`
