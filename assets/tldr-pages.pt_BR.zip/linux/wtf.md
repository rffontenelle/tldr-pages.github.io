# wtf

> Mostra a expansão de acrônimos.
> Mais informações: <https://manpages.debian.org/latest/bsdgames/wtf.6.en.html>.

- Expande um acrônimo:

`wtf {{IMO}}`

- Especifica um tipo de busca computacional:

`wtf -t {{comp}} {{WWW}}`
