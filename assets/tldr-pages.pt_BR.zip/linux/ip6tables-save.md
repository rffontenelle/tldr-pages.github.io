# ip6tables-save

> Este comando é um pseudônimo de `iptables-save`.

- Ver documentação sobre o comando original:

`tldr iptables-save`
