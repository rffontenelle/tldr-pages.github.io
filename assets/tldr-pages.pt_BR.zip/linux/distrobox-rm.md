# distrobox-rm

> Remover um contêiner distrobox.
> Subcomando de `distrobox`. Veja também: `tldr distrobox`.
> Mais informações: <https://distrobox.privatedns.org/usage/distrobox-rm.html>.

- Remover um contêiner distrobox (Dica: Pare o contêiner antes de removê-lo):

`distrobox-rm {{nome_do_contêiner}}`

- Remover um contêiner distrobox forçadamente:

`distrobox-rm {{nome_do_contêiner}} --force`
