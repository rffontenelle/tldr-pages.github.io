# wm

> Exibe informações da tela de um dispositivo Android.
> Esse comando só pode ser usado através de `adb shell`.
> Mais informações: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Mostra o tamanho da tela de um dispositivo Android:

`wm size`

- Mostra a densidade de pixels da tela de um dispositivo Android:

`wm density`
