# cpush

> Este comando é um pseudônimo de `choco-push`.
> Mais informações: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Exibe documentação sobre o comando original:

`tldr choco-push`
