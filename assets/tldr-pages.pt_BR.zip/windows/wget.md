# wget

> Este comando é um pseudônimo de `wget -p common`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Ver documentação sobre o comando original:

`tldr wget -p common`
