# wget

> Este comando é um pseudônimo de `wget -p common`.
> Mais informações: <https://www.gnu.org/software/wget>.

- Ver documentação sobre o comando original:

`tldr wget -p common`
