# sls

> Este comando é um pseudônimo de `where-object`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Ver documentação sobre o comando original:

`tldr where-object`
