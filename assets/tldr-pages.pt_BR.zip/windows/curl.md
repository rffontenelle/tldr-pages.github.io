# curl

> Este comando é um apelido de `curl -p common`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Exibe documentação sobre o comando original:

`tldr curl -p common`
