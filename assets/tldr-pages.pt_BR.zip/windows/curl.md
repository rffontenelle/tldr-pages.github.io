# curl

> Este comando é um pseudônimo de `curl -p common`.
> Mais informações: <https://curl.se>.

- Ver documentação sobre o comando original:

`tldr curl -p common`
