# curl

> Este comando é um pseudônimo de `curl -p common`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Ver documentação sobre o comando original:

`tldr curl -p common`
