# cuninst

> Este comando é um pseudônimo de `choco uninstall`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Ver documentação sobre o comando original:

`tldr choco uninstall`
