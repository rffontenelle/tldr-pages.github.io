# slmgr

> Este comando é um pseudônimo de `slmgr.vbs`.
> Mais informações: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Ver documentação sobre o comando original:

`tldr slmgr.vbs`
