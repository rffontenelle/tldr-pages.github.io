# chdir

> Este comando é um pseudônimo de `cd`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Ver documentação sobre o comando original:

`tldr cd`
