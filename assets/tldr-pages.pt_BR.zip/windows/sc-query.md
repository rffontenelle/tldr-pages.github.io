# sc-query

> Este comando é um pseudônimo de `sc`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Ver documentação sobre o comando original:

`tldr sc`
