# sl

> Este comando é um pseudônimo de `set-location`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Ver documentação sobre o comando original:

`tldr set-location`
