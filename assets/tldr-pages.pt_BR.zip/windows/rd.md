# rd

> Este comando é um pseudônimo de `rmdir`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Ver documentação sobre o comando original:

`tldr rmdir`
