# rd

> Este comando é um apelido de `rmdir` no Prompt de Comando e, subsequentemente, `Remove-Item` em PowerShell.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Exibe documentação sobre o comando original do Prompt de Comando:

`tldr rmdir`

- Exibe documentação sobre o comando original do PowerShell:

`tldr remove-item`
