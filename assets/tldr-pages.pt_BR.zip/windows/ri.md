# ri

> Este comando é um pseudônimo de `remove-item`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Ver documentação sobre o comando original:

`tldr remove-item`
