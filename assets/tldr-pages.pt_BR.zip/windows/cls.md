# cls

> Limpar a tela de saída.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Limpa a tela:

`cls`
