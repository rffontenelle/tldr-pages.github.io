# gal

> Este comando é um pseudônimo de `get-alias`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Ver documentação sobre o comando original:

`tldr get-alias`
