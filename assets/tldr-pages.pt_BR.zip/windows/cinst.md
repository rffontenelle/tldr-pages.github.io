# cinst

> Este comando é um apelido de `choco install`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Exibe documentação sobre o comando original:

`tldr choco install`
