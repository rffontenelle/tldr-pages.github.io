# cinst

> Este comando é um pseudônimo de `choco install`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Exibe documentação sobre o comando original:

`tldr choco install`
