# title

> Exibe o título do prompt de comando.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/title>.

- Define o título do prompt de comando:

`title {{novo_título}}`
