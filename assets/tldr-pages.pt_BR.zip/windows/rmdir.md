# rmdir

> Este comando é um pseudônimo de `remove-item`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/rmdir>.

- Ver documentação sobre o comando original:

`tldr remove-item`
