# pwsh where

> Este comando é um apelido de `Where-Object`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Exibe documentação sobre o comando original:

`tldr Where-Object`
