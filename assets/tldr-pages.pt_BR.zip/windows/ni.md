# ni

> Este comando é um pseudônimo de `new-item`.
> Mais informações: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Ver documentação sobre o comando original:

`tldr new-item`
