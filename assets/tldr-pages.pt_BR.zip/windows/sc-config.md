# sc-config

> Este comando é um pseudônimo de `sc`.
> Mais informações: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Ver documentação sobre o comando original:

`tldr sc`
