# clist

> Este comando é um apelido de `choco list`.
> Mais informações: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Exibe documentação sobre o comando original:

`tldr choco list`
