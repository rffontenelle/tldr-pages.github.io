# gxargs

> Este comando é um pseudônimo de `-p linux xargs`.

- Ver documentação sobre o comando original:

`tldr -p linux xargs`
