# airportd

> Gerencia interfaces sem fio.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/airportd/>.

- Inicia o daemon:

`airportd`
