# airportd

> Gerencia interfaces sem fio.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/airportd.8.html>.

- Inicia o daemon:

`airportd`
