# gsha256sum

> Este comando é um pseudônimo de `-p linux sha256sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux sha256sum`
