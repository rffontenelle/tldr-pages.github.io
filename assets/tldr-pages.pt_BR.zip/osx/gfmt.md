# gfmt

> Este comando é um apelido de `-p linux fmt`.

- Exibe documentação sobre o comando original:

`tldr -p linux fmt`
