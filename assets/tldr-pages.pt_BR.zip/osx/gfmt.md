# gfmt

> Este comando é um pseudônimo de `-p linux fmt`.

- Exibe documentação sobre o comando original:

`tldr -p linux fmt`
