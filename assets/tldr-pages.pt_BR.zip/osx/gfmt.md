# gfmt

> Este comando é um pseudônimo de `-p linux fmt`.

- Ver documentação sobre o comando original:

`tldr -p linux fmt`
