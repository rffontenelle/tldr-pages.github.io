# gseq

> Este comando é um pseudônimo de `-p linux seq`.

- Ver documentação sobre o comando original:

`tldr -p linux seq`
