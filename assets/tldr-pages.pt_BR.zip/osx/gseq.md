# gseq

> Este comando é um apelido de `-p linux seq`.

- Exibe documentação sobre o comando original:

`tldr -p linux seq`
