# gdate

> Este comando é um pseudônimo de `-p linux date`.

- Ver documentação sobre o comando original:

`tldr -p linux date`
