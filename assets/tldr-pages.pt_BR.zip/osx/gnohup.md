# gnohup

> Este comando é um pseudônimo de `-p linux nohup`.

- Ver documentação sobre o comando original:

`tldr -p linux nohup`
