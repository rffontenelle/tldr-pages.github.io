# gnohup

> Este comando é um pseudônimo de `-p linux nohup`.

- Exibe documentação sobre o comando original:

`tldr -p linux nohup`
