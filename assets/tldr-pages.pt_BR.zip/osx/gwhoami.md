# gwhoami

> Este comando é um pseudônimo de `-p linux whoami`.

- Ver documentação sobre o comando original:

`tldr -p linux whoami`
