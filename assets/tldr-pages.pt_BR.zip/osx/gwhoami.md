# gwhoami

> Este comando é um pseudônimo de `-p linux whoami`.

- Exibe documentação sobre o comando original:

`tldr -p linux whoami`
