# glibtool

> Este comando é um pseudônimo de `-p linux libtool`.

- Ver documentação sobre o comando original:

`tldr -p linux libtool`
