# gchmod

> Este comando é um pseudônimo de `-p linux chmod`.

- Ver documentação sobre o comando original:

`tldr -p linux chmod`
