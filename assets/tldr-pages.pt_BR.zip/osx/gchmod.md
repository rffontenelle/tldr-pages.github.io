# gchmod

> Este comando é um pseudônimo de `-p linux chmod`.

- Exibe documentação sobre o comando original:

`tldr -p linux chmod`
