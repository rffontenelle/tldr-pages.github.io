# gdf

> Este comando é um apelido de `-p linux df`.

- Exibe documentação sobre o comando original:

`tldr -p linux df`
