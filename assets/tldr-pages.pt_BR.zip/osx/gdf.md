# gdf

> Este comando é um pseudônimo de `-p linux df`.

- Ver documentação sobre o comando original:

`tldr -p linux df`
