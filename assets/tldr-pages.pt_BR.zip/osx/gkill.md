# gkill

> Este comando é um pseudônimo de `-p linux kill`.

- Exibe documentação sobre o comando original:

`tldr -p linux kill`
