# gkill

> Este comando é um apelido de `-p linux kill`.

- Exibe documentação sobre o comando original:

`tldr -p linux kill`
