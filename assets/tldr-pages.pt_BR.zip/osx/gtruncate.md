# gtruncate

> Este comando é um pseudônimo de `-p linux truncate`.

- Ver documentação sobre o comando original:

`tldr -p linux truncate`
