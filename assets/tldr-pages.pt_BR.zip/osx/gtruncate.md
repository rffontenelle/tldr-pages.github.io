# gtruncate

> Este comando é um pseudônimo de `-p linux truncate`.

- Exibe documentação sobre o comando original:

`tldr -p linux truncate`
