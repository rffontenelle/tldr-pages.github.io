# gsort

> Este comando é um pseudônimo de `-p linux sort`.

- Ver documentação sobre o comando original:

`tldr -p linux sort`
