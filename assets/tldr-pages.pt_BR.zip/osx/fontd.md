# fontd

> Disponibiliza fontes para o sistema.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/fontd/>.

- Inicia o daemon:

`fontd`
