# gprintenv

> Este comando é um pseudônimo de `-p linux printenv`.

- Exibe documentação sobre o comando original:

`tldr -p linux printenv`
