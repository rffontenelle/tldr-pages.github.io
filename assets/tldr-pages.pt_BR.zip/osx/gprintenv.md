# gprintenv

> Este comando é um pseudônimo de `-p linux printenv`.

- Ver documentação sobre o comando original:

`tldr -p linux printenv`
