# gstat

> Este comando é um pseudônimo de `-p linux stat`.

- Ver documentação sobre o comando original:

`tldr -p linux stat`
