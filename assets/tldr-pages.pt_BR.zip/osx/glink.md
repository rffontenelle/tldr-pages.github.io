# glink

> Este comando é um pseudônimo de `-p linux link`.

- Ver documentação sobre o comando original:

`tldr -p linux link`
