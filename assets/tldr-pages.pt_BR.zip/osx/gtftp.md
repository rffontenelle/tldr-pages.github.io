# gtftp

> Este comando é um pseudônimo de `-p linux tftp`.

- Exibe documentação sobre o comando original:

`tldr -p linux tftp`
