# gtftp

> Este comando é um pseudônimo de `-p linux tftp`.

- Ver documentação sobre o comando original:

`tldr -p linux tftp`
