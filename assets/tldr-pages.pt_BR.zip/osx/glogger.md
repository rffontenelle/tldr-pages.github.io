# glogger

> Este comando é um apelido de `-p linux logger`.

- Exibe documentação sobre o comando original:

`tldr -p linux logger`
