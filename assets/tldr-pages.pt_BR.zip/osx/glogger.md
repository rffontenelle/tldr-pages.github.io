# glogger

> Este comando é um pseudônimo de `-p linux logger`.

- Exibe documentação sobre o comando original:

`tldr -p linux logger`
