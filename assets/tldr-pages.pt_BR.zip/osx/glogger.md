# glogger

> Este comando é um pseudônimo de `-p linux logger`.

- Ver documentação sobre o comando original:

`tldr -p linux logger`
