# gcksum

> Este comando é um pseudônimo de `-p linux cksum`.

- Exibe documentação sobre o comando original:

`tldr -p linux cksum`
