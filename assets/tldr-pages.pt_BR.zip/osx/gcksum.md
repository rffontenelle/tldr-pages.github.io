# gcksum

> Este comando é um apelido de `-p linux cksum`.

- Exibe documentação sobre o comando original:

`tldr -p linux cksum`
