# gunexpand

> Este comando é um pseudônimo de `-p linux unexpand`.

- Ver documentação sobre o comando original:

`tldr -p linux unexpand`
