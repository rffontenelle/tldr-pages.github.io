# grmdir

> Este comando é um pseudônimo de `-p linux rmdir`.

- Ver documentação sobre o comando original:

`tldr -p linux rmdir`
