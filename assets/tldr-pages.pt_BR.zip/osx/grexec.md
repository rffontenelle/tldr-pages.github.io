# grexec

> Este comando é um pseudônimo de `-p linux rexec`.

- Ver documentação sobre o comando original:

`tldr -p linux rexec`
