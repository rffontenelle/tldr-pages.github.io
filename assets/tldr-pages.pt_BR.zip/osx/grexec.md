# grexec

> Este comando é um pseudônimo de `-p linux rexec`.

- Exibe documentação sobre o comando original:

`tldr -p linux rexec`
