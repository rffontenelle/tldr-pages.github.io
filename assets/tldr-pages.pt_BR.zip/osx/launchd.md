# launchd

> Este comando é um apelido de `launchctl`.
> Mais informações: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Exibe documentação sobre o comando original:

`tldr launchctl`
