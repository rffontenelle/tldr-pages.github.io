# gdircolors

> Este comando é um pseudônimo de `-p linux dircolors`.

- Ver documentação sobre o comando original:

`tldr -p linux dircolors`
