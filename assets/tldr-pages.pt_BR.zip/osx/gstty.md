# gstty

> Este comando é um pseudônimo de `-p linux stty`.

- Ver documentação sobre o comando original:

`tldr -p linux stty`
