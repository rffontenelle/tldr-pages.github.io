# gyes

> Este comando é um pseudônimo de `-p linux yes`.

- Ver documentação sobre o comando original:

`tldr -p linux yes`
