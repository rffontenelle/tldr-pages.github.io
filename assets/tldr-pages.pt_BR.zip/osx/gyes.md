# gyes

> Este comando é um pseudônimo de `-p linux yes`.

- Exibe documentação sobre o comando original:

`tldr -p linux yes`
