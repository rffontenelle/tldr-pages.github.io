# InternetSharing

> Configura o Compartilhamento de Internet.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/InternetSharing/>.

- Inicia o daemon:

`InternetSharing`
