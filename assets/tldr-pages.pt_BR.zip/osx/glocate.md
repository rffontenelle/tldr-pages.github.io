# glocate

> Este comando é um pseudônimo de `-p linux locate`.

- Ver documentação sobre o comando original:

`tldr -p linux locate`
