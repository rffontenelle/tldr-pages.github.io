# gpwd

> Este comando é um pseudônimo de `-p linux pwd`.

- Exibe documentação sobre o comando original:

`tldr -p linux pwd`
