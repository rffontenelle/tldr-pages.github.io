# gupdatedb

> Este comando é um pseudônimo de `-p linux updatedb`.

- Exibe documentação sobre o comando original:

`tldr -p linux updatedb`
