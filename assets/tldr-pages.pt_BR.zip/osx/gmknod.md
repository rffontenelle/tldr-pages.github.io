# gmknod

> Este comando é um apelido de `-p linux mknod`.

- Exibe documentação sobre o comando original:

`tldr -p linux mknod`
