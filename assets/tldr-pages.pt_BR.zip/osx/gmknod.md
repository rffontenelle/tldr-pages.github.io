# gmknod

> Este comando é um pseudônimo de `-p linux mknod`.

- Exibe documentação sobre o comando original:

`tldr -p linux mknod`
