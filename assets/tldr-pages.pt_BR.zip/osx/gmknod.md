# gmknod

> Este comando é um pseudônimo de `-p linux mknod`.

- Ver documentação sobre o comando original:

`tldr -p linux mknod`
