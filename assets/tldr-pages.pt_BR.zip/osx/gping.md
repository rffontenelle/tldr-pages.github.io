# gping

> Este comando é um apelido de `-p linux ping`.

- Exibe documentação sobre o comando original:

`tldr -p linux ping`
