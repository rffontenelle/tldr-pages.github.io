# distnoted

> Fornece serviços de notificação distribuídos.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/distnoted/>.

- Inicia o daemon:

`distnoted`
