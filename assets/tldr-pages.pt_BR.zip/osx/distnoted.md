# distnoted

> Fornece serviços de notificação distribuídos.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/distnoted.8.html>.

- Inicia o daemon:

`distnoted`
