# gbasenc

> Este comando é um pseudônimo de `-p linux basenc`.

- Exibe documentação sobre o comando original:

`tldr -p linux basenc`
