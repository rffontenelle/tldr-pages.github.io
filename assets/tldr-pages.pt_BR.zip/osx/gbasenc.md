# gbasenc

> Este comando é um pseudônimo de `-p linux basenc`.

- Ver documentação sobre o comando original:

`tldr -p linux basenc`
