# gpaste

> Este comando é um pseudônimo de `-p linux paste`.

- Exibe documentação sobre o comando original:

`tldr -p linux paste`
