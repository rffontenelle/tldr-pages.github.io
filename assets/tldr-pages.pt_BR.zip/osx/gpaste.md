# gpaste

> Este comando é um pseudônimo de `-p linux paste`.

- Ver documentação sobre o comando original:

`tldr -p linux paste`
