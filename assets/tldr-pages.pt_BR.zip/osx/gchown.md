# gchown

> Este comando é um pseudônimo de `-p linux chown`.

- Ver documentação sobre o comando original:

`tldr -p linux chown`
