# gchown

> Este comando é um pseudônimo de `-p linux chown`.

- Exibe documentação sobre o comando original:

`tldr -p linux chown`
