# gcomm

> Este comando é um pseudônimo de `-p linux comm`.

- Exibe documentação sobre o comando original:

`tldr -p linux comm`
