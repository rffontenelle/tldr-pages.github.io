# gln

> Este comando é um pseudônimo de `-p linux ln`.

- Ver documentação sobre o comando original:

`tldr -p linux ln`
