# gln

> Este comando é um pseudônimo de `-p linux ln`.

- Exibe documentação sobre o comando original:

`tldr -p linux ln`
