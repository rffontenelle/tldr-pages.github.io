# gnproc

> Este comando é um pseudônimo de `-p linux nproc`.

- Ver documentação sobre o comando original:

`tldr -p linux nproc`
