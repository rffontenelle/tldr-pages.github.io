# gnproc

> Este comando é um pseudônimo de `-p linux nproc`.

- Exibe documentação sobre o comando original:

`tldr -p linux nproc`
