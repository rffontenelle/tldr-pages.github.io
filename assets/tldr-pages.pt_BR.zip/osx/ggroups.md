# ggroups

> Este comando é um apelido de `-p linux groups`.

- Exibe documentação sobre o comando original:

`tldr -p linux groups`
