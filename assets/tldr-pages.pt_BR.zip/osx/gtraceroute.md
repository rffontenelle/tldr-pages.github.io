# gtraceroute

> Este comando é um pseudônimo de `-p linux traceroute`.

- Exibe documentação sobre o comando original:

`tldr -p linux traceroute`
