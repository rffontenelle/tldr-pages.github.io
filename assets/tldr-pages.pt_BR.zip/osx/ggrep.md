# ggrep

> Este comando é um apelido de `-p linux grep`.

- Exibe documentação sobre o comando original:

`tldr -p linux grep`
