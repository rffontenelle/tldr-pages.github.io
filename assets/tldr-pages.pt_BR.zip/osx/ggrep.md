# ggrep

> Este comando é um pseudônimo de `-p linux grep`.

- Exibe documentação sobre o comando original:

`tldr -p linux grep`
