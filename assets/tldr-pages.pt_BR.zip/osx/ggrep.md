# ggrep

> Este comando é um pseudônimo de `-p linux grep`.

- Ver documentação sobre o comando original:

`tldr -p linux grep`
