# gifconfig

> Este comando é um pseudônimo de `-p linux ifconfig`.

- Ver documentação sobre o comando original:

`tldr -p linux ifconfig`
