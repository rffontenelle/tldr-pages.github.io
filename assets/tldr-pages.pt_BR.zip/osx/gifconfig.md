# gifconfig

> Este comando é um pseudônimo de `-p linux ifconfig`.

- Exibe documentação sobre o comando original:

`tldr -p linux ifconfig`
