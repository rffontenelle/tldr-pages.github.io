# gfind

> Este comando é um pseudônimo de `-p linux find`.

- Ver documentação sobre o comando original:

`tldr -p linux find`
