# gfind

> Este comando é um pseudônimo de `-p linux find`.

- Exibe documentação sobre o comando original:

`tldr -p linux find`
