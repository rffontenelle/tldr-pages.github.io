# appsleepd

> Fornece serviços app sleep.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/appsleepd.8.html>.

- Inicia o daemon:

`appsleepd`
