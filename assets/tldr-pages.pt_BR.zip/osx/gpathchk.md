# gpathchk

> Este comando é um pseudônimo de `-p linux pathchk`.

- Ver documentação sobre o comando original:

`tldr -p linux pathchk`
