# gftp

> Este comando é um pseudônimo de `-p linux ftp`.

- Exibe documentação sobre o comando original:

`tldr -p linux ftp`
