# applecamerad

> Gerenciador de câmera.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.theiphonewiki.com/wiki/Services>.

- Iniciar o daemon:

`applecamerad`
