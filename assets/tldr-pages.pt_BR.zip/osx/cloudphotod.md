# cloudphotod

> Sincroniza fotos do iCloud.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/cloudphotosd/>.

- Inicia o daemon:

`cloudphotod`
