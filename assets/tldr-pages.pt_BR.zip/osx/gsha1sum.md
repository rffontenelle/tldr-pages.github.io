# gsha1sum

> Este comando é um pseudônimo de `-p linux sha1sum`.

- Ver documentação sobre o comando original:

`tldr -p linux sha1sum`
