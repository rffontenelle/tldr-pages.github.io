# glibtoolize

> Este comando é um pseudônimo de `-p linux libtoolize`.

- Ver documentação sobre o comando original:

`tldr -p linux libtoolize`
