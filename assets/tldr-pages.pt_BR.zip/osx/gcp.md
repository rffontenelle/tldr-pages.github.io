# gcp

> Este comando é um pseudônimo de `-p linux cp`.

- Exibe documentação sobre o comando original:

`tldr -p linux cp`
