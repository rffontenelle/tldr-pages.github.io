# gtty

> Este comando é um pseudônimo de `-p linux tty`.

- Ver documentação sobre o comando original:

`tldr -p linux tty`
