# grcp

> Este comando é um pseudônimo de `-p linux rcp`.

- Exibe documentação sobre o comando original:

`tldr -p linux rcp`
