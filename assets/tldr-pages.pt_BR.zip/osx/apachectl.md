# apachectl

> Interface de controle do Servidor HTTP Apache para macOS.
> Mais informações: <https://www.unix.com/man-page/osx/8/apachectl/>.

- Iniciar o job launchd `org.apache.httpd`:

`apachectl start`

- Parar o job launchd:

`apachectl stop`

- Parar, e então iniciar o job launchd:

`apachectl restart`
