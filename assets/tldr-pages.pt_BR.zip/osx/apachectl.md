# apachectl

> Interface de controle do Servidor HTTP Apache para macOS.
> Mais informações: <https://www.unix.com/man-page/osx/8/apachectl/>.

- Inicia o job launchd `org.apache.httpd`:

`apachectl start`

- Para o job launchd:

`apachectl stop`

- Para, e então inicia o job launchd:

`apachectl restart`
