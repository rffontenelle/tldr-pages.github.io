# gtar

> Este comando é um apelido de `-p linux tar`.

- Exibe documentação sobre o comando original:

`tldr -p linux tar`
