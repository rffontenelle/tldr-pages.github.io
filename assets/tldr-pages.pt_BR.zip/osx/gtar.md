# gtar

> Este comando é um pseudônimo de `-p linux tar`.

- Ver documentação sobre o comando original:

`tldr -p linux tar`
