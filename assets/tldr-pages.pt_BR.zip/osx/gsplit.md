# gsplit

> Este comando é um pseudônimo de `-p linux split`.

- Exibe documentação sobre o comando original:

`tldr -p linux split`
