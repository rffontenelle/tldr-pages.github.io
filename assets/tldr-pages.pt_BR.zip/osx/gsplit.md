# gsplit

> Este comando é um pseudônimo de `-p linux split`.

- Ver documentação sobre o comando original:

`tldr -p linux split`
