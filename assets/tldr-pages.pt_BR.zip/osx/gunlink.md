# gunlink

> Este comando é um pseudônimo de `-p linux unlink`.

- Ver documentação sobre o comando original:

`tldr -p linux unlink`
