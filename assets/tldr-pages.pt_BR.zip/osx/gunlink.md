# gunlink

> Este comando é um pseudônimo de `-p linux unlink`.

- Exibe documentação sobre o comando original:

`tldr -p linux unlink`
