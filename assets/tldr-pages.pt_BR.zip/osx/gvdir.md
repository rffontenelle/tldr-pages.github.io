# gvdir

> Este comando é um pseudônimo de `-p linux vdir`.

- Exibe documentação sobre o comando original:

`tldr -p linux vdir`
