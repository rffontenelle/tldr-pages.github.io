# filecoordinationd

> Coordena o acesso a arquivos por vários processos (`NSFileCoordinator`, `NSFilePresenter`).
> Não deve ser invocado manualmente.
> Mais informações: <https://www.unix.com/man-page/osx/8/filecoordinationd/>.

- Inicia o daemon:

`filecoordinationd`
