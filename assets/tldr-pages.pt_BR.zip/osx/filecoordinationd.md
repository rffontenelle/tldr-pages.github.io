# filecoordinationd

> Coordena o acesso a arquivos por vários processos (`NSFileCoordinator`, `NSFilePresenter`).
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/filecoordinationd.8.html>.

- Inicia o daemon:

`filecoordinationd`
