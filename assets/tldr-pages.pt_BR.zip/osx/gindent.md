# gindent

> Este comando é um pseudônimo de `-p linux indent`.

- Ver documentação sobre o comando original:

`tldr -p linux indent`
