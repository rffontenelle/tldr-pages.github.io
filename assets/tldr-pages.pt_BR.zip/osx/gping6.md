# gping6

> Este comando é um apelido de `-p linux ping6`.

- Exibe documentação sobre o comando original:

`tldr -p linux ping6`
