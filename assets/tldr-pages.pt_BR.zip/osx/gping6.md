# gping6

> Este comando é um pseudônimo de `-p linux ping6`.

- Ver documentação sobre o comando original:

`tldr -p linux ping6`
