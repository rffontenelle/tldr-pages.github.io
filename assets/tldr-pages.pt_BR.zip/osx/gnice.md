# gnice

> Este comando é um pseudônimo de `-p linux nice`.

- Exibe documentação sobre o comando original:

`tldr -p linux nice`
