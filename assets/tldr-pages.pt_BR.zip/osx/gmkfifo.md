# gmkfifo

> Este comando é um pseudônimo de `-p linux mkfifo`.

- Ver documentação sobre o comando original:

`tldr -p linux mkfifo`
