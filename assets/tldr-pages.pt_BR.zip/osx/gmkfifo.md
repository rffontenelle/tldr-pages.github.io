# gmkfifo

> Este comando é um apelido de `-p linux mkfifo`.

- Exibe documentação sobre o comando original:

`tldr -p linux mkfifo`
