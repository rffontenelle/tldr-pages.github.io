# coreautha

> Um agente de sistema que fornece o framework `LocalAuthentication`.
> Não deve ser invocado manualmente. Veja também: `coreauthd`.
> Mais informações: <https://keith.github.io/xcode-man-pages/coreautha.8.html>.

- Inicia o agente:

`coreautha`
