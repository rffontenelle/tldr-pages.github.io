# coreautha

> Um agente de sistema que fornece o framework `LocalAuthentication`.
> Não deve ser invocado manualmente. Veja também: `coreauthd`.
> Mais informações: <https://www.manpagez.com/man/8/coreautha/>.

- Inicia o agente:

`coreautha`
