# coreauthd

> Um daemon de sistema que fornece o framework `LocalAuthentication`.
> Não deve ser invocado manualmente. Veja também: `coreautha`.
> Mais informações: <https://www.manpagez.com/man/8/coreauthd/>.

- Inicia o daemon:

`coreauthd`
