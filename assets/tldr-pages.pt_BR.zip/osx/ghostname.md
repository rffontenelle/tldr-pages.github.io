# ghostname

> Este comando é um pseudônimo de `-p linux hostname`.

- Ver documentação sobre o comando original:

`tldr -p linux hostname`
