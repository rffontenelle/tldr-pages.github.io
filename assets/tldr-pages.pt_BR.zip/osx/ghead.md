# ghead

> Este comando é um pseudônimo de `-p linux head`.

- Exibe documentação sobre o comando original:

`tldr -p linux head`
