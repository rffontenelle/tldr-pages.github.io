# ghead

> Este comando é um pseudônimo de `-p linux head`.

- Ver documentação sobre o comando original:

`tldr -p linux head`
