# greadlink

> Este comando é um pseudônimo de `-p linux readlink`.

- Ver documentação sobre o comando original:

`tldr -p linux readlink`
