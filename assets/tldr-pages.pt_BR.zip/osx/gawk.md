# gawk

> Este comando é um pseudônimo de `-p linux awk`.

- Exibe documentação sobre o comando original:

`tldr -p linux awk`
