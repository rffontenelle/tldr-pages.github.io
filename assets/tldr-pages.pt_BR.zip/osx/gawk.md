# gawk

> Este comando é um pseudônimo de `-p linux awk`.

- Ver documentação sobre o comando original:

`tldr -p linux awk`
