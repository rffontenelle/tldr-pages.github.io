# grealpath

> Este comando é um pseudônimo de `-p linux realpath`.

- Ver documentação sobre o comando original:

`tldr -p linux realpath`
