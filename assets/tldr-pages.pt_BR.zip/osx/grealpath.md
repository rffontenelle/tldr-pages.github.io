# grealpath

> Este comando é um pseudônimo de `-p linux realpath`.

- Exibe documentação sobre o comando original:

`tldr -p linux realpath`
