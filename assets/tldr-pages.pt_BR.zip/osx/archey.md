# archey

> Ferramenta simples para exibir as informações do sistema com estilo.
> Mais informações: <https://github.com/joshfinnie/archey-osx>.

- Mostrar informações do sistema:

`archey`

- Mostrar informações do sistema sem saída colorida:

`archey --nocolor`

- Mostrar informações do sistema, usando MacPorts em vez de Homebrew:

`archey --macports`

- Mostrar informações do sistema sem verificação de endereço IP:

`archey --offline`
