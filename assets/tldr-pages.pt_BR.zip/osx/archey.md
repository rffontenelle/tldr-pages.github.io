# archey

> Ferramenta simples para exibir as informações do sistema com estilo.
> Mais informações: <https://github.com/joshfinnie/archey-osx>.

- Mostra informações do sistema:

`archey`

- Mostra informações do sistema sem saída colorida:

`archey --nocolor`

- Mostra informações do sistema, usando MacPorts em vez de Homebrew:

`archey --macports`

- Mostra informações do sistema sem verificação de endereço IP:

`archey --offline`
