# gtr

> Este comando é um pseudônimo de `-p linux tr`.

- Ver documentação sobre o comando original:

`tldr -p linux tr`
