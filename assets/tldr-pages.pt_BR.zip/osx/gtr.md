# gtr

> Este comando é um pseudônimo de `-p linux tr`.

- Exibe documentação sobre o comando original:

`tldr -p linux tr`
