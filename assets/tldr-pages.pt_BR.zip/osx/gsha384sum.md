# gsha384sum

> Este comando é um pseudônimo de `-p linux sha384sum`.

- Ver documentação sobre o comando original:

`tldr -p linux sha384sum`
