# gfgrep

> Este comando é um pseudônimo de `-p linux fgrep`.

- Ver documentação sobre o comando original:

`tldr -p linux fgrep`
