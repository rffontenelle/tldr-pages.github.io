# guniq

> Este comando é um pseudônimo de `-p linux uniq`.

- Ver documentação sobre o comando original:

`tldr -p linux uniq`
