# genv

> Este comando é um pseudônimo de `-p linux env`.

- Ver documentação sobre o comando original:

`tldr -p linux env`
