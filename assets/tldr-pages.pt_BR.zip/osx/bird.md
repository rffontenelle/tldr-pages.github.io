# bird

> Suporta a sincronização do iCloud e iCloud Drive.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.unix.com/man-page/mojave/8/bird/>.

- Iniciar o daemon:

`bird`
