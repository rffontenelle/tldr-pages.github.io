# bird

> Suporta a sincronização do iCloud e iCloud Drive.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/bird.8.html>.

- Inicia o daemon:

`bird`
