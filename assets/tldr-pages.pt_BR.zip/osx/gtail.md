# gtail

> Este comando é um pseudônimo de `-p linux tail`.

- Ver documentação sobre o comando original:

`tldr -p linux tail`
