# gtail

> Este comando é um pseudônimo de `-p linux tail`.

- Exibe documentação sobre o comando original:

`tldr -p linux tail`
