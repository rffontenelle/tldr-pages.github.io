# gshuf

> Este comando é um pseudônimo de `-p linux shuf`.

- Exibe documentação sobre o comando original:

`tldr -p linux shuf`
