# gfold

> Este comando é um pseudônimo de `-p linux fold`.

- Ver documentação sobre o comando original:

`tldr -p linux fold`
