# gprintf

> Este comando é um pseudônimo de `-p linux printf`.

- Ver documentação sobre o comando original:

`tldr -p linux printf`
