# gstdbuf

> Este comando é um pseudônimo de `-p linux stdbuf`.

- Ver documentação sobre o comando original:

`tldr -p linux stdbuf`
