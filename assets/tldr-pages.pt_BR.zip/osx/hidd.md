# hidd

> Daemon de nível de usuário da biblioteca HID.
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/hidd.8.html>.

- Inicia o daemon:

`hidd`
