# hidd

> Daemon de nível de usuário da biblioteca HID.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/hidd/>.

- Inicia o daemon:

`hidd`
