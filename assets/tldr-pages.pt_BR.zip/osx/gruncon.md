# gruncon

> Este comando é um apelido de `-p linux runcon`.

- Exibe documentação sobre o comando original:

`tldr -p linux runcon`
