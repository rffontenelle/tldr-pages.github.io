# gruncon

> Este comando é um pseudônimo de `-p linux runcon`.

- Ver documentação sobre o comando original:

`tldr -p linux runcon`
