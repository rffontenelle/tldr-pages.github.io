# gruncon

> Este comando é um pseudônimo de `-p linux runcon`.

- Exibe documentação sobre o comando original:

`tldr -p linux runcon`
