# gtime

> Este comando é um apelido de `-p linux time`.

- Exibe documentação sobre o comando original:

`tldr -p linux time`
