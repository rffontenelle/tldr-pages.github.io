# gtime

> Este comando é um pseudônimo de `-p linux time`.

- Exibe documentação sobre o comando original:

`tldr -p linux time`
