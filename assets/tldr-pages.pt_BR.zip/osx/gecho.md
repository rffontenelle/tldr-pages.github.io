# gecho

> Este comando é um pseudônimo de `-p linux echo`.

- Ver documentação sobre o comando original:

`tldr -p linux echo`
