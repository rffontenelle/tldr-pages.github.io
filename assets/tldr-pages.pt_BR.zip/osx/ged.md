# ged

> Este comando é um pseudônimo de `-p linux ed`.

- Ver documentação sobre o comando original:

`tldr -p linux ed`
