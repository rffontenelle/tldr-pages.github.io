# ged

> Este comando é um pseudônimo de `-p linux ed`.

- Exibe documentação sobre o comando original:

`tldr -p linux ed`
