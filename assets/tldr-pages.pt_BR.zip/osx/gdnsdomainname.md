# gdnsdomainname

> Este comando é um pseudônimo de `-p linux dnsdomainname`.

- Exibe documentação sobre o comando original:

`tldr -p linux dnsdomainname`
