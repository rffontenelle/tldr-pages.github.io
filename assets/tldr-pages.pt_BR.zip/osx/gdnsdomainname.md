# gdnsdomainname

> Este comando é um pseudônimo de `-p linux dnsdomainname`.

- Ver documentação sobre o comando original:

`tldr -p linux dnsdomainname`
