# gchroot

> Este comando é um pseudônimo de `-p linux chroot`.

- Exibe documentação sobre o comando original:

`tldr -p linux chroot`
