# gmv

> Este comando é um pseudônimo de `-p linux mv`.

- Ver documentação sobre o comando original:

`tldr -p linux mv`
