# gbase64

> Este comando é um apelido de `-p linux base64`.

- Exibe documentação sobre o comando original:

`tldr -p linux base64`
