# gbase64

> Este comando é um pseudônimo de `-p linux base64`.

- Ver documentação sobre o comando original:

`tldr -p linux base64`
