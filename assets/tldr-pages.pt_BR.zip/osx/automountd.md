# automountd

> Um daemon de montagem/desmontagem automática para `autofs`. Iniciado sob demanda por `launchd`.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/automountd/>.

- Inicia o daemon:

`automountd`

- Log de mais detalhes em `syslog`:

`automountd -v`
