# gbasename

> Este comando é um pseudônimo de `-p linux basename`.

- Ver documentação sobre o comando original:

`tldr -p linux basename`
