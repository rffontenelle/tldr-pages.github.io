# avbdeviced

> Serviço para gerenciar dispositivos Audio Video Bridging (AVB).
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/1/avbdeviced/>.

- Iniciar o daemon:

`avbdeviced`
