# avbdeviced

> Serviço para gerenciar dispositivos Audio Video Bridging (AVB).
> Não deve ser invocado manualmente.
> Mais informações: <https://keith.github.io/xcode-man-pages/avbdeviced.1.html>.

- Inicia o daemon:

`avbdeviced`
