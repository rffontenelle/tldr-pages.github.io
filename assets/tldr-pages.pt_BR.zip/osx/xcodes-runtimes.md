# xcodes runtimes

> Gerencia runtimes do Simulador Xcode.
> Mais informações: <https://github.com/xcodesorg/xcodes>.

- Lista todos os runtimes do Simulador disponíveis:

`xcodes runtimes --include-betas`

- Baixa um runtime do Simulador:

`xcodes runtimes download {{nome-do-runtime}}`

- Baixa e instala um runtime do Simulador:

`xcodes runtimes install {{nome-do-runtime}}`
