# gchgrp

> Este comando é um pseudônimo de `-p linux chgrp`.

- Exibe documentação sobre o comando original:

`tldr -p linux chgrp`
