# gwhich

> Este comando é um pseudônimo de `-p linux which`.

- Ver documentação sobre o comando original:

`tldr -p linux which`
