# gwhich

> Este comando é um pseudônimo de `-p linux which`.

- Exibe documentação sobre o comando original:

`tldr -p linux which`
