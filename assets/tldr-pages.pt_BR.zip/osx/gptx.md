# gptx

> Este comando é um apelido de `-p linux ptx`.

- Exibe documentação sobre o comando original:

`tldr -p linux ptx`
