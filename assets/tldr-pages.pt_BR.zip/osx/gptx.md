# gptx

> Este comando é um pseudônimo de `-p linux ptx`.

- Exibe documentação sobre o comando original:

`tldr -p linux ptx`
