# gdirname

> Este comando é um apelido de `-p linux dirname`.

- Exibe documentação sobre o comando original:

`tldr -p linux dirname`
