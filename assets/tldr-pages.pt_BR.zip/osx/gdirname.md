# gdirname

> Este comando é um pseudônimo de `-p linux dirname`.

- Exibe documentação sobre o comando original:

`tldr -p linux dirname`
