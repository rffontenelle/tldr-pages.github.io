# gunits

> Este comando é um pseudônimo de `-p linux units`.

- Ver documentação sobre o comando original:

`tldr -p linux units`
