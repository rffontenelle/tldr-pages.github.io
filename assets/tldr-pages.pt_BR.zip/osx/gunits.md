# gunits

> Este comando é um pseudônimo de `-p linux units`.

- Exibe documentação sobre o comando original:

`tldr -p linux units`
