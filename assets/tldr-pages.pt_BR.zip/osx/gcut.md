# gcut

> Este comando é um pseudônimo de `-p linux cut`.

- Exibe documentação sobre o comando original:

`tldr -p linux cut`
