# gcut

> Este comando é um pseudônimo de `-p linux cut`.

- Ver documentação sobre o comando original:

`tldr -p linux cut`
