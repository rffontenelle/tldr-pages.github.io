# deleted

> Acompanha o espaço purgável e solicita que os clientes removam os arquivos quando o espaço estiver baixo.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.manpagez.com/man/8/deleted/>.

- Inicia o daemon:

`deleted`
