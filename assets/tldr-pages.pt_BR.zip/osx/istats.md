# istats

> Ferramenta CLI que mostra estatísticas como temperatura da CPU, velocidade das ventoinhas, e status da bateria.
> Mais informações: <https://github.com/Chris911/iStats>.

- Exibe todas as estatísticas:

`istats`

- Exibe todas as estatísticas da CPU:

`istats cpu`

- Exibe todas as estatísticas das ventoinhas:

`istats fan`

- Examina e imprime as temperaturas:

`istats scan`
