# glogname

> Este comando é um pseudônimo de `-p linux logname`.

- Exibe documentação sobre o comando original:

`tldr -p linux logname`
