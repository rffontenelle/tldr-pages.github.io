# glogname

> Este comando é um pseudônimo de `-p linux logname`.

- Ver documentação sobre o comando original:

`tldr -p linux logname`
