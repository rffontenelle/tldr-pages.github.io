# gtest

> Este comando é um pseudônimo de `-p linux test`.

- Exibe documentação sobre o comando original:

`tldr -p linux test`
