# gpinky

> Este comando é um pseudônimo de `-p linux pinky`.

- Ver documentação sobre o comando original:

`tldr -p linux pinky`
