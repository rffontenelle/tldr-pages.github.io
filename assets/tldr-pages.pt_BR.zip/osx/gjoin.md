# gjoin

> Este comando é um pseudônimo de `-p linux join`.

- Ver documentação sobre o comando original:

`tldr -p linux join`
