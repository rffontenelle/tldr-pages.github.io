# gjoin

> Este comando é um apelido de `-p linux join`.

- Exibe documentação sobre o comando original:

`tldr -p linux join`
