# gnl

> Este comando é um pseudônimo de `-p linux nl`.

- Exibe documentação sobre o comando original:

`tldr -p linux nl`
