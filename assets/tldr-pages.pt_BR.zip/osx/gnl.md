# gnl

> Este comando é um pseudônimo de `-p linux nl`.

- Ver documentação sobre o comando original:

`tldr -p linux nl`
