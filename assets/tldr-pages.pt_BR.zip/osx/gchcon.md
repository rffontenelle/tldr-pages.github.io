# gchcon

> Este comando é um pseudônimo de `-p linux chcon`.

- Ver documentação sobre o comando original:

`tldr -p linux chcon`
