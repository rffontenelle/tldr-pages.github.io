# gchcon

> Este comando é um pseudônimo de `-p linux chcon`.

- Exibe documentação sobre o comando original:

`tldr -p linux chcon`
