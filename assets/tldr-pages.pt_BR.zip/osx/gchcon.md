# gchcon

> Este comando é um apelido de `-p linux chcon`.

- Exibe documentação sobre o comando original:

`tldr -p linux chcon`
