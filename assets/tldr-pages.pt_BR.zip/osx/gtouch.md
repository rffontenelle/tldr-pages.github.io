# gtouch

> Este comando é um pseudônimo de `-p linux touch`.

- Exibe documentação sobre o comando original:

`tldr -p linux touch`
