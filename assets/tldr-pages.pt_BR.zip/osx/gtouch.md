# gtouch

> Este comando é um pseudônimo de `-p linux touch`.

- Ver documentação sobre o comando original:

`tldr -p linux touch`
