# gsha224sum

> Este comando é um pseudônimo de `-p linux sha224sum`.

- Ver documentação sobre o comando original:

`tldr -p linux sha224sum`
