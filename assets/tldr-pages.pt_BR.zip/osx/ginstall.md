# ginstall

> Este comando é um pseudônimo de `-p linux install`.

- Ver documentação sobre o comando original:

`tldr -p linux install`
