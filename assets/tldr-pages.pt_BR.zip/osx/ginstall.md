# ginstall

> Este comando é um apelido de `-p linux install`.

- Exibe documentação sobre o comando original:

`tldr -p linux install`
