# grm

> Este comando é um apelido de `-p linux rm`.

- Exibe documentação sobre o comando original:

`tldr -p linux rm`
