# god

> Este comando é um pseudônimo de `-p linux od`.

- Exibe documentação sobre o comando original:

`tldr -p linux od`
