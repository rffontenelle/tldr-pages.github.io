# guname

> Este comando é um pseudônimo de `-p linux uname`.

- Exibe documentação sobre o comando original:

`tldr -p linux uname`
