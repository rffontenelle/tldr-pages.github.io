# gshred

> Este comando é um apelido de `-p linux shred`.

- Exibe documentação sobre o comando original:

`tldr -p linux shred`
