# gshred

> Este comando é um pseudônimo de `-p linux shred`.

- Ver documentação sobre o comando original:

`tldr -p linux shred`
