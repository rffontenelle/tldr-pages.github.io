# gtee

> Este comando é um pseudônimo de `-p linux tee`.

- Ver documentação sobre o comando original:

`tldr -p linux tee`
