# gtee

> Este comando é um pseudônimo de `-p linux tee`.

- Exibe documentação sobre o comando original:

`tldr -p linux tee`
