# gexpand

> Este comando é um apelido de `-p linux expand`.

- Exibe documentação sobre o comando original:

`tldr -p linux expand`
