# gexpand

> Este comando é um pseudônimo de `-p linux expand`.

- Ver documentação sobre o comando original:

`tldr -p linux expand`
