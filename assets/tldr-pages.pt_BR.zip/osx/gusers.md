# gusers

> Este comando é um pseudônimo de `-p linux users`.

- Ver documentação sobre o comando original:

`tldr -p linux users`
