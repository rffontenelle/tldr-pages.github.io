# gtelnet

> Este comando é um pseudônimo de `-p linux telnet`.

- Ver documentação sobre o comando original:

`tldr -p linux telnet`
