# gtelnet

> Este comando é um pseudônimo de `-p linux telnet`.

- Exibe documentação sobre o comando original:

`tldr -p linux telnet`
