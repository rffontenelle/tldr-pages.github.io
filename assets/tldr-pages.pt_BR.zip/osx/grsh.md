# grsh

> Este comando é um pseudônimo de `-p linux rsh`.

- Exibe documentação sobre o comando original:

`tldr -p linux rsh`
