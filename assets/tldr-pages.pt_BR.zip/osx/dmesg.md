# dmesg

> Exibe mensagens do kernel na saída padrão.
> Mais informações: <https://www.manpagez.com/man/8/dmesg/>.

- Exibe mensagens do kernel:

`dmesg`

- Exibe quanta memória física está disponível no sistema:

`dmesg | grep -i memory`

- Exibe mensagens do kernel, 1 página por vez:

`dmesg | less`
