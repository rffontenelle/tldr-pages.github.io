# gdir

> Este comando é um pseudônimo de `-p linux dir`.

- Ver documentação sobre o comando original:

`tldr -p linux dir`
