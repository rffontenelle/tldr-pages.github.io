# cfprefsd

> Fornece serviços de preferências (`CFPreferences`, `NSUserDefaults`).
> Não deve ser invocado manualmente.
> Mais informações: <https://www.unix.com/man-page/osx/8/cfprefsd/>.

- Inicia o daemon:

`cfprefsd`
