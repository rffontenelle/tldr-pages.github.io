# coreaudiod

> Serviço para o Core Audio, o sistema de áudio da Apple.
> Não deve ser invocado manualmente.
> Mais informações: <https://developer.apple.com/library/archive/documentation/MusicAudio/Conceptual/CoreAudioOverview/WhatisCoreAudio/WhatisCoreAudio.html>.

- Inicia o daemon:

`coreaudiod`
