# gcsplit

> Este comando é um pseudônimo de `-p linux csplit`.

- Ver documentação sobre o comando original:

`tldr -p linux csplit`
