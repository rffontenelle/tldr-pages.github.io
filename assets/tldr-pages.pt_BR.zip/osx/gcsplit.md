# gcsplit

> Este comando é um pseudônimo de `-p linux csplit`.

- Exibe documentação sobre o comando original:

`tldr -p linux csplit`
