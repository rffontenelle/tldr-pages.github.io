# gcsplit

> Este comando é um apelido de `-p linux csplit`.

- Exibe documentação sobre o comando original:

`tldr -p linux csplit`
