# gtac

> Este comando é um pseudônimo de `-p linux tac`.

- Exibe documentação sobre o comando original:

`tldr -p linux tac`
