# gtac

> Este comando é um pseudônimo de `-p linux tac`.

- Ver documentação sobre o comando original:

`tldr -p linux tac`
