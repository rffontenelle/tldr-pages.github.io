# guptime

> Este comando é um pseudônimo de `-p linux uptime`.

- Ver documentação sobre o comando original:

`tldr -p linux uptime`
