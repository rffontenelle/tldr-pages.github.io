# guptime

> Este comando é um apelido de `-p linux uptime`.

- Exibe documentação sobre o comando original:

`tldr -p linux uptime`
