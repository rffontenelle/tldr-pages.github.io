# gfactor

> Este comando é um pseudônimo de `-p linux factor`.

- Ver documentação sobre o comando original:

`tldr -p linux factor`
