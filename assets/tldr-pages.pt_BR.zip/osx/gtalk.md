# gtalk

> Este comando é um pseudônimo de `-p linux talk`.

- Ver documentação sobre o comando original:

`tldr -p linux talk`
