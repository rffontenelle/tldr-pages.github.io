# gtalk

> Este comando é um apelido de `-p linux talk`.

- Exibe documentação sobre o comando original:

`tldr -p linux talk`
