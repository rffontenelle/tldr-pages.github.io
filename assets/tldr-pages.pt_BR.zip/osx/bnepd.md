# bnepd

> Serviço que lida com todas as conexões de rede Bluetooth.
> Não deve ser invocado manualmente.
> Mais informações: <https://www.unix.com/man-page/osx/8/bnepd/>.

- Iniciar o daemon:

`bnepd`
