# gmd5sum

> Este comando é um pseudônimo de `-p linux md5sum`.

- Ver documentação sobre o comando original:

`tldr -p linux md5sum`
