# gmd5sum

> Este comando é um pseudônimo de `-p linux md5sum`.

- Exibe documentação sobre o comando original:

`tldr -p linux md5sum`
