# gexpr

> Este comando é um pseudônimo de `-p linux expr`.

- Exibe documentação sobre o comando original:

`tldr -p linux expr`
