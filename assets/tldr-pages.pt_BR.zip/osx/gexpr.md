# gexpr

> Este comando é um pseudônimo de `-p linux expr`.

- Ver documentação sobre o comando original:

`tldr -p linux expr`
