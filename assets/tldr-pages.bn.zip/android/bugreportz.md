# bugreportz

> একটি জিপ করা অ্যান্ড্রয়েড বাগ রিপোর্ট তৈরি করুন।
> এই কমান্ডটি শুধুমাত্র `adb shell` এর মাধ্যমে ব্যবহার করা যেতে পারে।
> আরও তথ্য পাবেন: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreportz>.

- একটি অ্যান্ড্রয়েড ডিভাইসের একটি সম্পূর্ণ জিপ করা বাগ রিপোর্ট তৈরি করুন:

`bugreportz`

- চলমান অপারেশনের অগ্রগতি দেখুন:

`bugreportz -p`

- সংস্করণ দেখুন:

`bugreportz -v`

- সাহায্য প্রদর্শন:

`bugreportz -h`
