# dalvikvm

> অ্যান্ড্রয়েড জাভা ভার্চুয়াল মেশিন।
> আরও তথ্য পাবেন: <https://source.android.com/devices/tech/dalvik>.

- একটি নির্দিষ্ট জাভা প্রোগ্রাম শুরু করুন:

`dalvikvm -classpath {{ফাইল.jar/এর/পথ}} {{ক্লাসের নাম}}`
