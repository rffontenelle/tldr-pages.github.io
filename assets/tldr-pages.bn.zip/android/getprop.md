# getprop

> অ্যান্ড্রয়েড সিস্টেম বৈশিষ্ট্য সম্পর্কে তথ্য দেখান।
> আরও তথ্য পাবেন: <https://manned.org/getprop>।

- অ্যান্ড্রয়েড সিস্টেম বৈশিষ্ট্য সম্পর্কে তথ্য প্রদর্শন করুন:

`getprop`

- একটি নির্দিষ্ট সম্পত্তি সম্পর্কে তথ্য প্রদর্শন করুন:

`getprop {{সম্পত্তি}}`

- SDK API স্তর প্রদর্শন করুন:

`getprop {{ro.build.version.sdk}}`

- অ্যান্ড্রয়েড সংস্করণ প্রদর্শন করুন:

`getprop {{ro.build.version.release}}`

- অ্যান্ড্রয়েড ডিভাইস মডেল প্রদর্শন করুন:

`getprop {{ro.vendor.product.model}}`

- OEM আনলক স্থিতি প্রদর্শন করুন:

`getprop {{ro.oem_unlock_supported}}`

- Android এর Wi-Fi কার্ডের MAC ঠিকানা প্রদর্শন করুন:

`getprop {{ro.boot.wifimacaddr}}`
