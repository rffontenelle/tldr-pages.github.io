# bugreport

> একটি অ্যান্ড্রয়েড বাগ রিপোর্ট দেখান।
> এই কমান্ডটি শুধুমাত্র `adb shell` এর মাধ্যমে ব্যবহার করা যেতে পারে।
> আরও তথ্য পাবেন: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreport>.

- একটি অ্যান্ড্রয়েড ডিভাইসের একটি সম্পূর্ণ বাগ রিপোর্ট দেখান:

`bugreport`
