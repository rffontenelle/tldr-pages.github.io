# launchd

> এই কমান্ড একটি উপনাম `launchctl`.
> আরও তথ্য পাবেন: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr launchctl`
