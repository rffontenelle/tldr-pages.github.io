# glibtool

> এই কমান্ড একটি উপনাম `-p linux libtool`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr -p linux libtool`
