# gsha512sum

> এই কমান্ড একটি উপনাম `-p linux sha512sum`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr -p linux sha512sum`
