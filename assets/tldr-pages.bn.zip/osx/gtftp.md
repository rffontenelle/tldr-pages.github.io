# gtftp

> এই কমান্ড একটি উপনাম `-p linux tftp`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr -p linux tftp`
