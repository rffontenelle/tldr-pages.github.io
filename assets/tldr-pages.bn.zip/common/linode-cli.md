# linode-cli

> এই কমান্ড একটি উপনাম `linode-cli account`.
> আরও তথ্য পাবেন: <https://www.linode.com/docs/products/tools/cli/get-started/>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr linode-cli account`
