# docker-container-remove

> এই কমান্ড একটি উপনাম `docker rm`.
> আরও তথ্য পাবেন: <https://docs.docker.com/engine/reference/commandline/rm>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr docker rm`
