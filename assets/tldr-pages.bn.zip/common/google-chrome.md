# google-chrome

> এই কমান্ড একটি উপনাম `chromium`.
> আরও তথ্য পাবেন: <https://chrome.google.com>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr chromium`
