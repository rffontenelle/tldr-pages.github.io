# lima

> এই কমান্ড একটি উপনাম `limactl`.
> আরও তথ্য পাবেন: <https://github.com/lima-vm/lima>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr limactl`
