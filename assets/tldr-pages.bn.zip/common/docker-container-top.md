# docker-container-top

> এই কমান্ড একটি উপনাম `docker top`.
> আরও তথ্য পাবেন: <https://docs.docker.com/engine/reference/commandline/top>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr docker top`
