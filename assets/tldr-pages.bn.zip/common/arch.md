# arch

> সিস্টেমের আর্কিটেকচারের নাম দেখানো।
> `uname` ওয়েবসাইটে দেখানো যাক।
> আরও জানতে: <https://www.gnu.org/software/coreutils/arch>.

- সিস্টেম আর্কিটেকচার দেখানো:

`arch`
