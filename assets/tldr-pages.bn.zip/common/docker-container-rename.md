# docker-container-rename

> এই কমান্ড একটি উপনাম `docker rename`.
> আরও তথ্য পাবেন: <https://docs.docker.com/engine/reference/commandline/rename>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr docker rename`
