# ntl

> এই কমান্ড একটি উপনাম `netlify`.
> আরও তথ্য পাবেন: <https://cli.netlify.com>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr netlify`
