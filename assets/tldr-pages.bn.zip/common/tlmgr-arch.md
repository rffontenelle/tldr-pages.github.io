# tlmgr-arch

> এই কমান্ড একটি উপনাম `tlmgr platform`.
> আরও তথ্য পাবেন: <https://www.tug.org/texlive/tlmgr.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr tlmgr platform`
