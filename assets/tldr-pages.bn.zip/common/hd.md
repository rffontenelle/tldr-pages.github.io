# hd

> এই কমান্ড একটি উপনাম `hexdump`.
> আরও তথ্য পাবেন: <https://manned.org/hd.1>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr hexdump`
