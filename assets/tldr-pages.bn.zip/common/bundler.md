# bundler

> এই কমান্ড একটি উপনাম `bundle`.
> আরও তথ্য পাবেন: <https://bundler.io/man/bundle.1.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr bundle`
