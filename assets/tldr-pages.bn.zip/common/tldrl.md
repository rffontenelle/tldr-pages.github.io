# tldrl

> এই কমান্ড একটি উপনাম `tldr-lint`.
> আরও তথ্য পাবেন: <https://github.com/tldr-pages/tldr-lint>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr tldr-lint`
