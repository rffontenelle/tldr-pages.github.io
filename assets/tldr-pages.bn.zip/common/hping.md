# hping

> এই কমান্ড একটি উপনাম `hping3`.
> আরও তথ্য পাবেন: <https://github.com/antirez/hping>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr hping3`
