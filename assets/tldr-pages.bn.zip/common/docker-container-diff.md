# docker-container-diff

> এই কমান্ড একটি উপনাম `docker diff`.
> আরও তথ্য পাবেন: <https://docs.docker.com/engine/reference/commandline/diff>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr docker diff`
