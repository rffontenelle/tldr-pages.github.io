# gh-cs

> এই কমান্ড একটি উপনাম `gh-codespace`.
> আরও তথ্য পাবেন: <https://cli.github.com/manual/gh_codespace>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr gh-codespace`
