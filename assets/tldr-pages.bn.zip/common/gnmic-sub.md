# gnmic-sub

> এই কমান্ড একটি উপনাম `gnmic subscribe`.
> আরও তথ্য পাবেন: <https://gnmic.kmrd.dev/cmd/subscribe>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr gnmic subscribe`
