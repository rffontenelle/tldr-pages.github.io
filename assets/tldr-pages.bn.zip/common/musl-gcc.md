# musl-gcc

> এই কমান্ড একটি উপনাম `gcc`.
> আরও তথ্য পাবেন: <https://manned.org/musl-gcc>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr gcc`
