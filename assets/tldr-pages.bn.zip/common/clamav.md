# clamav

> এই কমান্ড একটি উপনাম `clamdscan`.
> আরও তথ্য পাবেন: <https://www.clamav.net>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr clamdscan`
