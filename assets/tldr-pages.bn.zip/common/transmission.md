# transmission

> এই কমান্ড একটি উপনাম `transmission-daemon`.
> আরও তথ্য পাবেন: <https://transmissionbt.com/>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr transmission-daemon`
