# batcat

> এই কমান্ড একটি উপনাম `bat`.
> আরও তথ্য পাবেন: <https://github.com/sharkdp/bat>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr bat`
