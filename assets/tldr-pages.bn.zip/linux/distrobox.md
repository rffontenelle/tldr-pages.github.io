# distrobox

> এই কমান্ড একটি উপনাম `distrobox-create`.
> আরও তথ্য পাবেন: <https://github.com/89luca89/distrobox>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr distrobox-create`
