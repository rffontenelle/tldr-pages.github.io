# apx

> এই কমান্ড একটি উপনাম `apx pkgmanagers`.
> আরও তথ্য পাবেন: <https://github.com/Vanilla-OS/apx>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr apx pkgmanagers`
