# alternatives

> এই কমান্ড একটি উপনাম `update-alternatives`.
> আরও তথ্য পাবেন: <https://manned.org/alternatives>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr update-alternatives`
