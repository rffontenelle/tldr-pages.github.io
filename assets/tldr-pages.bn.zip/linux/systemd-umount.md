# systemd-umount

> এই কমান্ড একটি উপনাম `systemd-mount`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr systemd-mount`
