# pkgctl

> এই কমান্ড একটি উপনাম `pkgctl auth`.
> আরও তথ্য পাবেন: <https://man.archlinux.org/man/pkgctl.1>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr pkgctl auth`
