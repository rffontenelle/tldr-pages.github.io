# ip6tables

> এই কমান্ড একটি উপনাম `iptables`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr iptables`
