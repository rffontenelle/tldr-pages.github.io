# megadl

> এই কমান্ড একটি উপনাম `megatools-dl`.
> আরও তথ্য পাবেন: <https://megatools.megous.com/man/megatools-dl.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr megatools-dl`
