# cgroups

> এই কমান্ড একটি উপনাম `cgclassify`.
> আরও তথ্য পাবেন: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr cgclassify`
