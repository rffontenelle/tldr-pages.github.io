# nmcli

> এই কমান্ড একটি উপনাম `nmcli agent`.
> আরও তথ্য পাবেন: <https://networkmanager.dev/docs/api/latest/nmcli.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr nmcli agent`
