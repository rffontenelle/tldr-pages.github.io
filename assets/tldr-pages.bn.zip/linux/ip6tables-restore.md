# ip6tables-restore

> এই কমান্ড একটি উপনাম `iptables-restore`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr iptables-restore`
