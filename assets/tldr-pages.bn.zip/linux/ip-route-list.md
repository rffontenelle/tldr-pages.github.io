# ip-route-list

> এই কমান্ড একটি উপনাম `ip-route-show`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr ip-route-show`
