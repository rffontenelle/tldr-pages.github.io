# qm-move-disk

> এই কমান্ড একটি উপনাম `qm-disk-move`.
> আরও তথ্য পাবেন: <https://pve.proxmox.com/pve-docs/qm.1.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr qm-disk-move`
