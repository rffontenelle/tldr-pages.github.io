# qm-importdisk

> এই কমান্ড একটি উপনাম `qm disk import`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr qm disk import`
