# ip6tables-save

> এই কমান্ড একটি উপনাম `iptables-save`.

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr iptables-save`
