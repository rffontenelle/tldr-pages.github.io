# pkg

> এই কমান্ড একটি উপনাম `pkg_add`.
> আরও তথ্য পাবেন: <https://www.openbsd.org/faq/faq15.html>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr pkg_add`
