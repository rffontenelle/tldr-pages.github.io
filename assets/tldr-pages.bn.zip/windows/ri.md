# ri

> এই কমান্ড একটি উপনাম `remove-item`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr remove-item`
