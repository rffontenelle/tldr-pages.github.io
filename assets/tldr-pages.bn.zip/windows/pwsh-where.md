# pwsh-where

> এই কমান্ড একটি উপনাম `Where-Object`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr Where-Object`
