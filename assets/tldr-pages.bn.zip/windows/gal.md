# gal

> এই কমান্ড একটি উপনাম `get-alias`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr get-alias`
