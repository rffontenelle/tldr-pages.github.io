# chrome

> এই আদেশটির উপনাম `chromium`।
> আরও তথ্যের জন্য: <https://chrome.google.com>.

- মৌল আদেশের জন্য ডকুমেন্টেশন দেখুন:

`tldr chromium`
