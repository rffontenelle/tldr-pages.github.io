# sc-config

> এই কমান্ড একটি উপনাম `sc`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr sc`
