# cpush

> এই কমান্ড একটি উপনাম `choco-push`.
> আরও তথ্য পাবেন: <https://docs.chocolatey.org/en-us/create/commands/push>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr choco-push`
