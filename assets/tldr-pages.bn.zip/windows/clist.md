# clist

> এই কমান্ড একটি উপনাম `choco list`.
> আরও তথ্য পাবেন: <https://docs.chocolatey.org/en-us/choco/commands/list>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr choco list`
