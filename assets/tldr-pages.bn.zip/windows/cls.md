# cls

> এই কমান্ড একটি উপনাম `clear-host`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr clear-host`
