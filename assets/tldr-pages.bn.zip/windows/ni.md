# ni

> এই কমান্ড একটি উপনাম `new-item`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr new-item`
