# slmgr

> এই কমান্ড একটি উপনাম `slmgr.vbs`.
> আরও তথ্য পাবেন: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr slmgr.vbs`
