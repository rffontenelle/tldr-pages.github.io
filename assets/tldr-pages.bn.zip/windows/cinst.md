# cinst

> এই কমান্ড একটি উপনাম `choco install`.
> আরও তথ্য পাবেন: <https://docs.chocolatey.org/en-us/choco/commands/install>।

- মূল কমান্ডের জন্য ডকুমেন্টেশন দেখুন:

`tldr choco install`
