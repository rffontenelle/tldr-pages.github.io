# pkg

> 這是 `pkg_add` 命令的一個別名。
> 更多資訊：<https://www.openbsd.org/faq/faq15.html>.

- 原命令的文件在：

`tldr pkg_add`
