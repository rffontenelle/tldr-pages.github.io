# logcat

> 轉存系統訊息日誌。
> 更多資訊：<https://developer.android.com/tools/logcat>.

- 顯示系統日誌：

`logcat`

- 將系統日誌寫入檔案：

`logcat -f {{文件路径}}`

- 顯示與正規表示式匹配的列：

`logcat --regex {{正規表示式}}`
