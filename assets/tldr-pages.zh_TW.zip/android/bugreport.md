# bugreport

> 顯示安卓的 Bug 報告。
> 該命令只能透過 `adb shell` 使用。
> 更多資訊：<https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreport>.

- 顯示 Android 裝置的完整錯誤報告：

`bugreport`
