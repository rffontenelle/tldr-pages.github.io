# wm

> 顯示關於 Android 裝置的螢幕的資訊。
> 此命令只能透過 `adb shell` 使用。
> 更多資訊：<https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- 顯示 Android 裝置的螢幕的物理尺寸：

`wm {{size}}`

- 顯示 Android 裝置的螢幕的物理密度：

`wm {{density}}`
