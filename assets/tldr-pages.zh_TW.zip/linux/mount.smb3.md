# mount.smb3

> 這是 `mount.cifs` 命令的一個別名。

- 原命令的文件在：

`tldr mount.cifs`
