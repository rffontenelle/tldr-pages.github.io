# cgroups

> 這是 `cgclassify` 命令的一個別名。
> 更多資訊：<https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- 原命令的文件在：

`tldr cgclassify`
