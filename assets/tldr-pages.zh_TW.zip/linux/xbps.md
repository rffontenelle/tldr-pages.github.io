# xbps

> 這是 `xbps-install` 命令的一個別名。
> 更多資訊：<https://docs.voidlinux.org/xbps/index.html>.

- 原命令的文件在：

`tldr xbps-install`
