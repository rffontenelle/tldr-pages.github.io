# qm-move-disk

> 這是 `qm-disk-move` 命令的一個別名。
> 更多資訊：<https://pve.proxmox.com/pve-docs/qm.1.html>.

- 原命令的文件在：

`tldr qm-disk-move`
