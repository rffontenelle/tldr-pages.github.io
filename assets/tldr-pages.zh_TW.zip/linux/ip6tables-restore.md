# ip6tables-restore

> 這是 `iptables-restore` 命令的一個別名。

- 原命令的文件在：

`tldr iptables-restore`
