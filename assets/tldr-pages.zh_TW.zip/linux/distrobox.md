# distrobox

> 這是 `distrobox-create` 命令的一個別名。
> 更多資訊：<https://github.com/89luca89/distrobox>.

- 原命令的文件在：

`tldr distrobox-create`
