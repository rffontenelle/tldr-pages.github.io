# nmcli

> 這是 `nmcli agent` 命令的一個別名。
> 更多資訊：<https://networkmanager.dev/docs/api/latest/nmcli.html>.

- 原命令的文件在：

`tldr nmcli agent`
