# pkgctl

> 這是 `pkgctl auth` 命令的一個別名。
> 更多資訊：<https://man.archlinux.org/man/pkgctl.1>.

- 原命令的文件在：

`tldr pkgctl auth`
