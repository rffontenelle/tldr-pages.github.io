# cc

> 這是 `gcc` 命令的一個別名。
> 更多資訊：<https://gcc.gnu.org>.

- 原命令的文件在：

`tldr gcc`
