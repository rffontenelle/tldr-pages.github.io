# batcat

> 這是 `bat` 命令的一個別名。
> 更多資訊：<https://github.com/sharkdp/bat>.

- 原命令的文件在：

`tldr bat`
