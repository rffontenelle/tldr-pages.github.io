# systemd-umount

> 這是 `systemd-mount` 命令的一個別名。

- 原命令的文件在：

`tldr systemd-mount`
