# ni

> 這是 `new-item` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- 原命令的文件在：

`tldr new-item`
