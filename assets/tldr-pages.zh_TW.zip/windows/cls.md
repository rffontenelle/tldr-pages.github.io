# cls

> 清除命令提示字元中的輸出文字。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- 清除輸出：

`cls`
