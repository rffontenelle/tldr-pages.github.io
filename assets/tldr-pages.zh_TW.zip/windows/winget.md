# winget

> Windows 套件管理員的命令列工具。
> 更多資訊：<https://learn.microsoft.com/windows/package-manager/winget>.

- 安裝一個套件：

`winget install {{套件}}`

- 顯示指定套件的相關資訊：

`winget show {{套件}}`

- 搜尋指定套件：

`winget search {{套件}}`
