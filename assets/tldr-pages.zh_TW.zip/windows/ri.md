# ri

> 這是 `remove-item` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- 原命令的文件在：

`tldr remove-item`
