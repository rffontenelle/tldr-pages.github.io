# gal

> 這是 `get-alias` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- 原命令的文件在：

`tldr get-alias`
