# cd

> 這是 `set-location` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- 原命令的文件在：

`tldr set-location`
