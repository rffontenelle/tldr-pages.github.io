# clear

> 這是 `clear-host` 命令的一個別名。

- 原命令的文件在：

`tldr clear-host`
