# exit

> 退出當前的命令解釋器實例或批次檔。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- 退出當前的命令解釋器實例：

`exit`

- 退出當前的批次檔：

`exit /b`

- 使用一個指定的退出碼退出：

`exit {{退出碼}}`
