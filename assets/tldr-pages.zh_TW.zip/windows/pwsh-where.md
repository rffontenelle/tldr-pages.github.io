# pwsh where

> 這是 `Where-Object` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- 原命令的文件在：

`tldr Where-Object`
