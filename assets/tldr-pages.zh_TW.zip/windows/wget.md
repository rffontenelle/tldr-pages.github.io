# wget

> 這是 `wget -p common` 命令的一個別名。
> 更多資訊：<https://www.gnu.org/software/wget>.

- 原命令的文件在：

`tldr wget -p common`
