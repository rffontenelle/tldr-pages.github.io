# type

> 顯示文件的內容。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/type>.

- 顯示指定文件的內容：

`type {{檔案/完整/路徑}}`
