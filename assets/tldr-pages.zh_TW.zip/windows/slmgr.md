# slmgr

> 這是 `slmgr.vbs` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- 原命令的文件在：

`tldr slmgr.vbs`
