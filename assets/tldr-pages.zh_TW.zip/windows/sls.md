# sls

> 這是 `where-object` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- 原命令的文件在：

`tldr where-object`
