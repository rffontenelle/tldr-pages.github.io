# rd

> 這是 `rmdir` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- 原命令的文件在：

`tldr rmdir`
