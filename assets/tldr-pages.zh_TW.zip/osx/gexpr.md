# gexpr

> 這是 `-p linux expr` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux expr`
