# gmktemp

> 這是 `-p linux mktemp` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux mktemp`
