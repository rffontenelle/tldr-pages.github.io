# gpinky

> 這是 `-p linux pinky` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux pinky`
