# gwhich

> 這是 `-p linux which` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux which`
