# gmkdir

> 這是 `-p linux mkdir` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux mkdir`
