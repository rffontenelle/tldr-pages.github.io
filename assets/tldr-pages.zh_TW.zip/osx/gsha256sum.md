# gsha256sum

> 這是 `-p linux sha256sum` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux sha256sum`
