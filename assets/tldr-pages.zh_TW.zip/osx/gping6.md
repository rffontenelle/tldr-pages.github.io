# gping6

> 這是 `-p linux ping6` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux ping6`
