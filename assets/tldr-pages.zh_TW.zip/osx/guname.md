# guname

> 這是 `-p linux uname` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux uname`
