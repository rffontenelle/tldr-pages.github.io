# launchd

> 這是 `launchctl` 命令的一個別名。
> 更多資訊：<https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- 原命令的文件在：

`tldr launchctl`
