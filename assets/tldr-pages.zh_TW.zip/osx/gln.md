# gln

> 這是 `-p linux ln` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux ln`
