# gtalk

> 這是 `-p linux talk` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux talk`
