# gegrep

> 這是 `-p linux egrep` 命令的一個別名。

- 原命令的文件在：

`tldr -p linux egrep`
