# azure-cli

> 這是 `az` 命令的一個別名。
> 更多資訊：<https://learn.microsoft.com/cli/azure>.

- 原命令的文件在：

`tldr az`
