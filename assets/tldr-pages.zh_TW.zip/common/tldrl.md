# tldrl

> 這是 `tldr-lint` 命令的一個別名。
> 更多資訊：<https://github.com/tldr-pages/tldr-lint>.

- 原命令的文件在：

`tldr tldr-lint`
