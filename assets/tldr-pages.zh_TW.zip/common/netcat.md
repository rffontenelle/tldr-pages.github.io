# netcat

> 這是 `nc` 命令的一個別名。

- 原命令的文件在：

`tldr nc`
