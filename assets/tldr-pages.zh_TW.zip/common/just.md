# just

> 這是 `just.1` 命令的一個別名。

- 原命令的文件在：

`tldr just.1`
