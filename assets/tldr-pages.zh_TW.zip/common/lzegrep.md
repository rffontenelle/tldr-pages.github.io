# lzegrep

> 這是 `xzgrep` 命令的一個別名。

- 原命令的文件在：

`tldr xzgrep`
