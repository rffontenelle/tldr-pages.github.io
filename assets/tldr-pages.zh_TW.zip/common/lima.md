# lima

> 這是 `limactl` 命令的一個別名。
> 更多資訊：<https://github.com/lima-vm/lima>.

- 原命令的文件在：

`tldr limactl`
