# pwd

> 印出目前目錄的名稱。
> 更多資訊：<https://www.gnu.org/software/coreutils/pwd>.

- 印出目前所在的目錄名稱：

`pwd`

- 印出目前所在的目錄名稱，並將符號連結轉換為實體路徑：

`pwd -P`
