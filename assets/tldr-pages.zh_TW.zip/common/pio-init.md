# pio-init

> 這是 `pio project` 命令的一個別名。

- 原命令的文件在：

`tldr pio project`
