# hd

> 這是 `hexdump` 命令的一個別名。
> 更多資訊：<https://manned.org/hd.1>.

- 原命令的文件在：

`tldr hexdump`
