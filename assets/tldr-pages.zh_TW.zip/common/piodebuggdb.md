# piodebuggdb

> 這是 `pio debug` 命令的一個別名。

- 原命令的文件在：

`tldr pio debug`
