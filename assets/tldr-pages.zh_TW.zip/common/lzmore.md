# lzmore

> 這是 `xzmore` 命令的一個別名。

- 原命令的文件在：

`tldr xzmore`
