# hping

> 這是 `hping3` 命令的一個別名。
> 更多資訊：<https://github.com/antirez/hping>.

- 原命令的文件在：

`tldr hping3`
