# pwsh

> 這是 `powershell` 命令的一個別名。

- 原命令的文件在：

`tldr powershell`
