# gnmic-sub

> 這是 `gnmic subscribe` 命令的一個別名。
> 更多資訊：<https://gnmic.kmrd.dev/cmd/subscribe>.

- 原命令的文件在：

`tldr gnmic subscribe`
