# ClamAV

> 這是 `clamdscan` 命令的一個別名。
> 更多資訊：<https://www.clamav.net>.

- 原命令的文件在：

`tldr clamdscan`
