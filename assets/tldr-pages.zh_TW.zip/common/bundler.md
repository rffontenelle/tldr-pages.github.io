# bundler

> 這是 `bundle` 命令的一個別名。
> 更多資訊：<https://bundler.io/man/bundle.1.html>.

- 原命令的文件在：

`tldr bundle`
