# fossil-forget

> 這是 `fossil rm` 命令的一個別名。
> 更多資訊：<https://fossil-scm.org/home/help/forget>.

- 原命令的文件在：

`tldr fossil rm`
