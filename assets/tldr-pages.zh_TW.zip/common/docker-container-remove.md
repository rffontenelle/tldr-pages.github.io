# docker-container-remove

> 這是 `docker rm` 命令的一個別名。
> 更多資訊：<https://docs.docker.com/engine/reference/commandline/rm>.

- 原命令的文件在：

`tldr docker rm`
