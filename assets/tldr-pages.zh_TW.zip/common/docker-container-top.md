# docker-container-top

> 這是 `docker top` 命令的一個別名。
> 更多資訊：<https://docs.docker.com/engine/reference/commandline/top>.

- 原命令的文件在：

`tldr docker top`
