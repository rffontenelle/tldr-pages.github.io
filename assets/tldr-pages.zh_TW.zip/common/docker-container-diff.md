# docker-container-diff

> 這是 `docker diff` 命令的一個別名。
> 更多資訊：<https://docs.docker.com/engine/reference/commandline/diff>.

- 原命令的文件在：

`tldr docker diff`
