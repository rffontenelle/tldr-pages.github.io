# lzma

> 這是 `xz` 命令的一個別名。
> 更多資訊：<https://manned.org/lzma>.

- 原命令的文件在：

`tldr xz`
