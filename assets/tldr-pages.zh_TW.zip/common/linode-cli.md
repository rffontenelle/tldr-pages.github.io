# linode-cli

> 這是 `linode-cli account` 命令的一個別名。
> 更多資訊：<https://www.linode.com/docs/products/tools/cli/get-started/>.

- 原命令的文件在：

`tldr linode-cli account`
