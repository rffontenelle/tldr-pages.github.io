# docker-container-rename

> 這是 `docker rename` 命令的一個別名。
> 更多資訊：<https://docs.docker.com/engine/reference/commandline/rename>.

- 原命令的文件在：

`tldr docker rename`
