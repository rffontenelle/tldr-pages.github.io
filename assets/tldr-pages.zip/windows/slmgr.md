# slmgr

> This command is an alias of `slmgr.vbs`.
> More information: <https://docs.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- View documentation for the original command:

`tldr slmgr.vbs`
