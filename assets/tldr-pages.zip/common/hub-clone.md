# hub clone

> Clone an existing repository.
> More information: <https://hub.github.com/hub-clone.1.html>.

- Clone an existing repository to current directory (If run into authentication problem, try full ssh path):

`hub clone {{remote_repository_location}}`
