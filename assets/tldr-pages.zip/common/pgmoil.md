# pgmoil

> This command is superseded by `pamoil`.
> More information: <https://netpbm.sourceforge.net/doc/pgmoil.html>.

- View documentation for the current command:

`tldr pamoil`
