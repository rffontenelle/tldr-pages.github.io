# docker container rename

> This command is an alias of `docker rename`.
> More information: <https://docs.docker.com/engine/reference/commandline/rename>.

- View documentation for the original command:

`tldr docker rename`
