# f3read

> Validate .h2w files to test the real capacity of the drive.
> See also: `f3write`, `f3probe`, `f3fix`.
> More information: <http://oss.digirati.com.br/f3/>.

- Validate a device by checking the files in a given directory:

`f3read {{path/to/mount_point}}`
