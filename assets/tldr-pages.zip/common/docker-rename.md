# docker rename

> Rename a container.
> More information: <https://docs.docker.com/engine/reference/commandline/rename>.

- Rename a container:

`docker rename {{container}} {{new_name}}`

- Display help:

`docker rename --help`
