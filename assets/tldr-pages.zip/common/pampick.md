# pampick

> Pick images out of a multi-image Netpbm stream.
> See also: `pamfile`, `pamsplit`.
> More information: <https://netpbm.sourceforge.net/doc/pampick.html>.

- Execute a shell command on each image in a Netpbm file:

`pampick {{image_number1 image_number2 ...}} < {{path/to/image.pam}} > {{path/to/output.pam}}`
