# ppmtowinicon

> This command is superseded by `pamtowinicon`.
> More information: <https://netpbm.sourceforge.net/doc/ppmtowinicon.html>.

- View documentation for the current command:

`tldr pamtowinicon`
