# pnmflip

> This command is superseded by `pamflip`.
> More information: <https://netpbm.sourceforge.net/doc/pnmflip.html>.

- View documentation for the current command:

`tldr pamflip`
