# gemtopbm

> This command is superseded by `gemtopnm`.
> More information: <https://netpbm.sourceforge.net/doc/gemtopbm.html>.

- View documentation for the current command:

`tldr gemtopnm`
