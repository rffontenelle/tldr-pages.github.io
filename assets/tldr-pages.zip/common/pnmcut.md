# pnmcut

> This command is superseded by `pamcut`.
> More information: <https://netpbm.sourceforge.net/doc/pnmcut.html>.

- View documentation for the current command:

`tldr pamcut`
