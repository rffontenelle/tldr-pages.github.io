# gbase64

> This command is an alias of GNU `base64`.

- View documentation for the original command:

`tldr -p linux base64`
