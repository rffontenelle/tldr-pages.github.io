# airportd

> Manages wireless interfaces.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/airportd/>.

- Start the daemon:

`airportd`
