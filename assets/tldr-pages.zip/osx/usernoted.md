# usernoted

> Provides notification services.
> It should not be invoked manually.
> More information: <https://www.unix.com/man-page/mojave/8/usernoted>.

- Start the daemon:

`usernoted`
