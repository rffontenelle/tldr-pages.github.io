# toolbox help

> Displays help information about `toolbox`.
> More information: <https://manned.org/toolbox-help.1>.

- Display the `toolbox` manual:

`toolbox help`

- Display the `toolbox` manual for a specific subcommand:

`toolbox help {{subcommand}}`
