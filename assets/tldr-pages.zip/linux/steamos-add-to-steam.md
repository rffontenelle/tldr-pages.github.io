# steamos-add-to-steam

> Add a program to Steam library.
> More information: <https://gitlab.com/users/evlaV/projects>.

- Add a program to Steam library:

`steamos-add-to-steam {{path/to/file}}`
