# debchange

> Mantain the debian/changelog file of a Debian source package.
> More information: <https://manpages.debian.org/latest/devscripts/debchange.1.en.html>.

- Add a new version for a non-maintainer upload to the changelog:

`debchange --nmu`

- Add a changelog entry to the current version:

`debchange --append`

- Add a changelog entry to close the bug with specified ID:

`debchange --closes {{bug_id}}`
