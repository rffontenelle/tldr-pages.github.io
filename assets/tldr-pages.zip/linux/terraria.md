# terraria

> Create and start a headless Terraria server.
> More information: <https://terraria.wiki.gg/wiki/Server>.

- Start an interactive server setup:

`{{path/to/TerrariaServer}}`

- Start a Terraria server:

`{{path/to/TerrariaServer}} -world {{path/to/world.wld}}`
