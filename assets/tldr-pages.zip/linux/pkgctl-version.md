# pkgctl version

> Display `pkgctl` version information.
> More information: <https://man.archlinux.org/man/pkgctl-version.1>.

- Display version:

`pkgctl version`
