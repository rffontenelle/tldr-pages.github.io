# gal

> Perintah ini merupakan alias dari `get-alias`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr get-alias`
