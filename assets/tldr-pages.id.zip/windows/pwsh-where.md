# pwsh-where

> Perintah ini merupakan alias dari `Where-Object`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr Where-Object`
