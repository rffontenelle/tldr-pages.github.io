# sc-config

> Perintah ini merupakan alias dari `sc`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr sc`
