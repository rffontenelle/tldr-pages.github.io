# chrome

> Perintah ini merupakan alias dari `chromium`.
> Informasi lebih lanjut: <https://chrome.google.com>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr chromium`
