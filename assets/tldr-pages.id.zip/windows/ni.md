# ni

> Perintah ini merupakan alias dari `new-item`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr new-item`
