# sls

> Perintah ini merupakan alias dari `Select-String`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr select-string`
