# sls

> Perintah ini merupakan alias dari `where-object`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr where-object`
