# rm

> Perintah ini merupakan alias dari `remove-item`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr remove-item`
