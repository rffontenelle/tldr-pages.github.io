# sc-create

> Perintah ini merupakan alias dari `sc`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr sc`
