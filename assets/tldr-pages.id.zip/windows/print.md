# print

> Mencetak sebuah file teks ke dalam mesin pencetak (printer).
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/print>.

- Mencetak file teks ke dalam mesin pencetak (printer) default:

`print {{jalan/menuju/file}}`

- Mencetak file teks ke dalam mesin pencetak (printer) tertentu:

`print /d:{{mesin_pencetak}} {{jalan/menuju/file}}`
