# del

> Perintah ini merupakan alias dari `remove-item`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr remove-item`
