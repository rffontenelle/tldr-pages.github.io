# sc-query

> Perintah ini merupakan alias dari `sc`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr sc`
