# cpush

> Perintah ini merupakan alias dari `choco-push`.
> Informasi lebih lanjut: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr choco-push`
