# ver

> Tampilkan nomor versi Windows atau MS-DOS saat ini.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/ver>.

- Tampilkan nomor versi saat ini:

`ver`
