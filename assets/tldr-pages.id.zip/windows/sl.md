# sl

> Perintah ini merupakan alias dari `set-location`.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr set-location`
