# sl

> Perintah ini merupakan alias dari `Set-Location` di PowerShell.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr set-location`
