# slmgr

> Perintah ini merupakan alias dari `slmgr.vbs`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr slmgr.vbs`
