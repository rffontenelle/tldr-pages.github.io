# clear

> Perintah ini merupakan alias dari `clear-host`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr clear-host`
