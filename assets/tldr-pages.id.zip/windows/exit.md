# exit

> Keluar dari sesi Command Prompt (CMD) atau berkas skrip batch saat ini.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- Keluar dari sesi CMD saat ini:

`exit`

- Keluar dari proses eksekusi skrip [b]atch saat ini:

`exit /b`

- Keluar menggunakan kode status keluar (exit code) khusus:

`exit {{2}}`
