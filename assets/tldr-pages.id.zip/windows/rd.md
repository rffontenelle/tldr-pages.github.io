# rd

> Perintah ini merupakan alias dari `rmdir`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr rmdir`
