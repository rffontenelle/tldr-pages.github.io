# chdir

> Perintah ini merupakan alias dari `cd`.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr cd`
