# cls

> Bersihkan layar terminal.
> Dalam PowerShell, perintah ini merupakan alias dari `Clear-Host`. Dokumentasi ini ditulis menurut perintah `cd` versi Command Prompt (`cls`).
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Lihat dokumentasi untuk perintah PowerShell serupa:

`tldr clear-host`

- Bersihkan layar:

`cls`
