# cls

> Membersihkan layar.
> Informasi lebih lanjut: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Bersihkan layar:

`cls`
