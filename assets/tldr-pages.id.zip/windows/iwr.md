# iwr

> Perintah ini merupakan alias dari `Invoke-WebRequest` di PowerShell.
> Informasi lebih lanjut: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr invoke-webrequest`
