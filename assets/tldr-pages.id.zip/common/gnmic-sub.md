# gnmic-sub

> Perintah ini merupakan alias dari `gnmic subscribe`.
> Informasi lebih lanjut: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr gnmic subscribe`
