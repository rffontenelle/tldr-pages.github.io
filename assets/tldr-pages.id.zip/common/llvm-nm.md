# llvm-nm

> Perintah ini merupakan alias dari `nm`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr nm`
