# hd

> Perintah ini merupakan alias dari `hexdump`.
> Informasi lebih lanjut: <https://manned.org/hd.1>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr hexdump`
