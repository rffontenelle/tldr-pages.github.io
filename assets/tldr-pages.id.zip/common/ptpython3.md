# ptpython3

> Perintah ini merupakan alias dari `ptpython`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr ptpython`
