# musl-gcc

> Perintah ini merupakan alias dari `gcc`.
> Informasi lebih lanjut: <https://manned.org/musl-gcc>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr gcc`
