# lzma

> Perintah ini merupakan alias dari `xz`.
> Informasi lebih lanjut: <https://manned.org/lzma>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xz`
