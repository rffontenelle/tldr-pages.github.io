# cron

> Perintah ini merupakan alias dari `crontab`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr crontab`
