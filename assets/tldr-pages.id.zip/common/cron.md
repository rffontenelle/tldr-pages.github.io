# cron

> Perintah ini merupakan alias dari `crontab`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr crontab`
