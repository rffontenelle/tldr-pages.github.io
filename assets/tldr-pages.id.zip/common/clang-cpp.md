# clang-cpp

> Perintah ini merupakan alias dari `clang++`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr clang++`
