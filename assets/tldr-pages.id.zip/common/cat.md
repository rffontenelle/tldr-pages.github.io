# cat

> Mencetak dan menggabungkan berkas.
> Informasi lebih lanjut: <https://www.gnu.org/software/coreutils/cat>.

- Mencetak konten berkas ke keluaran standar:

`cat {{berkas}}`

- Menggabungkan konten beberapa berkas ke berkas tujuan:

`cat {{berkas1 berkas2 ...}} > {{berkas_tujuan}}`

- Menambahkan konten beberapa berkas ke berkas tujuan:

`cat {{berkas1 berkas2 ...}} >> {{berkas_tujuan}}`
