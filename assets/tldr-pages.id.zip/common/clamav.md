# clamav

> Perintah ini merupakan alias dari `clamdscan`.
> Informasi lebih lanjut: <https://www.clamav.net>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr clamdscan`
