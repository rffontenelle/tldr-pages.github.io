# source

> Mengeksekusi perintah dalam file pada shell saat ini.
> Informasi lebih lanjut: <https://manned.org/source>.

- Mengevaluasi konten pada file yang ditentukan:

`source {{jalan/menuju/file}}`

- Mengevaluasi konten pada file yang ditentukan (`.` adalah alias dari `source`):

`. {{jalan/menuju/file}}`
