# llvm-strings

> Perintah ini merupakan alias dari `strings`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr strings`
