# calligraflow

> Aplikasi pengolah flowchart dan diagram, bagian dari Calligra.
> Lihat juga:  `calligrastage`, `calligrawords`, `calligrasheets`.
> Informasi lebih lanjut: <https://manned.org/calligraflow>.

- Buka aplikasi pengolah flowchart dan diagram:

`calligraflow`

- Buka suatu berkas:

`calligraflow {{jalan/menuju/berkas}}`

- Tampilkan informasi bantuan atau versi aplikasi:

`calligraflow --{{help|version}}`
