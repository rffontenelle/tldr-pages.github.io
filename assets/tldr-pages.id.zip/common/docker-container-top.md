# docker-container-top

> Perintah ini merupakan alias dari `docker top`.
> Informasi lebih lanjut: <https://docs.docker.com/engine/reference/commandline/top>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr docker top`
