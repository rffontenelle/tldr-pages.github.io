# lzmore

> Perintah ini merupakan alias dari `xzmore`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xzmore`
