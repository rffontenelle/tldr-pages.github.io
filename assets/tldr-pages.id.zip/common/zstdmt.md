# zstdmt

> Perintah ini merupakan alias dari `zstd`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr zstd`
