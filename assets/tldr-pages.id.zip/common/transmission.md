# transmission

> Perintah ini merupakan alias dari `transmission-daemon`.
> Informasi lebih lanjut: <https://transmissionbt.com/>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr transmission-daemon`
