# platformio

> Perintah ini merupakan alias dari `pio`.
> Informasi lebih lanjut: <https://docs.platformio.org/en/latest/core/userguide/>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr pio`
