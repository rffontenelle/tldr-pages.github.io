# ivpn

> Antarmuka baris perintah bagi program klien layanan jaringan privat virtual (VPN) IVPN.
> Lihat juga: `fastd`, `mozillavpn`, `mullvad`, `warp-cli`.
> Informasi lebih lanjut: <https://www.ivpn.net>.

- Tampilkan status layanan IVPN, termasuk kondisi koneksi dan firewall:

`ivpn status`

- Tampilkan daftar peladen (server) yang dapat dihubungkan:

`ivpn servers`
