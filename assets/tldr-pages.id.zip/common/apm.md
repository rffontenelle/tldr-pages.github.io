# apm

> Manajer paket untuk aplikasi pengolah teks Atom.
> Lihat juga: `atom`.
> Informasi lebih lanjut: <https://github.com/atom/apm>.

- Pasang suatu paket dari <http://atom.io/packages> atau tema dari <http://atom.io/themes>:

`apm install {{nama_paket}}`

- Hapus pemasangan suatu paket atau tema:

`apm remove {{nama_paket}}`

- Mutakhirkan paket atau tema menuju versi terbaru:

`apm upgrade {{nama_paket}}`
