# rcat

> Perintah ini merupakan alias dari `rc`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr rc`
