# git coauthor

> Tambahkan penulis komit baru dalam komit terkini. Perintah ini menulis ulang riwayat perubahan pada Git, karena itu opsi `--force` akan dibutuhkan saat melakukan pendorongan perubahan (push) di lain waktu.
> Bagian dari `git extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-coauthor>.

- Tambahkan penulis baru terkadap komit Git terakhir:

`git coauthor {{nama}} {{nama@example.com}}`
