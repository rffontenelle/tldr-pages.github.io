# unlzma

> Perintah ini merupakan alias dari `xz`.
> Informasi lebih lanjut: <https://manned.org/unlzma>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr xz`
