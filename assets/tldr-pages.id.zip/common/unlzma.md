# unlzma

> Perintah ini merupakan alias dari `xz`.
> Informasi lebih lanjut: <https://manned.org/unlzma>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xz`
