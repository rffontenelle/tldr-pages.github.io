# docker-container-rm

> Perintah ini merupakan alias dari `docker rm`.
> Informasi lebih lanjut: <https://docs.docker.com/engine/reference/commandline/rm>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr docker rm`
