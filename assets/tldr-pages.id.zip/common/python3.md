# python3

> Perintah ini merupakan alias dari `python`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr python`
