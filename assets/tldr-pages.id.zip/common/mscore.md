# mscore

> Perintah ini merupakan alias dari `musescore`.
> Informasi lebih lanjut: <https://musescore.org/handbook/command-line-options>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr musescore`
