# docker-container-rename

> Perintah ini merupakan alias dari `docker rename`.
> Informasi lebih lanjut: <https://docs.docker.com/engine/reference/commandline/rename>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr docker rename`
