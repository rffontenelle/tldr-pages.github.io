# gitstats

> Buat laporan statistika atas repositori Git.
> Informasi lebih lanjut: <https://gitstats.sourceforge.net>.

- Buat laporan statistik terhadap suatu repositori lokal:

`gitstats {{jalan/menuju/repo_git/.git}} {{jalan/menuju/direktori_luaran}}`

- Lihat hasil laporan dalam suatu peramban web dalam Windows (PowerShell)/macOS/Linux:

`{{Invoke-Item|open|xdg-open}} {{jalan/menuju/direktori_luaran/index.html}}`
