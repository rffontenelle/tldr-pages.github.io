# linode-cli

> Perintah ini merupakan alias dari `linode-cli account`.
> Informasi lebih lanjut: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr linode-cli account`
