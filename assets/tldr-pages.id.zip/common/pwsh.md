# pwsh

> Perintah ini merupakan alias dari `powershell`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr powershell`
