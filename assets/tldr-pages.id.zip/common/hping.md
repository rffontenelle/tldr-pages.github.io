# hping

> Perintah ini merupakan alias dari `hping3`.
> Informasi lebih lanjut: <https://github.com/antirez/hping>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr hping3`
