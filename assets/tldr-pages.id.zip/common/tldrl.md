# tldrl

> Perintah ini merupakan alias dari `tldr-lint`.
> Informasi lebih lanjut: <https://github.com/tldr-pages/tldr-lint>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr tldr-lint`
