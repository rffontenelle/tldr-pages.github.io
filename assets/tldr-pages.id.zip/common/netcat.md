# netcat

> Perintah ini merupakan alias dari `nc`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr nc`
