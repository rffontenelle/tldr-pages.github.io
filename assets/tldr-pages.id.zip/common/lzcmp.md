# lzcmp

> Perintah ini merupakan alias dari `xzcmp`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xzcmp`
