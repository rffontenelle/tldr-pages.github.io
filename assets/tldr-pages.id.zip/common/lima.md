# lima

> Perintah ini merupakan alias dari `limactl`.
> Informasi lebih lanjut: <https://github.com/lima-vm/lima>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr limactl`
