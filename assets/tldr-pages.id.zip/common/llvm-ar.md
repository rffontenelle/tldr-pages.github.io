# llvm-ar

> Perintah ini merupakan alias dari `ar`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ar`
