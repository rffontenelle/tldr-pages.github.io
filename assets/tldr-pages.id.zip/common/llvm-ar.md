# llvm-ar

> Perintah ini merupakan alias dari `ar`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr ar`
