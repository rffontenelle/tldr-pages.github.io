# kafkacat

> Perintah ini merupakan alias dari `kcat`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr kcat`
