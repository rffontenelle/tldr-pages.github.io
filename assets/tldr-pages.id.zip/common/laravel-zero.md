# laravel-zero

> Pemasang Laravel Zero framework berbasis command-line.
> Informasi lebih lanjut: <https://laravel-zero.com>.

- Buat aplikasi Laravel Zero baru:

`laravel-zero new {{nama}}`

- Perbarui pemasang ke versi terkini:

`laravel-zero self-update`

- Lis perintah yang tersedia:

`laravel-zero list`
