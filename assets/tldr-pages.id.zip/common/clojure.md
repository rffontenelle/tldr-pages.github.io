# clojure

> Perintah ini merupakan alias dari `clj`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr clj`
