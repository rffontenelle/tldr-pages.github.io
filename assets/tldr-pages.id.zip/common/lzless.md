# lzless

> Perintah ini merupakan alias dari `xzless`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xzless`
