# docker-container-diff

> Perintah ini merupakan alias dari `docker diff`.
> Informasi lebih lanjut: <https://docs.docker.com/engine/reference/commandline/diff>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr docker diff`
