# ntl

> Perintah ini merupakan alias dari `netlify`.
> Informasi lebih lanjut: <https://cli.netlify.com>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr netlify`
