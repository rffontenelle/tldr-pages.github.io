# cd

> Mengganti direktori yang dikunjungi saat ini.
> Informasi lebih lanjut: <https://manned.org/cd>.

- Menuju ke direktori yang telah ditentukan:

`cd {{lokasi/ke/direktori}}`

- Menuju ke direktori pangkal/home milik pengguna:

`cd`

- Menuju ke induk direktori dari direktori saat ini:

`cd ..`

- Menuju direktori yang telah dikunjungi sebelumnya:

`cd -`
