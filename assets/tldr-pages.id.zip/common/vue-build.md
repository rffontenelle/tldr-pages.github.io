# vue build

> Sub-perintah yang disediakan oleh `@vue/cli` dan `@vue/cli-service-global` yang memungkinkan prototipe cepat.
> Informasi lebih lanjut: <https://cli.vuejs.org/guide/prototyping.html>.

- Membangun berkas `.js` or `.vue` pada mode produksi tanpa konfigurasi:

`vue build {{nama_file}}`
