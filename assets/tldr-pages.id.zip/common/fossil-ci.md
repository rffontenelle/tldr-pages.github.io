# fossil-ci

> Perintah ini merupakan alias dari `fossil-commit`.
> Informasi lebih lanjut: <https://fossil-scm.org/home/help/commit>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr fossil-commit`
