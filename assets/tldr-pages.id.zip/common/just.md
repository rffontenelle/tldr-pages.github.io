# just

> Perintah ini merupakan alias dari `just.1`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr just.1`
