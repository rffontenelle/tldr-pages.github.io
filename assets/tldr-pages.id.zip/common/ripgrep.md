# ripgrep

> Perintah ini merupakan alias dari `rg`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr rg`
