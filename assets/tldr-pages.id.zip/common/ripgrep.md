# ripgrep

> Perintah ini merupakan alias dari `rg`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr rg`
