# xzegrep

> Perintah ini merupakan alias dari `xzgrep`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xzgrep`
