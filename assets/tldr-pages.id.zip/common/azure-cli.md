# azure-cli

> Perintah ini merupakan alias dari `az`.
> Informasi lebih lanjut: <https://learn.microsoft.com/cli/azure>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr az`
