# nm-classic

> Perintah ini merupakan alias dari `nm`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr nm`
