# lzcat

> Perintah ini merupakan alias dari `xz`.
> Informasi lebih lanjut: <https://manned.org/lzcat>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr xz`
