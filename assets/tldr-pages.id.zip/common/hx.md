# hx

> Perintah ini merupakan alias dari `helix`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr helix`
