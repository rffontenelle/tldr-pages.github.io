# fossil new

> Perintah ini merupakan alias dari  `fossil init`.
> Informasi lebih lanjut: <https://fossil-scm.org/home/help/new>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fossil-init`
