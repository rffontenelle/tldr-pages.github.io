# exit

> Keluar dari sesi shell.
> Informasi lebih lanjut: <https://manned.org/exit.1posix>.

- Keluar dengan kode status keluar (exit code) yang berasal dari hasil eksekusi perintah sebelumnya:

`exit`

- Keluar dengan kode status keluar khusus:

`exit {{exit_code}}`
