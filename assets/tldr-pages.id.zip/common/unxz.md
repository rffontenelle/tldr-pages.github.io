# unxz

> Perintah ini merupakan alias dari `xz`.
> Informasi lebih lanjut: <https://manned.org/unxz>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xz`
