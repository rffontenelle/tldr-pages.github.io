# calligrastage

> Aplikasi presentasi, bagian dari Calligra.
> Lihat juga: `calligraflow`, `calligrawords`, `calligrasheets`.
> Informasi lebih lanjut: <https://manned.org/calligrastage>.

- Buka aplikasi presentasi:

`calligrastage`

- Buka suatu berkas:

`calligrastage {{jalan/menuju/berkas}}`

- Tampilkan informasi bantuan atau versi aplikasi:

`calligrastage --{{help|version}}`
