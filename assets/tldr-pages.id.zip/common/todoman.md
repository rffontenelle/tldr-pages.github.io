# todoman

> Perintah ini merupakan alias dari `todo`.
> Informasi lebih lanjut: <https://todoman.readthedocs.io/>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr todo`
