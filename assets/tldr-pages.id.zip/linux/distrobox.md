# distrobox

> Perintah ini merupakan alias dari `distrobox-create`.
> Informasi lebih lanjut: <https://github.com/89luca89/distrobox>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr distrobox-create`
