# ip6tables-save

> Perintah ini merupakan alias dari `iptables-save`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr iptables-save`
