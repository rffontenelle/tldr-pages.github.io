# ip6tables-restore

> Perintah ini merupakan alias dari `iptables-restore`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr iptables-restore`
