# shntool-split

> Perintah ini merupakan alias dari `shnsplit`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr shnsplit`
