# cc

> Perintah ini merupakan alias dari `gcc`.
> Informasi lebih lanjut: <https://gcc.gnu.org>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr gcc`
