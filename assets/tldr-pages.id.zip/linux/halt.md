# halt

> Hentikan sistem.
> Informasi lebih lanjut: <https://manned.org/halt.8>.

- Hentikan sistem:

`halt`

- Matikan sistem (sama seperti `poweroff`):

`halt --poweroff`

- Reboot sistem (sama seperti `reboot`):

`halt --reboot`

- Berhenti segera tanpa menghubungi manajer sistem:

`halt --force --force`

- Tulis entri wtmp shutdown tanpa menghentikan sistem:

`halt --wtmp-only`
