# halt

> Hentikan sistem.
> Informasi lebih lanjut: <https://www.man7.org/linux/man-pages/man8/halt.8.html>.

- Hentikan sistem:

`halt`

- Matikan sistem (sama seperti `poweroff`):

`halt --poweroff`

- Reboot sistem (sama seperti `reboot`):

`halt --reboot`

- Berhenti segera tanpa menghubungi manajer sistem:

`halt --force --force`

- Tulis entri wtmp shutdown tanpa menghentikan sistem:

`halt --wtmp-only`
