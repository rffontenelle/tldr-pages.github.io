# a2ensite

> Izinkan sebuah host maya (virtual host) Apache pada OS berbasis Debian.
> Informasi lebih lanjut: <https://manned.org/a2ensite.8>.

- Izinkan sebuah host maya:

`sudo a2ensite {{host_maya}}`

- Jangan tampilkan pesan informatif:

`sudo a2ensite --quiet {{host_maya}}`
