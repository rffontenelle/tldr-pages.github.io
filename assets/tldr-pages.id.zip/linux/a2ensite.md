# a2ensite

> Izinkan sebuah host maya (virtual host) Apache pada OS berbasis Debian.
> Informasi lebih lanjut: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Izinkan sebuah host maya:

`sudo a2ensite {{host_maya}}`

- Jangan tampilkan pesan informatif:

`sudo a2ensite --quiet {{host_maya}}`
