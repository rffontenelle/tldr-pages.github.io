# ncal

> Perintah ini merupakan alias dari `cal`.
> Informasi lebih lanjut: <https://manned.org/ncal>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr cal`
