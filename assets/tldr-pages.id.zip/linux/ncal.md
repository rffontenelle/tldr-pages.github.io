# ncal

> Perintah ini merupakan alias dari `cal`.
> Informasi lebih lanjut: <https://manned.org/ncal>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr cal`
