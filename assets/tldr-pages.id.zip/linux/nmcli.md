# nmcli

> Perintah ini merupakan alias dari `nmcli agent`.
> Informasi lebih lanjut: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr nmcli agent`
