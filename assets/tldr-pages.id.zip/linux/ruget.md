# ruget

> Alternatif untuk wget yang ditulis dalam Rust.
> Informasi lebih lanjut: <https://github.com/ksk001100/ruget>.

- Unduh konten URL ke file:

`ruget {{https://contoh.com/file}}`

- Unduh konten URL ke file [o]utput tertentu:

`ruget --output {{nama_file}} {{https://contoh.com/file}}`
