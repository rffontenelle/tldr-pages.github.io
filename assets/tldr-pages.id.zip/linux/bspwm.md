# bspwm

> Perintah ini merupakan alias dari `bspc`.
> Informasi lebih lanjut: <https://github.com/baskerville/bspwm>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr bspc`
