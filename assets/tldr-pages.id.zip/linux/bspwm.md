# bspwm

> Perintah ini merupakan alias dari `bspc`.
> Informasi lebih lanjut: <https://github.com/baskerville/bspwm>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr bspc`
