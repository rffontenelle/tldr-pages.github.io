# batcat

> Perintah ini merupakan alias dari `bat`.
> Informasi lebih lanjut: <https://github.com/sharkdp/bat>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr bat`
