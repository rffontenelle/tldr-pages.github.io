# ip-route-list

> Perintah ini merupakan alias dari `ip-route-show`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr ip-route-show`
