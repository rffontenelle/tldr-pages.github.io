# ip route list

> Perintah ini merupakan alias dari  `ip route show`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ip-route-show`
