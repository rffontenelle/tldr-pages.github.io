# qm-resize

> Perintah ini merupakan alias dari `qm-disk-resize`.
> Informasi lebih lanjut: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr qm-disk-resize`
