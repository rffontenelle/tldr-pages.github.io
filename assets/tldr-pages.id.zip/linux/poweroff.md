# poweroff

> Matikan sistem.
> Informasi lebih lanjut: <https://www.manned.org/poweroff>.

- Matikan sistem:

`poweroff`

- Hentikan sistem (sama seperti `halt`):

`poweroff --halt`

- Reboot sistem (sama seperti `reboot`):

`poweroff --reboot`

- Matikan segera tanpa menghubungi manajer sistem:

`poweroff --force --force`

- Tulis entri wtmp shutdown tanpa mematikan sistem:

`poweroff --wtmp-only`
