# apx

> Perintah ini merupakan alias dari `apx pkgmanagers`.
> Informasi lebih lanjut: <https://github.com/Vanilla-OS/apx>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr apx pkgmanagers`
