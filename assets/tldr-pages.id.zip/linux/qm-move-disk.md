# qm-move-disk

> Perintah ini merupakan alias dari `qm-disk-move`.
> Informasi lebih lanjut: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr qm-disk-move`
