# systemd-umount

> Perintah ini merupakan alias dari `systemd-mount`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr systemd-mount`
