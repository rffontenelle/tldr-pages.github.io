# ip6tables

> Perintah ini merupakan alias dari `iptables`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr iptables`
