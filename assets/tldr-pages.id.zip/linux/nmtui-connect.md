# nmtui-connect

> Perintah ini merupakan alias dari `nmtui`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr nmtui`
