# qm-importdisk

> Perintah ini merupakan alias dari `qm disk import`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr qm disk import`
