# pkgctl

> Perintah ini merupakan alias dari `pkgctl auth`.
> Informasi lebih lanjut: <https://man.archlinux.org/man/pkgctl.1>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr pkgctl auth`
