# xbps

> Perintah ini merupakan alias dari `xbps-install`.
> Informasi lebih lanjut: <https://docs.voidlinux.org/xbps/index.html>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr xbps-install`
