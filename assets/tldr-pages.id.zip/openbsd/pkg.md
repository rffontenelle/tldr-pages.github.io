# pkg

> Perintah ini merupakan alias dari `pkg_add`.
> Informasi lebih lanjut: <https://www.openbsd.org/faq/faq15.html>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr pkg_add`
