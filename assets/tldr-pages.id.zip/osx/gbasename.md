# gbasename

> Perintah ini merupakan alias dari `-p linux basename`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux basename`
