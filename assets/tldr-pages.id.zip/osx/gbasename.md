# gbasename

> Perintah ini merupakan alias dari `-p linux basename`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux basename`
