# gsplit

> Perintah ini merupakan alias dari `-p linux split`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux split`
