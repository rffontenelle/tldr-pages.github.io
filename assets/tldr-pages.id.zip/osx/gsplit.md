# gsplit

> Perintah ini merupakan alias dari `-p linux split`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux split`
