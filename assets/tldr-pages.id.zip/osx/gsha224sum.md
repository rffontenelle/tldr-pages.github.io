# gsha224sum

> Perintah ini merupakan alias dari `-p linux sha224sum`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux sha224sum`
