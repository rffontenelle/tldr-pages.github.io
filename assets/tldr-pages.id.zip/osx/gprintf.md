# gprintf

> Perintah ini merupakan alias dari `-p linux printf`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux printf`
