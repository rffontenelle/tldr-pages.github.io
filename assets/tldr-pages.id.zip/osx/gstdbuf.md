# gstdbuf

> Perintah ini merupakan alias dari `-p linux stdbuf`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux stdbuf`
