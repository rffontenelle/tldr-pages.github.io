# grealpath

> Perintah ini merupakan alias dari `-p linux realpath`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux realpath`
