# gbasenc

> Perintah ini merupakan alias dari `-p linux basenc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux basenc`
