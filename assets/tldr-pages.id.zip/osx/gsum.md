# gsum

> Perintah ini merupakan alias dari `-p linux sum`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux sum`
