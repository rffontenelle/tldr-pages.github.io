# gtest

> Perintah ini merupakan alias dari `-p linux test`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux test`
