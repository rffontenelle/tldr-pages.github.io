# gtest

> Perintah ini merupakan alias dari `-p linux test`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux test`
