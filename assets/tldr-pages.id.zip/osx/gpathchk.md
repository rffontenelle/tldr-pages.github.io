# gpathchk

> Perintah ini merupakan alias dari `-p linux pathchk`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux pathchk`
