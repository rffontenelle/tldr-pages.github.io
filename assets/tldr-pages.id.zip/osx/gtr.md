# gtr

> Perintah ini merupakan alias dari `-p linux tr`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tr`
