# gifconfig

> Perintah ini merupakan alias dari `-p linux ifconfig`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux ifconfig`
