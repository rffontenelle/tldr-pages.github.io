# gunlink

> Perintah ini merupakan alias dari `-p linux unlink`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux unlink`
