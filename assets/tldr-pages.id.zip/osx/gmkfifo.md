# gmkfifo

> Perintah ini merupakan alias dari `-p linux mkfifo`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux mkfifo`
