# gshuf

> Perintah ini merupakan alias dari `-p linux shuf`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux shuf`
