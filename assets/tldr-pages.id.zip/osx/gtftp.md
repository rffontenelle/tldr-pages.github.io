# gtftp

> Perintah ini merupakan alias dari `-p linux tftp`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tftp`
