# gtime

> Perintah ini merupakan alias dari `-p linux time`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux time`
