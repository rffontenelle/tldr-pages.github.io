# gcksum

> Perintah ini merupakan alias dari `-p linux cksum`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux cksum`
