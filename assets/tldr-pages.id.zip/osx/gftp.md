# gftp

> Perintah ini merupakan alias dari `-p linux ftp`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux ftp`
