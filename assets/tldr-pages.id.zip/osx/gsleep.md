# gsleep

> Perintah ini merupakan alias dari `-p linux sleep`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux sleep`
