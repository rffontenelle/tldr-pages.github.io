# gjoin

> Perintah ini merupakan alias dari `-p linux join`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux join`
