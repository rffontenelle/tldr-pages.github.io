# gping6

> Perintah ini merupakan alias dari `-p linux ping6`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux ping6`
