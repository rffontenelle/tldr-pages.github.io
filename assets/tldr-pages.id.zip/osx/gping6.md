# gping6

> Perintah ini merupakan alias dari `-p linux ping6`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux ping6`
