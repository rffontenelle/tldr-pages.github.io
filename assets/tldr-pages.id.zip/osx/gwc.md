# gwc

> Perintah ini merupakan alias dari `-p linux wc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux wc`
