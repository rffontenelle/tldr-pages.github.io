# gwc

> Perintah ini merupakan alias dari `-p linux wc`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux wc`
