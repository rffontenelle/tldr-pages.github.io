# aa

> Perintah ini merupakan alias dari `yaa`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr yaa`
