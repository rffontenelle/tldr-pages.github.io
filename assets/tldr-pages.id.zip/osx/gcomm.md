# gcomm

> Perintah ini merupakan alias dari `-p linux comm`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux comm`
