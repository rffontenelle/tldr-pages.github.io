# gstat

> Perintah ini merupakan alias dari `-p linux stat`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux stat`
