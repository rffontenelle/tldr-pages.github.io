# genv

> Perintah ini merupakan alias dari `-p linux env`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux env`
