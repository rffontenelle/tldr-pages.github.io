# genv

> Perintah ini merupakan alias dari `-p linux env`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux env`
