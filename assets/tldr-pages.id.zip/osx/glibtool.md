# glibtool

> Perintah ini merupakan alias dari `-p linux libtool`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux libtool`
