# gexpand

> Perintah ini merupakan alias dari `-p linux expand`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux expand`
