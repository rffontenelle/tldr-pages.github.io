# gexpand

> Perintah ini merupakan alias dari `-p linux expand`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux expand`
