# gmake

> Perintah ini merupakan alias dari `-p linux make`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux make`
