# gnice

> Perintah ini merupakan alias dari `-p linux nice`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux nice`
