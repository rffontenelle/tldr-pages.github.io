# gmkdir

> Perintah ini merupakan alias dari `-p linux mkdir`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux mkdir`
