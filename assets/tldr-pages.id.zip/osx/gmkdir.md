# gmkdir

> Perintah ini merupakan alias dari `-p linux mkdir`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux mkdir`
