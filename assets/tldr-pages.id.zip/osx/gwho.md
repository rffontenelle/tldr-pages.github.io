# gwho

> Perintah ini merupakan alias dari `-p linux who`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux who`
