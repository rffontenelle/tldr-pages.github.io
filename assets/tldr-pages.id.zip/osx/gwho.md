# gwho

> Perintah ini merupakan alias dari `-p linux who`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux who`
