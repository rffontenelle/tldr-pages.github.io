# gdd

> Perintah ini merupakan alias dari `-p linux dd`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux dd`
