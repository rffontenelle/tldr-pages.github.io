# gnumfmt

> Perintah ini merupakan alias dari `-p linux numfmt`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux numfmt`
