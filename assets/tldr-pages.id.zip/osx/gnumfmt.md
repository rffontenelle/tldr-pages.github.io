# gnumfmt

> Perintah ini merupakan alias dari `-p linux numfmt`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux numfmt`
