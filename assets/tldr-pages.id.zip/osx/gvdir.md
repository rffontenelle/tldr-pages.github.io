# gvdir

> Perintah ini merupakan alias dari `-p linux vdir`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux vdir`
