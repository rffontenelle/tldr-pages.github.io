# llvm-lipo

> Perintah ini merupakan alias dari `lipo`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr lipo`
