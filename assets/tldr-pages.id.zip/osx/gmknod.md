# gmknod

> Perintah ini merupakan alias dari `-p linux mknod`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux mknod`
