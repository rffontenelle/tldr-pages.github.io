# gmknod

> Perintah ini merupakan alias dari `-p linux mknod`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux mknod`
