# ginstall

> Perintah ini merupakan alias dari `-p linux install`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux install`
