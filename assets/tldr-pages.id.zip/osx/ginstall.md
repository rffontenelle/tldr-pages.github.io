# ginstall

> Perintah ini merupakan alias dari `-p linux install`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux install`
