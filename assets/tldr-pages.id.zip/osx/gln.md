# gln

> Perintah ini merupakan alias dari `-p linux ln`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux ln`
