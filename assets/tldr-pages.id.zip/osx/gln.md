# gln

> Perintah ini merupakan alias dari `-p linux ln`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux ln`
