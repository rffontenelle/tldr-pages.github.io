# gtelnet

> Perintah ini merupakan alias dari `-p linux telnet`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux telnet`
