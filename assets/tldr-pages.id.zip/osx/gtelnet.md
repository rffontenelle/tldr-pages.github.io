# gtelnet

> Perintah ini merupakan alias dari `-p linux telnet`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux telnet`
