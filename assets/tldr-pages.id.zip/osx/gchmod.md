# gchmod

> Perintah ini merupakan alias dari `-p linux chmod`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux chmod`
