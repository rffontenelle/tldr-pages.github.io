# gmktemp

> Perintah ini merupakan alias dari `-p linux mktemp`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux mktemp`
