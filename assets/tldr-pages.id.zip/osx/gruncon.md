# gruncon

> Perintah ini merupakan alias dari `-p linux runcon`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux runcon`
