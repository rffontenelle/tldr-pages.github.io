# gchgrp

> Perintah ini merupakan alias dari `-p linux chgrp`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux chgrp`
