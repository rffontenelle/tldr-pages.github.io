# greadlink

> Perintah ini merupakan alias dari `-p linux readlink`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux readlink`
