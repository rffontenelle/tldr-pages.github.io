# glogname

> Perintah ini merupakan alias dari `-p linux logname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux logname`
