# pbpaste

> Mengirim isi papan klip (clipboard) ke output standar.
> Informasi lebih lanjut: <https://ss64.com/osx/pbpaste.html>.

- Menulis konten papan klip ke dalam sebuah file:

`pbpaste > {{file}}`

- Menggunakan konten papan klip sebagai input bagi sebuah perintah:

`pbpaste | grep foo`
