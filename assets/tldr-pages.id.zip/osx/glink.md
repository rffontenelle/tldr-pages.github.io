# glink

> Perintah ini merupakan alias dari `-p linux link`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux link`
