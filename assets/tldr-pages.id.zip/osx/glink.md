# glink

> Perintah ini merupakan alias dari `-p linux link`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux link`
