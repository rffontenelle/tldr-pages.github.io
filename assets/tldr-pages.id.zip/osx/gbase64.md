# gbase64

> Perintah ini merupakan alias dari `-p linux base64`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux base64`
