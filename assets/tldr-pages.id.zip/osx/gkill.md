# gkill

> Perintah ini merupakan alias dari `-p linux kill`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux kill`
