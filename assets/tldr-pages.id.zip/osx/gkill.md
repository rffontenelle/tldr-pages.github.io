# gkill

> Perintah ini merupakan alias dari `-p linux kill`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux kill`
