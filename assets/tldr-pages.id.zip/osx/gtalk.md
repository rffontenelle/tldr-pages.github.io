# gtalk

> Perintah ini merupakan alias dari `-p linux talk`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux talk`
