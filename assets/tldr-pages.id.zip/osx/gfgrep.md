# gfgrep

> Perintah ini merupakan alias dari `-p linux fgrep`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux fgrep`
