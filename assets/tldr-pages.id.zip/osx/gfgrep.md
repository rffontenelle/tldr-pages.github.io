# gfgrep

> Perintah ini merupakan alias dari `-p linux fgrep`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux fgrep`
