# gtail

> Perintah ini merupakan alias dari `-p linux tail`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tail`
