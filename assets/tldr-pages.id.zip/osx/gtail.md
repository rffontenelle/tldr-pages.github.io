# gtail

> Perintah ini merupakan alias dari `-p linux tail`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux tail`
