# gchroot

> Perintah ini merupakan alias dari `-p linux chroot`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux chroot`
