# gchroot

> Perintah ini merupakan alias dari `-p linux chroot`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux chroot`
