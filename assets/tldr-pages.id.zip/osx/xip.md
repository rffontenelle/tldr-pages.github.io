# xip

> Kompres atau ekstrak file dari/dalam arsip xip yang .
> Jangan gunakan alat ini untuk membuat arsip baru, karena macOS hanya menerima arsip xip yang berasal atau ditandatangani oleh Apple.
> Informasi lebih lanjut: <https://www.manpagez.com/man/1/xip/>.

- Ekstrak arsip xip ke dalam direktori saat ini:

`xip --expand {{jalan/menuju/file.xip}}`
