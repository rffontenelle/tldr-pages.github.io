# ghostname

> Perintah ini merupakan alias dari `-p linux hostname`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux hostname`
