# gunits

> Perintah ini merupakan alias dari `-p linux units`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux units`
