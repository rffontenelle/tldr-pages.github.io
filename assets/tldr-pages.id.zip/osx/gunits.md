# gunits

> Perintah ini merupakan alias dari `-p linux units`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux units`
