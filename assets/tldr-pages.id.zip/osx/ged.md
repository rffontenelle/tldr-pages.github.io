# ged

> Perintah ini merupakan alias dari `-p linux ed`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux ed`
