# gsync

> Perintah ini merupakan alias dari `-p linux sync`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux sync`
