# gsync

> Perintah ini merupakan alias dari `-p linux sync`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux sync`
