# grlogin

> Perintah ini merupakan alias dari `-p linux rlogin`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux rlogin`
