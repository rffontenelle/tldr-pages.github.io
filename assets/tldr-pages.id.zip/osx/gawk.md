# gawk

> Perintah ini merupakan alias dari `-p linux awk`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux awk`
