# gtrue

> Perintah ini merupakan alias dari `-p linux true`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux true`
