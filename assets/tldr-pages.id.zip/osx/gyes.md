# gyes

> Perintah ini merupakan alias dari `-p linux yes`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux yes`
