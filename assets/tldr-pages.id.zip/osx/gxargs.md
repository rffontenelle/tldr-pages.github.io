# gxargs

> Perintah ini merupakan alias dari `-p linux xargs`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux xargs`
