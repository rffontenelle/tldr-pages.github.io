# gchown

> Perintah ini merupakan alias dari `-p linux chown`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux chown`
