# gpaste

> Perintah ini merupakan alias dari `-p linux paste`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux paste`
