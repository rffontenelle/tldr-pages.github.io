# gid

> Perintah ini merupakan alias dari `-p linux id`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux id`
