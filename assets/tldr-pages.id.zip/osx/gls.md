# gls

> Perintah ini merupakan alias dari `-p linux ls`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux ls`
