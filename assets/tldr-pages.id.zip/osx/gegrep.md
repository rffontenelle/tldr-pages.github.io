# gegrep

> Perintah ini merupakan alias dari `-p linux egrep`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux egrep`
