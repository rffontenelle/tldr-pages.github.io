# grm

> Perintah ini merupakan alias dari `-p linux rm`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux rm`
