# gpinky

> Perintah ini merupakan alias dari `-p linux pinky`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux pinky`
