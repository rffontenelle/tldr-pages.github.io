# launchd

> Perintah ini merupakan alias dari `launchctl`.
> Informasi lebih lanjut: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr launchctl`
