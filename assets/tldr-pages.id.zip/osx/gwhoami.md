# gwhoami

> Perintah ini merupakan alias dari `-p linux whoami`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux whoami`
