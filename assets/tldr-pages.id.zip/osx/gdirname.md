# gdirname

> Perintah ini merupakan alias dari `-p linux dirname`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux dirname`
