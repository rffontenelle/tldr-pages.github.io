# gtee

> Perintah ini merupakan alias dari `-p linux tee`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux tee`
