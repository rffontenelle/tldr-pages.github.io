# gtee

> Perintah ini merupakan alias dari `-p linux tee`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tee`
