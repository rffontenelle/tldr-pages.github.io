# gmd5sum

> Perintah ini merupakan alias dari `-p linux md5sum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux md5sum`
