# gwhich

> Perintah ini merupakan alias dari `-p linux which`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux which`
