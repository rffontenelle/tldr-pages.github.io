# gwhich

> Perintah ini merupakan alias dari `-p linux which`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux which`
