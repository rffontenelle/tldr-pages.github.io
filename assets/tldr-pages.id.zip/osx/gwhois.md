# gwhois

> Perintah ini merupakan alias dari `-p linux whois`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux whois`
