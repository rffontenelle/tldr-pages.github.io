# brightness

> Menampilkan dan mengubah brightness (tingkat kecerahan) untuk internal dan external displays.
> Informasi lebih lanjut: <https://github.com/nriley/brightness>.

- Menampilkan brightness sekarang:

`brightness -l`

- Mengubah brightness menjadi 100%:

`brightness {{1}}`

- Mengubah brightness menjadi 50%:

`brightness {{0.5}}`
