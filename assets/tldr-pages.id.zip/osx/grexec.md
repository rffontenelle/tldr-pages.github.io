# grexec

> Perintah ini merupakan alias dari `-p linux rexec`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux rexec`
