# gdir

> Perintah ini merupakan alias dari `-p linux dir`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux dir`
