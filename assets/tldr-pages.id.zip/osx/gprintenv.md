# gprintenv

> Perintah ini merupakan alias dari `-p linux printenv`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux printenv`
