# xcodes runtimes

> Atur pemasangan runtime Simulator yang tersedia bagi aplikasi Xcode.
> Informasi lebih lanjut: <https://github.com/xcodesorg/xcodes>.

- Tampilkan seluruh Simulator yang tersedia bagi aplikasi Xcode:

`xcodes runtimes --include-betas`

- Unduh sebuah runtime Simulator:

`xcodes runtimes download {{nama_runtime}}`

- Unduh dan pasang sebuah runtime Simulator:

`xcodes runtimes install {{nama_runtime}}`
