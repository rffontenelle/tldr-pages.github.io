# gsha384sum

> Perintah ini merupakan alias dari `-p linux sha384sum`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux sha384sum`
