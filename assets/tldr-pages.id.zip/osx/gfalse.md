# gfalse

> Perintah ini merupakan alias dari `-p linux false`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux false`
