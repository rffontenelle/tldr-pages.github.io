# gnohup

> Perintah ini merupakan alias dari `-p linux nohup`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux nohup`
