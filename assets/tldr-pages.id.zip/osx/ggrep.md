# ggrep

> Perintah ini merupakan alias dari `-p linux grep`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux grep`
