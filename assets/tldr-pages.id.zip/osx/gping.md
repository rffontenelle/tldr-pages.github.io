# gping

> Perintah ini merupakan alias dari `-p linux ping`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux ping`
