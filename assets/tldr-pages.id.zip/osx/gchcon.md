# gchcon

> Perintah ini merupakan alias dari `-p linux chcon`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux chcon`
