# guptime

> Perintah ini merupakan alias dari `-p linux uptime`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux uptime`
