# gtsort

> Perintah ini merupakan alias dari `-p linux tsort`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tsort`
