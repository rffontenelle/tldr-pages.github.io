# gfind

> Perintah ini merupakan alias dari `-p linux find`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux find`
