# gdf

> Perintah ini merupakan alias dari `-p linux df`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux df`
