# gdf

> Perintah ini merupakan alias dari `-p linux df`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux df`
