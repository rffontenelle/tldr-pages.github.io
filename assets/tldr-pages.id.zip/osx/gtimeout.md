# gtimeout

> Perintah ini merupakan alias dari `-p linux timeout`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux timeout`
