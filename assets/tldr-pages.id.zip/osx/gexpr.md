# gexpr

> Perintah ini merupakan alias dari `-p linux expr`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux expr`
