# g[

> Perintah ini merupakan alias dari `-p linux [`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux [`
