# g[

> Perintah ini merupakan alias dari `-p linux [`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux [`
