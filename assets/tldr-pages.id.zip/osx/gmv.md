# gmv

> Perintah ini merupakan alias dari `-p linux mv`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux mv`
