# gnproc

> Perintah ini merupakan alias dari `-p linux nproc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux nproc`
