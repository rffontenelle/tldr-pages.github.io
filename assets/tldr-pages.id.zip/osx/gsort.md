# gsort

> Perintah ini merupakan alias dari `-p linux sort`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux sort`
