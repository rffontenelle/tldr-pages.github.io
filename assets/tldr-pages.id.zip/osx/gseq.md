# gseq

> Perintah ini merupakan alias dari `-p linux seq`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux seq`
