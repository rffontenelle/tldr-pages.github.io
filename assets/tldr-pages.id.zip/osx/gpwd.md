# gpwd

> Perintah ini merupakan alias dari `-p linux pwd`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux pwd`
