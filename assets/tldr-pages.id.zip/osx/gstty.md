# gstty

> Perintah ini merupakan alias dari `-p linux stty`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux stty`
