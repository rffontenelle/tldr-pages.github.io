# guniq

> Perintah ini merupakan alias dari `-p linux uniq`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux uniq`
