# guniq

> Perintah ini merupakan alias dari `-p linux uniq`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux uniq`
