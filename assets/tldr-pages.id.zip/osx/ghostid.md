# ghostid

> Perintah ini merupakan alias dari `-p linux hostid`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux hostid`
