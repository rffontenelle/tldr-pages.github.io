# ggroups

> Perintah ini merupakan alias dari `-p linux groups`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux groups`
