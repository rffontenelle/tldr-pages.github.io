# gtac

> Perintah ini merupakan alias dari `-p linux tac`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tac`
