# gcsplit

> Perintah ini merupakan alias dari `-p linux csplit`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr -p linux csplit`
