# gfold

> Perintah ini merupakan alias dari `-p linux fold`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux fold`
