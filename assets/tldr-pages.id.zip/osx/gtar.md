# gtar

> Perintah ini merupakan alias dari `-p linux tar`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr -p linux tar`
