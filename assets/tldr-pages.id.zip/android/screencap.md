# screencap

> Lakukan tangkapan (screenshot) layar perangkat Anda.
> Perintah ini hanya dapat dijalankan melalui `adb shell`.
> Informasi lebih lanjut: <https://developer.android.com/tools/adb#screencap>.

- Lakukan tangkapan layar (screenshot):

`screencap {{path/to/file}}`
