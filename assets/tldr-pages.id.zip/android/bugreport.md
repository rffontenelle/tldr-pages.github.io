# bugreport

> Tunjukkan sebuah laporan masalah bagi Android.
> Perintah ini hanya dapat digunakan di dalam `adb shell`.
> Informasi lebih lanjut: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Tunjukkan laporan masalah perangkat Android secara lengkap:

`bugreport`
