# dalvikvm

> Mesin virtual Java untuk Android.
> Informasi lebih lanjut: <https://source.android.com/devices/tech/dalvik>.

- Jalankan sebuah program Java:

`dalvikvm -classpath {{jalan/menuju/file.jar}} {{nama_kelas}}`
