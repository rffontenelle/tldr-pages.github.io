# lzless

> This command is an alias of `xzless`.

- View documentation for the original command:

`tldr xzless`
