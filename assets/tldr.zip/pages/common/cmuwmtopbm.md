# cmuwmtopbm

> Convert a CMU window manager bitmap to a PBM image.
> See also: `pbmtocmuwm`.
> More information: <https://netpbm.sourceforge.net/doc/cmuwmtopbm.html>.

- Convert a CMU window manager bitmap to a PBM image:

`cmuwmtopbm {{path/to/image.pbm}} > {{path/to/output.bmp}}`
