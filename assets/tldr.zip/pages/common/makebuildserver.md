# makebuildserver

> Create an F-Droid build server virtual machine.
> More information: <https://f-droid.org/en/docs/Build_Server_Setup/>.

- Create a new virtual machine or update an existing one (if available):

`makebuildserver`

- Force creating a fresh virtual machine:

`makebuildserver --clean`
