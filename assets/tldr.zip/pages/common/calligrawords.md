# calligrawords

> Calligra's word processor application.
> See also: `calligraflow`, `calligrastage`, `calligrasheets`.
> More information: <https://manned.org/calligrawords>.

- Launch the word processor application:

`calligrawords`

- Open a specific document:

`calligrawords {{path/to/document}}`

- Display help or version:

`calligrawords --{{help|version}}`
