# git stage

> This command is an alias of `git add`.
> More information: <https://git-scm.com/docs/git-stage>.

- View documentation for the original command:

`tldr git-add`
