# pbmtoybm

> Convert a PBM file to a Bennet Yee "face" file.
> More information: <https://netpbm.sourceforge.net/doc/pbmtoybm.html>.

- Convert a PBM image file to YBM:

`pbmtoybm {{path/to/input_file.pbm}} > {{path/to/output_file.ybm}}`
