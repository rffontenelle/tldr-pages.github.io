# false

> Returns a non-zero exit code.
> More information: <https://www.gnu.org/software/coreutils/false>.

- Return a non-zero exit code:

`false`
