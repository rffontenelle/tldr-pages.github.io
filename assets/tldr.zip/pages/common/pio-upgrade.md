# pio upgrade

> Update PlatformIO to the latest version.
> More information: <https://docs.platformio.org/en/latest/core/userguide/cmd_upgrade.html>.

- Update PlatformIO to the latest version:

`pio upgrade`

- Update PlatformIO to the latest development (unstable) version:

`pio upgrade --dev`
