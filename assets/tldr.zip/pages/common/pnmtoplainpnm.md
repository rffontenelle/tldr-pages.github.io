# pnmtoplainpnm

> This command is an alias of `pamtopnm -plain`.
> More information: <https://netpbm.sourceforge.net/doc/pnmtoplainpnm.html>.

- View documentation for the original command:

`tldr pamtopnm`
