# musl-gcc

> A wrapper around `gcc` that automatically sets options for linking against musl libc.
> All options specified are passed directly to `gcc`.
> More information: <https://manned.org/musl-gcc>.

- View documentation for `gcc`:

`tldr gcc`
