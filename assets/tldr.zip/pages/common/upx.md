# upx

> Compress or decompress executables.
> More information: <https://upx.github.io>.

- Compress executable:

`upx {{path/to/file}}`

- Decompress executable:

`upx -d {{path/to/file}}`

- Detailed help:

`upx --help`
