# xvminitoppm

> Convert an XV thumbnail picture to PPM.
> More information: <https://netpbm.sourceforge.net/doc/xvminitoppm.html>.

- Convert an XV thumbnail image file to PPM:

`xvminitoppm {{path/to/input_file}} > {{path/to/output_file.ppm}}`
