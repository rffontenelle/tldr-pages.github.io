# xzcat

> This command is an alias of `xz --decompress --stdout`.
> More information: <https://manned.org/xzcat>.

- View documentation for the original command:

`tldr xz`
