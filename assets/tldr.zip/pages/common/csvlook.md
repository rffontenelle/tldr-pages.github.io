# csvlook

> Render a CSV file in the console as a fixed-width table.
> Included in csvkit.
> More information: <https://csvkit.readthedocs.io/en/latest/scripts/csvlook.html>.

- View a CSV file:

`csvlook {{data.csv}}`
