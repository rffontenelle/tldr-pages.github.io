# hx

> This command is an alias of `helix`.

- View documentation for the original command:

`tldr helix`
