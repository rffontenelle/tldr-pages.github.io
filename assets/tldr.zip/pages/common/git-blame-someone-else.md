# git blame-someone-else

> Blame someone else for your bad code.
> More information: <https://github.com/jayphelps/git-blame-someone-else>.

- Change the committer and author of a commit:

`git blame-someone-else "{{author <someone@example.com>}}" {{commit}}`
