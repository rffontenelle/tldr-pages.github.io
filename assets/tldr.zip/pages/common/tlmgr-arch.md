# tlmgr arch

> This command is an alias of `tlmgr platform`.
> More information: <https://www.tug.org/texlive/tlmgr.html>.

- View documentation for the original command:

`tldr tlmgr platform`
