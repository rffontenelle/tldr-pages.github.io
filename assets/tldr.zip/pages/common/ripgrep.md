# ripgrep

> `ripgrep` is the common name for the command `rg`.

- View documentation for the original command:

`tldr rg`
