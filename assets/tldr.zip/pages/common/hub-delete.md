# hub delete

> Delete an existing repository on GitHub.
> More information: <https://hub.github.com/hub-delete.1.html>.

- Delete personal repo on GitHub:

`hub delete {{repo}}`
