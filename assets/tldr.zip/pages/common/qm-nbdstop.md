# qm nbdstop

> Stop embedded nbd server.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Stop embedded nbd server:

`qm nbdstop {{VM_ID}}`
