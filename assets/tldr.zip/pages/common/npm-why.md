# npm-why

> Identifies why an npm package is installed.
> More information: <https://github.com/amio/npm-why>.

- Show why an npm package is installed:

`npm-why {{package_name}}`
