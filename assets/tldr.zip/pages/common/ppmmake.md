# ppmmake

> Create a PPM image of a specified color and dimensions.
> More information: <https://netpbm.sourceforge.net/doc/ppmmake.html>.

- Create a PPM image of the specified color and dimensions:

`ppmmake {{color}} {{width}} {{height}} > {{path/to/output_file.ppm}}`
