# mispipe

> Pipe two commands and return the exit status of the first command.
> More information: <https://joeyh.name/code/moreutils/>.

- Pipe two commands and return the exit status of the first command:

`mispipe {{command1}} {{command2}}`
