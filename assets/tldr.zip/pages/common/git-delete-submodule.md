# git delete-submodule

> Delete a specific submodule from a `git` repository.
> Part of `git-extras`.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-delete-submodule>.

- Delete a specific submodule:

`git delete-submodule {{path/to/submodule}}`
