# Get-NodeInstallLocation

> Get the current Node.js installation directory for `ps-nvm`.
> Part of `ps-nvm` and can only be run under PowerShell.
> More information: <https://github.com/aaronpowell/ps-nvm>.

- Get the current Node.js installation directory:

`Get-NodeInstallLocation`
