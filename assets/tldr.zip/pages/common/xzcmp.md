# xzcmp

> Compare compressed files.
> More information: <https://manned.org/xzcmp>.

- Compare two specific files:

`xzcmp {{path/to/file1}} {{path/to/file2}}`
