# sup

> Manage a RSS feed in the current directory.
> See also: `lb`.
> More information: <https://github.com/LukeSmithxyz/lb>.

- Add an article to the RSS feed:

`sup {{path/to/file.html}}`
