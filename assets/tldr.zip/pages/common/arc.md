# arc

> Arcanist: A CLI for Phabricator.
> More information: <https://secure.phabricator.com/book/phabricator/article/arcanist/>.

- Send the changes to Differential for review:

`arc diff`

- Show pending revision information:

`arc list`

- Update Git commit messages after review:

`arc amend`

- Push Git changes:

`arc land`
