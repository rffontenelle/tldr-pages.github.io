# git gh-pages

> Create a new branch inside the current repository called `gh-pages`.
> Part of `git-extras`.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-gh-pages>.

- Create the GitHub pages branch inside the repository in the current directory:

`git gh-pages`
