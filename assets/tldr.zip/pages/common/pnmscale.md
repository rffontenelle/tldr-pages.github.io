# pnmscale

> This command has been replaced by `pamscale`.
> More information: <https://netpbm.sourceforge.net/doc/pnmscale.html>.

- View documentation for `pamscale`:

`tldr pamscale`
