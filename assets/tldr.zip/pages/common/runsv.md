# runsv

> Start and manage a runit service.
> More information: <https://manpages.ubuntu.com/manpages/latest/man8/runsv.8.html>.

- Start a runit service as the current user:

`runsv {{path/to/service}}`

- Start a runit service as root:

`sudo runsv {{path/to/service}}`
