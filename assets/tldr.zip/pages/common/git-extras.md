# git extras

> Git extension pack.
> More information: <https://github.com/tj/git-extras>.

- Install or upgrade `git-extras` commands:

`git extras update`

- Display help:

`git extras --help`

- Display version:

`git extras --version`
