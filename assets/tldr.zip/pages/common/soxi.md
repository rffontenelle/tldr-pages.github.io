# soxi

> SoXI - Sound eXchange Information, display sound file metadata.
> More information: <https://manned.org/soxi.1>.

- Display the sound file metadata:

`soxi {{path/to/file.wav}}`
