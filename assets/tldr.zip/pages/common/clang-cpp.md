# clang-cpp

> This command is an alias of `clang++`.

- View documentation for the original command:

`tldr clang++`
