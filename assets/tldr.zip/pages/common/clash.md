# clash

> A rule-based tunnel in Go.
> More information: <https://github.com/Dreamacro/clash/wiki>.

- Specify a configuration [d]irectory:

`clash -d {{path/to/directory}}`

- Specify a configuration [f]ile:

`clash -f {{path/to/configuration_file}}`
