# pgmtopgm

> Copy a PGM image file.
> More information: <https://netpbm.sourceforge.net/doc/pgmtopgm.html>.

- Copy PGM file from `stdin` to `stderr`:

`pgmtopgm`

- Display version:

`pgmtopgm -version`
