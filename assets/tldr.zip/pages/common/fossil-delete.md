# fossil delete

> This command is an alias of `fossil rm`.
> More information: <https://fossil-scm.org/home/help/delete>.

- View documentation for the original command:

`tldr fossil rm`
