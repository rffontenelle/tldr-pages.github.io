# hub branch

> Create a branch or show current branch.
> See also `git branch`.

- Show the name of the currently active branch:

`hub branch`

- Create a new branch:

`hub branch {{branch_name}}`
