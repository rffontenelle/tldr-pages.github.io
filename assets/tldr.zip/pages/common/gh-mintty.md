# gh mintty

> Display help about MinTTY integration for the GitHub CLI command.
> More information: <https://cli.github.com/manual/gh_help_mintty>.

- Display help about using `gh` with MinTTY:

`gh mintty`
