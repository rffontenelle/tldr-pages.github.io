# vectorize-pixelart

> Convert PNG pixel art graphics to SVG/EPS vector images.
> More information: <https://github.com/und3f/vectorize-pixelart>.

- Convert a PNG to a vector image format:

`vectorize-pixelart {{path/to/input.png}} {{path/to/output.svg|.eps}}`
