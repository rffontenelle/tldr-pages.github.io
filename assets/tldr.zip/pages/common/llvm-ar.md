# llvm-ar

> This command is an alias of `ar`.

- View documentation for the original command:

`tldr ar`
