# mscore

> This command is an alias of `musescore`.
> More information: <https://musescore.org/handbook/command-line-options>.

- View documentation for the original command:

`tldr musescore`
