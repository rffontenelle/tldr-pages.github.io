# sirtopnm

> Convert a Solitaire Image Recorder file to a PNM file.
> More information: <https://netpbm.sourceforge.net/doc/sirtopnm.html>.

- Convert a SIR image to a PNM file:

`sirtopnm {{path/to/input.sir}} > {{path/to/output.pnm}}`
