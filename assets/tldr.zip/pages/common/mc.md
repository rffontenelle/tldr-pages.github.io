# mc

> Midnight Commander, a TUI file manager.
> Navigate the directory structure using the arrow keys, the mouse or by typing the commands into the terminal.
> See also: `ranger`, `clifm`, `vifm`, `nautilus`.
> More information: <https://midnight-commander.org>.

- Start Midnight Commander:

`mc`

- Start Midnight Commander in black and white:

`mc -b`
