# ivpn

> Command-line interface for the IVPN client.
> More information: <https://www.ivpn.net>.

- Print the current state of IVPN, including the connection and firewall status:

`ivpn status`

- Print a list of available servers to connect to:

`ivpn servers`
