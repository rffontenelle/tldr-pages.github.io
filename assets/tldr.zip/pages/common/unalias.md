# unalias

> Remove aliases.
> More information: <https://manned.org/unalias>.

- Remove an alias:

`unalias {{alias_name}}`

- Remove all aliases:

`unalias -a`
