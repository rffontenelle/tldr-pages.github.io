# zstdmt

> This command is an alias of `zstd --threads 0` (which sets the number of working threads to the number of physical CPU cores).

- View documentation for the original command:

`tldr zstd`
