# pamtoqoi

> Convert a Netpbm image to a QOI image (Quite OK Image format).
> More information: <https://netpbm.sourceforge.net/doc/pamtoqoi.html>.

- Convert a Netpbm image to the QOI format:

`pamtoqoi {{path/to/image.pnm}} > {{path/to/output.qoi}}`
