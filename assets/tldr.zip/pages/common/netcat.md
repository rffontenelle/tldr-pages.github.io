# netcat

> This command is an alias of `nc`.

- View documentation for the original command:

`tldr nc`
