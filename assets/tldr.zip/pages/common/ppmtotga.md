# ppmtotga

> This command is superseded by `pamtotga`.
> More information: <https://netpbm.sourceforge.net/doc/ppmtotga.html>.

- View documentation for the current command:

`tldr pamtotga`
