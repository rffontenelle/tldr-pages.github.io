# fc-match

> Match available fonts.
> More information: <https://manned.org/fc-match>.

- Return a sorted list of best matching fonts:

`fc-match -s '{{DejaVu Serif}}'`
