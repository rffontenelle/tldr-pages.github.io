# git brv

> Print a list of branches, sorted by last commit date.
> Part of `git-extras`.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-brv>.

- List each branch showing date, latest commit hash and message:

`git brv`
