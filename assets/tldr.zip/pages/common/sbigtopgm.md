# sbigtopgm

> Convert an SBIG CCDOPS file to PGM.
> More information: <https://netpbm.sourceforge.net/doc/sbigtopgm.html>.

- Convert an SBIG CCDOPS image file to PGM:

`sbigtopgm {{path/to/input_file.sbig}} > {{path/to/output.pgm}}`
