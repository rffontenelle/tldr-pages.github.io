# lima

> This command is an alias of `limactl shell` for the default VM instance.
> You can also set the `$LIMA_INSTANCE` environment variable to work on a different instance.
> More information: <https://github.com/lima-vm/lima>.

- View documentation for the original command:

`tldr limactl`
