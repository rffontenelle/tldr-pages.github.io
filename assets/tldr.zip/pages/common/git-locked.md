# git locked

> List locked files in a Git repository.
> Part of `git-extras`.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-locked>.

- List all local locked files:

`git locked`
