# sindresorhus

> Sindre Sorhus's personal CLI.
> More information: <https://github.com/sindresorhus/sindresorhus-cli>.

- Start Sindre's interactive CLI:

`sindresorhus`
