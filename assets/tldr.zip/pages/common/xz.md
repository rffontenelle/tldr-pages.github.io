# xz

> Compress or decompress .xz and .lzma files.
> More information: <https://tukaani.org/xz/format.html>.

- Compress a file to the xz file format:

`xz {{path/to/file}}`

- Decompress a xz file:

`xz -d {{file.xz}}`

- Compress a file to the LZMA file format:

`xz --format={{lzma}} {{path/to/file}}`

- Decompress an LZMA file:

`xz -d --format={{lzma}} {{file.lzma}}`

- Decompress a file and write to `stdout`:

`xz -dc {{file.xz}}`

- Compress a file, but don't delete the original:

`xz -k {{path/to/file}}`

- Compress a file using the fastest compression:

`xz -0 {{path/to/file}}`

- Compress a file using the best compression:

`xz -9 {{path/to/file}}`
