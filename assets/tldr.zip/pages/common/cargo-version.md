# cargo version

> Display `cargo` version information.
> More information: <https://doc.rust-lang.org/cargo/commands/cargo-version.html>.

- Display the version of `cargo`:

`cargo version`

- Display additional build information:

`cargo version --verbose`
