# tty

> Returns terminal name.
> More information: <https://www.gnu.org/software/coreutils/tty>.

- Print the file name of this terminal:

`tty`
