# llvm-strings

> This command is an alias of `strings`.

- View documentation for the original command:

`tldr strings`
