# ptpython3

> This command is an alias of `ptpython`.

- View documentation for the original command:

`tldr ptpython`
