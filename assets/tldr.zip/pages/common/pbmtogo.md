# pbmtogo

> Convert a PBM image to a compressed GraphOn graphic.
> More information: <https://netpbm.sourceforge.net/doc/pbmtogo.html>.

- Convert a PBM image to a compressed GraphOn graphic:

`pbmtogo {{path/to/image.pbm}} > {{path/to/output.go}}`
