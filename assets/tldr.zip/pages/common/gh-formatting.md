# gh formatting

> Formatting options for JSON data exported from gh GitHub CLI command.
> More information: <https://cli.github.com/manual/gh_help_formatting>.

- Display help about formatting JSON output from `gh` using `jq`:

`gh formatting`
