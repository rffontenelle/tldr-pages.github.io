# pwsh

> This command is an alias of `powershell`.

- View documentation for the original command:

`tldr powershell`
