# pnmenlarge

> This command is superseded by `pamenlarge`.
> More information: <https://netpbm.sourceforge.net/doc/pnmenlarge.html>.

- View documentation for the current command:

`tldr pamenlarge`
