# lzma

> This command is an alias of `xz --format=lzma`.
> More information: <https://manned.org/lzma>.

- View documentation for the original command:

`tldr xz`
