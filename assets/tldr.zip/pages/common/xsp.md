# xsp

> Mono ASP.NET Web Server.
> More information: <https://www.mono-project.com/docs/web/aspnet/>.

- Listen on all interfaces (`0.0.0.0`) and port `8080`:

`xsp`

- Listen on a specific IP address and port:

`xsp --address {{127.0.0.1}} --port {{8000}}`
