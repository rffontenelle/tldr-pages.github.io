# gh cs

> This command is an alias of `gh codespace`.
> More information: <https://cli.github.com/manual/gh_codespace>.

- View documentation for the original command:

`tldr gh-codespace`
