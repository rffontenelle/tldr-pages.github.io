# zless

> View `gzip` and `xz` compressed files.
> More information: <https://manned.org/zless>.

- Page through a `gzip` compressed file with `less`:

`zless {{file.txt.gz}}`
