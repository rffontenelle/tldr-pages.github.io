# git show-unmerged-branches

> Print all branches which are not merged into the current HEAD.
> More information: <https://github.com/tj/git-extras/blob/master/Commands.md#git-show-unmerged-branches>.

- Print all branches which are not merged into the current HEAD:

`git show-unmerged-branches`
