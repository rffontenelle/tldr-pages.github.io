# go generate

> Generate Go files by running commands within source files.
> More information: <https://golang.org/cmd/go/#hdr-Generate_Go_files_by_processing_source>.

- Generate Go files by running commands within source files:

`go generate`
