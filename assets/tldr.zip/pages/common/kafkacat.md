# kafkacat

> This command is an alias of `kcat`.

- View documentation for the original command:

`tldr kcat`
