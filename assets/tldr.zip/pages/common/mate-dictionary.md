# mate-dictionary

> Look up words on dictionaries.
> More information: <https://manned.org/mate-dictionary>.

- Print a specific word definition:

`mate-dictionary --no-window --look-up '{{word}}'`

- Show similar words for a specific one in a new window:

`mate-dictionary --match '{{word}}'`
