# lzcmp

> This command is an alias of `xzcmp`.

- View documentation for the original command:

`tldr xzcmp`
