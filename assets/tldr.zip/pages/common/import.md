# import

> This command is an alias of `magick import`.

- View documentation for the original command:

`tldr magick import`
