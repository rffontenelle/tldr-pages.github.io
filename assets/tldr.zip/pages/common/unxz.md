# unxz

> This command is an alias of `xz --decompress`.
> More information: <https://manned.org/unxz>.

- View documentation for the original command:

`tldr xz`
