# vm_stat

> Show virtual memory statistics.
> More information: <https://www.unix.com/man-page/osx/1/vm_stat>.

- Display virtual memory statistics:

`vm_stat`

- Display reports every 2 seconds for 5 times:

`vm_stat -c {{5}} {{2}}`
