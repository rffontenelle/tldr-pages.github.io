# vm_stat

> Show virtual memory statistics.
> More information: <https://keith.github.io/xcode-man-pages/vm_stat.1.html>.

- Display virtual memory statistics:

`vm_stat`

- Display reports every 2 seconds for 5 times:

`vm_stat -c {{5}} {{2}}`
