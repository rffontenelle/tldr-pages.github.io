# autofsd

> Run `automount` on startup and network configuration change events.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/autofsd.8.html>.

- Start the daemon:

`autofsd`
