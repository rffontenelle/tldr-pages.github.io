# warmd

> Controls caches used during startup and login.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/warmd/>.

- Start the daemon:

`warmd`
