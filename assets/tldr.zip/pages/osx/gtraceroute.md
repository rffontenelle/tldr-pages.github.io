# gtraceroute

> This command is an alias of GNU `traceroute`.

- View documentation for the original command:

`tldr -p linux traceroute`
