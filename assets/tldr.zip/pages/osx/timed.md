# timed

> Service that synchronizes system time (e.g. using NTP).
> It should not be invoked manually.
> More information: <https://manned.org/timed>.

- Start the daemon:

`timed`
