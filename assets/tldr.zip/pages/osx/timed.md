# timed

> Service that synchronizes system time (e.g. using NTP).
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/timed.8.html>.

- Start the daemon:

`timed`
