# machine

> Print machine type.
> More information: <https://keith.github.io/xcode-man-pages/machine.1.html>.

- Print CPU architecture:

`machine`
