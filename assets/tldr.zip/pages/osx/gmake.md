# gmake

> This command is an alias of GNU `make`.

- View documentation for the original command:

`tldr -p linux make`
