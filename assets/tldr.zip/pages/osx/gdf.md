# gdf

> This command is an alias of GNU `df`.

- View documentation for the original command:

`tldr -p linux df`
