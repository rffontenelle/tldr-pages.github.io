# ctkd

> SmartCard daemon.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/ctkd/>.

- Start the daemon:

`ctkd`
