# airportd

> Manages wireless interfaces.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/airportd.8.html>.

- Start the daemon:

`airportd`
