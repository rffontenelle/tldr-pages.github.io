# webinspectord

> Relays commands between Web Inspector and remote targets like WKWebView.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/webinspectord/>.

- Start the daemon:

`webinspectord`
