# gnl

> This command is an alias of GNU `nl`.

- View documentation for the original command:

`tldr -p linux nl`
