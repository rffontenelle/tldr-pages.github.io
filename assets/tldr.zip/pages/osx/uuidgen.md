# uuidgen

> Generate new UUID (Universally Unique IDentifier) strings.
> More information: <https://www.ss64.com/osx/uuidgen.html>.

- Generate a UUID string:

`uuidgen`
