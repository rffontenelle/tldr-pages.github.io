# corebrightnessd

> Manages Night Shift.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/corebrightnessd/>.

- Start the daemon:

`corebrightnessd`
