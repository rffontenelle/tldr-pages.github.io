# gcp

> This command is an alias of GNU `cp`.

- View documentation for the original command:

`tldr -p linux cp`
