# gsha1sum

> This command is an alias of GNU `sha1sum`.

- View documentation for the original command:

`tldr -p linux sha1sum`
