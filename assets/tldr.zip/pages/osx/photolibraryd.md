# photolibraryd

> This handles all photo library requests.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/photolibraryd.8.html>.

- Start the daemon:

`photolibraryd`
