# distnoted

> Provides distributed notification services.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/distnoted.8.html>.

- Start the daemon:

`distnoted`
