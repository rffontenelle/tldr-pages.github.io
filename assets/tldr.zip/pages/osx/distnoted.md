# distnoted

> Provides distributed notification services.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/distnoted/>.

- Start the daemon:

`distnoted`
