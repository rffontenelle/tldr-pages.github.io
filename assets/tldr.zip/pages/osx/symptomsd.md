# symptomsd

> Provides services for `Symptoms.framework`.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/symptomsd/>.

- Start the daemon:

`symptomsd`
