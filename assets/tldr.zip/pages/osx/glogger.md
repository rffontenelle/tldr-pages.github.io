# glogger

> This command is an alias of GNU `logger`.

- View documentation for the original command:

`tldr -p linux logger`
