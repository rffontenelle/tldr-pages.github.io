# gsum

> This command is an alias of GNU `sum`.

- View documentation for the original command:

`tldr -p linux sum`
