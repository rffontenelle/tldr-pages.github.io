# gupdatedb

> This command is an alias of GNU `updatedb`.

- View documentation for the original command:

`tldr -p linux updatedb`
