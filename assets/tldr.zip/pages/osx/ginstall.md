# ginstall

> This command is an alias of GNU `install`.

- View documentation for the original command:

`tldr -p linux install`
