# wps

> Assists AirPort in connecting to a network using Wireless Protected Setup.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/wps/>.

- Start the daemon:

`wps`
