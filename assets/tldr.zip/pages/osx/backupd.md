# backupd

> Creates Time Machine backups and manages its backup history.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/backupd/>.

- Start the daemon:

`backupd`
