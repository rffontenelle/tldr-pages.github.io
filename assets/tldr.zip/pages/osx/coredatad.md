# coredatad

> Schedules CloudKit operations for clients of NSPersistentCloudKitContainer.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/coredatad.8.html>.

- Start the daemon:

`coredatad`
