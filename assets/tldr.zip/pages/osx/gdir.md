# gdir

> This command is an alias of GNU `dir`.

- View documentation for the original command:

`tldr -p linux dir`
