# universalaccessd

> Provides universal access services.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/universalaccessd.8.html>.

- Start the daemon:

`universalaccessd`
