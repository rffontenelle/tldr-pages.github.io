# universalaccessd

> Provides universal access services.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/universalaccessd/>.

- Start the daemon:

`universalaccessd`
