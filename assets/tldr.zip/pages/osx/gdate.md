# gdate

> This command is an alias of GNU `date`.

- View documentation for the original command:

`tldr -p linux date`
