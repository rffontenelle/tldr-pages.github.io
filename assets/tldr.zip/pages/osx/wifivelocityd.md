# wifivelocityd

> XPC helper for performing system context actions for the WiFiVelocity framework.
> It should not be invoked manually.
> More information: <http://www.manpagez.com/man/8/wifivelocityd/>.

- Start the daemon:

`wifivelocityd`
