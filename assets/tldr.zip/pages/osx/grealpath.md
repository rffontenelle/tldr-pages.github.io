# grealpath

> This command is an alias of GNU `realpath`.

- View documentation for the original command:

`tldr -p linux realpath`
