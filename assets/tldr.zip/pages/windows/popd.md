# popd

> Changes the current directory to the directory stored by the `pushd` command.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/popd>.

- Switch to directory at the top of the stack:

`popd`
