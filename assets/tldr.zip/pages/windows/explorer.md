# explorer

> The Windows File Explorer.
> More information: <https://ss64.com/nt/explorer.html>.

- Open Windows Explorer:

`explorer`

- Open Windows Explorer in the current directory:

`explorer .`

- Open Windows Explorer in a specific directory:

`explorer {{path\to\directory}}`
