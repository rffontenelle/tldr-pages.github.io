# gal

> In PowerShell, this command is an alias of `Get-Alias`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- View documentation for the original command:

`tldr get-alias`
