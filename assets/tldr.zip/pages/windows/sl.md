# sl

> In PowerShell, this command is an alias of `Set-Location`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- View documentation for the original command:

`tldr set-location`
