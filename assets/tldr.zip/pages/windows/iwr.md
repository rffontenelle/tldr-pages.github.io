# iwr

> In PowerShell, this command is an alias of `Invoke-WebRequest`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- View documentation for the original command:

`tldr invoke-webrequest`
