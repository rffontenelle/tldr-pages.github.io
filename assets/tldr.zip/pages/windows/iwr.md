# iwr

> This command is an alias of `Invoke-WebRequest` in PowerShell.

- View documentation for the original command:

`tldr invoke-webrequest`
