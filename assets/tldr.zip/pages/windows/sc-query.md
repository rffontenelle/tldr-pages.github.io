# sc query

> This command is an alias of `sc.exe query`.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-query>.

- View documentation for the original command:

`tldr sc`
