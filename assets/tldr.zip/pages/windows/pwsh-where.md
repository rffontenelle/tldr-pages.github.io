# pwsh where

> This command is an alias of `Where-Object`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- View documentation for the original command:

`tldr Where-Object`
