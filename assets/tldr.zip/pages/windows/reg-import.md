# reg import

> Import all available keys, subkeys, and values from a `.reg` file.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/reg-import>.

- Import all keys, subkeys and values from a file:

`reg import {{path\to\file.reg}}`
