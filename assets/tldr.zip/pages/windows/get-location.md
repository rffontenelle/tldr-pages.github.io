# Get-Location

> Print name of current/working directory.
> This command can only be run through PowerShell.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/get-location>.

- Print the current directory:

`Get-Location`
