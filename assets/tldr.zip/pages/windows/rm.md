# rm

> In PowerShell, this command is an alias of `Remove-Item`.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- View documentation for the original command:

`tldr remove-item`
