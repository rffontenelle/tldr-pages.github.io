# cpush

> This command is an alias of `choco push`.
> More information: <https://docs.chocolatey.org/en-us/create/commands/push>.

- See documentation for the original command:

`tldr choco-push`
