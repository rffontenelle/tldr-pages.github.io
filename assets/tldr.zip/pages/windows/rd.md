# rd

> This command is an alias of `rmdir` on Command Prompt, and subsequently `Remove-Item` in PowerShell.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- View documentation for the original Command Prompt command:

`tldr rmdir`

- View documentation for the original PowerShell command:

`tldr remove-item`
