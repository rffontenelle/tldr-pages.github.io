# sc config

> This command is an alias of `sc.exe config`.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-config>.

- View documentation for the original command:

`tldr sc`
