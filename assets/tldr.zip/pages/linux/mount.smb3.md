# mount.smb3

> This command is an alias of `mount.cifs`.
> Note: for SMB versions before 3 you have to use `mount.cifs` instead.

- View documentation for the original command:

`tldr mount.cifs`
