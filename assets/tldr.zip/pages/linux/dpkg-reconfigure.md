# dpkg-reconfigure

> Reconfigure an already installed package.
> More information: <https://manpages.debian.org/latest/debconf/dpkg-reconfigure.8.html>.

- Reconfigure one or more packages:

`dpkg-reconfigure {{package1 package2 ...}}`
