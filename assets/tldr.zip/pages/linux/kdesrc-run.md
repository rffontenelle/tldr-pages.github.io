# kdesrc-run

> Run KDE components that have been built with `kdesrc-build`.
> More information: <https://invent.kde.org/sdk/kdesrc-build>.

- Run a component:

`kdesrc-run {{component_name}}`
