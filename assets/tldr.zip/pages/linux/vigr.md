# vigr

> Edit the group file.
> More information: <https://manned.org/vigr>.

- Edit the group file:

`vigr`

- Display version:

`vigr --version`
