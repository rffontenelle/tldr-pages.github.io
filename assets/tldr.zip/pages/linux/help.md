# help

> Display information about Bash builtin commands.
> More information: <https://www.gnu.org/software/bash/manual/bash.html#index-help>.

- Display the full list of builtin commands:

`help`

- Print instructions on how to use the `while` loop construct:

`help while`

- Print instructions on how to use the `for` loop construct:

`help for`

- Print instructions on how to use `[[ ]]` for conditional commands:

`help [[ ]]`

- Print instruction on how to use `(( ))` to evaluate arithmetic expressions:

`help \( \)`

- Print instructions on how to use the `cd` command:

`help cd`
