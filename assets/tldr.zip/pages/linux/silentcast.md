# silentcast

> Silent screencast creator. Saves in `.mkv` and animated GIF formats.
> More information: <https://github.com/colinkeenan/silentcast>.

- Launch silentcast:

`silentcast`

- Launch silentcast on a specific display:

`silentcast --display={{display}}`
