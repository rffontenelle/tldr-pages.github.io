# ksvgtopng5

> Convert SVG files to PNG format.
> More information: <https://invent.kde.org/plasma/kde-cli-tools/-/blob/master/ksvgtopng/ksvgtopng.cpp>.

- Convert an SVG file (should be an absolute path) to PNG:

`ksvgtopng5 {{width}} {{height}} {{path/to/file.svg}} {{output_filename.png}}`
