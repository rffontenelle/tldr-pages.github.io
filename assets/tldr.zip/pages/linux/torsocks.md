# torsocks

> Use any application through the Tor network.
> More information: <https://gitlab.torproject.org/tpo/core/torsocks/>.

- Run a command using Tor:

`torsocks {{command}}`

- Enable or disable Tor in this shell:

`. torsocks {{on|off}}`
