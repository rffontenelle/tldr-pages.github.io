# steamos-session-select

> Manipulate which session is currently in use.
> More information: <https://gitlab.com/users/evlaV/projects>.

- Change to desktop mode:

`steamos-session-select plasma`

- Change to gamemode:

`steamos-session-select gamescope`

- Change to Wayland desktop mode:

`steamos-session-select plasma-wayland-persistent`

- Change to X11 desktop mode:

`steamos-session-select plasma-x11-persistent`
