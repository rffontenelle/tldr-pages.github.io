# mate-about

> Show information about MATE desktop environment.
> More information: <https://manned.org/mate-about>.

- Print MATE version:

`mate-about --version`
