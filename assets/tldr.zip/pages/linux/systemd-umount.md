# systemd-umount

> This command is an alias of `systemd-mount --umount`.

- View documentation for the original command:

`tldr systemd-mount`
