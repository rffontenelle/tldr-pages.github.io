# mlabel

> Set an MS-DOS volume label for FAT and VFAT filesystems.
> More information: <https://www.gnu.org/software/mtools/manual/mtools.html#mlabel>.

- Set a filesystem label:

`mlabel -i {{/dev/sda}} ::"{{new_label}}"`
