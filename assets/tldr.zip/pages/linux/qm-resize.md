# qm resize

> This command is an alias of `qm-disk-resize`.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- View documentation for the original command:

`tldr qm-disk-resize`
