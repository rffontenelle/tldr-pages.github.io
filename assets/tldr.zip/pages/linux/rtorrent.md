# rtorrent

> Download torrents over the command-line.
> More information: <https://github.com/rakshasa/rtorrent>.

- Add a torrent file or magnet to be downloaded:

`rtorrent {{torrent_or_magnet}}`

- Start the download:

`<Ctrl>S`

- View details about downloading torrent:

`->`

- Close rtorrent safely:

`<Ctrl>Q`
