# pkgctl db update

> Update the pacman database as final release step for packages that have been transfered and staged on <https://repos.archlinux.org>.
> More information: <https://man.archlinux.org/man/pkgctl-db-update.1>.

- Update the binary repository as final release step:

`pkgctl db update`
