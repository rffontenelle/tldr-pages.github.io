# systemd-resolve

> Resolve domain names, IPV4 and IPv6 addresses, DNS resource records, and services.
> Note: this tool has been renamed to `resolvectl` in new versions of `systemd`.
> More information: <https://manned.org/systemd-resolve>.

- View documentation for `resolvectl`:

`tldr resolvectl`
