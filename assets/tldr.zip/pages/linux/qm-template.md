# qm template

> Create a Proxmox VM template.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Create a template out of a specific virtual machine:

`qm template {{vm_id}}`
