# qm guest cmd

> Execute QEMU Guest Agent commands.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Execute a specific QEMU Guest Agent command:

`qm guest cmd {{virtual_machine_id}} {{fsfreeze-freeze|fsfreeze-status|fsfreeze-thaw|fstrim|get-fsinfo|...}}`
