# qm unlock

> Unlock a virtual machine in QEMU/KVM Virtual Machine Manager.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Unlock a specific virtual machine:

`qm unlock {{vm_id}}`
