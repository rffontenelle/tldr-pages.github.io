# megadl

> This command is an alias of `megatools-dl`.
> More information: <https://megatools.megous.com/man/megatools-dl.html>.

- View documentation for the original command:

`tldr megatools-dl`
