# check-dfsg-status

> Report non-free packages installed on Debian-based OSes.
> This command was formerly known as `vrms`.
> More information: <https://debian.pages.debian.net/check-dfsg-status/>.

- List non-free and contrib packages (and their description):

`check-dfsg-status`

- Only output the package names:

`check-dfsg-status --sparse`
