# fluidsynth

> Synthesize audio from MIDI files.
> More information: <https://github.com/FluidSynth/fluidsynth/wiki/UserManual>.

- Play a MIDI file:

`fluidsynth --audio-driver={{pipewire|pulseaudio}} {{path/to/soundfont.sf2}} {{path/to/file.midi}}`
