# pkgctl

> Unified command-line devtools frontend for Arch Linux.
> More information: <https://man.archlinux.org/man/pkgctl.1>.

- Download PKGBUILD of a package in a folder named `package_name`:

`pkgctl repo clone --protocol=https {{package_name}}`
