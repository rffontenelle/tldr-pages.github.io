# lz

> List all files inside a '.tar.gz' compressed archive.
> More information: <https://manned.org/lz.1>.

- List all files inside a compressed archive:

`lz {{path/to/file.tar.gz}}`
