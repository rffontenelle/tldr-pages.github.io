# rpm2cpio

> Convert an RPM package to a `cpio` archive.
> More information: <http://ftp.rpm.org/max-rpm/s1-rpm-miscellania-rpm2cpio.html>.

- Convert an RPM package to a `cpio` archive and save it as `file.cpio` in the current directory:

`rpm2cpio {{path/to/file.rpm}}}`
