# caffeine-indicator

> Manually inhibit desktop idleness with a toggle.
> More information: <https://manned.org/caffeine-indicator>.

- Manually inhibit desktop idleness with a toggle:

`caffeine-indicator`
