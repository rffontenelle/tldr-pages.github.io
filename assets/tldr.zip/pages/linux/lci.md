# lci

> LOLCODE interpreter written in C.
> More information: <https://github.com/justinmeza/lci>.

- Run a LOLCODE file:

`lci {{path/to/file}}`

- Display help:

`lci -h`

- Display version:

`lci -v`
