# ip6tables-restore

> This command is an alias of `iptables-restore` for the IPv6 firewall.

- View documentation for the original command:

`tldr iptables-restore`
