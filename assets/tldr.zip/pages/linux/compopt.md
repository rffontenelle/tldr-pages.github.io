# compopt

> Print or change the completion options for a command.
> More information: <https://manned.org/compopt>.

- Print the options for the currently executing completion:

`compopt`

- Print the completion options for given command:

`compopt {{command}}`
