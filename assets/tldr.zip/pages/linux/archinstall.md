# archinstall

> Guided Arch Linux installer with a twist.
> More information: <https://archinstall.readthedocs.io>.

- Start the interactive installer:

`archinstall`

- Start a preset installer:

`archinstall {{minimal|unattended}}`
