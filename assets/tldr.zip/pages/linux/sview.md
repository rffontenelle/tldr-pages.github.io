# sview

> Start a GUI to view and modify the state of Slurm.
> More information: <https://slurm.schedmd.com/sview.html>.

- Start a GUI to view and modify the state of Slurm:

`sview`
