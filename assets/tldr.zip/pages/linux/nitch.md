# nitch

> A small and incredibly fast system fetch written fully in Nim.
> More information: <https://github.com/ssleert/nitch>.

- Display system information (hostname, kernel, uptime, etc.):

`nitch`

- Display [h]elp:

`nitch --help`

- Display [v]ersion:

`nitch --version`
