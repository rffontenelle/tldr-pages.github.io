# auto-cpufreq

> Automatic CPU speed & power optimizer.
> More information: <https://github.com/AdnanHodzic/auto-cpufreq>.

- Run `auto-cpufreq` in a specific mode:

`sudo auto-cpufreq --{{monitor|live|update|remove|stats|force=governor}}`
