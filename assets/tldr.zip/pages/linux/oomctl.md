# oomctl

> Analyze the state stored in `systemd-oomd`.
> More information: <https://www.freedesktop.org/software/systemd/man/oomctl.html>.

- Show the current state of the cgroups and system contexts stored by `systemd-oomd`:

`oomctl dump`
