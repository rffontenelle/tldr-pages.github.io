# dhcpcd

> DHCP client.
> More information: <https://roy.marples.name/projects/dhcpcd>.

- Release all address leases:

`sudo dhcpcd --release`

- Request the DHCP server for new leases:

`sudo dhcpcd --rebind`
