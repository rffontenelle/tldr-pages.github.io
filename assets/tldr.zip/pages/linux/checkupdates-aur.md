# checkupdates-aur

> Tool to check pending updates from the Arch User Repository (AUR).
> More information: <https://metacpan.org/dist/OS-CheckUpdates-AUR>.

- List pending updates for AUR packages:

`checkupdates-aur`

- List pending updates for AUR packages in debug mode:

`CHECKUPDATES_DEBUG=1 checkupdates-aur`

- Display help:

`checkupdates-aur --help`
