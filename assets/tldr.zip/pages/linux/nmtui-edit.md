# nmtui-edit

> This command is an alias of `nmtui edit`.

- View documentation for the original command:

`tldr nmtui`
