# lddd

> Find broken library links on the system.
> This tool is only available on Arch Linux.
> More information: <https://man.archlinux.org/man/extra/devtools/lddd.1>.

- Scan directories to find and list packages with broken library links that need to be rebuilt:

`lddd`
