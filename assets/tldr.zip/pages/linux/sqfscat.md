# sqfscat

> Concatenate files from a squashfs filesystem and print them to `stdout`.
> More information: <https://manned.org/sqfscat>.

- Display the contents of one or more files from a squashfs filesystem:

`sqfscat {{filesystem.squashfs}} {{file1 file2 ...}}`
