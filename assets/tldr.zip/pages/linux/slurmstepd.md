# slurmstepd

> Slurm daemon for managing and monitoring individual job steps within a multi-step job.
> It should not be invoked manually.
> More information: <https://slurm.schedmd.com/slurmstepd.html>.

- Start the daemon:

`slurmstepd`
