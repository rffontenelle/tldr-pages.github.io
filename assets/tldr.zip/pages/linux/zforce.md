# zforce

> Add a `.gz` extension to files compressed using `gzip`.
> More information: <https://manned.org/zforce>.

- Add a `.gz` extension to the supplied Gzip files (Note: other files are ignored):

`zforce {{path/to/file1 path/to/file2 ...}}`
