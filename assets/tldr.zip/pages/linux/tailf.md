# tailf

> This command is superseded by `tail -f`.
> More information: <https://manned.org/tailf.1>.

- View documentation for the recommended replacement:

`tldr tail`
