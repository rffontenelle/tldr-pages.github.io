# broot

> Navigate directory trees interactively.
> See also: `br`.
> More information: <https://github.com/Canop/broot>.

- Install or reinstall the `br` shell function:

`broot --install`
