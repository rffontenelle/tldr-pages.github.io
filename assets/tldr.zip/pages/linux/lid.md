# lid

> NOTE: This page is currently a redirection stub. If you are familiar with this program, please open a pull request.
> Query ID database and report results.
> On Fedora and Arch Linux, the binary name `lid` is taken by another program. See `tldr libuser-lid`.
> More information: <https://www.gnu.org/software/idutils/>.

- View documentation for `libuser-lid`:

`tldr libuser-lid`
