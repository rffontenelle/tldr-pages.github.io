# repo-remove

> Package database maintenance utility which removes packages from a local repository.
> More information: <https://man.archlinux.org/man/repo-add>.

- Remove a package from a local repository:

`repo-remove {{path/to/database.db.tar.gz}} {{package}}`
