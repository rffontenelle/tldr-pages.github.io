# vipw

> Edit the password file.
> More information: <https://manned.org/vipw>.

- Edit the password file:

`vipw`

- Display version:

`vipw --version`
