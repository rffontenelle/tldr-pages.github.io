# vipw

> Edit the password file.
> More information: <https://manned.org/vipw>.

- Edit the password file:

`vipw`

- Display the current version of `vipw`:

`vipw --version`
