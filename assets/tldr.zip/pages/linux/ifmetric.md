# ifmetric

> An IPv4 route metrics manipulation tool.
> More information: <https://0pointer.de/lennart/projects/ifmetric/>.

- Set the priority of the specified network interface (a higher number indicates lower priority):

`sudo ifmetric {{interface}} {{value}}`

- Reset the priority of the specified network interface:

`sudo ifmetric {{interface}} {{0}}`
