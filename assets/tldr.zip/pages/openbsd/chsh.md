# chsh

> This command is an alias of `chpass`.

- View documentation for the original command:

`tldr chpass`
