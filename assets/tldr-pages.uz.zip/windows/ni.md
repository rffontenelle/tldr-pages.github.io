# ni

> Ushbu buyruq taxallus `new-item`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/new-item>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr new-item`
