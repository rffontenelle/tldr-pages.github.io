# cuninst

> Ushbu buyruq taxallus `choco uninstall`.
> Ko'proq malumot: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr choco uninstall`
