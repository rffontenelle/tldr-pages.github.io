# rd

> Ushbu buyruq taxallus `rmdir`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr rmdir`
