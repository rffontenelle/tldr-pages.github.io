# clear

> Ushbu buyruq taxallus `clear-host`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr clear-host`
