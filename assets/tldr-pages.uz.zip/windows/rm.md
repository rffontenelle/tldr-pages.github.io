# rm

> Ushbu buyruq taxallus `remove-item`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/remove-item>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr remove-item`
