# cpush

> Ushbu buyruq taxallus `choco-push`.
> Ko'proq malumot: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr choco-push`
