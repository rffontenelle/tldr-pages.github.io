# slmgr

> Ushbu buyruq taxallus `slmgr.vbs`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/get-started/activation-slmgr-vbs-options>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr slmgr.vbs`
