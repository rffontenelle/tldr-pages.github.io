# pwsh-where

> Ushbu buyruq taxallus `Where-Object`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr Where-Object`
