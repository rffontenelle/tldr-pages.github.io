# cd

> Ushbu buyruq taxallus `set-location`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr set-location`
