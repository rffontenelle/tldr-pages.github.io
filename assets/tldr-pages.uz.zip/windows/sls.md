# sls

> Ushbu buyruq taxallus `where-object`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr where-object`
