# del

> Ushbu buyruq taxallus `remove-item`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/del>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr remove-item`
