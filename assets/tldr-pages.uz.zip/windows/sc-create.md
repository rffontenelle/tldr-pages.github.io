# sc-create

> Ushbu buyruq taxallus `sc`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-create>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr sc`
