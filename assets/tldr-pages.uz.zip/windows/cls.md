# cls

> Ushbu buyruq taxallus `clear-host`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr clear-host`
