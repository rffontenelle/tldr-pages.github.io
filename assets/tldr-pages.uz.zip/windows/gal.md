# gal

> Ushbu buyruq taxallus `get-alias`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr get-alias`
