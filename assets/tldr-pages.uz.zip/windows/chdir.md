# chdir

> Ushbu buyruq taxallus `cd`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/chdir>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr cd`
