# iwr

> Ushbu buyruq taxallus `invoke-webrequest`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr invoke-webrequest`
