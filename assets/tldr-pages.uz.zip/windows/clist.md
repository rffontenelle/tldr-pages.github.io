# clist

> Ushbu buyruq taxallus `choco list`.
> Ko'proq malumot: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr choco list`
