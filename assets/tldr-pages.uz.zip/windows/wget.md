# wget

> Ushbu buyruq taxallus `wget -p common`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr wget -p common`
