# sc-delete

> Ushbu buyruq taxallus `sc`.
> Ko'proq malumot: <https://learn.microsoft.com/windows-server/administration/windows-commands/sc-delete>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr sc`
