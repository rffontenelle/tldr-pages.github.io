# cinst

> Ushbu buyruq taxallus `choco install`.
> Ko'proq malumot: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr choco install`
