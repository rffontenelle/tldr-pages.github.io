# sl

> Ushbu buyruq taxallus `set-location`.
> Ko'proq malumot: <https://learn.microsoft.com/powershell/module/microsoft.powershell.management/set-location>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr set-location`
