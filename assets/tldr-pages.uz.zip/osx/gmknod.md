# gmknod

> Ushbu buyruq taxallus `-p linux mknod`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux mknod`
