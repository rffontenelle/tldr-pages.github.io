# gtac

> Ushbu buyruq taxallus `-p linux tac`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tac`
