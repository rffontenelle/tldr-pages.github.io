# gvdir

> Ushbu buyruq taxallus `-p linux vdir`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux vdir`
