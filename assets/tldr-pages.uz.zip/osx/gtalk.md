# gtalk

> Ushbu buyruq taxallus `-p linux talk`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux talk`
