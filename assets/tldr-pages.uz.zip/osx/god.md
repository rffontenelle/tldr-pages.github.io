# god

> Ushbu buyruq taxallus `-p linux od`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux od`
