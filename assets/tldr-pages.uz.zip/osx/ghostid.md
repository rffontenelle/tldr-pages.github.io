# ghostid

> Ushbu buyruq taxallus `-p linux hostid`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux hostid`
