# gtest

> Ushbu buyruq taxallus `-p linux test`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux test`
