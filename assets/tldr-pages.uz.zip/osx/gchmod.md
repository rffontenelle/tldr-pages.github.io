# gchmod

> Ushbu buyruq taxallus `-p linux chmod`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux chmod`
