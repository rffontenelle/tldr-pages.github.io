# gprintf

> Ushbu buyruq taxallus `-p linux printf`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux printf`
