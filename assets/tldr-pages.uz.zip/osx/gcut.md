# gcut

> Ushbu buyruq taxallus `-p linux cut`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux cut`
