# gtty

> Ushbu buyruq taxallus `-p linux tty`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tty`
