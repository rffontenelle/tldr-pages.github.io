# gruncon

> Ushbu buyruq taxallus `-p linux runcon`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux runcon`
