# grm

> Ushbu buyruq taxallus `-p linux rm`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux rm`
