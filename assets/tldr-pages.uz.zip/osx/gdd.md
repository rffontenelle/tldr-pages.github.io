# gdd

> Ushbu buyruq taxallus `-p linux dd`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux dd`
