# gcp

> Ushbu buyruq taxallus `-p linux cp`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux cp`
