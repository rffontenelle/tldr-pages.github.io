# gjoin

> Ushbu buyruq taxallus `-p linux join`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux join`
