# ghead

> Ushbu buyruq taxallus `-p linux head`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux head`
