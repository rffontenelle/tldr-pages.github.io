# gwhois

> Ushbu buyruq taxallus `-p linux whois`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux whois`
