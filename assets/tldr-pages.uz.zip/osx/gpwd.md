# gpwd

> Ushbu buyruq taxallus `-p linux pwd`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux pwd`
