# glogname

> Ushbu buyruq taxallus `-p linux logname`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux logname`
