# gyes

> Ushbu buyruq taxallus `-p linux yes`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux yes`
