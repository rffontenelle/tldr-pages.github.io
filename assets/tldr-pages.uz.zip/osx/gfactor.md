# gfactor

> Ushbu buyruq taxallus `-p linux factor`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux factor`
