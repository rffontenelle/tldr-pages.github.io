# gpathchk

> Ushbu buyruq taxallus `-p linux pathchk`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux pathchk`
