# gptx

> Ushbu buyruq taxallus `-p linux ptx`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ptx`
