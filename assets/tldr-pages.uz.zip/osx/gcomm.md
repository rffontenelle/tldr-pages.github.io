# gcomm

> Ushbu buyruq taxallus `-p linux comm`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux comm`
