# gtail

> Ushbu buyruq taxallus `-p linux tail`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tail`
