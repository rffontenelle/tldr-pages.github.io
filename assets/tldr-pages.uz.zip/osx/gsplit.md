# gsplit

> Ushbu buyruq taxallus `-p linux split`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux split`
