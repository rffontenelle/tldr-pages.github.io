# gls

> Ushbu buyruq taxallus `-p linux ls`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ls`
