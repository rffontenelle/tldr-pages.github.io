# gdirname

> Ushbu buyruq taxallus `-p linux dirname`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux dirname`
