# gnl

> Ushbu buyruq taxallus `-p linux nl`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux nl`
