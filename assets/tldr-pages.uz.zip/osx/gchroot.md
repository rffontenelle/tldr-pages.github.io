# gchroot

> Ushbu buyruq taxallus `-p linux chroot`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux chroot`
