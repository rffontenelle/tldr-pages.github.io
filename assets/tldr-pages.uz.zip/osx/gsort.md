# gsort

> Ushbu buyruq taxallus `-p linux sort`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sort`
