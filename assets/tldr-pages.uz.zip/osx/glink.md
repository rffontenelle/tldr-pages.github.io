# glink

> Ushbu buyruq taxallus `-p linux link`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux link`
