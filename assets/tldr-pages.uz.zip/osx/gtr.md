# gtr

> Ushbu buyruq taxallus `-p linux tr`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tr`
