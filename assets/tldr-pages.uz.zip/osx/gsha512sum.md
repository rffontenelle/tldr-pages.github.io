# gsha512sum

> Ushbu buyruq taxallus `-p linux sha512sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sha512sum`
