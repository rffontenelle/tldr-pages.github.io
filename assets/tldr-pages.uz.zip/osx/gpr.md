# gpr

> Ushbu buyruq taxallus `-p linux pr`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux pr`
