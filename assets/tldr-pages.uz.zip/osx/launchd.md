# launchd

> Ushbu buyruq taxallus `launchctl`.
> Ko'proq malumot: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr launchctl`
