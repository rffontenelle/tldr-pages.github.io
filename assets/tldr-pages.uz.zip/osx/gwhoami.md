# gwhoami

> Ushbu buyruq taxallus `-p linux whoami`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux whoami`
