# gtime

> Ushbu buyruq taxallus `-p linux time`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux time`
