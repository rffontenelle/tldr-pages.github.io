# aa

> Ushbu buyruq taxallus `yaa`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr yaa`
