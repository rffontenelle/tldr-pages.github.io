# gmkdir

> Ushbu buyruq taxallus `-p linux mkdir`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux mkdir`
