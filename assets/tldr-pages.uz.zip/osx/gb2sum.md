# gb2sum

> Ushbu buyruq taxallus `-p linux b2sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux b2sum`
