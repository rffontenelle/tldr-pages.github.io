# gping6

> Ushbu buyruq taxallus `-p linux ping6`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ping6`
