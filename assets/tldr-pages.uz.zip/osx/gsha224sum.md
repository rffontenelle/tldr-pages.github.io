# gsha224sum

> Ushbu buyruq taxallus `-p linux sha224sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sha224sum`
