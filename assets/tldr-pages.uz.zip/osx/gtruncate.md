# gtruncate

> Ushbu buyruq taxallus `-p linux truncate`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux truncate`
