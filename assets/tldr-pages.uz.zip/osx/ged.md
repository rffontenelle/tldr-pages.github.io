# ged

> Ushbu buyruq taxallus `-p linux ed`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ed`
