# ghostname

> Ushbu buyruq taxallus `-p linux hostname`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux hostname`
