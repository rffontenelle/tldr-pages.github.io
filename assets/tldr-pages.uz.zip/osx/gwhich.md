# gwhich

> Ushbu buyruq taxallus `-p linux which`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux which`
