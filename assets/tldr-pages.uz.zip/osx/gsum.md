# gsum

> Ushbu buyruq taxallus `-p linux sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sum`
