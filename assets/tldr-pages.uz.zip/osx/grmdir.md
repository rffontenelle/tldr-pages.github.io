# grmdir

> Ushbu buyruq taxallus `-p linux rmdir`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux rmdir`
