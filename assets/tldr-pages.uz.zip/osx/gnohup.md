# gnohup

> Ushbu buyruq taxallus `-p linux nohup`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux nohup`
