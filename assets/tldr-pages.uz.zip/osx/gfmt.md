# gfmt

> Ushbu buyruq taxallus `-p linux fmt`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux fmt`
