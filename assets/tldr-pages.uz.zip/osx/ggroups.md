# ggroups

> Ushbu buyruq taxallus `-p linux groups`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux groups`
