# gmd5sum

> Ushbu buyruq taxallus `-p linux md5sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux md5sum`
