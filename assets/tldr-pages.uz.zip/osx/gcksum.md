# gcksum

> Ushbu buyruq taxallus `-p linux cksum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux cksum`
