# gwc

> Ushbu buyruq taxallus `-p linux wc`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux wc`
