# gupdatedb

> Ushbu buyruq taxallus `-p linux updatedb`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux updatedb`
