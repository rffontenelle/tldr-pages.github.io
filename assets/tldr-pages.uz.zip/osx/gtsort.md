# gtsort

> Ushbu buyruq taxallus `-p linux tsort`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tsort`
