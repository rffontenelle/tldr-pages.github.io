# gkill

> Ushbu buyruq taxallus `-p linux kill`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux kill`
