# gpaste

> Ushbu buyruq taxallus `-p linux paste`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux paste`
