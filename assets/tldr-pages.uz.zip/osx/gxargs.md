# gxargs

> Ushbu buyruq taxallus `-p linux xargs`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux xargs`
