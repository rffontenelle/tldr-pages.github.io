# gmkfifo

> Ushbu buyruq taxallus `-p linux mkfifo`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux mkfifo`
