# llvm-lipo

> Ushbu buyruq taxallus `lipo`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr lipo`
