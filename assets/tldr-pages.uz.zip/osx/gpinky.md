# gpinky

> Ushbu buyruq taxallus `-p linux pinky`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux pinky`
