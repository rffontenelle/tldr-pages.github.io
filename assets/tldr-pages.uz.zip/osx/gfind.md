# gfind

> Ushbu buyruq taxallus `-p linux find`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux find`
