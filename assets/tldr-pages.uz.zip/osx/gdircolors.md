# gdircolors

> Ushbu buyruq taxallus `-p linux dircolors`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux dircolors`
