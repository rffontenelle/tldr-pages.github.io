# gmv

> Ushbu buyruq taxallus `-p linux mv`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux mv`
