# ggrep

> Ushbu buyruq taxallus `-p linux grep`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux grep`
