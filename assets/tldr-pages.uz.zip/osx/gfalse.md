# gfalse

> Ushbu buyruq taxallus `-p linux false`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux false`
