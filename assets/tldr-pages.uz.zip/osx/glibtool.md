# glibtool

> Ushbu buyruq taxallus `-p linux libtool`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux libtool`
