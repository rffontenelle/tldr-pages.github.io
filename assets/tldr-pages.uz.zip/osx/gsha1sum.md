# gsha1sum

> Ushbu buyruq taxallus `-p linux sha1sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sha1sum`
