# gtar

> Ushbu buyruq taxallus `-p linux tar`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tar`
