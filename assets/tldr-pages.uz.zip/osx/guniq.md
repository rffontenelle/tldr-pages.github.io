# guniq

> Ushbu buyruq taxallus `-p linux uniq`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux uniq`
