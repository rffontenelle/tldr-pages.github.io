# greadlink

> Ushbu buyruq taxallus `-p linux readlink`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux readlink`
