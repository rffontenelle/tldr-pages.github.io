# gbase64

> Ushbu buyruq taxallus `-p linux base64`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux base64`
