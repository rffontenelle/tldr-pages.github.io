# grcp

> Ushbu buyruq taxallus `-p linux rcp`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux rcp`
