# guname

> Ushbu buyruq taxallus `-p linux uname`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux uname`
