# gchgrp

> Ushbu buyruq taxallus `-p linux chgrp`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux chgrp`
