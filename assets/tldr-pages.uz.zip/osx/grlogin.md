# grlogin

> Ushbu buyruq taxallus `-p linux rlogin`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux rlogin`
