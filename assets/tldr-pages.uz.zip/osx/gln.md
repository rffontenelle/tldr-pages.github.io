# gln

> Ushbu buyruq taxallus `-p linux ln`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ln`
