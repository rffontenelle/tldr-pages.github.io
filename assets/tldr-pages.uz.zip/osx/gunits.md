# gunits

> Ushbu buyruq taxallus `-p linux units`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux units`
