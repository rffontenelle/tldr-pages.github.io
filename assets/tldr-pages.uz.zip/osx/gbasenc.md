# gbasenc

> Ushbu buyruq taxallus `-p linux basenc`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux basenc`
