# gtimeout

> Ushbu buyruq taxallus `-p linux timeout`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux timeout`
