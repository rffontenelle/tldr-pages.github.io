# gbasename

> Ushbu buyruq taxallus `-p linux basename`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux basename`
