# guptime

> Ushbu buyruq taxallus `-p linux uptime`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux uptime`
