# gdir

> Ushbu buyruq taxallus `-p linux dir`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux dir`
