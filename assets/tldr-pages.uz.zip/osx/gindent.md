# gindent

> Ushbu buyruq taxallus `-p linux indent`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux indent`
