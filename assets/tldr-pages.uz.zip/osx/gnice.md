# gnice

> Ushbu buyruq taxallus `-p linux nice`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux nice`
