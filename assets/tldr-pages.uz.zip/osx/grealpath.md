# grealpath

> Ushbu buyruq taxallus `-p linux realpath`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux realpath`
