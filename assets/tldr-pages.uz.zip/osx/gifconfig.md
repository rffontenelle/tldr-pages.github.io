# gifconfig

> Ushbu buyruq taxallus `-p linux ifconfig`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ifconfig`
