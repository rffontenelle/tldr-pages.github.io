# gftp

> Ushbu buyruq taxallus `-p linux ftp`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ftp`
