# gseq

> Ushbu buyruq taxallus `-p linux seq`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux seq`
