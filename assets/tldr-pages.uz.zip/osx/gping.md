# gping

> Ushbu buyruq taxallus `-p linux ping`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux ping`
