# gfold

> Ushbu buyruq taxallus `-p linux fold`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux fold`
