# gfgrep

> Ushbu buyruq taxallus `-p linux fgrep`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux fgrep`
