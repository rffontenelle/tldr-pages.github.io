# gsha256sum

> Ushbu buyruq taxallus `-p linux sha256sum`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sha256sum`
