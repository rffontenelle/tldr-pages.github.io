# gecho

> Ushbu buyruq taxallus `-p linux echo`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux echo`
