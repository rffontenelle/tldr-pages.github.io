# gunlink

> Ushbu buyruq taxallus `-p linux unlink`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux unlink`
