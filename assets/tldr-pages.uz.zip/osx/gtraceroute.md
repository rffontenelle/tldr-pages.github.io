# gtraceroute

> Ushbu buyruq taxallus `-p linux traceroute`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux traceroute`
