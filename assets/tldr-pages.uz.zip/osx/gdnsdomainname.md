# gdnsdomainname

> Ushbu buyruq taxallus `-p linux dnsdomainname`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux dnsdomainname`
