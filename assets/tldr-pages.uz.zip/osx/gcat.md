# gcat

> Ushbu buyruq taxallus `-p linux cat`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux cat`
