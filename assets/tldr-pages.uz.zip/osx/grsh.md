# grsh

> Ushbu buyruq taxallus `-p linux rsh`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux rsh`
