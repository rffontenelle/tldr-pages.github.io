# glocate

> Ushbu buyruq taxallus `-p linux locate`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux locate`
