# gunexpand

> Ushbu buyruq taxallus `-p linux unexpand`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux unexpand`
