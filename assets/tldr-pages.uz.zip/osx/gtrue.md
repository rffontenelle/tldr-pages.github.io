# gtrue

> Ushbu buyruq taxallus `-p linux true`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux true`
