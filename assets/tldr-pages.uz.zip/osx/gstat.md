# gstat

> Ushbu buyruq taxallus `-p linux stat`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux stat`
