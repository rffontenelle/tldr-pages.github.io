# gexpr

> Ushbu buyruq taxallus `-p linux expr`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux expr`
