# gid

> Ushbu buyruq taxallus `-p linux id`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux id`
