# gtftp

> Ushbu buyruq taxallus `-p linux tftp`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tftp`
