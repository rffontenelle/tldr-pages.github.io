# gtouch

> Ushbu buyruq taxallus `-p linux touch`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux touch`
