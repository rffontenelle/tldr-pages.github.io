# gshuf

> Ushbu buyruq taxallus `-p linux shuf`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux shuf`
