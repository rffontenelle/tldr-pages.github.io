# gchown

> Ushbu buyruq taxallus `-p linux chown`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux chown`
