# gegrep

> Ushbu buyruq taxallus `-p linux egrep`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux egrep`
