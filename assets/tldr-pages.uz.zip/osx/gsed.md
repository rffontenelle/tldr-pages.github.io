# gsed

> Ushbu buyruq taxallus `-p linux sed`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux sed`
