# gtee

> Ushbu buyruq taxallus `-p linux tee`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux tee`
