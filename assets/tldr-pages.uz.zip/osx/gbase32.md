# gbase32

> Ushbu buyruq taxallus `-p linux base32`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux base32`
