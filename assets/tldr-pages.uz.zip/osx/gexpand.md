# gexpand

> Ushbu buyruq taxallus `-p linux expand`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr -p linux expand`
