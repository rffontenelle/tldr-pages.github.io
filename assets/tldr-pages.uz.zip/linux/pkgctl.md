# pkgctl

> Ushbu buyruq taxallus `pkgctl auth`.
> Ko'proq malumot: <https://man.archlinux.org/man/pkgctl.1>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr pkgctl auth`
