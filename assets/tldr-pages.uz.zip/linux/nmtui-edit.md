# nmtui-edit

> Ushbu buyruq taxallus `nmtui`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr nmtui`
