# nmcli

> Ushbu buyruq taxallus `nmcli agent`.
> Ko'proq malumot: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr nmcli agent`
