# cgroups

> Ushbu buyruq taxallus `cgclassify`.
> Ko'proq malumot: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr cgclassify`
