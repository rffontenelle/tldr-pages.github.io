# ip6tables

> Ushbu buyruq taxallus `iptables`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr iptables`
