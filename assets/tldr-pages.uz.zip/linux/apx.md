# apx

> Ushbu buyruq taxallus `apx pkgmanagers`.
> Ko'proq malumot: <https://github.com/Vanilla-OS/apx>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr apx pkgmanagers`
