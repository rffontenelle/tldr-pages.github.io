# ip6tables-save

> Ushbu buyruq taxallus `iptables-save`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr iptables-save`
