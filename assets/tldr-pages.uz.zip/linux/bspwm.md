# bspwm

> Ushbu buyruq taxallus `bspc`.
> Ko'proq malumot: <https://github.com/baskerville/bspwm>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr bspc`
