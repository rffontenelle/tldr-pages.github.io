# qm-move-disk

> Ushbu buyruq taxallus `qm-disk-move`.
> Ko'proq malumot: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr qm-disk-move`
