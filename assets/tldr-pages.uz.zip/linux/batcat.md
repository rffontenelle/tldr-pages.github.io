# batcat

> Ushbu buyruq taxallus `bat`.
> Ko'proq malumot: <https://github.com/sharkdp/bat>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr bat`
