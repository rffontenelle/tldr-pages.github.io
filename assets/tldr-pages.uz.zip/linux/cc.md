# cc

> Ushbu buyruq taxallus `gcc`.
> Ko'proq malumot: <https://gcc.gnu.org>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr gcc`
