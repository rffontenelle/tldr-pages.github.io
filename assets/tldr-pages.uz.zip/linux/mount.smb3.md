# mount.smb3

> Ushbu buyruq taxallus `mount.cifs`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr mount.cifs`
