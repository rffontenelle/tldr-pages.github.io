# qm-resize

> Ushbu buyruq taxallus `qm-disk-resize`.
> Ko'proq malumot: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr qm-disk-resize`
