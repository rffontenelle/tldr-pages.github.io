# qm-importdisk

> Ushbu buyruq taxallus `qm disk import`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr qm disk import`
