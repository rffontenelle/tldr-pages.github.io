# megadl

> Ushbu buyruq taxallus `megatools-dl`.
> Ko'proq malumot: <https://megatools.megous.com/man/megatools-dl.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr megatools-dl`
