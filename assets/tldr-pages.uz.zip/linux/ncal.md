# ncal

> Ushbu buyruq taxallus `cal`.
> Ko'proq malumot: <https://manned.org/ncal>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr cal`
