# ubuntu-bug

> Ushbu buyruq taxallus `apport-bug`.
> Ko'proq malumot: <https://manned.org/ubuntu-bug>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr apport-bug`
