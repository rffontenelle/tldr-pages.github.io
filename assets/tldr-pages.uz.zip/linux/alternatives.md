# alternatives

> Ushbu buyruq taxallus `update-alternatives`.
> Ko'proq malumot: <https://manned.org/alternatives>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr update-alternatives`
