# shntool-split

> Ushbu buyruq taxallus `shnsplit`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr shnsplit`
