# systemd-umount

> Ushbu buyruq taxallus `systemd-mount`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr systemd-mount`
