# ip-route-list

> Ushbu buyruq taxallus `ip-route-show`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr ip-route-show`
