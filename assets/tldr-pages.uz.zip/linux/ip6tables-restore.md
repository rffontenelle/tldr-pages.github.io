# ip6tables-restore

> Ushbu buyruq taxallus `iptables-restore`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr iptables-restore`
