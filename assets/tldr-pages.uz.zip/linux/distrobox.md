# distrobox

> Ushbu buyruq taxallus `distrobox-create`.
> Ko'proq malumot: <https://github.com/89luca89/distrobox>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr distrobox-create`
