# xbps

> Ushbu buyruq taxallus `xbps-install`.
> Ko'proq malumot: <https://docs.voidlinux.org/xbps/index.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xbps-install`
