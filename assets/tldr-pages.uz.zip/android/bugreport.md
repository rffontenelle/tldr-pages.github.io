# bugreport

> Android xatolik xisobotini ko'rsatish.
> Bu buyruq faqat `adb shell` orqali amalga oshiriladi.
> Ko'proq malumot: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Android qurulmasida to'liq xatoliklar xabarini ko'rsatish:

`bugreport`
