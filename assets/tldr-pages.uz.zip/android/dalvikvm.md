# dalvikvm

> Android Java virtual mashinasi.
> Ko'proq malumot: <https://source.android.com/devices/tech/dalvik>.

- Java dasturini ishga tushirish:

`dalvikvm -classpath {{fayl/uchun/yo_l.jar}} {{klassnomi}}`
