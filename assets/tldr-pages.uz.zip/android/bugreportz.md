# bugreportz

> Arxivlangan Android xatolik xisoboti.
> Bu buyruq faqat `adb shell` orqali amalga oshiriladi.
> Ko'proq malumot: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>.

- Android qurulmasida to'liq arxivlangan xatoliklar xisobotini yaratish:

`bugreportz`

- Bajarilayotgan `bugreportz` jarayonni progresini ko'rsatish:

`bugreportz -p`

- Yordam ko'rsatish:

`bugreportz -h`

- Ni versiyasini ko'rsatish `bugreportz`:

`bugreportz -v`
