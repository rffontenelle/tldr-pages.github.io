# cmd

> Android xizmatlar boshqaruvchisi.
> Ko'proq malumot: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- Barcha bajarilayotgan xizmatlarni ko'rsatish:

`cmd -l`

- Biron xizmatni chaqirish:

`cmd {{alarm}}`

- Xizmatni argumentlar bilan ishlatish:

`cmd {{vibrator}} {{vibrate 300}}`
