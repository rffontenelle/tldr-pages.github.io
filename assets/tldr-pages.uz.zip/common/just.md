# just

> Ushbu buyruq taxallus `just.1`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr just.1`
