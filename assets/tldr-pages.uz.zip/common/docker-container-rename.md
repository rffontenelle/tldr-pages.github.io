# docker-container-rename

> Ushbu buyruq taxallus `docker rename`.
> Ko'proq malumot: <https://docs.docker.com/engine/reference/commandline/rename>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr docker rename`
