# cron

> Ushbu buyruq taxallus `crontab`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr crontab`
