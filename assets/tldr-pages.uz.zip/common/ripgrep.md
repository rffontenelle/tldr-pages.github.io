# ripgrep

> Ushbu buyruq taxallus `rg`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr rg`
