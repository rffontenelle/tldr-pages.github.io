# unlzma

> Ushbu buyruq taxallus `xz`.
> Ko'proq malumot: <https://manned.org/unlzma>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xz`
