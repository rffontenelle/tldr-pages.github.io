# kafkacat

> Ushbu buyruq taxallus `kcat`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr kcat`
