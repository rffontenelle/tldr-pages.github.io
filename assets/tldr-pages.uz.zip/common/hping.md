# hping

> Ushbu buyruq taxallus `hping3`.
> Ko'proq malumot: <https://github.com/antirez/hping>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr hping3`
