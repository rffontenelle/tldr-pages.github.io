# clamav

> Ushbu buyruq taxallus `clamdscan`.
> Ko'proq malumot: <https://www.clamav.net>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr clamdscan`
