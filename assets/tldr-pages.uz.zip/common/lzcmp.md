# lzcmp

> Ushbu buyruq taxallus `xzcmp`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xzcmp`
