# lima

> Ushbu buyruq taxallus `limactl`.
> Ko'proq malumot: <https://github.com/lima-vm/lima>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr limactl`
