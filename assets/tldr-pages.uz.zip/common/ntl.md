# ntl

> Ushbu buyruq taxallus `netlify`.
> Ko'proq malumot: <https://cli.netlify.com>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr netlify`
