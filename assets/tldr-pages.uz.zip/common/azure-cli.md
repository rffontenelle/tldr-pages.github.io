# azure-cli

> Ushbu buyruq taxallus `az`.
> Ko'proq malumot: <https://learn.microsoft.com/cli/azure>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr az`
