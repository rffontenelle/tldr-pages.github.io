# linode-cli

> Ushbu buyruq taxallus `linode-cli account`.
> Ko'proq malumot: <https://www.linode.com/docs/products/tools/cli/get-started/>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr linode-cli account`
