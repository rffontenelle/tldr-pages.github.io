# llvm-objdump

> Ushbu buyruq taxallus `objdump`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr objdump`
