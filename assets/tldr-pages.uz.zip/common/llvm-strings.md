# llvm-strings

> Ushbu buyruq taxallus `strings`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr strings`
