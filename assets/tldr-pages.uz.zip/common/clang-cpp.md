# clang-cpp

> Ushbu buyruq taxallus `clang++`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr clang++`
