# todoman

> Ushbu buyruq taxallus `todo`.
> Ko'proq malumot: <https://todoman.readthedocs.io/>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr todo`
