# tldrl

> Ushbu buyruq taxallus `tldr-lint`.
> Ko'proq malumot: <https://github.com/tldr-pages/tldr-lint>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr tldr-lint`
