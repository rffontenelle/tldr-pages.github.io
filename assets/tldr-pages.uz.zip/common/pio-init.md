# pio-init

> Ushbu buyruq taxallus `pio project`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr pio project`
