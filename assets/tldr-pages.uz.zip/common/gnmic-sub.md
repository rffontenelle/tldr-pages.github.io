# gnmic-sub

> Ushbu buyruq taxallus `gnmic subscribe`.
> Ko'proq malumot: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr gnmic subscribe`
