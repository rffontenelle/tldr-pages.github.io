# vi

> Ushbu buyruq taxallus `vim`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr vim`
