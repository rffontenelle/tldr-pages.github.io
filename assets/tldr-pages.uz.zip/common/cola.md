# cola

> Ushbu buyruq taxallus `git-cola`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr git-cola`
