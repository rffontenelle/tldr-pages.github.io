# docker-container-top

> Ushbu buyruq taxallus `docker top`.
> Ko'proq malumot: <https://docs.docker.com/engine/reference/commandline/top>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr docker top`
