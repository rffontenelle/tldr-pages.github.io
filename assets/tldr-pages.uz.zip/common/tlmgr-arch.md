# tlmgr-arch

> Ushbu buyruq taxallus `tlmgr platform`.
> Ko'proq malumot: <https://www.tug.org/texlive/tlmgr.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr tlmgr platform`
