# hx

> Ushbu buyruq taxallus `helix`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr helix`
