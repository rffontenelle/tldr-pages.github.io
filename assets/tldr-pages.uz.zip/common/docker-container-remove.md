# docker-container-remove

> Ushbu buyruq taxallus `docker rm`.
> Ko'proq malumot: <https://docs.docker.com/engine/reference/commandline/rm>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr docker rm`
