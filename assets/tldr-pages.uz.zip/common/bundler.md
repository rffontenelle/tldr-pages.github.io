# bundler

> Ushbu buyruq taxallus `bundle`.
> Ko'proq malumot: <https://bundler.io/man/bundle.1.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr bundle`
