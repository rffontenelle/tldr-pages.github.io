# piodebuggdb

> Ushbu buyruq taxallus `pio debug`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr pio debug`
