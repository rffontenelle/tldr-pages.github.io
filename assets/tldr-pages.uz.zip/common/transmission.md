# transmission

> Ushbu buyruq taxallus `transmission-daemon`.
> Ko'proq malumot: <https://transmissionbt.com/>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr transmission-daemon`
