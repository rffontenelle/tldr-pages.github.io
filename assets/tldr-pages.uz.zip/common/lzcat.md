# lzcat

> Ushbu buyruq taxallus `xz`.
> Ko'proq malumot: <https://manned.org/lzcat>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xz`
