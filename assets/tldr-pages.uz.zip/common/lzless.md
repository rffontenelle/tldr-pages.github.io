# lzless

> Ushbu buyruq taxallus `xzless`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xzless`
