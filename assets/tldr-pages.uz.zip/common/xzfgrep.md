# xzfgrep

> Ushbu buyruq taxallus `xzgrep`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xzgrep`
