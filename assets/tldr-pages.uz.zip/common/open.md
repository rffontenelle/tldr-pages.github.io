# open

> Ushbu buyruq taxallus `open -p osx`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr open -p osx`
