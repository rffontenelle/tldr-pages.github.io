# rcat

> Ushbu buyruq taxallus `rc`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr rc`
