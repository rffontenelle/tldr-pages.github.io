# fossil-new

> Ushbu buyruq taxallus `fossil-init`.
> Ko'proq malumot: <https://fossil-scm.org/home/help/new>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr fossil-init`
