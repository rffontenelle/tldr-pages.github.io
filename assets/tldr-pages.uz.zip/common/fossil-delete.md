# fossil-delete

> Ushbu buyruq taxallus `fossil rm`.
> Ko'proq malumot: <https://fossil-scm.org/home/help/delete>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr fossil rm`
