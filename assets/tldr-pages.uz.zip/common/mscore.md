# mscore

> Ushbu buyruq taxallus `musescore`.
> Ko'proq malumot: <https://musescore.org/handbook/command-line-options>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr musescore`
