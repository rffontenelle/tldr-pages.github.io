# google-chrome

> Ushbu buyruq taxallus `chromium`.
> Ko'proq malumot: <https://chrome.google.com>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr chromium`
