# netcat

> Ushbu buyruq taxallus `nc`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr nc`
