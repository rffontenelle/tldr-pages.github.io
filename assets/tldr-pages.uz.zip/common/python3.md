# python3

> Ushbu buyruq taxallus `python`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr python`
