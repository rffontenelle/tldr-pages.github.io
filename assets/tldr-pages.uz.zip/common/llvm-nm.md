# llvm-nm

> Ushbu buyruq taxallus `nm`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr nm`
