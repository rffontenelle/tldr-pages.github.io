# gh-cs

> Ushbu buyruq taxallus `gh-codespace`.
> Ko'proq malumot: <https://cli.github.com/manual/gh_codespace>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr gh-codespace`
