# llvm-ar

> Ushbu buyruq taxallus `ar`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr ar`
