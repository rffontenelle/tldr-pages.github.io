# clojure

> Ushbu buyruq taxallus `clj`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr clj`
