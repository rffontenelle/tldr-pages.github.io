# platformio

> Ushbu buyruq taxallus `pio`.
> Ko'proq malumot: <https://docs.platformio.org/en/latest/core/userguide/>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr pio`
