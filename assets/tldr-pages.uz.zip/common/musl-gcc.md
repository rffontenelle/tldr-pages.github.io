# musl-gcc

> Ushbu buyruq taxallus `gcc`.
> Ko'proq malumot: <https://manned.org/musl-gcc>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr gcc`
