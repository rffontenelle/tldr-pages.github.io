# hd

> Ushbu buyruq taxallus `hexdump`.
> Ko'proq malumot: <https://manned.org/hd.1>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr hexdump`
