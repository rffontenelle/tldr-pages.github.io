# ptpython3

> Ushbu buyruq taxallus `ptpython`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr ptpython`
