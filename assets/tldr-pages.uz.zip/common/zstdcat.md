# zstdcat

> Ushbu buyruq taxallus `zstd`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr zstd`
