# docker-container-diff

> Ushbu buyruq taxallus `docker diff`.
> Ko'proq malumot: <https://docs.docker.com/engine/reference/commandline/diff>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr docker diff`
