# unxz

> Ushbu buyruq taxallus `xz`.
> Ko'proq malumot: <https://manned.org/unxz>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xz`
