# pwsh

> Ushbu buyruq taxallus `powershell`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr powershell`
