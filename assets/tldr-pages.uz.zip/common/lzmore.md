# lzmore

> Ushbu buyruq taxallus `xzmore`.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xzmore`
