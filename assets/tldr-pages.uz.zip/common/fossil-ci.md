# fossil-ci

> Ushbu buyruq taxallus `fossil-commit`.
> Ko'proq malumot: <https://fossil-scm.org/home/help/commit>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr fossil-commit`
