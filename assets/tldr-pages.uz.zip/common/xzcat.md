# xzcat

> Ushbu buyruq taxallus `xz`.
> Ko'proq malumot: <https://manned.org/xzcat>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr xz`
