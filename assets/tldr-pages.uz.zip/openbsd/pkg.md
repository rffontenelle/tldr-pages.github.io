# pkg

> Ushbu buyruq taxallus `pkg_add`.
> Ko'proq malumot: <https://www.openbsd.org/faq/faq15.html>.

- Asl buyruq uchun hujjatlarni ko'rish:

`tldr pkg_add`
